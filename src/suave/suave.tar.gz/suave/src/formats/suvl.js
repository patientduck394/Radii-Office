/* SUVL: Suave Values, Suave's own data format. Friendly like YAML, exact like JSON, and typed like TOML.

     # comments start with # (or //)
     name: "Ada Lovelace"          key: value   (a = also works, and commas are optional)
     tags: [math, poetry, 3.5]     bare words are text; numbers, true, false and none are typed
     point: {x: 1, y: 2}
     server {                      a block: key { ... } is key: { ... }
       host: localhost
       timeout: 90s                durations become seconds: ms s m h d w
       cache: 64mb                 sizes become bytes: b kb mb gb tb
       ratio: 50%                  percentages become fractions (0.5)
     }
     born: 1815-12-10              dates and date-times become dates
     accent: #ff8800               hex colors stay text
     bio: """
       Several lines, dedented.
     """
*/
import rt from '../runtime.js';

const { SMap, SObj, SVariant, Sym, SSet, SRange, rtError, show } = rt;

function serr(msg, text, pos) {
    let line = 1, col = 1;
    for (let i = 0; i < pos && i < text.length; i++) { if (text[i] === '\n') { line++; col = 1; } else col++; }
    const lines = text.split('\n');
    const src = lines[line - 1] !== undefined ? '\n  ' + lines[line - 1].slice(0, 100) + '\n  ' + ' '.repeat(Math.min(col - 1, 100)) + '^' : '';
    return rtError('SUVL error at line ' + line + ', column ' + col + ': ' + msg + src, 'ParseError');
}
const DUR = { ms: 0.001, s: 1, m: 60, h: 3600, d: 86400, w: 604800 };
const SIZE = { b: 1, kb: 1024, mb: 1048576, gb: 1073741824, tb: 1099511627776 };
const WORD_END = /[\s,\]}\[{#"']/;

// opts: raw (do not turn 90s, 64mb and 50% into numbers)
export function parse(text, opts) {
    opts = opts || {};
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    let i = 0;
    const n = text.length;
    const fail = (m, p) => { throw serr(m, text, p === undefined ? i : p); };
    // skip spaces and comments; returns true if a newline was crossed
    function ws(stopAtNewline) {
        let nl = false;
        for (;;) {
            const c = text[i];
            if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
            if (c === '\n') { if (stopAtNewline) return nl; nl = true; i++; continue; }
            if (c === '/' && text[i + 1] === '/') { while (i < n && text[i] !== '\n') i++; continue; }
            if (c === '#' && !isColor(i)) { while (i < n && text[i] !== '\n') i++; continue; }
            break;
        }
        return nl;
    }
    function isColor(p) { const m = /^#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3,4})(?![\w])/.exec(text.slice(p, p + 10)); return !!m; }
    function sep() { // after an entry: a comma or a newline or a closing bracket must follow
        let sawNl = false;
        for (;;) {
            const nl = ws(false);
            sawNl = sawNl || nl;
            if (text[i] === ',') { i++; sawNl = true; continue; }
            break;
        }
        return sawNl;
    }
    function key() {
        const c = text[i];
        if (c === '"' || c === "'") return quoted(c);
        const m = /^[A-Za-z_][\w.\-]*|^\d[\w.\-]*/.exec(text.slice(i, i + 200));
        if (!m) fail('A key was expected here but found ' + JSON.stringify(c));
        i += m[0].length;
        return m[0];
    }
    function entries(close) {
        const out = new SMap();
        for (;;) {
            ws(false);
            if (close ? text[i] === close : i >= n) break;
            if (i >= n) fail('A { was never closed');
            const kpos = i;
            const k = key();
            ws(true);
            let v;
            if (text[i] === ':' || text[i] === '=') { i++; ws(true); v = value(true); }
            else if (text[i] === '{') v = braceMap();
            else if (text[i] === '[') v = list();
            else fail('A : or = or { was expected after the key "' + k + '"');
            if (out.has(k)) fail('The key "' + k + '" appears twice', kpos);
            out.set(k, v);
            const before = i;
            const sawSep = sep();
            if (!sawSep && !(close ? text[i] === close : i >= n)) fail('Put a comma or a new line between entries', before);
        }
        return out;
    }
    function braceMap() { i++; const m = entries('}'); i++; return m; }
    function list() {
        i++;
        const out = [];
        for (;;) {
            ws(false);
            if (text[i] === ']') { i++; return out; }
            if (i >= n) fail('A [ was never closed');
            out.push(value(false));
            const before = i;
            const sawSep = sep();
            if (!sawSep && text[i] !== ']') fail('Put a comma or a new line between list items', before);
        }
    }
    function quoted(q) {
        const start = i;
        if (q === '"' && text.startsWith('"""', i)) {
            const e = text.indexOf('"""', i + 3);
            if (e < 0) fail('This """ string never ends', start);
            let body = text.slice(i + 3, e);
            i = e + 3;
            const lines = body.split('\n');
            if (lines.length && /^[ \t]*$/.test(lines[0])) lines.shift();
            if (lines.length && /^[ \t]*$/.test(lines[lines.length - 1])) lines.pop();
            let min = Infinity;
            for (const l of lines) { if (!l.trim()) continue; const m = /^[ \t]*/.exec(l)[0].length; if (m < min) min = m; }
            if (min === Infinity) min = 0;
            return lines.map((l) => l.slice(min)).join('\n');
        }
        i++;
        let out = '';
        for (;;) {
            if (i >= n) fail('This string never ends', start);
            const c = text[i];
            if (c === q) { i++; return out; }
            if (c === '\n') fail('A string must end on its line (use """ for several lines)', start);
            if (c === '\\' && q === '"') {
                const d = text[i + 1];
                i += 2;
                switch (d) {
                    case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break; case '0': out += '\0'; break;
                    case '"': out += '"'; break; case '\\': out += '\\'; break; case "'": out += "'"; break;
                    case 'u': { if (text[i] === '{') { const e = text.indexOf('}', i); out += String.fromCodePoint(parseInt(text.slice(i + 1, e), 16)); i = e + 1; } else { out += String.fromCharCode(parseInt(text.substr(i, 4), 16)); i += 4; } break; }
                    default: fail('\\' + d + ' is not a valid escape', i - 2);
                }
                continue;
            }
            out += c; i++;
        }
    }
    function value(allowBlock) {
        ws(true);
        const c = text[i];
        if (c === undefined) fail('A value was expected but the text ended');
        if (c === '"' || c === "'") return quoted(c);
        if (c === '[') return list();
        if (c === '{') return braceMap();
        if (c === '\n') fail('A value was expected after the colon');
        if (c === '#' && isColor(i)) { const m = /^#[0-9a-fA-F]+/.exec(text.slice(i)); i += m[0].length; return m[0]; }
        if (c === ',' || c === ']' || c === '}') fail('A value was expected here');
        // a bare word: read to the end of the token
        const s = i;
        while (i < n && !WORD_END.test(text[i])) i++;
        const w = text.slice(s, i);
        if (w === '') fail('I did not expect ' + JSON.stringify(c) + ' here');
        return typed(w, s);
    }
    function typed(w, pos) {
        if (w === 'true') return true;
        if (w === 'false') return false;
        if (w === 'none' || w === 'null') return null;
        if (w === 'inf' || w === '+inf') return Infinity;
        if (w === '-inf') return -Infinity;
        if (w === 'nan') return NaN;
        if (/^[-+]?(0x[0-9a-fA-F_]+|0b[01_]+|0o[0-7_]+)$/.test(w)) { const neg = w[0] === '-'; const b = w.replace(/^[-+]/, '').replace(/_/g, ''); const v = Number(b); return neg ? -v : v; }
        if (/^[-+]?\d[\d_]*(\.\d[\d_]*)?([eE][-+]?\d+)?$/.test(w)) {
            const clean = w.replace(/_/g, '');
            if (/\d_$|__/.test(w)) fail('An underscore in a number must sit between digits', pos);
            if (!/[.eE]/.test(clean)) { const v = Number(clean); return Number.isSafeInteger(v) ? v : BigInt(clean); }
            return Number(clean);
        }
        if (/^\d{4}-\d\d-\d\d([Tt]\d\d:\d\d(:\d\d(\.\d+)?)?([Zz]|[-+]\d\d:\d\d)?)?$/.test(w)) {
            const d = new Date(/[Tt]/.test(w) && !/([Zz]|[-+]\d\d:\d\d)$/.test(w) ? w + 'Z' : w);
            if (Number.isNaN(d.getTime())) fail('This is not a real date: ' + w, pos);
            return d;
        }
        if (!opts.raw) {
            let m = /^(\d+(?:\.\d+)?)(ms|s|m|h|d|w)$/.exec(w);
            if (m) return Number(m[1]) * DUR[m[2]];
            m = /^(\d+(?:\.\d+)?)(b|kb|mb|gb|tb)$/i.exec(w);
            if (m) return Math.round(Number(m[1]) * SIZE[m[2].toLowerCase()]);
            m = /^(\d+(?:\.\d+)?)%$/.exec(w);
            if (m) return Number(m[1]) / 100;
        }
        return w;
    }
    ws(false);
    if (i >= n) return new SMap();
    // a whole document that is a list, a brace map, or a single value
    if (text[i] === '[') { const v = list(); ws(false); if (i < n) fail('Extra text after the list'); return v; }
    if (text[i] === '{') {
        const save = i;
        const v = braceMap();
        ws(false);
        if (i >= n) return v;
        i = save;
    }
    // a lone value (no key)?
    {
        const save = i;
        let isEntry = false;
        try {
            if (text[i] === '"' || text[i] === "'" || /[A-Za-z_\d]/.test(text[i])) { const k = key(); ws(true); isEntry = text[i] === ':' || text[i] === '=' || text[i] === '{' || text[i] === '['; void k; }
        } catch (e) { isEntry = false; }
        i = save;
        if (!isEntry) { const v = value(false); ws(false); if (i < n) fail('Extra text after the value'); return v; }
    }
    return entries(null);
}

// ---------- writing ----------
const RESERVED = /^(true|false|none|null|inf|nan)$/;
function bareOk(s) {
    if (!/^[A-Za-z_][\w.\/@+-]*$/.test(s) || RESERVED.test(s)) return false;
    if (/^(\d+(\.\d+)?)(ms|s|m|h|d|w|b|kb|mb|gb|tb)$/i.test(s)) return false;
    return true;
}
function quote(s) {
    return '"' + s.replace(/[\\"\u0000-\u001f\u007f]/g, (c) => ({ '\\': '\\\\', '"': '\\"', '\n': '\\n', '\r': '\\r', '\t': '\\t', '\0': '\\0' }[c] || '\\u{' + c.charCodeAt(0).toString(16) + '}')) + '"';
}
function keyText(k) { const s = typeof k === 'string' ? k : show(k); return /^[A-Za-z_][\w.\-]*$/.test(s) ? s : quote(s); }
function dateText(d) { const iso = d.toISOString(); return iso.endsWith('T00:00:00.000Z') ? iso.slice(0, 10) : iso.replace('.000Z', 'Z'); }
function scalar(x) {
    if (x === null || x === undefined) return 'none';
    switch (typeof x) {
        case 'boolean': return x ? 'true' : 'false';
        case 'number': return Number.isNaN(x) ? 'nan' : x === Infinity ? 'inf' : x === -Infinity ? '-inf' : String(x);
        case 'bigint': return x.toString();
        case 'string': return x.includes('\n') && !/[\u0000-\u0008\u000b-\u001f]/.test(x) ? null : (bareOk(x) ? x : quote(x));
    }
    if (x instanceof Date) return dateText(x);
    if (x instanceof Sym) return bareOk(x.name) ? x.name : quote(x.name);
    return undefined;
}
// opts: indent (default 2), sort_keys
export function stringify(v, opts) {
    opts = opts || {};
    const step = ' '.repeat(Math.max(1, Math.min(8, opts.indent || 2)));
    const seen = new Set();
    const isMap = (x) => x instanceof SMap || x instanceof SObj || (x instanceof SVariant && x.vals.length);
    const entriesOf = (x) => {
        let e;
        if (x instanceof SMap) e = x.entries().map(([k, val]) => [k, val]);
        else if (x instanceof SObj) e = Object.keys(x.f).map((k) => [k, x.f[k]]);
        else e = [['variant', x.v.name], ['values', x.vals]];
        if (opts.sort_keys) e.sort((a, b) => (show(a[0]) < show(b[0]) ? -1 : 1));
        return e;
    };
    const itemsOf = (x) => (x instanceof SSet ? x.values() : x instanceof SRange ? x.toArray() : x);
    const isList = (x) => Array.isArray(x) || x instanceof SSet || x instanceof SRange;
    function multiline(s, ind) { return '"""\n' + s.replace(/"""/g, '\\u{22}""').split('\n').map((l) => (l ? ind + l : l)).join('\n') + '\n' + ind + '"""'; }
    function inlineValue(x) {
        const s = scalar(x);
        if (s !== undefined && s !== null) return s;
        if (isList(x)) return '[' + itemsOf(x).map(inlineValue).join(', ') + ']';
        if (isMap(x)) { const es = entriesOf(x); return '{' + es.map(([k, val]) => keyText(k) + ': ' + inlineValue(val)).join(', ') + '}'; }
        if (typeof x === 'string') return quote(x);
        throw rtError('A ' + rt.typeOf(x) + ' cannot be written as SUVL', 'TypeError');
    }
    function simple(x) { return !(isMap(x) || isList(x)) || ((isList(x) && itemsOf(x).every((y) => !isMap(y) && !isList(y)))); }
    function writeValue(x, ind) {   // text after "key: " (may span lines)
        if (seen.has(x)) throw rtError('This value contains itself, so it cannot be written as SUVL', 'TypeError');
        const s = scalar(x);
        if (s === null) return multiline(x, ind + step);
        if (s !== undefined) return s;
        if (isMap(x)) return blockMap(x, ind);
        seen.add(x);
        try {
            if (isList(x)) {
                const items = itemsOf(x);
                if (!items.length) return '[]';
                const inline = '[' + items.map((y) => (scalar(y) === null ? quote(y) : writeValue(y, ind))).join(', ') + ']';
                if (items.every((y) => !isMap(y) && !isList(y)) && inline.length + ind.length < 76) return inline;
                return '[\n' + items.map((y) => ind + step + (isMap(y) ? blockMap(y, ind + step) : writeValue(y, ind + step))).join('\n') + '\n' + ind + ']';
            }
            throw rtError('A ' + rt.typeOf(x) + ' cannot be written as SUVL', 'TypeError');
        } finally { seen.delete(x); }
    }
    function blockMap(x, ind) {
        if (seen.has(x)) throw rtError('This value contains itself, so it cannot be written as SUVL', 'TypeError');
        seen.add(x);
        try {
            const es = entriesOf(x);
            if (!es.length) return '{}';
            return '{\n' + es.map(([k, val]) => ind + step + keyText(k) + (isMap(val) && entriesOf(val).length ? ' ' + blockMap(val, ind + step) : ': ' + writeValue(val, ind + step))).join('\n') + '\n' + ind + '}';
        } finally { seen.delete(x); }
    }
    if (isMap(v)) {
        const es = entriesOf(v);
        if (!es.length) return '{}\n';
        seen.add(v);
        const lines = es.map(([k, val]) => keyText(k) + (isMap(val) && entriesOf(val).length ? ' ' + blockMap(val, '') : ': ' + writeValue(val, '')));
        return lines.join('\n') + '\n';
    }
    return writeValue(v, '') + '\n';
}
