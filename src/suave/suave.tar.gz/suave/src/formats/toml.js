/* TOML 1.0 for Suave: tables, arrays of tables, dotted keys, inline tables, all string kinds, numbers, and date-times.
   Date-times (offset or local, and plain dates) become dates; a local time stays text like "07:32:00". */
import rt from '../runtime.js';

const { SMap, SObj, SVariant, Sym, SSet, rtError, show } = rt;

function terr(msg, text, pos) {
    let line = 1, col = 1;
    for (let i = 0; i < pos && i < text.length; i++) { if (text[i] === '\n') { line++; col = 1; } else col++; }
    return rtError('TOML error at line ' + line + ', column ' + col + ': ' + msg, 'ParseError');
}

export function parse(text) {
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    let i = 0;
    const n = text.length;
    const root = new SMap();
    let cur = root;
    const defined = new Set();       // table headers written explicitly
    const arrayTables = new WeakSet();
    const implicit = new WeakSet();   // tables created only as a path to another table
    const dottedTables = new WeakSet();   // tables created by dotted keys

    const fail = (m, p) => { throw terr(m, text, p === undefined ? i : p); };
    function skipWs() { while (i < n && (text[i] === ' ' || text[i] === '\t')) i++; }
    function skipLine() { skipWs(); if (text[i] === '#') { while (i < n && text[i] !== '\n') { if (text[i] < ' ' && text[i] !== '\t' && text[i] !== '\r') fail('A control character cannot be in a comment'); i++; } } }
    function endLine() { skipLine(); if (i < n && text[i] === '\r' && text[i + 1] === '\n') i++; if (i < n && text[i] !== '\n') fail('Expected the end of the line but found ' + JSON.stringify(text[i])); if (i < n) i++; }
    function skipWsNl() { for (;;) { skipWs(); if (text[i] === '#') { skipLine(); continue; } if (text[i] === '\n' || (text[i] === '\r' && text[i + 1] === '\n')) { i += text[i] === '\r' ? 2 : 1; continue; } break; } }

    function bareKey() {
        const s = i;
        while (i < n && /[A-Za-z0-9_-]/.test(text[i])) i++;
        if (i === s) fail('A key was expected here');
        return text.slice(s, i);
    }
    function keyPart() {
        skipWs();
        if (text[i] === '"') return basicString(false);
        if (text[i] === "'") return literalString(false);
        return bareKey();
    }
    function dottedKey() {
        const parts = [keyPart()];
        for (;;) { skipWs(); if (text[i] === '.') { i++; parts.push(keyPart()); } else break; }
        return parts;
    }
    function basicString(multi) {
        const start = i;
        let out = '';
        if (multi) { i += 3; if (text[i] === '\r' && text[i + 1] === '\n') i += 2; else if (text[i] === '\n') i++; } else i++;
        for (;;) {
            if (i >= n) fail('This string never ends', start);
            const c = text[i];
            if (multi) {
                if (text.startsWith('"""', i)) { i += 3; while (text[i] === '"' && out.length >= 0 && text[i - 1] === '"' && text.startsWith('"', i) && false) i++; if (text[i] === '"') { out += '"'; i++; if (text[i] === '"') { out += '"'; i++; } } return out; }
            } else {
                if (c === '"') { i++; return out; }
                if (c === '\n') fail('A string must close on the same line (use """ for several lines)', i);
            }
            if (c === '\\') {
                const d = text[i + 1];
                i += 2;
                switch (d) {
                    case 'b': out += '\b'; break; case 't': out += '\t'; break; case 'n': out += '\n'; break; case 'f': out += '\f'; break; case 'r': out += '\r'; break;
                    case 'e': out += '\x1b'; break; case '"': out += '"'; break; case '\\': out += '\\'; break;
                    case 'u': { const h = text.substr(i, 4); if (!/^[0-9a-fA-F]{4}$/.test(h)) fail('\\u needs 4 hex digits', i - 2); out += String.fromCharCode(parseInt(h, 16)); i += 4; break; }
                    case 'U': { const h = text.substr(i, 8); if (!/^[0-9a-fA-F]{8}$/.test(h)) fail('\\U needs 8 hex digits', i - 2); out += String.fromCodePoint(parseInt(h, 16)); i += 8; break; }
                    case 'x': { const h = text.substr(i, 2); out += String.fromCharCode(parseInt(h, 16)); i += 2; break; }
                    default:
                        if (multi && /[ \t\r\n]/.test(d || '')) { i--; while (i < n && /[ \t\r\n]/.test(text[i])) i++; break; }
                        fail('\\' + d + ' is not a valid escape', i - 2);
                }
                continue;
            }
            out += c; i++;
        }
    }
    function literalString(multi) {
        const start = i;
        if (multi) { i += 3; if (text[i] === '\r' && text[i + 1] === '\n') i += 2; else if (text[i] === '\n') i++; const e = text.indexOf("'''", i); if (e < 0) fail('This string never ends', start); let end = e; while (text[end + 3] === "'" && end - e < 2) end++; const s = text.slice(i, end); i = end + 3; return s; }
        i++;
        const e = text.indexOf("'", i);
        if (e < 0 || text.slice(i, e).includes('\n')) fail('This string never ends', start);
        const s = text.slice(i, e);
        i = e + 1;
        return s;
    }
    const DT = /^(\d{4}-\d\d-\d\d)([Tt ](\d\d:\d\d(:\d\d(\.\d+)?)?)([Zz]|[-+]\d\d:\d\d)?)?/;
    function value() {
        skipWs();
        const c = text[i];
        if (c === '"') return text.startsWith('"""', i) ? basicString(true) : basicString(false);
        if (c === "'") return text.startsWith("'''", i) ? literalString(true) : literalString(false);
        if (c === '[') return array();
        if (c === '{') return inlineTable();
        if (text.startsWith('true', i) && !/[\w-]/.test(text[i + 4] || '')) { i += 4; return true; }
        if (text.startsWith('false', i) && !/[\w-]/.test(text[i + 5] || '')) { i += 5; return false; }
        const rest = text.slice(i, i + 40);
        const dt = DT.exec(rest);
        if (dt && !/^\d{4}$/.test(rest.slice(0, 4)) === false) {
            if (/^\d{4}-\d\d-\d\d/.test(rest)) {
                i += dt[0].length;
                const date = dt[1];
                if (!dt[3]) { const d = new Date(date + 'T00:00:00Z'); if (Number.isNaN(d.getTime())) fail('This is not a real date: ' + date, i); return d; }
                const time = dt[3].length === 5 ? dt[3] + ':00' : dt[3];
                const d = new Date(date + 'T' + time + (dt[6] ? (dt[6] === 'z' ? 'Z' : dt[6]) : 'Z'));
                if (Number.isNaN(d.getTime())) fail('This is not a real date and time', i);
                return d;
            }
        }
        const tm = /^\d\d:\d\d(:\d\d(\.\d+)?)?/.exec(rest);
        if (tm) { i += tm[0].length; return tm[0].length === 5 ? tm[0] + ':00' : tm[0]; }
        const num = /^[-+]?(inf|nan|0x[0-9a-fA-F_]+|0o[0-7_]+|0b[01_]+|\d[\d_]*(\.\d[\d_]*)?([eE][-+]?\d[\d_]*)?)/.exec(rest);
        if (num) {
            const s = num[0];
            if (/\d_$|__|^[-+]?_/.test(s)) fail('An underscore in a number must sit between digits');
            i += s.length;
            if (/^[-+]?inf$/.test(s)) return s[0] === '-' ? -Infinity : Infinity;
            if (/^[-+]?nan$/.test(s)) return NaN;
            const clean = s.replace(/_/g, '');
            if (/^[-+]?0[xob]/i.test(clean) ) { const neg = clean[0] === '-'; const body = clean.replace(/^[-+]/, ''); const v = Number(body); return neg ? -v : v; }
            if (/^[-+]?0\d/.test(clean) && !/[.eE]/.test(clean)) fail('A number cannot start with a leading zero', i - s.length);
            if (/[.eE]/.test(clean)) return Number(clean);
            const v = Number(clean);
            return Number.isSafeInteger(v) ? v : BigInt(clean);
        }
        fail('I could not understand this value: ' + JSON.stringify(rest.split(/[\s,\]}]/)[0] || text[i]));
    }
    function array() {
        i++;
        const out = [];
        for (;;) {
            skipWsNl();
            if (text[i] === ']') { i++; return out; }
            if (i >= n) fail('A [ was never closed');
            out.push(value());
            skipWsNl();
            if (text[i] === ',') { i++; continue; }
            skipWsNl();
            if (text[i] === ']') { i++; return out; }
            fail('A , or ] was expected');
        }
    }
    function inlineTable() {
        i++;
        const t = new SMap();
        skipWs();
        if (text[i] === '}') { i++; return t; }
        for (;;) {
            skipWs();
            const path = dottedKey();
            skipWs();
            if (text[i] !== '=') fail('A = was expected after the key');
            i++;
            const v = value();
            assign(t, path, v, true);
            skipWs();
            if (text[i] === ',') { i++; continue; }
            if (text[i] === '}') { i++; return t; }
            fail('A , or } was expected in the inline table');
        }
    }
    function assign(table, path, v, inline) {
        let t = table;
        for (let k = 0; k < path.length - 1; k++) {
            let nx = t.get(path[k]);
            if (nx === undefined) { nx = new SMap(); dottedTables.add(nx); t.set(path[k], nx); }
            else if (Array.isArray(nx) && arrayTables.has(nx)) nx = nx[nx.length - 1];
            if (!(nx instanceof SMap)) fail('The key "' + path[k] + '" already holds a value, so it cannot also be a table');
            t = nx;
        }
        const last = path[path.length - 1];
        if (t.has(last)) fail('The key "' + path.join('.') + '" is set twice');
        t.set(last, v);
    }
    function enter(path, isArray, startPos) {
        let t = root;
        for (let k = 0; k < path.length; k++) {
            const part = path[k];
            const lastPart = k === path.length - 1;
            let nx = t.get(part);
            if (nx === undefined) {
                if (lastPart && isArray) { const a = []; arrayTables.add(a); const m = new SMap(); a.push(m); t.set(part, a); return m; }
                nx = new SMap();
                if (!lastPart) implicit.add(nx);
                t.set(part, nx);
                if (lastPart) defined.add(nx);
            } else if (Array.isArray(nx) && arrayTables.has(nx)) {
                if (lastPart) {
                    if (!isArray) fail('"' + path.join('.') + '" is an array of tables, so use [[ ]]', startPos);
                    const m = new SMap(); nx.push(m); return m;
                }
                nx = nx[nx.length - 1];
            } else if (nx instanceof SMap) {
                if (lastPart) {
                    if (isArray) fail('"' + path.join('.') + '" is already a table, so it cannot be an array of tables', startPos);
                    if (defined.has(nx) || dottedTables.has(nx) && true) { if (!implicit.has(nx)) fail('The table [' + path.join('.') + '] is written twice', startPos); }
                    implicit.delete(nx); defined.add(nx);
                }
            } else fail('"' + part + '" already holds a value, so it cannot be a table', startPos);
            t = nx;
        }
        return t;
    }
    for (;;) {
        skipWsNl();
        if (i >= n) break;
        if (text[i] === '[') {
            const start = i;
            const isArr = text[i + 1] === '[';
            i += isArr ? 2 : 1;
            const path = dottedKey();
            skipWs();
            if (isArr) { if (!text.startsWith(']]', i)) fail('A ]] was expected to close the table name'); i += 2; }
            else { if (text[i] !== ']') fail('A ] was expected to close the table name'); i++; }
            cur = enter(path, isArr, start);
            endLine();
            continue;
        }
        const path = dottedKey();
        skipWs();
        if (text[i] !== '=') fail('A = was expected after the key');
        i++;
        const v = value();
        assign(cur, path, v);
        endLine();
    }
    return root;
}

// ---------- writing ----------
const BARE = /^[A-Za-z0-9_-]+$/;
const key = (k) => { const s = typeof k === 'string' ? k : show(k); return BARE.test(s) ? s : JSON.stringify(s); };
function str(s) {
    if (s.includes('\n') && !/[\u0000-\u0008\u000b-\u001f\u007f]/.test(s)) return '"""\n' + s.replace(/\\/g, '\\\\').replace(/"""/g, '""\\"') + '"""';
    return '"' + s.replace(/[\\"\u0000-\u001f\u007f]/g, (c) => ({ '\\': '\\\\', '"': '\\"', '\n': '\\n', '\r': '\\r', '\t': '\\t', '\b': '\\b', '\f': '\\f' }[c] || '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'))) + '"';
}
const isTable = (x) => x instanceof SMap || x instanceof SObj;
const entriesOf = (x) => (x instanceof SMap ? x.entries().map(([k, v]) => [k, v]) : Object.keys(x.f).map((k) => [k, x.f[k]]));
function inline(x) {
    if (x === null || x === undefined) throw rtError('TOML has no "none". Leave the key out instead', 'TypeError');
    switch (typeof x) {
        case 'boolean': return x ? 'true' : 'false';
        case 'number': return Number.isNaN(x) ? 'nan' : x === Infinity ? 'inf' : x === -Infinity ? '-inf' : (Number.isInteger(x) ? String(x) : String(x));
        case 'bigint': return x.toString();
        case 'string': return str(x);
    }
    if (x instanceof Date) return x.toISOString().replace('.000Z', 'Z');
    if (x instanceof Sym) return str(x.name);
    if (x instanceof SSet) return '[' + x.values().map(inline).join(', ') + ']';
    if (Array.isArray(x)) return '[' + x.map(inline).join(', ') + ']';
    if (isTable(x)) { const es = entriesOf(x).filter(([, v]) => v !== null && v !== undefined); return es.length ? '{ ' + es.map(([k, v]) => key(k) + ' = ' + inline(v)).join(', ') + ' }' : '{}'; }
    if (x instanceof SVariant) return x.vals.length ? '{ variant = ' + str(x.v.name) + ', values = ' + inline(x.vals) + ' }' : str(x.v.name);
    throw rtError('A ' + rt.typeOf(x) + ' cannot be written as TOML', 'TypeError');
}
export function stringify(v, opts) {
    opts = opts || {};
    if (!isTable(v)) throw rtError('TOML needs a map at the top, not a ' + rt.typeOf(v), 'TypeError');
    const out = [];
    function table(t, path) {
        const es = entriesOf(t).filter(([, val]) => val !== null && val !== undefined);
        if (opts.sort_keys) es.sort((a, b) => (show(a[0]) < show(b[0]) ? -1 : 1));
        const simple = [], tables = [], arrays = [];
        for (const [k, val] of es) {
            if (isTable(val)) tables.push([k, val]);
            else if (Array.isArray(val) && val.length && val.every(isTable)) arrays.push([k, val]);
            else simple.push([k, val]);
        }
        for (const [k, val] of simple) out.push(key(k) + ' = ' + inline(val));
        for (const [k, val] of tables) {
            const p = path.concat([k]);
            if (out.length) out.push('');
            out.push('[' + p.map(key).join('.') + ']');
            table(val, p);
        }
        for (const [k, arr] of arrays) {
            const p = path.concat([k]);
            for (const item of arr) { if (out.length) out.push(''); out.push('[[' + p.map(key).join('.') + ']]'); table(item, p); }
        }
    }
    table(v, []);
    return out.join('\n') + '\n';
}
