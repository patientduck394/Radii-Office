/* YAML for Suave: block and flow collections, quoted/plain/block scalars, anchors and aliases, merge keys, several documents.
   Follows YAML 1.2 core types (true/false, null, numbers). Not covered: complex "? " keys and custom tags. */
import rt from '../runtime.js';

const { SMap, SSet, SObj, SVariant, Sym, SRange, rtError, show } = rt;

function yerr(msg, line) { return rtError('YAML error' + (line ? ' on line ' + line : '') + ': ' + msg, 'ParseError'); }

function resolvePlain(s, opts) {
    if (s === '' || s === '~' || /^(null|Null|NULL)$/.test(s)) return null;
    if (/^(true|True|TRUE)$/.test(s)) return true;
    if (/^(false|False|FALSE)$/.test(s)) return false;
    if (/^[-+]?[0-9]+$/.test(s)) { const n = Number(s); return Number.isSafeInteger(n) ? n : BigInt(s); }
    if (/^0o[0-7]+$/.test(s)) return parseInt(s.slice(2), 8);
    if (/^0x[0-9a-fA-F]+$/.test(s)) return parseInt(s.slice(2), 16);
    if (/^[-+]?(\.[0-9]+|[0-9]+(\.[0-9]*)?)([eE][-+]?[0-9]+)?$/.test(s)) return Number(s);
    if (/^[-+]?\.(inf|Inf|INF)$/.test(s)) return s[0] === '-' ? -Infinity : Infinity;
    if (/^\.(nan|NaN|NAN)$/.test(s)) return NaN;
    if (opts.dates && /^\d{4}-\d\d-\d\d([Tt ]\d\d:\d\d(:\d\d(\.\d+)?)?([Zz]|[-+]\d\d(:?\d\d)?)?)?$/.test(s)) { const d = new Date(s.replace(' ', 'T')); if (!Number.isNaN(d.getTime())) return d; }
    return s;
}
function unescapeDouble(s, line) {
    return s.replace(/\\(?:(x[0-9a-fA-F]{2})|(u[0-9a-fA-F]{4})|(U[0-9a-fA-F]{8})|([\s\S]))/g, (m, x, u, U, c) => {
        if (x) return String.fromCharCode(parseInt(x.slice(1), 16));
        if (u) return String.fromCharCode(parseInt(u.slice(1), 16));
        if (U) return String.fromCodePoint(parseInt(U.slice(1), 16));
        switch (c) {
            case 'n': return '\n'; case 't': return '\t'; case 'r': return '\r'; case '0': return '\0'; case 'e': return '\x1b'; case 'a': return '\x07'; case 'b': return '\b';
            case 'f': return '\f'; case 'v': return '\v'; case '"': return '"'; case '/': return '/'; case '\\': return '\\'; case ' ': return ' '; case 'N': return '\u0085'; case '_': return '\u00a0';
            case '\n': return '';
        }
        throw yerr('\\' + c + ' is not a valid escape', line);
    });
}

// remove a trailing "# comment" that is not inside quotes
function stripComment(s) {
    let q = null;
    for (let i = 0; i < s.length; i++) {
        const c = s[i];
        if (q) { if (q === '"' && c === '\\') i++; else if (c === q) { if (q === "'" && s[i + 1] === "'") i++; else q = null; } continue; }
        if ((c === '"' || c === "'") && (i === 0 || /[\s\[{,:-]/.test(s[i - 1]))) { q = c; continue; }
        if (c === '#' && (i === 0 || /\s/.test(s[i - 1]))) return s.slice(0, i).trimEnd();
    }
    return s.trimEnd();
}

class Reader {
    constructor(lines, startNo, opts) { this.raw = lines; this.i = 0; this.base = startNo; this.opts = opts; this.anchors = new Map(); }
    lineNo(i) { return this.base + i + 1; }
    // the next line that has content: { i, indent, text }
    peek() {
        while (this.i < this.raw.length) {
            const r = this.raw[this.i];
            const t = r.trim();
            if (t === '' || t.startsWith('#')) { this.i++; continue; }
            const indent = r.length - r.trimStart().length;
            if (r.slice(0, indent).includes('\t')) throw yerr('A tab cannot be used to indent. Use spaces', this.lineNo(this.i));
            return { i: this.i, indent, text: stripComment(r.slice(indent)) };
        }
        return null;
    }
    // block (a node whose lines are indented at least minIndent)
    block(minIndent, parentSeq) {
        const l = this.peek();
        if (!l || l.indent < minIndent) return null;
        if (l.text === '-' || l.text.startsWith('- ')) return this.seq(l.indent);
        if (this.isMapLine(l.text)) return this.map(l.indent);
        return this.inlineValue(l.text, l.indent - 1, l.i, true);
    }
    isMapLine(t) { return this.splitKey(t) !== null; }
    // "key: rest" -> [key, rest, wasQuoted]  or null
    splitKey(t) {
        if (t.startsWith('? ')) return null;
        let i = 0, key;
        if (t[0] === '"' || t[0] === "'") {
            const q = t[0];
            i = 1;
            while (i < t.length) { if (q === '"' && t[i] === '\\') { i += 2; continue; } if (t[i] === q) { if (q === "'" && t[i + 1] === "'") { i += 2; continue; } break; } i++; }
            if (i >= t.length) return null;
            const after = t.slice(i + 1);
            if (!/^\s*:(\s|$)/.test(after)) return null;
            key = q === '"' ? unescapeDouble(t.slice(1, i), 0) : t.slice(1, i).replace(/''/g, "'");
            return [key, after.replace(/^\s*:\s?/, ''), true];
        }
        if (t[0] === '[' || t[0] === '{' || t[0] === '|' || t[0] === '>' || t[0] === '&' && false) return null;
        for (i = 0; i < t.length; i++) {
            if (t[i] === ':' && (i + 1 === t.length || t[i + 1] === ' ')) { key = t.slice(0, i).trim(); if (key === '') return null; return [key, t.slice(i + 1).replace(/^\s/, ''), false]; }
        }
        return null;
    }
    seq(indent) {
        const out = [];
        for (;;) {
            const l = this.peek();
            if (!l || l.indent !== indent || !(l.text === '-' || l.text.startsWith('- '))) break;
            const rest = l.text === '-' ? '' : l.text.slice(2);
            if (rest.trim() === '') {
                this.i = l.i + 1;
                const next = this.peek();
                out.push(next && next.indent > indent ? this.block(indent + 1) : null);
            } else {
                // the text after "- " is the start of a nested node that sits at a deeper virtual indent
                const lead = l.text.length - l.text.slice(1).trimStart().length;
                const nested = indent + lead;
                this.raw[l.i] = ' '.repeat(nested) + this.raw[l.i].trimStart().slice(lead);
                out.push(this.block(nested));
            }
        }
        return out;
    }
    map(indent) {
        const out = new SMap();
        const merges = [];
        for (;;) {
            const l = this.peek();
            if (!l || l.indent !== indent) break;
            const kv = this.splitKey(l.text);
            if (!kv) { if (l.indent === indent && !(l.text.startsWith('- '))) throw yerr('I expected "key: value" here but found: ' + l.text.slice(0, 40), this.lineNo(l.i)); break; }
            let [key, rest, quoted] = kv;
            const lineNo = this.lineNo(l.i);
            this.i = l.i + 1;
            let keyVal = quoted ? key : resolvePlain(key, this.opts);
            if (!quoted && typeof keyVal !== 'string') keyVal = typeof keyVal === 'number' || typeof keyVal === 'boolean' || keyVal === null ? keyVal : String(key);
            let val;
            rest = rest.trim();
            if (rest === '' || /^(&\S+|!\S*)(\s+(&\S+|!\S*))*$/.test(rest)) {
                let anchor = null, tag = null;
                for (const w of rest.split(/\s+/).filter(Boolean)) { if (w[0] === '&') anchor = w.slice(1); else tag = w; }
                const next = this.peek();
                if (next && next.indent > indent) val = this.block(indent + 1);
                else if (next && next.indent === indent && (next.text === '-' || next.text.startsWith('- '))) val = this.seq(indent);
                else val = null;
                if (tag === '!!str' && val === null) val = '';
                if (anchor) this.anchors.set(anchor, val);
            } else val = this.inlineValue(rest, indent, l.i, false);
            if (!quoted && key === '<<') { for (const s of (Array.isArray(val) ? val : [val])) if (s instanceof SMap) merges.push(s); continue; }
            if (out.has(keyVal) && !this.opts.allowDuplicates) throw yerr('The key "' + show(keyVal) + '" appears twice', lineNo);
            out.set(keyVal, val);
        }
        // merge keys (<<: *base) fill in only what the map did not say itself
        for (const src of merges) for (const [k, v] of src.entries()) if (!out.has(k)) out.set(k, v);
        return out;
    }
    // a value that starts on the same line as its key (or "- "): anchors, aliases, tags, block scalars, quoted, flow, plain
    inlineValue(text, parentIndent, lineIdx, isBlockStart) {
        let t = text, anchor = null, tag = null;
        const lineNo = this.lineNo(lineIdx);
        // consume the line (callers positioned i at the next line already, except block starts)
        if (isBlockStart) this.i = lineIdx + 1;
        for (;;) {
            const m = /^(&(\S+)|!(\S*))\s*/.exec(t);
            if (!m || t === m[0].trim() && false) break;
            if (m[2]) anchor = m[2]; else tag = '!' + m[3];
            t = t.slice(m[0].length);
        }
        let v;
        if (t[0] === '*') {
            const name = t.slice(1).trim();
            if (!this.anchors.has(name)) throw yerr('The alias *' + name + ' has no anchor (&' + name + ') before it', lineNo);
            return this.anchors.get(name);
        }
        if (t[0] === '|' || t[0] === '>') v = this.blockScalar(t, parentIndent, lineIdx);
        else if (t[0] === '"' || t[0] === "'") v = this.quoted(t, parentIndent, lineIdx);
        else if (t[0] === '[' || t[0] === '{') v = this.flow(t, parentIndent, lineIdx);
        else v = this.plain(t, parentIndent, lineIdx);
        if (tag === '!!str') v = typeof v === 'string' ? v : show(v === null ? '' : v);
        else if (tag === '!!int' || tag === '!!float') v = Number(v);
        else if (tag === '!!binary') v = Uint8Array.from(atob(String(v).replace(/\s+/g, '')), (c) => c.charCodeAt(0));
        else if (tag === '!!set' && v instanceof SMap) v = new SSet(v.keys());
        if (anchor) this.anchors.set(anchor, v);
        return v;
    }
    // continuation lines of a multi-line plain or quoted scalar
    takeContinuation(parentIndent) {
        const parts = [];
        while (this.i < this.raw.length) {
            const r = this.raw[this.i];
            const t = r.trim();
            if (t === '') { parts.push(''); this.i++; continue; }
            const ind = r.length - r.trimStart().length;
            if (ind <= parentIndent) break;
            parts.push(stripComment(t));
            this.i++;
        }
        while (parts.length && parts[parts.length - 1] === '') parts.pop();
        return parts;
    }
    fold(first, more) {
        let out = first;
        let pendingBreaks = 0;
        for (const p of more) {
            if (p === '') { pendingBreaks++; continue; }
            out += pendingBreaks ? '\n'.repeat(pendingBreaks) : ' ';
            pendingBreaks = 0;
            out += p;
        }
        return out;
    }
    plain(t, parentIndent, lineIdx) {
        const more = this.takeContinuation(parentIndent);
        // a plain value whose next lines look like "key: v" is not a continuation (it would have been taken as a block earlier), so just fold
        return resolvePlain(more.length ? this.fold(t, more) : t, this.opts);
    }
    quoted(t, parentIndent, lineIdx) {
        const q = t[0];
        let text = t;
        const closed = (s) => { let i = 1; while (i < s.length) { if (q === '"' && s[i] === '\\') { i += 2; continue; } if (s[i] === q) { if (q === "'" && s[i + 1] === "'") { i += 2; continue; } return i; } i++; } return -1; };
        let end = closed(text);
        const lines = [text];
        while (end < 0) {
            if (this.i >= this.raw.length) throw yerr('A quoted string was never closed', this.lineNo(lineIdx));
            const nxt = this.raw[this.i++].trim();
            lines.push(nxt);
            text = this.foldQuoted(lines);
            end = closed(text);
        }
        text = lines.length > 1 ? this.foldQuoted(lines) : text;
        end = closed(text);
        const body = text.slice(1, end);
        const after = stripComment(text.slice(end + 1)).trim();
        if (after && !this.isFlowContext) throw yerr('Unexpected text after the string: ' + after.slice(0, 30), this.lineNo(lineIdx));
        return q === '"' ? unescapeDouble(body, this.lineNo(lineIdx)) : body.replace(/''/g, "'");
    }
    foldQuoted(lines) {
        let out = lines[0];
        let blanks = 0;
        for (let k = 1; k < lines.length; k++) { if (lines[k] === '') { blanks++; continue; } out += blanks ? '\n'.repeat(blanks) : ' '; blanks = 0; out += lines[k]; }
        return out;
    }
    blockScalar(head, parentIndent, lineIdx) {
        const m = /^([|>])([+-]?)(\d?)([+-]?)\s*$/.exec(head);
        if (!m) throw yerr('A | or > block needs to be alone on its line (found: ' + head.slice(0, 30) + ')', this.lineNo(lineIdx));
        const folded = m[1] === '>';
        const chomp = m[2] || m[4];
        let blockIndent = m[3] ? parentIndent + Number(m[3]) : null;
        const lines = [];
        while (this.i < this.raw.length) {
            const r = this.raw[this.i];
            if (r.trim() === '') { lines.push(''); this.i++; continue; }
            const ind = r.length - r.trimStart().length;
            if (blockIndent === null) { if (ind <= parentIndent) break; blockIndent = ind; }
            if (ind < blockIndent) break;
            lines.push(r.slice(blockIndent));
            this.i++;
        }
        let trailing = 0;
        while (lines.length && lines[lines.length - 1] === '') { lines.pop(); trailing++; }
        let text;
        if (!folded) text = lines.join('\n');
        else {
            text = '';
            for (let k = 0; k < lines.length; k++) {
                const cur = lines[k];
                if (k === 0) { text = cur; continue; }
                const prev = lines[k - 1];
                if (cur === '') { text += '\n'; continue; }
                if (prev === '') { text += cur; continue; }
                if (/^\s/.test(cur) || /^\s/.test(prev)) text += '\n' + cur; else text += ' ' + cur;
            }
        }
        if (chomp === '-') return text;
        if (!lines.length) return chomp === '+' ? '\n'.repeat(trailing) : '';
        return text + (chomp === '+' ? '\n'.repeat(1 + trailing) : '\n');
    }
    // flow collections: [a, b] and {a: 1}; may continue over several lines until the brackets balance
    flow(t, parentIndent, lineIdx) {
        let text = t;
        const balanced = (s) => { let d = 0, q = null; for (let i = 0; i < s.length; i++) { const c = s[i]; if (q) { if (q === '"' && c === '\\') i++; else if (c === q) q = null; continue; } if (c === '"' || c === "'") q = c; else if (c === '[' || c === '{') d++; else if (c === ']' || c === '}') d--; else if (c === '#' && /\s/.test(s[i - 1] || ' ')) { while (i < s.length && s[i] !== '\n') i++; } } return d <= 0; };
        while (!balanced(text)) {
            if (this.i >= this.raw.length) throw yerr('A [ or { was never closed', this.lineNo(lineIdx));
            text += ' ' + stripComment(this.raw[this.i++].trim());
        }
        const self = this;
        let p = 0;
        const lineNo = this.lineNo(lineIdx);
        const ws = () => { while (p < text.length && /\s/.test(text[p])) p++; };
        function node() {
            ws();
            const c = text[p];
            if (c === '[') {
                p++; const out = [];
                for (;;) {
                    ws();
                    if (text[p] === ']') { p++; return out; }
                    if (p >= text.length) throw yerr('A [ was never closed', lineNo);
                    const v = node();
                    ws();
                    // [a: b] is a one-pair map
                    if (text[p] === ':' && (text[p + 1] === ' ' || p + 1 >= text.length)) { p++; const m = new SMap(); m.set(v, node()); out.push(m); } else out.push(v);
                    ws();
                    if (text[p] === ',') p++; else if (text[p] !== ']') throw yerr('Expected , or ] but found "' + (text[p] || 'the end') + '"', lineNo);
                }
            }
            if (c === '{') {
                p++; const out = new SMap();
                for (;;) {
                    ws();
                    if (text[p] === '}') { p++; return out; }
                    if (p >= text.length) throw yerr('A { was never closed', lineNo);
                    const k = node();
                    ws();
                    let v = null;
                    if (text[p] === ':') { p++; ws(); if (text[p] !== ',' && text[p] !== '}') v = node(); }
                    out.set(k, v);
                    ws();
                    if (text[p] === ',') p++; else if (text[p] !== '}') throw yerr('Expected , or } but found "' + (text[p] || 'the end') + '"', lineNo);
                }
            }
            if (c === '"' || c === "'") {
                const q = c; let i = p + 1;
                while (i < text.length) { if (q === '"' && text[i] === '\\') { i += 2; continue; } if (text[i] === q) { if (q === "'" && text[i + 1] === "'") { i += 2; continue; } break; } i++; }
                if (i >= text.length) throw yerr('A quoted string was never closed', lineNo);
                const body = text.slice(p + 1, i);
                p = i + 1;
                return q === '"' ? unescapeDouble(body, lineNo) : body.replace(/''/g, "'");
            }
            if (c === '*') { let i = p + 1; while (i < text.length && !/[\s,\]}]/.test(text[i])) i++; const name = text.slice(p + 1, i); p = i; if (!self.anchors.has(name)) throw yerr('The alias *' + name + ' has no anchor', lineNo); return self.anchors.get(name); }
            let i = p;
            while (i < text.length) {
                const d = text[i];
                if (d === ',' || d === ']' || d === '}') break;
                if (d === ':' && (text[i + 1] === ' ' || i + 1 >= text.length || /[,\]}]/.test(text[i + 1]))) break;
                i++;
            }
            const s = text.slice(p, i).trim();
            p = i;
            return resolvePlain(s, self.opts);
        }
        const v = node();
        ws();
        if (p < text.length) throw yerr('Unexpected text after the list or map: ' + text.slice(p, p + 20), lineNo);
        return v;
    }
}

// opts: all (return a list of every document), dates (turn 2026-01-01 into dates), allowDuplicates
export function parse(text, opts) {
    opts = opts || {};
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    const all = text.split(/\r?\n/);
    const docs = [];
    let cur = [], start = 0, any = false, sawMarker = false;
    for (let i = 0; i < all.length; i++) {
        const l = all[i];
        if (/^---(\s|$)/.test(l)) {
            if (cur.some((x) => x.trim() && !x.trim().startsWith('#') && !x.startsWith('%')) || any) { docs.push({ lines: cur, start }); }
            cur = []; start = i + 1; any = false; sawMarker = true;
            const rest = l.slice(3).trim();
            if (rest && !rest.startsWith('#')) cur.push(rest);
            continue;
        }
        if (/^\.\.\.(\s|$)/.test(l)) { docs.push({ lines: cur, start }); cur = []; start = i + 1; any = false; continue; }
        if (l.startsWith('%') && cur.every((x) => !x.trim())) continue;
        cur.push(l);
    }
    if (cur.some((x) => x.trim() && !x.trim().startsWith('#')) || !docs.length || (sawMarker && !docs.length)) docs.push({ lines: cur, start });
    const results = docs.map((d) => {
        const r = new Reader(d.lines.slice(), d.start, opts);
        const l = r.peek();
        const v = l ? r.block(0) : null;
        const extra = r.peek();
        if (extra) throw yerr('I could not understand this line: ' + extra.text.slice(0, 40), r.lineNo(extra.i));
        return v;
    });
    if (opts.all) return results;
    if (results.length > 1) throw yerr('This text has ' + results.length + ' documents (separated by ---). Use all: true to read them all');
    return results.length ? results[0] : null;
}

// ---------- writing ----------
const RESERVED = /^(true|false|null|yes|no|on|off|y|n|~|)$/i;
function needsQuote(s) {
    if (s === '' || RESERVED.test(s)) return true;
    if (/^[-+]?(\d[\d_]*)(\.\d*)?([eE][-+]?\d+)?$/.test(s) || /^0[xo][0-9a-fA-F]+$/.test(s) || /^[-+]?\.(inf|nan)$/i.test(s)) return true;
    if (/^\d{4}-\d\d-\d\d/.test(s)) return true;
    if (/^[\s]|[\s]$/.test(s)) return true;
    if (/^[-?:,\[\]{}#&*!|>'"%@`]/.test(s) && !/^[-?:][^\s]/.test(s)) return true;
    if (/^[-?:]$/.test(s) || /^[-?:]\s/.test(s)) return true;
    if (/: |\s#|:$/.test(s)) return true;
    if (/[\u0000-\u001f\u007f\u0085\u2028\u2029]/.test(s)) return true;
    return false;
}
function quoteStr(s) { return JSON.stringify(s); }
function keyStr(k) {
    if (typeof k === 'string') return needsQuote(k) || /[\n]/.test(k) ? quoteStr(k) : k;
    return scalarStr(k);
}
function scalarStr(x) {
    if (x === null || x === undefined) return 'null';
    switch (typeof x) {
        case 'boolean': return x ? 'true' : 'false';
        case 'number': return Number.isNaN(x) ? '.nan' : x === Infinity ? '.inf' : x === -Infinity ? '-.inf' : String(x);
        case 'bigint': return x.toString();
        case 'string': return needsQuote(x) ? quoteStr(x) : x;
    }
    if (x instanceof Date) return x.toISOString();
    if (x instanceof Sym) return needsQuote(x.name) ? quoteStr(x.name) : x.name;
    if (x instanceof Uint8Array) return '!!binary ' + btoa(String.fromCharCode(...x));
    return quoteStr(show(x));
}
// opts: indent (default 2), sort_keys
export function stringify(v, opts) {
    opts = opts || {};
    const step = ' '.repeat(Math.max(1, Math.min(8, opts.indent || 2)));
    const seen = new Set();
    const lines = [];
    const kindOf = (x) => {
        if (x instanceof SSet) return 'seq';
        if (x instanceof SRange) return 'seq';
        if (Array.isArray(x)) return 'seq';
        if (x instanceof SMap || x instanceof SObj || (x instanceof SVariant && x.vals.length)) return 'map';
        return 'scalar';
    };
    const entriesOf = (x) => {
        let e;
        if (x instanceof SMap) e = x.entries().map(([k, val]) => [k, val]);
        else if (x instanceof SObj) e = Object.keys(x.f).map((k) => [k, x.f[k]]);
        else e = [['variant', x.v.name], ['values', x.vals]];
        if (opts.sort_keys) e.sort((a, b) => (show(a[0]) < show(b[0]) ? -1 : 1));
        return e;
    };
    const itemsOf = (x) => (x instanceof SSet ? x.values() : x instanceof SRange ? x.toArray() : x);
    function multi(s, ind) {
        const body = s.replace(/\n$/, '').split('\n');
        const head = s.endsWith('\n\n') ? '|+' : s.endsWith('\n') ? '|' : '|-';
        return [head].concat(body.map((l) => (l === '' ? '' : ind + l)));
    }
    function emit(x, ind, out) {
        const k = kindOf(x);
        if (seen.has(x)) throw rtError('This value contains itself, so it cannot be written as YAML', 'TypeError');
        if (k === 'scalar') { out.push(ind + scalarStr(x)); return; }
        seen.add(x);
        try {
            if (k === 'seq') {
                const items = itemsOf(x);
                if (!items.length) { out.push(ind + '[]'); return; }
                for (const it of items) {
                    const ik = kindOf(it);
                    if (ik === 'scalar') {
                        if (typeof it === 'string' && it.includes('\n') && !/[ \t]\n|^\n|^\s/.test(it)) { const m = multi(it, ind + step); out.push(ind + '- ' + m[0]); for (const l of m.slice(1)) out.push(l); }
                        else out.push(ind + '- ' + scalarStr(it));
                    } else if ((it instanceof SMap && it.size === 0) || (Array.isArray(it) && !it.length)) out.push(ind + '- ' + (Array.isArray(it) ? '[]' : '{}'));
                    else { const sub = []; emit(it, ind + step, sub); sub[0] = ind + '- ' + sub[0].slice((ind + step).length); out.push(...sub); }
                }
                return;
            }
            const es = entriesOf(x);
            if (!es.length) { out.push(ind + '{}'); return; }
            for (const [key, val] of es) {
                const ks = keyStr(key), vk = kindOf(val);
                if (vk === 'scalar') {
                    if (typeof val === 'string' && val.includes('\n') && !/[ \t]\n|^\n|^\s/.test(val)) { const m = multi(val, ind + step); out.push(ind + ks + ': ' + m[0]); for (const l of m.slice(1)) out.push(l); }
                    else out.push(ind + ks + ': ' + scalarStr(val));
                } else if ((val instanceof SMap && val.size === 0) || (Array.isArray(val) && !val.length) || (val instanceof SSet && !val.size)) out.push(ind + ks + ': ' + (val instanceof SMap ? '{}' : '[]'));
                else { out.push(ind + ks + ':'); emit(val, ind + step, out); }
            }
        } finally { seen.delete(x); }
    }
    emit(v, '', lines);
    return lines.join('\n') + '\n';
}
