/* CSV and TSV for Suave: quoted fields, new lines inside quotes, headers into maps, and optional type guessing. */
import rt from '../runtime.js';

const { SMap, SObj, rtError, show } = rt;

function guess(s) {
    if (s === '') return null;
    if (/^-?\d+$/.test(s) && s.length < 16) return Number(s);
    if (/^-?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$/.test(s)) return Number(s);
    if (s === 'true' || s === 'TRUE' || s === 'True') return true;
    if (s === 'false' || s === 'FALSE' || s === 'False') return false;
    return s;
}
// opts: sep (default ","), header (default true: rows become maps), infer (guess numbers, true/false, empty = none), comment (a prefix to skip lines), trim
export function parse(text, opts) {
    opts = opts || {};
    const sep = opts.sep === undefined ? ',' : String(opts.sep);
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    const rows = [];
    let row = [], field = '', inQ = false, i = 0, quotedField = false, line = 1;
    const n = text.length;
    const endField = () => { row.push(quotedField || !opts.infer ? (opts.trim && !quotedField ? field.trim() : field) : guess(opts.trim ? field.trim() : field)); field = ''; quotedField = false; };
    const endRow = () => { endField(); if (!(row.length === 1 && row[0] === '' )) rows.push(row); row = []; };
    while (i < n) {
        const c = text[i];
        if (inQ) {
            if (c === '"') { if (text[i + 1] === '"') { field += '"'; i += 2; continue; } inQ = false; i++; continue; }
            if (c === '\n') line++;
            field += c; i++; continue;
        }
        if (c === '"' && field === '' && !quotedField) { inQ = true; quotedField = true; i++; continue; }
        if (text.startsWith(sep, i)) { endField(); i += sep.length; continue; }
        if (c === '\r') { i++; continue; }
        if (c === '\n') { endRow(); line++; i++; continue; }
        if (opts.comment && field === '' && row.length === 0 && text.startsWith(opts.comment, i)) { while (i < n && text[i] !== '\n') i++; continue; }
        field += c; i++;
    }
    if (inQ) throw rtError('CSV error: a quote that opened was never closed (it started before line ' + line + ')', 'ParseError');
    if (field !== '' || row.length) endRow();
    if (opts.header === false) return rows;
    if (!rows.length) return [];
    const head = rows[0].map(String);
    return rows.slice(1).map((r) => {
        const m = new SMap();
        for (let k = 0; k < head.length; k++) m.set(head[k], r[k] === undefined ? null : r[k]);
        return m;
    });
}

function cell(v, sep) {
    if (v === null || v === undefined) return '';
    const s = typeof v === 'string' ? v : show(v);
    return /["\n\r]/.test(s) || s.includes(sep) || /^\s|\s$/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
// rows: a list of lists, or a list of maps (the keys of the first one become the header); opts: sep, header, columns
export function stringify(rows, opts) {
    opts = opts || {};
    const sep = opts.sep === undefined ? ',' : String(opts.sep);
    const eol = opts.crlf ? '\r\n' : '\n';
    if (!Array.isArray(rows)) throw rtError('CSV needs a list of rows', 'TypeError');
    if (!rows.length) return '';
    const out = [];
    if (rows[0] instanceof SMap || rows[0] instanceof SObj) {
        const get = (r, k) => (r instanceof SMap ? r.get(k) : r.f[k]);
        let cols = opts.columns;
        if (!cols) { cols = []; const seen = new Set(); for (const r of rows) for (const k of (r instanceof SMap ? r.keys() : Object.keys(r.f))) if (!seen.has(k)) { seen.add(k); cols.push(k); } }
        if (opts.header !== false) out.push(cols.map((c) => cell(c, sep)).join(sep));
        for (const r of rows) out.push(cols.map((c) => cell(get(r, c), sep)).join(sep));
    } else {
        for (const r of rows) out.push((Array.isArray(r) ? r : [r]).map((c) => cell(c, sep)).join(sep));
    }
    return out.join(eol) + eol;
}
