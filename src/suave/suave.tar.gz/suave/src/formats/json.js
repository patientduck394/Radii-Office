/* JSON for Suave: a parser with exact line and column errors (and an optional lenient mode), and a stringifier with indent and sorted keys. */
import rt from '../runtime.js';

const { SMap, SSet, SObj, SVariant, Sym, SRange, Tuple, rtError, show } = rt;

function perr(msg, text, pos) {
    let line = 1, col = 1;
    for (let i = 0; i < pos && i < text.length; i++) { if (text[i] === '\n') { line++; col = 1; } else col++; }
    const lines = text.split('\n');
    const src = lines[line - 1] !== undefined ? '\n  ' + lines[line - 1].slice(0, 100) + '\n  ' + ' '.repeat(Math.min(col - 1, 100)) + '^' : '';
    return rtError('JSON error at line ' + line + ', column ' + col + ': ' + msg + src, 'ParseError');
}

// opts: lenient (comments, trailing commas, single quotes), bigints (keep huge whole numbers as big integers)
export function parse(text, opts) {
    opts = opts || {};
    const lenient = !!opts.lenient;
    let i = 0;
    const n = text.length;
    if (text.charCodeAt(0) === 0xFEFF) i = 1;
    function ws() {
        for (;;) {
            const c = text[i];
            if (c === ' ' || c === '\t' || c === '\n' || c === '\r') { i++; continue; }
            if (lenient && c === '/' && text[i + 1] === '/') { while (i < n && text[i] !== '\n') i++; continue; }
            if (lenient && c === '/' && text[i + 1] === '*') { const e = text.indexOf('*/', i + 2); if (e < 0) throw perr('This comment never ends', text, i); i = e + 2; continue; }
            if (lenient && c === '#') { while (i < n && text[i] !== '\n') i++; continue; }
            break;
        }
    }
    function value(depth) {
        if (depth > 512) throw perr('This is nested too deeply', text, i);
        ws();
        const c = text[i];
        if (c === '{') return object(depth);
        if (c === '[') return array(depth);
        if (c === '"' || (lenient && c === "'")) return string(c);
        if (c === '-' || (c >= '0' && c <= '9')) return number();
        if (text.startsWith('true', i)) { i += 4; return true; }
        if (text.startsWith('false', i)) { i += 5; return false; }
        if (text.startsWith('null', i)) { i += 4; return null; }
        if (lenient && text.startsWith('none', i)) { i += 4; return null; }
        if (lenient && (text.startsWith('NaN', i))) { i += 3; return NaN; }
        if (lenient && text.startsWith('Infinity', i)) { i += 8; return Infinity; }
        if (i >= n) throw perr('The text ended where a value was expected', text, i);
        throw perr('I did not expect ' + JSON.stringify(c) + ' here', text, i);
    }
    function object(depth) {
        i++;
        const m = new SMap();
        ws();
        if (text[i] === '}') { i++; return m; }
        for (;;) {
            ws();
            let k;
            if (text[i] === '"' || (lenient && text[i] === "'")) k = string(text[i]);
            else if (lenient && /[A-Za-z_$]/.test(text[i] || '')) { const s = i; while (/[\w$-]/.test(text[i] || '')) i++; k = text.slice(s, i); }
            else throw perr('A key in quotes was expected', text, i);
            ws();
            if (text[i] !== ':') throw perr('A : was expected after the key', text, i);
            i++;
            const v = value(depth + 1);
            if (m.has(k) && !lenient) throw perr('The key "' + k + '" appears twice', text, i);
            m.set(k, v);
            ws();
            if (text[i] === ',') { i++; ws(); if (text[i] === '}') { if (!lenient) throw perr('A comma before } is not allowed in JSON', text, i); i++; return m; } continue; }
            if (text[i] === '}') { i++; return m; }
            throw perr('A , or } was expected', text, i);
        }
    }
    function array(depth) {
        i++;
        const a = [];
        ws();
        if (text[i] === ']') { i++; return a; }
        for (;;) {
            a.push(value(depth + 1));
            ws();
            if (text[i] === ',') { i++; ws(); if (text[i] === ']') { if (!lenient) throw perr('A comma before ] is not allowed in JSON', text, i); i++; return a; } continue; }
            if (text[i] === ']') { i++; return a; }
            throw perr('A , or ] was expected', text, i);
        }
    }
    function string(q) {
        const start = i;
        i++;
        let out = '';
        for (;;) {
            if (i >= n) throw perr('This string never ends', text, start);
            const c = text[i];
            if (c === q) { i++; return out; }
            if (c === '\\') {
                const d = text[i + 1];
                i += 2;
                switch (d) {
                    case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break; case 'b': out += '\b'; break; case 'f': out += '\f'; break;
                    case '/': out += '/'; break; case '\\': out += '\\'; break; case '"': out += '"'; break; case "'": out += "'"; break;
                    case 'u': { const h = text.substr(i, 4); if (!/^[0-9a-fA-F]{4}$/.test(h)) throw perr('A \\u needs 4 hex digits', text, i - 2); out += String.fromCharCode(parseInt(h, 16)); i += 4; break; }
                    default: throw perr('\\' + d + ' is not a valid escape', text, i - 2);
                }
                continue;
            }
            if (c < ' ' && c !== '\t' && !lenient) throw perr('A new line or control character must be escaped inside a string', text, i);
            out += c; i++;
        }
    }
    function number() {
        const start = i;
        if (text[i] === '-') i++;
        if (text[i] === '0' && /[0-9]/.test(text[i + 1] || '')) throw perr('A number cannot start with a leading zero', text, i);
        if (lenient && text[i] === '0' && /[xX]/.test(text[i + 1] || '')) { i += 2; while (/[0-9a-fA-F]/.test(text[i] || '')) i++; return Number(text.slice(start, i)); }
        if (!/[0-9]/.test(text[i] || '')) { if (lenient && text.startsWith('Infinity', i)) { i += 8; return text[start] === '-' ? -Infinity : Infinity; } throw perr('A digit was expected', text, i); }
        while (/[0-9]/.test(text[i] || '')) i++;
        let frac = false;
        if (text[i] === '.') { frac = true; i++; if (!/[0-9]/.test(text[i] || '')) throw perr('A digit was expected after the point', text, i); while (/[0-9]/.test(text[i] || '')) i++; }
        if (text[i] === 'e' || text[i] === 'E') { frac = true; i++; if (text[i] === '+' || text[i] === '-') i++; if (!/[0-9]/.test(text[i] || '')) throw perr('A digit was expected in the exponent', text, i); while (/[0-9]/.test(text[i] || '')) i++; }
        const s = text.slice(start, i);
        if (!frac && opts.bigints && s.replace('-', '').length > 15) { const b = BigInt(s); if (b > BigInt(Number.MAX_SAFE_INTEGER) || b < BigInt(Number.MIN_SAFE_INTEGER)) return b; }
        return Number(s);
    }
    const v = value(0);
    ws();
    if (i < n) throw perr('Extra text after the end of the value', text, i);
    return v;
}

// a stream of values, one per line (JSON Lines)
export function parseLines(text, opts) {
    const out = [];
    const lines = text.split(/\r?\n/);
    for (let k = 0; k < lines.length; k++) {
        if (!lines[k].trim()) continue;
        try { out.push(parse(lines[k], opts)); } catch (e) { e.message = 'Line ' + (k + 1) + ': ' + e.message; throw e; }
    }
    return out;
}

function esc(s) {
    return '"' + s.replace(/[\u0000-\u001f"\\\u2028\u2029]/g, (c) => ({ '"': '\\"', '\\': '\\\\', '\n': '\\n', '\r': '\\r', '\t': '\\t', '\b': '\\b', '\f': '\\f' }[c] || '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'))) + '"';
}
// opts: indent (number or text), sort_keys, ascii
export function stringify(v, opts) {
    opts = opts || {};
    let ind = '';
    if (typeof opts.indent === 'number') ind = ' '.repeat(Math.min(10, Math.max(0, opts.indent)));
    else if (typeof opts.indent === 'string') ind = opts.indent.slice(0, 10);
    const sortKeys = !!opts.sort_keys;
    const seen = new Set();
    function enc(x, cur) {
        if (x === null || x === undefined) return 'null';
        switch (typeof x) {
            case 'boolean': return x ? 'true' : 'false';
            case 'number': if (!Number.isFinite(x)) { if (opts.lenient) return Number.isNaN(x) ? 'NaN' : (x > 0 ? 'Infinity' : '-Infinity'); return 'null'; } return String(x);
            case 'bigint': return x.toString();
            case 'string': return opts.ascii ? esc(x).replace(/[\u0080-￿]/g, (c) => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0')) : esc(x);
            case 'function': throw rtError('A function cannot be written as JSON', 'TypeError');
        }
        if (x instanceof rt.SComplex) { const cm = new SMap(); cm.set('re', x.re); cm.set('im', x.im); return enc(cm, cur); }
        if (x instanceof Sym) return esc(x.name);
        if (x instanceof Date) return esc(x.toISOString());
        if (x instanceof Uint8Array) return esc(btoa(String.fromCharCode(...x)));
        if (seen.has(x)) throw rtError('This value contains itself, so it cannot be written as JSON', 'TypeError');
        seen.add(x);
        try {
            const nl = ind ? '\n' + cur + ind : '', end = ind ? '\n' + cur : '';
            let items;
            if (x instanceof SSet) x = x.values();
            if (x instanceof SRange) x = x.toArray();
            if (Array.isArray(x)) {
                if (!x.length) return '[]';
                items = x.map((e) => enc(e, cur + ind));
                return '[' + nl + items.join(',' + (ind ? nl : '')) + end + ']';
            }
            let entries;
            if (x instanceof SMap) entries = x.entries().map(([k, val]) => [typeof k === 'string' ? k : show(k), val]);
            else if (x instanceof SObj) entries = Object.keys(x.f).map((k) => [k, x.f[k]]);
            else if (x instanceof SVariant) { if (!x.vals.length) return esc(x.v.name); entries = [['variant', x.v.name], ['values', x.vals]]; }
            else throw rtError('A ' + rt.typeOf(x) + ' cannot be written as JSON', 'TypeError');
            if (sortKeys) entries.sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
            if (!entries.length) return '{}';
            return '{' + nl + entries.map(([k, val]) => esc(k) + (ind ? ': ' : ':') + enc(val, cur + ind)).join(',' + (ind ? nl : '')) + end + '}';
        } finally { seen.delete(x); }
    }
    return enc(v, '');
}
