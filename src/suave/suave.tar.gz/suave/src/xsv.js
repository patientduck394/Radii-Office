/* Suave web files.
     .sv   a Suave program or module
     .xsv  a web component: <props>, <script>, <template> and <style> in one file (it also acts as a small framework)
     .wsv  a web page or app: the same parts, plus a <head>; Suave turns it into an HTML page (suave build) or mounts it live in the browser

   A component file looks like this:

       <props>
         start = 0
       </props>

       <script>
         count = start
         def inc():
             count += 1
       </script>

       <template>
         <button on:click={inc}>Clicked {count} times</button>
       </template>

       <style>
         button { padding: 8px 14px }
       </style>

   The template is HTML with {expressions}, on:click / @click handlers, bind:value, class:name={cond}, if / else-if / else / for
   attributes, <slot/> and <Component prop={value}/> tags. A component redraws after every event handler (and when you call update()).
   Styles are scoped to the component unless you write :global(...). */
import rt from './runtime.js';
import { interp, runProgram, compileSnippet } from './interp.js';
import { build, patch, flat } from './stdlib/web.js';

const { SMap, Env, SFn, truthy, show, iterate, rtError } = rt;

/* ---------------------------------------------------------------- sections */
function lineAt(src, pos) { let n = 1; for (let i = 0; i < pos && i < src.length; i++) if (src.charCodeAt(i) === 10) n++; return n; }
function dedent(text) {
    const lines = text.replace(/\s+$/, '').split('\n');
    let min = Infinity;
    for (const l of lines) { if (!l.trim()) continue; const m = /^[ \t]*/.exec(l)[0].length; if (m < min) min = m; }
    if (min === Infinity) min = 0;
    return lines.map((l) => l.slice(min)).join('\n');
}
const SECTION = /<(props|script|style|template|head)(\s[^>]*)?>/y;

const SECTION_TAGS = /^[ \t]*<(props|script|style|template|head)(\s[^>]*)?>/m;   // only a tag that starts a line counts, so HTML inside a string does not turn an easy file into an HTML one
// "easy" files have no < > tags at all: plain Suave on the left edge, plus  page:  style:  props:  head:  blocks of indented markup
function isEasyFile(src) {
    for (const ln of src.split('\n')) {
        const t = ln.trim();
        if (!t || t.startsWith('#')) continue;
        if (t.startsWith('<!--') && t.endsWith('-->')) continue;
        if (t.startsWith('<')) return false;
        break;
    }
    return !SECTION_TAGS.test(src);
}

export function parseWeb(src, file, kind) {
    file = file || '<web>';
    if (isEasyFile(src)) return parseEasyFile(src, file, kind);
    const r = { file, kind: kind || (/\.wsv$/i.test(file) ? 'wsv' : 'xsv'), props: [], script: '', scriptLine: 1, templateSrc: null, templateLine: 1, style: '', head: '', name: '' };
    let rest = '', i = 0;
    while (i < src.length) {
        const lt = src.indexOf('<', i);
        if (lt < 0) { rest += src.slice(i); break; }
        rest += src.slice(i, lt);
        if (src.startsWith('<!--', lt)) { const e = src.indexOf('-->', lt); const end = e < 0 ? src.length : e + 3; i = end; continue; }
        SECTION.lastIndex = lt;
        const m = SECTION.exec(src);
        if (!m) { rest += '<'; i = lt + 1; continue; }
        const name = m[1], bodyStart = lt + m[0].length, closeTag = '</' + name + '>', end = src.indexOf(closeTag, bodyStart);
        if (end < 0) throw rtError('The <' + name + '> in ' + file + ' (line ' + lineAt(src, lt) + ') is never closed. Add ' + closeTag, 'SyntaxError');
        const body = src.slice(bodyStart, end);
        const line = lineAt(src, bodyStart);
        i = end + closeTag.length;
        if (name === 'script') { r.script = r.script ? r.script + '\n' + dedent(body) : dedent(body); r.scriptLine = line; }
        else if (name === 'style') r.style += (r.style ? '\n' : '') + body.trim();
        else if (name === 'template') { r.templateSrc = body; r.templateLine = line; }
        else if (name === 'head') r.head += body.trim() + '\n';
        else if (name === 'props') {
            body.split('\n').forEach((ln) => {
                const t = ln.replace(/#.*$/, '').trim();
                if (!t) return;
                const pm = /^([A-Za-z_]\w*)\s*(?:=\s*(.+))?$/.exec(t);
                if (!pm) throw rtError('A line in <props> should be  name  or  name = default.  I found: ' + t, 'SyntaxError');
                r.props.push({ name: pm[1], def: pm[2] ? pm[2].trim() : null, line });
            });
        }
    }
    if (r.templateSrc === null) { r.templateSrc = rest; r.templateLine = 1; }
    r.sections = true;                       // a <template> written without any < > is easy markup too
    const base = file.replace(/\\/g, '/').split('/').pop().replace(/\.[a-z]+$/i, '');
    r.name = base.replace(/(^|[-_ ]+)([a-z0-9])/gi, (x, a, b) => b.toUpperCase());
    return r;
}

/* ---------------------------------------------------------------- template parser */
const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
const ENT = { '&lt;': '<', '&gt;': '>', '&amp;': '&', '&quot;': '"', '&apos;': "'", '&nbsp;': ' ', '&copy;': '©', '&times;': '×', '&hellip;': '…', '&mdash;': '—', '&ndash;': '–', '&rarr;': '→', '&larr;': '←' };
const decode = (s) => s.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (m, e) => { if (ENT[m]) return ENT[m]; if (e[0] === '#') { const cp = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); return isNaN(cp) ? m : String.fromCodePoint(cp); } return m; });

// the end of a {...} that starts at s[from] (which is "{"), skipping strings; -1 when it never closes
function braceEnd(s, from) {
    let depth = 0, q = null;
    for (let j = from; j < s.length; j++) {
        const c = s[j];
        if (q) { if (c === '\\') j++; else if (c === q) q = null; continue; }
        if (c === '"' || c === "'") q = c;
        else if (c === '{') depth++;
        else if (c === '}') { depth--; if (depth === 0) return j; }
    }
    return -1;
}
// text with {expressions}: an array of strings and {code, line}
function textParts(s, line, file) {
    const out = []; let buf = '';
    for (let i = 0; i < s.length; i++) {
        const c = s[i];
        if (c === '\\' && (s[i + 1] === '{' || s[i + 1] === '}')) { buf += s[i + 1]; i++; continue; }
        if (c === '{') {
            const e = braceEnd(s, i);
            if (e < 0) throw rtError('A { in ' + file + ' (line ' + line + ') is never closed. Write \\{ for a plain brace', 'SyntaxError');
            if (buf) { out.push(decode(buf)); buf = ''; }
            out.push({ code: s.slice(i + 1, e), line: line + (s.slice(0, i).split('\n').length - 1) });
            i = e; continue;
        }
        buf += c;
    }
    if (buf) out.push(decode(buf));
    return out;
}

export function parseTemplate(src, baseLine, file) {
    const root = { kids: [] }; const stack = [root];
    let i = 0;
    const line = (pos) => baseLine + (src.slice(0, pos).split('\n').length - 1);
    const fail = (msg, pos) => { throw rtError(msg + ' (' + file + ' line ' + line(pos) + ')', 'SyntaxError'); };
    const pushText = (s, pos) => {
        if (!s) return;
        const top = stack[stack.length - 1];
        const pre = top.tag === 'pre' || top.tag === 'textarea';
        let t = s;
        if (!pre) { if (!t.trim() && /\n/.test(t)) return; t = t.replace(/\s+/g, ' '); }
        if (!t) return;
        top.kids.push({ t: 'text', parts: textParts(t, line(pos), file) });
    };
    while (i < src.length) {
        const lt = src.indexOf('<', i);
        const textEnd = lt < 0 ? src.length : lt;
        // "<" followed by a space or a digit is plain text, not a tag
        if (lt >= 0 && !/[A-Za-z\/!]/.test(src[lt + 1] || ' ')) { pushText(src.slice(i, lt + 1), i); i = lt + 1; continue; }
        pushText(src.slice(i, textEnd), i);
        if (lt < 0) break;
        if (src.startsWith('<!--', lt)) { const e = src.indexOf('-->', lt); i = e < 0 ? src.length : e + 3; continue; }
        if (src[lt + 1] === '/') {
            const e = src.indexOf('>', lt); const name = src.slice(lt + 2, e).trim();
            const top = stack[stack.length - 1];
            if (stack.length < 2 || top.tag !== name) fail('The closing </' + name + '> does not match' + (top.tag ? ' the open <' + top.tag + '>' : ' anything that is open'), lt);
            stack.pop(); i = e + 1; continue;
        }
        // an opening tag
        const m = /^<([A-Za-z][\w:.-]*)/.exec(src.slice(lt, lt + 80));
        if (!m) { pushText('<', lt); i = lt + 1; continue; }
        const tag = m[1];
        let p = lt + m[0].length;
        const attrs = [];
        let selfClose = false;
        for (;;) {
            while (p < src.length && /\s/.test(src[p])) p++;
            if (p >= src.length) fail('The tag <' + tag + '> is never finished with >', lt);
            if (src.startsWith('/>', p)) { selfClose = true; p += 2; break; }
            if (src[p] === '>') { p++; break; }
            const nm = /^[^\s=\/>{]+/.exec(src.slice(p));
            if (!nm) fail('I do not understand this inside the <' + tag + '> tag: ' + src.slice(p, p + 12), p);
            const name = nm[0]; p += name.length;
            let mode = 'none', value = '';
            if (src[p] === '=') {
                p++;
                if (src[p] === '"' || src[p] === "'") { const q = src[p]; const e = src.indexOf(q, p + 1); if (e < 0) fail('An attribute value in <' + tag + '> is never closed', p); value = src.slice(p + 1, e); mode = 'str'; p = e + 1; }
                else if (src[p] === '{') { const e = braceEnd(src, p); if (e < 0) fail('A { in the <' + tag + '> tag is never closed', p); value = src.slice(p + 1, e); mode = 'expr'; p = e + 1; }
                else { const bm = /^[^\s>]+/.exec(src.slice(p)); value = bm ? bm[0] : ''; mode = 'str'; p += value.length; }
            }
            attrs.push({ name, mode, value, line: line(p) });
        }
        const node = { t: 'el', tag, attrs, kids: [], line: line(lt) };
        // directives: if / else-if / else / for / key
        for (let k = attrs.length - 1; k >= 0; k--) {
            const a = attrs[k];
            if (a.name === 'if') { node.ifSrc = a.value; attrs.splice(k, 1); }
            else if (a.name === 'else-if') { node.elseIfSrc = a.value; attrs.splice(k, 1); }
            else if (a.name === 'else') { node.isElse = true; attrs.splice(k, 1); }
            else if (a.name === 'for') {
                const fm = /^\s*([A-Za-z_]\w*)\s*(?:,\s*([A-Za-z_]\w*)\s*)?in\s+([\s\S]+)$/.exec(a.value);
                if (!fm) fail('for needs the form  for="item in items"  or  for="index, item in items".  I found: ' + a.value, lt);
                node.forSpec = { a: fm[1], b: fm[2] || null, src: fm[3] };
                attrs.splice(k, 1);
            } else if (a.name === 'key') attrs.splice(k, 1);
        }
        if (tag === 'script' || tag === 'style') {
            const close = '</' + tag + '>'; const e = src.indexOf(close, p);
            if (e < 0) fail('The <' + tag + '> is never closed', lt);
            node.raw = src.slice(p, e);
            stack[stack.length - 1].kids.push(node);
            i = e + close.length; continue;
        }
        stack[stack.length - 1].kids.push(node);
        if (!selfClose && !VOID.has(tag.toLowerCase())) stack.push(node);
        i = p;
    }
    if (stack.length > 1) fail('The <' + stack[stack.length - 1].tag + '> is never closed', src.length);
    return root.kids;
}

/* ---------------------------------------------------------------- easy markup */
/*  page:
        h1.title: Hello, {name}!
        button.big @click=inc: Clicked {count} times
        if count > 3:
            p: That is a lot!
        for item in items:
            li: {item}
    A line is  tag.class#id  attribute=value ...  : text   (the tag is div when left out). Indented lines are its children.
    "quoted text" and | text are plain text lines. if / elif / else / for lines hold the lines under them. */
const NUM = /^-?\d+(\.\d+)?$/;
function easyAttrs(rest, line, file) {
    const attrs = []; let text = null; let p = 0;
    while (p < rest.length) {
        while (p < rest.length && /\s/.test(rest[p])) p++;
        if (p >= rest.length) break;
        if (rest[p] === ':' && (p + 1 >= rest.length || /\s/.test(rest[p + 1]))) { text = rest.slice(p + 1).trim(); break; }
        const nm = /^[^\s=]+/.exec(rest.slice(p));
        let name = nm[0];
        // a name that runs into the text colon:  button@click=go:  is not valid, but  h1:  is
        p += name.length;
        let mode = 'none', value = '';
        if (rest[p] === '=') {
            p++;
            if (rest[p] === '"' || rest[p] === "'") { const q = rest[p]; const e = rest.indexOf(q, p + 1); if (e < 0) throw rtError('A quote is never closed in: ' + rest + ' (' + file + ' line ' + line + ')', 'SyntaxError'); value = rest.slice(p + 1, e); mode = 'str'; p = e + 1; }
            else if (rest[p] === '{') { const e = braceEnd(rest, p); if (e < 0) throw rtError('A { is never closed in: ' + rest + ' (' + file + ' line ' + line + ')', 'SyntaxError'); value = rest.slice(p + 1, e); mode = 'expr'; p = e + 1; }
            else {
                const bm = /^[^\s]+/.exec(rest.slice(p)); value = bm ? bm[0] : ''; p += value.length;
                if (value.length > 1 && value.endsWith(':') && (p >= rest.length || /\s/.test(rest[p]))) { value = value.slice(0, -1); p -= 1; }   // go: is  go  and then the text colon
                // a name or handler stays a value; plain words are text
                mode = /^(@|on:|bind:|class:)/.test(name) || NUM.test(value) || /^(true|false|none)$/.test(value) ? 'expr' : 'str';
            }
        }
        attrs.push({ name, mode, value, line });
    }
    return { attrs, text };
}
function easyLine(body, line, file) {
    const q = body[0];
    if (q === '"' || q === "'") {
        if (body[body.length - 1] !== q || body.length < 2) throw rtError('This text line needs a closing ' + q + ' (' + file + ' line ' + line + '): ' + body, 'SyntaxError');
        return { t: 'text', parts: textParts(body.slice(1, -1), line, file), noKids: true };
    }
    if (q === '|') return { t: 'text', parts: textParts(body.slice(1).trim(), line, file), noKids: true };
    if (q === '{') return { t: 'text', parts: textParts(body, line, file), noKids: true };
    let m;
    if ((m = /^if\s+(.+?)\s*:$/.exec(body))) return { t: 'el', tag: 'block', attrs: [], kids: [], line, ifSrc: m[1] };
    if ((m = /^elif\s+(.+?)\s*:$/.exec(body))) return { t: 'el', tag: 'block', attrs: [], kids: [], line, elseIfSrc: m[1] };
    if (/^else\s*:$/.test(body)) return { t: 'el', tag: 'block', attrs: [], kids: [], line, isElse: true };
    if ((m = /^for\s+([A-Za-z_]\w*)\s*(?:,\s*([A-Za-z_]\w*)\s*)?in\s+(.+?)\s*:$/.exec(body))) return { t: 'el', tag: 'block', attrs: [], kids: [], line, forSpec: { a: m[1], b: m[2] || null, src: m[3] } };
    const em = /^([A-Za-z][\w-]*)?((?:[.#][\w-]+)*)/.exec(body);
    if (!em || !em[0]) throw rtError('I do not understand this line (' + file + ' line ' + line + '): ' + body, 'SyntaxError');
    const tag = em[1] || 'div';
    const { attrs, text } = easyAttrs(body.slice(em[0].length), line, file);
    for (const part of em[2].match(/[.#][\w-]+/g) || []) {
        if (part[0] === '#') attrs.unshift({ name: 'id', mode: 'str', value: part.slice(1), line });
        else attrs.unshift({ name: 'class:' + part.slice(1), mode: 'none', value: '', line });
    }
    const node = { t: 'el', tag, attrs, kids: [], line };
    if (text) node.kids.push({ t: 'text', parts: textParts(text, line, file) });
    return node;
}
export function parseEasyMarkup(text, baseLine, file) {
    const root = { kids: [], indent: -1 }; const stack = [root];
    text.split('\n').forEach((raw, n) => {
        const body = raw.trim();
        if (!body || body.startsWith('#')) return;
        const indent = /^[ \t]*/.exec(raw)[0].replace(/\t/g, '    ').length;
        const line = baseLine + n;
        while (stack.length > 1 && indent <= stack[stack.length - 1].indent) stack.pop();
        const parent = stack[stack.length - 1];
        if (parent.noKids) throw rtError('A text line cannot have lines under it (' + file + ' line ' + line + ')', 'SyntaxError');
        const node = easyLine(body, line, file);
        node.indent = indent;
        parent.kids.push(node);
        if (node.t === 'el' || node.noKids) stack.push(node);
    });
    return root.kids;
}
// static markup (the head) as an HTML string
function markupHtml(nodes) {
    const e = (x) => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
    return nodes.map((n) => {
        if (n.t === 'text') return e(n.parts.filter((p) => typeof p === 'string').join(''));
        const attrs = n.attrs.map((a) => ' ' + a.name + (a.mode === 'none' ? '' : '="' + e(a.value) + '"')).join('');
        return VOID.has(n.tag) ? '<' + n.tag + attrs + '>' : '<' + n.tag + attrs + '>' + markupHtml(n.kids) + '</' + n.tag + '>';
    }).join('\n');
}
function parseEasyFile(src, file, kind) {
    const r = { file, kind: kind || (/\.wsv$/i.test(file) ? 'wsv' : 'xsv'), props: [], script: '', scriptLine: 1, templateSrc: '', templateLine: 1, templateKind: 'easy', style: '', head: '', name: '' };
    const lines = src.split('\n'); const script = []; const heads = [];
    for (let i = 0; i < lines.length; i++) {
        const ln = lines[i];
        const m = /^(page|view|template|style|props|head)\s*:\s*$/.exec(ln);
        if (m) {
            const body = []; let j = i + 1; script.push('');
            while (j < lines.length && (!lines[j].trim() || /^[ \t]/.test(lines[j]))) { body.push(lines[j]); script.push(''); j++; }
            const text = dedent(body.join('\n'));
            const first = i + 2;
            if (m[1] === 'style') r.style += (r.style ? '\n' : '') + text;
            else if (m[1] === 'head') heads.push(markupHtml(parseEasyMarkup(text, first, file)));
            else if (m[1] === 'props') text.split('\n').forEach((l2) => { const t = l2.replace(/#.*$/, '').trim(); if (!t) return; const pm = /^([A-Za-z_]\w*)\s*(?:=\s*(.+))?$/.exec(t); if (!pm) throw rtError('A line in props: should be  name  or  name = default.  I found: ' + t, 'SyntaxError'); r.props.push({ name: pm[1], def: pm[2] ? pm[2].trim() : null, line: first }); });
            else { r.templateSrc = text; r.templateLine = first; }
            i = j - 1; continue;
        }
        const tm = /^title\s+(["'])(.*)\1\s*$/.exec(ln);
        if (tm) { heads.push('<title>' + tm[2].replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</title>'); script.push(''); continue; }
        script.push(ln);
    }
    r.script = script.join('\n').replace(/\s+$/, '');
    r.head = heads.join('\n');
    const base = file.replace(/\\/g, '/').split('/').pop().replace(/\.[a-z]+$/i, '');
    r.name = base.replace(/(^|[-_ ]+)([a-z0-9])/gi, (x, a, b) => b.toUpperCase());
    return r;
}

/* ---------------------------------------------------------------- css scoping */
function scopeSelector(sel, attr) {
    const s = sel.trim();
    if (!s) return sel;
    if (s.includes(':global(')) return s.replace(/:global\(([^)]*)\)/g, '$1');
    if (/^(from|to|\d+%)$/.test(s)) return sel;
    const m = /^([\s\S]*?)([^\s>+~]+)$/.exec(s);
    const head = m ? m[1] : '', last = m ? m[2] : s;
    let cut = last.length, depth = 0;
    for (let k = 0; k < last.length; k++) { const c = last[k]; if (c === '[' || c === '(') depth++; else if (c === ']' || c === ')') depth--; else if (c === ':' && depth === 0) { cut = k; break; } }
    return head + last.slice(0, cut) + '[' + attr + ']' + last.slice(cut);
}
export function scopeCss(css, attr) {
    css = css.replace(/\/\*[\s\S]*?\*\//g, '');
    let out = '', i = 0;
    while (i < css.length) {
        const open = css.indexOf('{', i);
        if (open < 0) { out += css.slice(i); break; }
        const head = css.slice(i, open);
        let d = 1, j = open + 1;
        while (j < css.length && d > 0) { if (css[j] === '{') d++; else if (css[j] === '}') d--; j++; }
        const body = css.slice(open + 1, j - 1);
        if (/^\s*@(media|supports|container|layer)/.test(head)) out += head + '{' + scopeCss(body, attr) + '}';
        else if (/^\s*@/.test(head)) out += head + '{' + body + '}';
        else out += head.split(',').map((x) => scopeSelector(x, attr)).join(',') + '{' + body + '}';
        i = j;
    }
    return out;
}

/* ---------------------------------------------------------------- components */
let compCounter = 0;
export class XComponent {
    constructor(parsed) {
        this.name = parsed.name; this.file = parsed.file; this.kind = parsed.kind;
        this.props = parsed.props; this.script = parsed.script; this.scriptLine = parsed.scriptLine;
        this.head = parsed.head;
        this.nodes = parsed.templateKind === 'easy' || !/<[A-Za-z\/!]/.test(parsed.templateSrc) && /\S/.test(parsed.templateSrc) && parsed.sections ? parseEasyMarkup(parsed.templateSrc, parsed.templateLine, parsed.file) : parseTemplate(parsed.templateSrc, parsed.templateLine, parsed.file);
        this.id = 'x' + (++compCounter).toString(36) + hash(parsed.file + parsed.name);
        this.attr = 'data-' + this.id;
        this.css = parsed.style ? scopeCss(parsed.style, this.attr) : '';
        this.snips = new Map();
    }
    snippet(src, line) {
        let f = this.snips.get(src);
        if (!f) { f = compileSnippet(src, this.file, line); this.snips.set(src, f); }
        return f;
    }
}
function hash(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }

export function compileWeb(src, file, kind) { return new XComponent(parseWeb(src, file, kind)); }

const mapOf = (obj) => { const m = new SMap(); for (const k of Object.keys(obj)) m.set(k, obj[k]); return m; };
const vnode = (tag, props, kids) => { const m = new SMap(); m.set('tag', tag); m.set('props', props); m.set('children', kids); return m; };
const SVG = /^(svg|path|circle|rect|line|polyline|polygon|g|defs|use|ellipse|text|tspan)$/;

class XInstance {
    constructor(comp, root) {
        this.comp = comp; this.root = root || this; this.env = interp.newScope(); this.kids = new Map(); this.seen = new Set();
        this.slot = []; this.ready = false;
        if (!root) { this.fresh = []; this.pending = false; }
    }
    init(props) {
        const env = this.env, root = this.root;
        for (const p of this.comp.props) {
            let v = null;
            if (props && props.has(p.name)) v = props.get(p.name);
            else if (p.def) v = this.eval(p.def, env, p.line);
            env.def(p.name, v, true);
        }
        env.def('update', (...a) => { root.schedule(); return null; }, false);
        if (this.comp.script) {
            const prev = rt.state.file;
            try { const r = runProgram('\n'.repeat(Math.max(0, this.comp.scriptLine - 1)) + this.comp.script, this.comp.file, env); if (r instanceof Promise) r.then(() => root.schedule(), (e) => rt.lateError && rt.lateError(e)); }
            finally { rt.state.file = prev; }
        }
        root.fresh.push(this);
    }
    setProps(props) {
        for (const p of this.comp.props) if (props.has(p.name)) this.env.assign(p.name, props.get(p.name));
    }
    eval(code, env, line) {
        const f = this.comp.snippet(code, line);
        const pf = rt.state.file, pl = rt.state.line;
        rt.state.file = this.comp.file; if (line) rt.state.line = line;
        try { return f(env); } finally { rt.state.file = pf; rt.state.line = pl; }
    }
    schedule() {
        const r = this.root;
        if (r.pending) return;
        r.pending = true;
        const go = () => { r.pending = false; if (r.draw) r.draw(); };
        if (typeof queueMicrotask === 'function') queueMicrotask(go); else Promise.resolve().then(go);
    }
    render(slot) {
        this.slot = slot || [];
        this.seen = new Set();
        const out = this.list(this.comp.nodes, this.env, '');
        for (const [k, inst] of this.kids) if (!this.seen.has(k)) { inst.destroy(); this.kids.delete(k); }
        return out;
    }
    destroy() {
        for (const inst of this.kids.values()) inst.destroy();
        const f = this.env.lookup('on_unmount');
        if (f instanceof SFn) { try { rt.call(f, []); } catch (e) { /* ignore */ } }
        this.dead = true;
    }
    list(nodes, env, path) {
        const out = [];
        let chain = null;   // null: no if in front, true: a branch already showed, false: still looking
        nodes.forEach((n, idx) => {
            if (n.t === 'text') { const s = this.text(n, env); if (s !== '') out.push(s); chain = null; return; }
            if (n.ifSrc !== undefined) { const ok = truthy(this.eval(n.ifSrc, env, n.line)); chain = ok; if (!ok) return; }
            else if (n.elseIfSrc !== undefined) { if (chain === null) throw rtError('else-if needs an if on the element just before it (' + this.comp.file + ' line ' + n.line + ')', 'SyntaxError'); if (chain) return; const ok = truthy(this.eval(n.elseIfSrc, env, n.line)); chain = ok; if (!ok) return; }
            else if (n.isElse) { if (chain === null) throw rtError('else needs an if on the element just before it (' + this.comp.file + ' line ' + n.line + ')', 'SyntaxError'); const was = chain; chain = null; if (was) return; }
            else chain = null;
            if (n.forSpec) {
                const items = Array.from(iterate(this.eval(n.forSpec.src, env, n.line)));
                items.forEach((item, k) => {
                    const e2 = new Env(env);
                    if (n.forSpec.b) { e2.def(n.forSpec.a, k, true); e2.def(n.forSpec.b, item, true); } else e2.def(n.forSpec.a, item, true);
                    for (const v of this.one(n, e2, path + '/' + idx + ':' + k)) out.push(v);
                });
            } else for (const v of this.one(n, env, path + '/' + idx)) out.push(v);
        });
        return out;
    }
    text(n, env) {
        let s = '';
        for (const p of n.parts) s += typeof p === 'string' ? p : (() => { const v = this.eval(p.code, env, p.line); return v === null || v === undefined ? '' : show(v); })();
        return s;
    }
    // the value of an attribute: {expr} keeps its kind, "text {with} holes" is a string, a bare name is true
    attrValue(a, env) {
        if (a.mode === 'expr') return this.eval(a.value, env, a.line);
        if (a.mode === 'none') return true;
        if (a.value.indexOf('{') < 0) return decode(a.value);
        return textParts(a.value, a.line, this.comp.file).map((p) => (typeof p === 'string' ? p : (() => { const v = this.eval(p.code, env, p.line); return v === null || v === undefined ? '' : show(v); })())).join('');
    }
    handler(a, env) {
        const root = this.root;
        const after = (r) => { if (r instanceof Promise) r.then(() => root.schedule(), (e) => { root.schedule(); if (rt.lateError) rt.lateError(e); }); root.schedule(); };   // an error in an async handler is shown, not lost
        if (a.mode === 'expr') {
            const f = this.eval(a.value, env, a.line);
            if (f === null || f === undefined) return () => null;
            return (ev) => { try { const r = f instanceof SFn ? rt.call(f, f.params.length ? [ev] : []) : (typeof f === 'function' ? f(ev) : rt.call(f, [ev])); after(r); } catch (e) { root.schedule(); throw e; } return null; };
        }
        // a quoted handler is a bit of code run in the component:  @click="count += 1"
        return (ev) => { const e2 = new Env(env); e2.def('event', ev, true); try { const r = this.eval(a.value, e2, a.line); after(r); } catch (e) { root.schedule(); throw e; } return null; };
    }
    one(n, env, path) {
        if (n.t === 'text') return [this.text(n, env)];
        const tag = n.tag;
        if (tag === 'slot') return this.slot.slice();
        if (tag === 'block' || tag === 'template' || tag === 'fragment') return this.list(n.kids, env, path);
        if (/^[A-Z]/.test(tag) || (tag.indexOf('.') > 0 && /^[A-Z]/.test(tag))) return this.component(n, env, path);
        const props = new SMap(); const classes = []; let baseClass = null;
        for (const a of n.attrs) {
            const name = a.name;
            if (name.startsWith('on:') || name.startsWith('@')) { props.set('on_' + name.replace(/^on:|^@/, '').replace(/-/g, '_'), this.handler(a, env)); continue; }
            if (name.startsWith('bind:')) {
                const what = name.slice(5), target = a.value.trim(), root = this.root;
                props.set(what, this.eval(target, env, a.line));
                const ev = what === 'checked' ? 'on_change' : 'on_input';
                props.set(ev, (e) => { const e2 = new Env(env); e2.def('__bind', e instanceof SMap ? e.get(what === 'checked' ? 'checked' : 'value') : null, true); try { this.eval(target + ' = __bind', e2, a.line); } finally { root.schedule(); } return null; });
                continue;
            }
            if (name.startsWith('class:')) { if (truthy(a.mode === 'expr' ? this.eval(a.value, env, a.line) : true)) classes.push(name.slice(6)); continue; }
            const v = this.attrValue(a, env);
            if (name === 'class') { baseClass = v === null || v === false ? '' : (Array.isArray(v) ? v.filter(Boolean).join(' ') : show(v)); continue; }
            if (v === false || v === null) continue;
            props.set(name, v);
        }
        const cls = [baseClass].concat(classes).filter(Boolean).join(' ');
        if (cls) props.set('class', cls);
        if (this.comp.css) props.set(this.comp.attr, true);
        if (n.raw !== undefined) { props.set('text', n.raw); return [vnode(tag, props, [])]; }
        const kids = this.list(n.kids, env, path);
        return [vnode(tag, props, kids)];
    }
    component(n, env, path) {
        const parts = n.tag.split('.');
        let C = env.lookup(parts[0]);
        for (let k = 1; k < parts.length && C; k++) C = C && C.exports ? C.exports[parts[k]] : undefined;
        if (C instanceof rt.SModule && C.exports) C = C.exports.component || C.exports[parts[parts.length - 1]] || C;
        if (!(C instanceof XComponent)) throw rtError('<' + n.tag + '> is not a component. Import it first, like:  use "./' + n.tag.toLowerCase() + '.xsv"   (' + this.comp.file + ' line ' + n.line + ')', 'NameError');
        const props = new SMap();
        for (const a of n.attrs) {
            if (a.name.startsWith('on:') || a.name.startsWith('@')) { props.set('on_' + a.name.replace(/^on:|^@/, '').replace(/-/g, '_'), a.mode === 'expr' ? this.eval(a.value, env, a.line) : this.handler(a, env)); continue; }
            if (a.name.startsWith('bind:')) { const what = a.name.slice(5), target = a.value.trim(), root = this.root; props.set(what, this.eval(target, env, a.line)); props.set('on_' + what + '_change', (v) => { const e2 = new Env(env); e2.def('__bind', v, true); try { this.eval(target + ' = __bind', e2, a.line); } finally { root.schedule(); } return null; }); continue; }
            props.set(a.name.replace(/-/g, '_'), this.attrValue(a, env));
        }
        const slot = this.list(n.kids, env, path + '/slot');
        let inst = this.kids.get(path);
        if (!inst || inst.comp !== C) { if (inst) inst.destroy(); inst = new XInstance(C, this.root); this.kids.set(path, inst); inst.init(props); } else inst.setProps(props);
        this.seen.add(path);
        return inst.render(slot);
    }
}

/* ---------------------------------------------------------------- styles, html, mount */
const injected = new Set();
function ensureStyles(inst) {
    if (typeof document === 'undefined') return;
    const add = (c) => { if (c.css && !injected.has(c.id)) { injected.add(c.id); const s = document.createElement('style'); s.setAttribute('data-xsv', c.name); s.textContent = c.css; document.head.appendChild(s); } };
    add(inst.comp);
    for (const k of inst.kids.values()) ensureStyles(k);
}

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escA = (s) => esc(s).replace(/"/g, '&quot;');
export function renderHtml(v) {
    if (v === null || v === undefined || v === false) return '';
    if (Array.isArray(v)) return v.map(renderHtml).join('');
    if (typeof v === 'string' || typeof v === 'number' || typeof v === 'bigint' || v === true) return esc(v);
    if (!(v instanceof SMap) || !v.has('tag')) return esc(show(v));
    const tag = String(v.get('tag')), props = v.get('props');
    let attrs = '', inner = null;
    if (props instanceof SMap) for (const [k, val] of props.entries()) {
        const key = String(k);
        if (key.startsWith('on_')) continue;
        if (key === 'text') { inner = esc(show(val)); continue; }
        if (key === 'html') { inner = show(val); continue; }
        if (val === true) attrs += ' ' + key;
        else if (val === false || val === null) continue;
        else if (key === 'style' && val instanceof SMap) attrs += ' style="' + escA(Array.from(val.entries()).map(([a, b]) => String(a).replace(/[A-Z]/g, (c) => '-' + c.toLowerCase()) + ':' + show(b)).join(';')) + '"';
        else attrs += ' ' + key + '="' + escA(key === 'class' && Array.isArray(val) ? val.filter(Boolean).join(' ') : show(val)) + '"';
    }
    if (VOID.has(tag.toLowerCase())) return '<' + tag + attrs + '>';
    return '<' + tag + attrs + '>' + (inner !== null ? inner : flat(v.get('children')).map(renderHtml).join('')) + '</' + tag + '>';
}

export function renderComponent(comp, props) {
    const inst = new XInstance(comp, null);
    inst.init(props instanceof SMap ? props : new SMap());
    return flat(inst.render());
}

export function mountComponent(comp, target, props) {
    if (typeof document === 'undefined') throw rtError('mount needs a web page. Run this in a browser (suave build app.wsv)', 'EnvError');
    const el = typeof target === 'string' ? document.querySelector(target) : target;
    if (!el) throw rtError('I could not find the page element ' + show(target), 'ArgError');
    const inst = new XInstance(comp, null);
    inst.draw = () => {
        try {
            const kids = flat(inst.render());
            ensureStyles(inst);
            for (let i = 0; i < kids.length; i++) patch(el, el.childNodes[i], kids[i], i);
            while (el.childNodes.length > kids.length) el.removeChild(el.lastChild);
            // on_update() runs after every draw (use it to talk to a canvas or another library; do not call update() from it every time)
            const ups = (x) => { const f = x.env.lookup('on_update'); if (f instanceof SFn && !x.dead) { try { const r = rt.call(f, []); if (r instanceof Promise) r.catch((e) => rt.lateError && rt.lateError(e)); } catch (e) { if (rt.lateError) rt.lateError(e); } } for (const k of x.kids.values()) ups(k); };
            const fresh = inst.fresh.splice(0);
            for (const f of fresh) { if (f.dead || f.ready) continue; f.ready = true; const m = f.env.lookup('on_mount'); if (m instanceof SFn) { const r = rt.call(m, []); if (r instanceof Promise) r.then(() => inst.schedule(), () => {}); inst.schedule(); } }
            ups(inst);
        } catch (e) { if (rt.lateError) rt.lateError(e); else throw e; }
    };
    inst.init(props instanceof SMap ? props : new SMap());
    inst.draw();
    const handle = new SMap();
    handle.set('update', () => { inst.schedule(); return null; });
    handle.set('redraw', () => { inst.draw(); return null; });
    handle.set('set_props', (p) => { if (p instanceof SMap) inst.setProps(p); inst.schedule(); return null; });
    handle.set('element', el);
    return handle;
}

// a whole page: title and head parts, then the app in #app (or the page body)
export function mountPage(src, file, target) {
    const comp = compileWeb(src, file, 'wsv');
    if (typeof document !== 'undefined' && !document.documentElement.hasAttribute('data-suave-built')) {
        const h = comp.head;
        if (h) {
            const t = document.createElement('template'); t.innerHTML = h;
            for (const node of Array.from(t.content.childNodes)) {
                if (node.nodeType !== 1) continue;
                if (node.tagName === 'TITLE') document.title = node.textContent;
                else document.head.appendChild(node);
            }
        }
    }
    let el = target || (typeof document !== 'undefined' && (document.getElementById('app') || document.querySelector('[data-suave-app]')));
    if (!el && typeof document !== 'undefined') { el = document.createElement('div'); el.id = 'app'; document.body.appendChild(el); }
    return mountComponent(comp, el, new SMap());
}

// look for mistakes without running: every script line, expression and handler in the file is compiled once
export function checkWeb(src, file) {
    const comp = compileWeb(src, file);
    const bad = [];
    const tryC = (code, line) => { try { compileSnippet(code, file, line); } catch (e) { if (code !== comp.script && e && e.message && !e.__tagged) { e.message += '\n  (in the code: ' + code.trim().slice(0, 70) + ')'; e.__tagged = true; } bad.push(e); } };
    if (comp.script) tryC(comp.script, comp.scriptLine);
    for (const p of comp.props) if (p.def) tryC(p.def, p.line);
    const walk = (nodes) => {
        for (const n of nodes) {
            if (n.t === 'text') { for (const p of n.parts) if (typeof p !== 'string') tryC(p.code, p.line); continue; }
            if (n.ifSrc !== undefined) tryC(n.ifSrc, n.line);
            if (n.elseIfSrc !== undefined) tryC(n.elseIfSrc, n.line);
            if (n.forSpec) tryC(n.forSpec.src, n.line);
            for (const a of n.attrs) {
                if (a.name.startsWith('bind:')) tryC(a.value.trim() + ' = __bind', a.line);
                else if (a.mode === 'expr' || (a.mode === 'str' && (a.name.startsWith('on:') || a.name.startsWith('@')))) tryC(a.value, a.line);
                else if (a.mode === 'str' && a.value.indexOf('{') >= 0) for (const p of textParts(a.value, a.line, file)) if (typeof p !== 'string') tryC(p.code, p.line);
            }
            walk(n.kids);
        }
    };
    walk(comp.nodes);
    if (bad.length) throw bad[0];
    return comp;
}

export { mapOf, Env as XEnv };
void build;
