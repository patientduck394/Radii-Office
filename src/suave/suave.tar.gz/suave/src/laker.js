/* Laker: desktop apps for Suave, like Tauri but for Suave. A Laker app is a Suave web app (.wsv or index.html) shown in its own window,
   plus an optional backend.sv whose functions the page can call.

   laker.suvl      name, id, version, entry, window size, backend
   backend.sv      def greet(name): ...      <- the page calls  await laker.invoke("greet", {name: "Ada"})  (use std.laker)

   laker init                make laker.suvl, a starter app.wsv and backend.sv
   laker dev                 build, serve and open the window (reload it by hand after changes)
   laker build [--dmg]       make a real desktop app: MyApp.app on a Mac (a folder with the program on other systems)
   laker run                 run the built app

   The window is the Chrome, Edge, Brave or Chromium you already have, opened as a plain app window with no tabs or address bar.
   The program inside the app is the Suave runtime itself (built with deno compile), so people who open your app need nothing installed. */
import rt from './runtime.js';
import * as suvl from './formats/suvl.js';

const sys = () => rt.sys;
const out = (s) => sys().out(s + '\n'), eout = (s) => sys().errOut(s + '\n');
const D = () => globalThis.Deno;
const slug = (s) => String(s || 'app').replace(/[^A-Za-z0-9._ -]/g, '').trim() || 'app';

/* ---------------------------------------------------------------- config */
export function readConfig(dir) {
    const p = dir + '/laker.suvl';
    if (!sys().exists(p)) throw rt.rtError('There is no laker.suvl here. Make one with:  laker init', 'LakerError');
    const m = suvl.parse(sys().readText(p));
    const get = (k, d) => { const v = m.get(k); return v === undefined || v === null ? d : v; };
    const w = m.get('window');
    const wget = (k, d) => (w && w.get && w.get(k) !== undefined ? w.get(k) : d);
    const name = String(get('name', 'My Suave App'));
    return {
        dir, name, id: String(get('id', 'com.suave.' + slug(name).toLowerCase().replace(/[ .]/g, ''))), version: String(get('version', '0.1.0')),
        entry: String(get('entry', sys().exists(dir + '/app.wsv') ? 'app.wsv' : 'index.html')), backend: get('backend', sys().exists(dir + '/backend.sv') ? 'backend.sv' : null),
        icon: get('icon', null), width: Number(wget('width', 1000)), height: Number(wget('height', 700)), title: String(wget('title', name)),
    };
}

const SAMPLE_CONFIG = (name) => `# laker.suvl: the settings of this desktop app (written in SUVL)
name: "${name}"
id: com.example.${slug(name).toLowerCase().replace(/[ .]/g, '')}
version: 0.1.0
entry: app.wsv
backend: backend.sv
window {
    width: 960
    height: 680
    title: "${name}"
}
`;
const SAMPLE_APP = (name) => `# ${name}: a desktop app written in Suave
title "${name}"

use std.laker

greeting = "Click the button!"
who = "world"

async def ask():
    greeting = await laker.invoke("greet", {name: who})

page:
    main:
        h1: ${name}
        input bind:value={who}
        button @click=ask: Say hello from the backend
        p.out: {greeting}

style:
    main { max-width: 30rem; margin: 3rem auto; font-family: system-ui; padding: 0 1rem }
    input, button { font: inherit; padding: 8px 12px; margin-right: 8px; border-radius: 8px; border: 1.5px solid #cbd5e1 }
    button { background: #4f46e5; border-color: #4f46e5; color: white; cursor: pointer }
    .out { font-size: 1.2rem; margin-top: 1.5rem }
`;
const SAMPLE_BACKEND = `# backend.sv: every function here that does not start with _ can be called from the page.
# The page calls it with:  await laker.invoke("greet", {name: "Ada"})

def greet(name):
    return "Hello, {name}! This answer came from Suave running on your computer."

def app_info():
    return {os: os_name(), data_folder: data_dir()}
`;

export function laker_init(dir, name) {
    name = name || 'My Suave App';
    const w = (f, t) => { if (!sys().exists(dir + '/' + f)) { sys().writeText(dir + '/' + f, t); out('  made ' + f); } else out('  kept your ' + f); };
    w('laker.suvl', SAMPLE_CONFIG(name)); w('app.wsv', SAMPLE_APP(name)); w('backend.sv', SAMPLE_BACKEND);
    out('\nNext:  laker dev      (try it in a window)\n       laker build    (make the desktop app)');
}

/* ---------------------------------------------------------------- the app server */
const MIME = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', mjs: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', json: 'application/json', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', ico: 'image/x-icon', txt: 'text/plain; charset=utf-8', wsv: 'text/plain; charset=utf-8', xsv: 'text/plain; charset=utf-8', sv: 'text/plain; charset=utf-8', woff2: 'font/woff2', wasm: 'application/wasm', pdf: 'application/pdf' };
const mimeOf = (p) => MIME[((/\.([A-Za-z0-9]+)$/.exec(p) || [])[1] || '').toLowerCase()] || 'application/octet-stream';

function dataDir(cfg) {
    const home = sys().home(), os = sys().os();
    const base = os === 'darwin' ? home + '/Library/Application Support' : os === 'windows' ? (sys().env('APPDATA') || home + '/AppData/Roaming') : (sys().env('XDG_DATA_HOME') || home + '/.local/share');
    const d = base + '/' + slug(cfg.name);
    try { sys().mkdir(d, true); } catch (e) { /* ignore */ }
    return d;
}
const osName = () => ({ darwin: 'mac', windows: 'windows', linux: 'linux' }[sys().os()] || sys().os());

// the page asks the operating system for a file (macOS uses osascript, Linux zenity, Windows PowerShell)
async function nativePicker(kind, arg) {
    const os = sys().os();
    let r;
    if (os === 'darwin') {
        const script = kind === 'open' ? 'POSIX path of (choose file with prompt "' + String(arg).replace(/"/g, '') + '")' : 'POSIX path of (choose file name default name "' + String(arg).replace(/"/g, '') + '")';
        r = await sys().run('osascript', ['-e', script]);
    } else if (os === 'linux') r = await sys().run('zenity', kind === 'open' ? ['--file-selection'] : ['--file-selection', '--save', '--filename=' + arg]);
    else r = await sys().run('powershell', ['-NoProfile', '-Command', '[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms"); $d = New-Object System.Windows.Forms.' + (kind === 'open' ? 'OpenFileDialog' : 'SaveFileDialog') + '; if ($d.ShowDialog() -eq "OK") { $d.FileName }']);
    return r.code === 0 ? r.stdout.trim() : null;   // null when the person cancelled
}

export function startServer(cfg, resources, opts) {
    opts = opts || {};
    const webDir = resources + '/web';
    // the backend: every function in backend.sv whose name does not start with _
    let backendScope = null;
    const backendPath = cfg.backend ? resources + '/' + cfg.backend : null;
    if (backendPath && sys().exists(backendPath)) {
        backendScope = rt.engine.interp.newScope();
        const nat = { data_dir: () => dataDir(cfg), os_name: () => osName(), app_dir: () => resources, app_name: () => cfg.name };
        for (const k of Object.keys(nat)) backendScope.def(k, nat[k], false);
        rt.engine.runProgram(sys().readText(backendPath), backendPath, backendScope);
    }
    const abort = new AbortController();
    const json = (obj, status) => new Response(JSON.stringify(obj), { status: status || 200, headers: { 'content-type': 'application/json' } });
    const handler = async (req) => {
        const url = new URL(req.url);
        let path = decodeURIComponent(url.pathname);
        if (path.startsWith('/__laker/')) {
            const cmd = path.slice(9);
            let body = {};
            try { body = await req.json(); } catch (e) { body = {}; }
            try {
                if (cmd === 'info') return json({ value: { name: cfg.name, id: cfg.id, version: cfg.version, os: osName(), data_folder: dataDir(cfg) } });
                if (cmd === 'quit') { setTimeout(() => { if (opts.onQuit) opts.onQuit(); }, 50); return json({ value: true }); }
                if (cmd === 'open-url') { const u = String(body.url || ''); if (!/^https?:\/\//.test(u)) return json({ error: 'Only web addresses can be opened' }, 400); await sys().run(sys().os() === 'darwin' ? 'open' : sys().os() === 'windows' ? 'cmd' : 'xdg-open', sys().os() === 'windows' ? ['/c', 'start', '', u] : [u]); return json({ value: true }); }
                if (cmd === 'pick-file') return json({ value: await nativePicker('open', body.prompt || 'Choose a file') });
                if (cmd === 'pick-save') return json({ value: await nativePicker('save', body.name || 'untitled') });
                if (cmd === 'read-file') return json({ value: sys().readText(String(body.path)) });
                if (cmd === 'write-file') { sys().writeText(String(body.path), String(body.text)); return json({ value: true }); }
                if (cmd.startsWith('invoke/')) {
                    const name = decodeURIComponent(cmd.slice(7));
                    const f = backendScope && !name.startsWith('_') ? backendScope.lookup(name) : undefined;
                    if (!(f instanceof rt.SFn)) return json({ error: 'The backend has no command called "' + name + '". Add  def ' + name + '(...)  to ' + (cfg.backend || 'backend.sv') }, 404);
                    let args = body.args, named = null;
                    if (args && !Array.isArray(args) && typeof args === 'object') { named = args; args = []; }
                    let value = rt.call(f, (args === null || args === undefined ? [] : args).map(rt.fromJS), named ? Object.fromEntries(Object.entries(named).map(([k, v]) => [k, rt.fromJS(v)])) : undefined);
                    if (value instanceof Promise) value = await value;
                    return json({ value: rt.toJS(value) });
                }
                return json({ error: 'Unknown Laker command ' + cmd }, 404);
            } catch (e) { return json({ error: (e && e.message) || String(e) }, 500); }
        }
        if (path.endsWith('/')) path += 'index.html';
        if (path.includes('..')) return new Response('Not allowed', { status: 403 });
        try {
            const file = webDir + path;
            let data = D().readFileSync(file);
            if (path === '/index.html') data = new TextEncoder().encode(new TextDecoder().decode(data).replace('<head>', '<head><script>window.__laker = true;</script>'));
            return new Response(data, { headers: { 'content-type': mimeOf(path), 'cache-control': 'no-store' } });
        } catch (e) { return new Response('Not found: ' + path, { status: 404 }); }
    };
    const server = D().serve({ port: opts.port || 0, hostname: '127.0.0.1', signal: abort.signal, onListen() {} }, handler);
    return { port: server.addr.port, stop: () => abort.abort(), finished: server.finished };
}

/* ---------------------------------------------------------------- the window */
export function findBrowser() {
    const os = sys().os();
    const exists = (p) => sys().exists(p);
    const mac = ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser', '/Applications/Chromium.app/Contents/MacOS/Chromium', sys().home() + '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'];
    if (os === 'darwin') return mac.find(exists) || null;
    if (os === 'windows') {
        const pf = [sys().env('PROGRAMFILES'), sys().env('PROGRAMFILES(X86)'), sys().env('LOCALAPPDATA')].filter(Boolean);
        const rel = ['/Google/Chrome/Application/chrome.exe', '/Microsoft/Edge/Application/msedge.exe', '/BraveSoftware/Brave-Browser/Application/brave.exe'];
        for (const b of pf) for (const r of rel) if (exists(b + r)) return b + r;
        return null;
    }
    for (const c of ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge', 'brave-browser']) { const r = sys().runSync('which', [c]); if (r.code === 0 && r.stdout.trim()) return r.stdout.trim(); }
    return null;
}

export async function openWindow(cfg, port) {
    const exe = findBrowser();
    const url = 'http://127.0.0.1:' + port + '/?laker';
    if (!exe) {
        eout('I could not find Chrome, Edge, Brave or Chromium for the app window, so I am opening your normal browser instead.');
        await sys().run(sys().os() === 'darwin' ? 'open' : sys().os() === 'windows' ? 'cmd' : 'xdg-open', sys().os() === 'windows' ? ['/c', 'start', '', url] : [url]);
        return null;
    }
    const profile = sys().tempDir();
    const child = new (D().Command)(exe, { args: ['--app=' + url, '--user-data-dir=' + profile, '--window-size=' + cfg.width + ',' + cfg.height, '--no-first-run', '--no-default-browser-check', '--disable-features=Translate'], stdin: 'null', stdout: 'null', stderr: 'null' }).spawn();
    const status = child.status;
    return { child, profile, status };
}

export async function runApp(cfg, resources, opts) {
    const srv = startServer(cfg, resources, Object.assign({}, opts, { onQuit: () => { try { win && win.child.kill(); } catch (e) { /* ignore */ } srv.stop(); } }));
    let win = null;
    out('  ' + cfg.name + ' is running at http://127.0.0.1:' + srv.port + (opts && opts.dev ? '   (close the window or press Ctrl+C to stop)' : ''));
    if (sys().env('LAKER_HEADLESS')) { out('  (headless: no window, for tests)'); await srv.finished; return; }
    win = await openWindow(cfg, srv.port);
    if (win) { await win.status; try { sys().remove(win.profile, true); } catch (e) { /* ignore */ } srv.stop(); }
    else await srv.finished;
}

/* ---------------------------------------------------------------- building */
async function buildWebTo(dir, cfg, outDir) {
    const main = sys().env('SUAVE_MAIN');
    const entry = cfg.entry;
    if (/\.wsv$/i.test(entry)) {
        const r = await sys().run(D().execPath(), ['run', '-A', '--quiet', '--v8-flags=--stack-size=7000', main, 'build', dir + '/' + entry, '-o', outDir]);
        if (r.code !== 0) throw rt.rtError('Building the web app failed:\n' + r.stderr + r.stdout, 'LakerError');
    } else {
        // a hand-written index.html: copy the whole folder (without the Laker files) and add suave.js
        const cp = (a, b) => { const st = sys().stat(a); if (st.isDir) { sys().mkdir(b, true); for (const e of sys().readDir(a)) { if (['node_modules', '.git', 'build', 'dist', '.laker-dev'].includes(e.name) || e.name.endsWith('.app')) continue; cp(a + '/' + e.name, b + '/' + e.name); } } else sys().copy(a, b); };
        cp(dir, outDir);
        const bundle = sys().env('SUAVE_ROOT') + '/dist/suave.js';
        if (sys().exists(bundle) && !sys().exists(outDir + '/suave.js')) sys().copy(bundle, outDir + '/suave.js');
    }
}

export async function laker_dev(dir) {
    const cfg = readConfig(dir);
    const res = dir + '/.laker-dev';
    sys().mkdir(res, true);
    out('Building ' + cfg.name + '...');
    try { sys().remove(res + '/web', true); } catch (e) { /* ignore */ }
    await buildWebTo(dir, cfg, res + '/web');
    if (cfg.backend && sys().exists(dir + '/' + cfg.backend)) sys().copy(dir + '/' + cfg.backend, res + '/' + cfg.backend);
    await runApp(cfg, res, { dev: true });
}

export async function laker_build(dir, flags) {
    const cfg = readConfig(dir);
    const os = sys().os();
    const outRoot = dir + '/build';
    out('Building ' + cfg.name + ' ' + cfg.version + ' for ' + osName() + '...');
    sys().mkdir(outRoot, true);
    const stage = outRoot + '/stage';
    try { sys().remove(stage, true); } catch (e) { /* ignore */ }
    sys().mkdir(stage, true);
    await buildWebTo(dir, cfg, stage + '/web');
    if (cfg.backend && sys().exists(dir + '/' + cfg.backend)) sys().copy(dir + '/' + cfg.backend, stage + '/' + cfg.backend);
    sys().writeText(stage + '/laker.suvl', sys().readText(dir + '/laker.suvl'));
    // the program: the Suave runtime and the Laker server in one file
    const root = sys().env('SUAVE_ROOT');
    const exeName = slug(cfg.name).replace(/\s+/g, '-');
    out('  Compiling the program (this takes a little while)...');
    const exePath = stage + '/' + exeName + (os === 'windows' ? '.exe' : '');
    const r = await sys().run(D().execPath(), ['compile', '-A', '--quiet', '--no-check', '--output', exePath, root + '/src/laker_main.js']);
    if (r.code !== 0) throw rt.rtError('Compiling failed:\n' + r.stderr, 'LakerError');
    if (os === 'darwin') {
        const app = outRoot + '/' + slug(cfg.name) + '.app';
        try { sys().remove(app, true); } catch (e) { /* ignore */ }
        sys().mkdir(app + '/Contents/MacOS', true); sys().mkdir(app + '/Contents/Resources', true);
        sys().rename(exePath, app + '/Contents/MacOS/' + exeName);
        for (const e of sys().readDir(stage)) sys().rename(stage + '/' + e.name, app + '/Contents/Resources/' + e.name);
        let iconKey = '';
        if (cfg.icon && sys().exists(dir + '/' + cfg.icon)) {
            const iconset = outRoot + '/icon.iconset';
            sys().mkdir(iconset, true);
            for (const [s, n] of [[16, 'icon_16x16'], [32, 'icon_16x16@2x'], [32, 'icon_32x32'], [64, 'icon_32x32@2x'], [128, 'icon_128x128'], [256, 'icon_128x128@2x'], [256, 'icon_256x256'], [512, 'icon_256x256@2x'], [512, 'icon_512x512']]) sys().runSync('sips', ['-z', String(s), String(s), dir + '/' + cfg.icon, '--out', iconset + '/' + n + '.png']);
            const ic = sys().runSync('iconutil', ['-c', 'icns', iconset, '-o', app + '/Contents/Resources/AppIcon.icns']);
            try { sys().remove(iconset, true); } catch (e) { /* ignore */ }
            if (ic.code === 0) iconKey = '\n  <key>CFBundleIconFile</key><string>AppIcon</string>';
        }
        sys().writeText(app + '/Contents/Info.plist', `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>${cfg.name}</string>
  <key>CFBundleDisplayName</key><string>${cfg.name}</string>
  <key>CFBundleIdentifier</key><string>${cfg.id}</string>
  <key>CFBundleVersion</key><string>${cfg.version}</string>
  <key>CFBundleShortVersionString</key><string>${cfg.version}</string>
  <key>CFBundleExecutable</key><string>${exeName}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>NSHighResolutionCapable</key><true/>${iconKey}
</dict></plist>
`);
        try { sys().remove(stage, true); } catch (e) { /* ignore */ }
        sys().runSync('xattr', ['-cr', app]);
        out('\nDone! Your app: ' + app + '\n  Double-click it in Finder, or run:  laker run');
        if (flags.includes('--dmg')) {
            const dmg = outRoot + '/' + slug(cfg.name) + '-' + cfg.version + '.dmg';
            try { sys().remove(dmg, false); } catch (e) { /* ignore */ }
            const h = sys().runSync('hdiutil', ['create', '-volname', cfg.name, '-srcfolder', app, '-ov', '-format', 'UDZO', dmg]);
            out(h.code === 0 ? '  Disk image: ' + dmg : '  The disk image failed: ' + h.stderr);
        }
    } else {
        const folder = outRoot + '/' + slug(cfg.name) + '-' + osName();
        try { sys().remove(folder, true); } catch (e) { /* ignore */ }
        sys().mkdir(folder, true);
        sys().rename(exePath, folder + '/' + exeName + (os === 'windows' ? '.exe' : ''));
        sys().mkdir(folder + '/resources', true);
        for (const e of sys().readDir(stage)) if (e.name !== exeName && e.name !== exeName + '.exe') sys().rename(stage + '/' + e.name, folder + '/resources/' + e.name);
        try { sys().remove(stage, true); } catch (e) { /* ignore */ }
        out('\nDone! Your app: ' + folder + '/' + exeName + (os === 'windows' ? '.exe' : '') + '\n  Keep the resources folder beside the program.');
    }
}

export async function laker_run(dir) {
    const cfg = readConfig(dir);
    const os = sys().os();
    const app = dir + '/build/' + slug(cfg.name) + '.app';
    if (os === 'darwin' && sys().exists(app)) { await sys().run('open', ['-W', app]); return; }
    const exe = dir + '/build/' + slug(cfg.name) + '-' + osName() + '/' + slug(cfg.name).replace(/\s+/g, '-') + (os === 'windows' ? '.exe' : '');
    if (!sys().exists(exe)) throw rt.rtError('There is no built app yet. Run:  laker build', 'LakerError');
    await sys().run(exe, []);
}

export async function lakerMain(argv) {
    const cmd = argv[0], dir = sys().cwd();
    try {
        if (!cmd || cmd === 'help' || cmd === '--help') { out('laker init [name]   laker dev   laker build [--dmg]   laker run\nDesktop apps for Suave: a web app in its own window, plus an optional backend.sv.'); return; }
        if (cmd === 'init') return laker_init(dir, argv.slice(1).join(' '));
        if (cmd === 'dev') return await laker_dev(dir);
        if (cmd === 'build') return await laker_build(dir, argv.slice(1));
        if (cmd === 'run') return await laker_run(dir);
        eout('I do not know the laker command "' + cmd + '". Try: init, dev, build, run');
        sys().exit(1);
    } catch (e) { eout((e && e.message) || String(e)); sys().exit(1); }
}
