/* The program inside a built Laker app (compiled with deno compile). It finds its resources next to itself and runs the app. */
import './index.js';
import rt from './runtime.js';
import { runApp, readConfig } from './laker.js';

const exe = Deno.execPath();
const resources = Deno.env.get('LAKER_RESOURCES') || (exe.includes('.app/Contents/MacOS/') ? exe.replace(/\/MacOS\/[^/]*$/, '/Resources') : exe.replace(/\/[^/]*$/, '/resources'));
try {
    const cfg = readConfig(resources);
    await runApp(cfg, resources, {});
} catch (e) {
    rt.sys.errOut(((e && e.message) || String(e)) + '\n');
    Deno.exit(1);
}
