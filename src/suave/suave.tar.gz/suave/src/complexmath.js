/* Complex number maths for Suave: the operators and functions behind 3 + 4i. */
import rt from './runtime.js';

const { SComplex, rtError } = rt;
export const C = (re, im) => new SComplex(re, im);
export const isC = (x) => x instanceof SComplex;
export const lift = (x) => {
    if (x instanceof SComplex) return x;
    if (typeof x === 'number') return new SComplex(x, 0);
    if (typeof x === 'bigint') return new SComplex(Number(x), 0);
    throw rtError('Cannot do complex maths with a ' + rt.typeOf(x), 'TypeError');
};
export const add = (a, b) => C(a.re + b.re, a.im + b.im);
export const sub = (a, b) => C(a.re - b.re, a.im - b.im);
export const mul = (a, b) => C(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re);
export function div(a, b) {
    const d = b.re * b.re + b.im * b.im;
    if (d === 0) throw rtError('Cannot divide by zero', 'MathError');
    return C((a.re * b.re + a.im * b.im) / d, (a.im * b.re - a.re * b.im) / d);
}
export const neg = (a) => C(-a.re, -a.im);
export const conj = (a) => C(a.re, -a.im);
export const abs = (a) => Math.hypot(a.re, a.im);
export const arg = (a) => Math.atan2(a.im, a.re);
export const norm2 = (a) => a.re * a.re + a.im * a.im;
export const fromPolar = (r, t) => C(r * Math.cos(t), r * Math.sin(t));
export const exp = (a) => { const e = Math.exp(a.re); return C(e * Math.cos(a.im), e * Math.sin(a.im)); };
export function ln(a) {
    if (a.re === 0 && a.im === 0) throw rtError('The logarithm of 0 does not exist', 'MathError');
    return C(Math.log(abs(a)), arg(a));
}
export function sqrt(a) {
    if (a.im === 0) return a.re >= 0 ? C(Math.sqrt(a.re), 0) : C(0, Math.sqrt(-a.re));
    const r = abs(a);
    const re = Math.sqrt((r + a.re) / 2), im = Math.sqrt((r - a.re) / 2);
    return C(re, a.im < 0 ? -im : im);
}
export function pow(a, b) {
    if (b.im === 0 && Number.isInteger(b.re) && Math.abs(b.re) <= 1024) {
        let n = Math.abs(b.re), r = C(1, 0), base = a;
        while (n > 0) { if (n & 1) r = mul(r, base); base = mul(base, base); n >>= 1; }
        return b.re < 0 ? div(C(1, 0), r) : r;
    }
    if (a.re === 0 && a.im === 0) { if (b.re > 0) return C(0, 0); throw rtError('0 cannot be raised to that power', 'MathError'); }
    return exp(mul(b, ln(a)));
}
export const sin = (a) => C(Math.sin(a.re) * Math.cosh(a.im), Math.cos(a.re) * Math.sinh(a.im));
export const cos = (a) => C(Math.cos(a.re) * Math.cosh(a.im), -Math.sin(a.re) * Math.sinh(a.im));
export const tan = (a) => div(sin(a), cos(a));
export const sinh = (a) => C(Math.sinh(a.re) * Math.cos(a.im), Math.cosh(a.re) * Math.sin(a.im));
export const cosh = (a) => C(Math.cosh(a.re) * Math.cos(a.im), Math.sinh(a.re) * Math.sin(a.im));
export const tanh = (a) => div(sinh(a), cosh(a));
export function roots(a, n) {
    const r = Math.pow(abs(a), 1 / n), t = arg(a);
    return Array.from({ length: n }, (_, k) => fromPolar(r, (t + 2 * Math.PI * k) / n));
}
// the operator + - * / ** with a number on either side
export function binop(op, a, b) {
    const x = lift(a), y = lift(b);
    switch (op) {
        case '+': return add(x, y); case '-': return sub(x, y); case '*': return mul(x, y); case '/': return div(x, y); case '**': return pow(x, y);
        case '%': throw rtError('Complex numbers have no remainder (%)', 'TypeError');
    }
    throw rtError('Complex numbers cannot be put in order (' + op + '). Compare abs(z) or re(z) instead', 'TypeError');
}
export function parse(text) {
    const t = String(text).replace(/\s+/g, '').replace(/j/g, 'i');
    const pure = /^([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|[+-]?)i$/.exec(t);
    if (pure) return C(0, pure[1] === '' || pure[1] === '+' ? 1 : pure[1] === '-' ? -1 : Number(pure[1]));
    let m = /^([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)?(?:([+-]?(?:\d+\.?\d*|\.\d+)?(?:[eE][+-]?\d+)?)i)?$/.exec(t);
    if (!m || t === '') throw rtError('"' + text + '" is not a complex number like 3+4i', 'ValueError');
    const re = m[1] === undefined ? 0 : Number(m[1]);
    let im = 0;
    if (m[2] !== undefined) im = m[2] === '' || m[2] === '+' ? 1 : m[2] === '-' ? -1 : Number(m[2]);
    return C(re, im);
}
// Fast Fourier Transform (any length: powers of two use the fast way)
export function fft(xs, inverse) {
    const n = xs.length;
    if (n <= 1) return xs.slice();
    if (n & (n - 1)) {
        const out = [];
        for (let k = 0; k < n; k++) { let s = C(0, 0); for (let t = 0; t < n; t++) s = add(s, mul(xs[t], fromPolar(1, ((inverse ? 2 : -2) * Math.PI * k * t) / n))); out.push(inverse ? C(s.re / n, s.im / n) : s); }
        return out;
    }
    const go = (a) => {
        const m = a.length;
        if (m === 1) return a;
        const ev = go(a.filter((_, i) => i % 2 === 0)), od = go(a.filter((_, i) => i % 2 === 1));
        const out = new Array(m);
        for (let k = 0; k < m / 2; k++) { const w = mul(fromPolar(1, ((inverse ? 2 : -2) * Math.PI * k) / m), od[k]); out[k] = add(ev[k], w); out[k + m / 2] = sub(ev[k], w); }
        return out;
    };
    const r = go(xs);
    return inverse ? r.map((z) => C(z.re / n, z.im / n)) : r;
}
