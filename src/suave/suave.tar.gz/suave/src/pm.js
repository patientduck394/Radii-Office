/* The Suave package manager (suave init / add / install / remove / list / update / pack / publish / search / info / registry).
   A package is a folder with a suave.suvl file. Installed packages live in suave_modules/<name>/ and are used with: use name  (or use name.file).
   Where packages come from:  name or name@^1.2   (a registry: a SUVL index file, in a folder or on a web server)
                              path:../folder      (a folder on this computer)
                              https://host/x.tar.gz   (a tarball)
                              github:user/repo or github:user/repo@tag   (GitHub's source tarball)
   suave.lock.suvl records exactly what was installed, with a SHA-256 checksum for every download. */
import rt from './runtime.js';
import * as suvl from './formats/suvl.js';
import { stdlib } from './stdlib/index.js';

const { SMap, rtError } = rt;
const sv = () => stdlib['std.semver'](rt);
const MANIFEST = 'suave.suvl', LOCK = 'suave.lock.suvl', MODULES = 'suave_modules';
const SKIP = new Set(['suave_modules', '.git', 'node_modules', 'dist', '.DS_Store', LOCK]);
const enc = new TextEncoder(), dec = new TextDecoder();
const sys = () => rt.needSys('the package manager');
const joinp = (...a) => a.filter((x) => x !== '').join('/').replace(/\/+/g, '/');
const isUrl = (s) => /^https?:\/\//i.test(s) || /^file:\/\//i.test(s);

// ---------- tar and gzip ----------
async function gzip(bytes) { return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer()); }
async function gunzip(bytes) { return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer()); }
export async function sha256(bytes) { const d = await crypto.subtle.digest('SHA-256', bytes); return Array.from(new Uint8Array(d), (b) => b.toString(16).padStart(2, '0')).join(''); }
const octal = (n, len) => n.toString(8).padStart(len - 1, '0') + '\0';
export function writeTar(files) {
    const blocks = [];
    for (const f of files) {
        const h = new Uint8Array(512);
        let name = f.path, prefix = '';
        if (enc.encode(name).length > 100) { const i = name.lastIndexOf('/', name.length - 1); const cut = name.slice(0, 155).lastIndexOf('/'); if (cut > 0 && name.length - cut - 1 <= 100) { prefix = name.slice(0, cut); name = name.slice(cut + 1); } else throw rtError('The file name is too long for a package: ' + f.path, 'PackageError'); void i; }
        const put = (str, off) => h.set(enc.encode(str), off);
        put(name, 0); put('0000644\0', 100); put('0000000\0', 108); put('0000000\0', 116); put(octal(f.data.length, 12), 124); put(octal(0, 12), 136);
        put('        ', 148); put('0', 156); put('ustar\0', 257); put('00', 263); put(prefix, 345);
        let sum = 0; for (const b of h) sum += b;
        put(octal(sum, 7), 148); h[155] = 32;
        blocks.push(h, f.data, new Uint8Array((512 - (f.data.length % 512)) % 512));
    }
    blocks.push(new Uint8Array(1024));
    const total = blocks.reduce((n, b) => n + b.length, 0);
    const out = new Uint8Array(total);
    let o = 0; for (const b of blocks) { out.set(b, o); o += b.length; }
    return out;
}
export function readTar(bytes) {
    const files = [];
    let o = 0, longName = null, paxPath = null;
    const str = (a, b) => { let e = a; while (e < b && bytes[e] !== 0) e++; return dec.decode(bytes.subarray(a, e)); };
    while (o + 512 <= bytes.length) {
        if (bytes.subarray(o, o + 512).every((b) => b === 0)) break;
        const type = String.fromCharCode(bytes[o + 156] || 48);
        const size = parseInt(str(o + 124, o + 136).trim() || '0', 8);
        let name = str(o, o + 100);
        const prefix = str(o + 345, o + 500);
        if (prefix) name = prefix + '/' + name;
        const data = bytes.subarray(o + 512, o + 512 + size);
        o += 512 + Math.ceil(size / 512) * 512;
        if (type === 'L') { longName = dec.decode(data).replace(/\0.*$/, ''); continue; }
        if (type === 'x') { const m = /(?:^|\n)\d+ path=([^\n]*)\n/.exec(dec.decode(data)); if (m) paxPath = m[1]; continue; }
        if (type === 'g') continue;
        if (longName) { name = longName; longName = null; }
        if (paxPath) { name = paxPath; paxPath = null; }
        if (type === '0' || type === '\0') files.push({ path: name, data: data.slice() });
        else if (type === '2' || type === '1') throw rtError('The package contains a link (' + name + '), which is not allowed', 'PackageError');
    }
    return files;
}
// a safe, relative path with the single top folder (like repo-v1.0/) removed
function cleanFiles(files) {
    const clean = files.map((f) => ({ path: f.path.replace(/^\.\//, ''), data: f.data }));
    for (const f of clean) if (f.path.startsWith('/') || f.path.split('/').includes('..') || /^[A-Za-z]:/.test(f.path)) throw rtError('The package has an unsafe file path (' + f.path + '), so I will not unpack it', 'PackageError');
    const tops = new Set(clean.map((f) => f.path.split('/')[0]));
    if (tops.size === 1 && clean.every((f) => f.path.includes('/')) && !clean.some((f) => f.path === MANIFEST)) { const t = [...tops][0]; return clean.map((f) => ({ path: f.path.slice(t.length + 1), data: f.data })).filter((f) => f.path); }
    return clean;
}

// ---------- files and manifests ----------
function listFiles(dir, base) {
    const s = sys(); const out = [];
    const go = (d, rel) => { for (const e of s.readDir(d).sort((a, b) => (a.name < b.name ? -1 : 1))) { if (SKIP.has(e.name) || e.name.startsWith('.')) continue; const p = d + '/' + e.name, r = rel ? rel + '/' + e.name : e.name; if (e.isDir) go(p, r); else out.push({ path: r, data: s.readBytes(p) }); } };
    go(dir, base || '');
    return out;
}
export function readManifest(dir) {
    const s = sys(); const p = joinp(dir || '.', MANIFEST);
    if (!s.exists(p)) return null;
    const m = suvl.parse(s.readText(p));
    if (!(m instanceof SMap)) throw rtError(p + ' must be a SUVL map', 'PackageError');
    return m;
}
export function writeManifest(dir, m) { sys().writeText(joinp(dir || '.', MANIFEST), suvl.stringify(m)); }
const depsOf = (m, key) => { const d = m && m.get(key); return d instanceof SMap ? d : new SMap(); };
function nameOk(n) { if (!/^[a-z][a-z0-9_-]{0,63}$/.test(n)) throw rtError('"' + n + '" is not a good package name. Use lowercase letters, digits, - and _, starting with a letter', 'PackageError'); return n; }

// ---------- sources ----------
export function parseSpec(spec) {
    spec = String(spec).trim();
    if (spec.startsWith('path:')) return { kind: 'path', path: spec.slice(5) };
    if (/^(\.{1,2}\/|\/)/.test(spec)) return { kind: 'path', path: spec };
    if (isUrl(spec)) return { kind: 'url', url: spec };
    let m = /^github:([\w.-]+)\/([\w.-]+?)(?:@(.+))?$/.exec(spec);
    if (m) return { kind: 'url', url: 'https://codeload.github.com/' + m[1] + '/' + m[2] + '/tar.gz/' + (m[3] || 'HEAD'), github: m[1] + '/' + m[2] + (m[3] ? '@' + m[3] : ''), suggest: m[2] };
    m = /^([a-z][a-z0-9_-]*)(?:@(.+))?$/.exec(spec);
    if (m) return { kind: 'registry', name: m[1], range: m[2] || '*' };
    throw rtError('I do not understand the package "' + spec + '". Use a name, name@^1.0, path:../folder, a tarball URL, or github:user/repo', 'PackageError');
}
async function fetchBytes(where) {
    if (isUrl(where)) {
        let r;
        try { r = await fetch(where); } catch (e) { throw rtError('I could not download ' + where + ': ' + (e.message || e), 'PackageError'); }
        if (!r.ok) throw rtError('Downloading ' + where + ' failed (' + r.status + ' ' + r.statusText + ')', 'PackageError');
        return new Uint8Array(await r.arrayBuffer());
    }
    try { return sys().readBytes(where.replace(/^file:\/\//, '')); } catch (e) { throw rtError('I could not read ' + where, 'PackageError'); }
}
const fetchText = async (where) => dec.decode(await fetchBytes(where));
const resolveRel = (base, rel) => (isUrl(rel) || rel.startsWith('/') ? rel : (isUrl(base) ? new URL(rel, base).toString() : joinp(base.replace(/[^/]*$/, ''), rel)));

// registry: a SUVL index  { packages { name { description, versions { "1.0.0" { url, sha256, deps } } } } }
export function registryLocation(project) {
    const s = sys();
    const m = readManifest(project);
    if (m && typeof m.get('registry') === 'string') return m.get('registry');
    const env = s.env('SUAVE_REGISTRY');
    if (env) return env;
    const cfg = joinp(s.home(), '.suave/config.suvl');
    if (s.exists(cfg)) { try { const c = suvl.parse(s.readText(cfg)); if (c instanceof SMap && typeof c.get('registry') === 'string') return c.get('registry'); } catch (e) { /* ignore a broken config */ } }
    return null;
}
const indexCache = new Map();
async function loadIndex(loc) {
    if (indexCache.has(loc)) return indexCache.get(loc);
    const at = /\.suvl$/.test(loc) ? loc : (isUrl(loc) ? loc.replace(/\/+$/, '') + '/index.suvl' : joinp(loc, 'index.suvl'));
    const idx = suvl.parse(await fetchText(at));
    const r = { at, packages: idx instanceof SMap && idx.get('packages') instanceof SMap ? idx.get('packages') : new SMap() };
    indexCache.set(loc, r);
    return r;
}

export class PM {
    constructor(opts) { opts = opts || {}; this.say = opts.say || (() => {}); this.dir = opts.dir || '.'; this.update = !!opts.update; this.frozen = !!opts.frozen; this.lock = new SMap(); this.oldLock = null; this.seen = new Map(); this.warnings = []; }
    modulesDir() { return joinp(this.dir, MODULES); }
    loadLock() { const p = joinp(this.dir, LOCK); const s = sys(); if (s.exists(p)) { try { const l = suvl.parse(s.readText(p)); if (l instanceof SMap && l.get('packages') instanceof SMap) return l.get('packages'); } catch (e) { /* a broken lock is rebuilt */ } } return new SMap(); }
    saveLock() { const out = new SMap(); out.set('lock_version', 1); out.set('packages', this.lock); const sorted = new SMap(); for (const k of this.lock.keys().sort()) sorted.set(k, this.lock.get(k)); out.set('packages', sorted); sys().writeText(joinp(this.dir, LOCK), suvl.stringify(out)); }

    // find where one dependency comes from and what version it is
    async resolve(name, spec, locked) {
        const src = parseSpec(spec);
        if (src.kind === 'path') {
            const base = this.dir === '.' ? '' : this.dir;
            const full = src.path.startsWith('/') ? src.path : joinp(base, src.path);
            const s = sys();
            if (!s.stat(full) || !s.stat(full).isDir) throw rtError('The folder ' + src.path + ' for "' + name + '" does not exist', 'PackageError');
            return { files: listFiles(full), version: (readManifest(full) && String(readManifest(full).get('version') || '0.0.0')) || '0.0.0', source: 'path:' + src.path, integrity: null };
        }
        if (src.kind === 'url') {
            const where = locked && locked.get('resolved') ? locked.get('resolved') : src.url;
            const bytes = await fetchBytes(where);
            const digest = await sha256(bytes);
            if (locked && locked.get('integrity') && locked.get('integrity') !== 'sha256:' + digest) throw rtError('The download for "' + name + '" does not match its checksum in ' + LOCK + '. Someone changed it. Run suave update ' + name + ' if you trust the new version', 'IntegrityError');
            const files = cleanFiles(readTar(await gunzip(bytes)));
            const man = files.find((f) => f.path === MANIFEST);
            const version = man ? String(suvl.parse(dec.decode(man.data)).get('version') || '0.0.0') : '0.0.0';
            return { files, version, source: src.github ? 'github:' + src.github : 'url:' + src.url, resolved: where, integrity: 'sha256:' + digest };
        }
        // a registry
        const loc = registryLocation(this.dir);
        if (!loc) throw rtError('Package "' + name + '" needs a registry, and none is set. Use: suave registry set <folder-or-url>   (or add path:, github: or a tarball URL)', 'PackageError');
        const idx = await loadIndex(loc);
        const entry = idx.packages.get(src.name);
        if (!(entry instanceof SMap)) throw rtError('The registry has no package called "' + src.name + '"', 'PackageError');
        const versions = entry.get('versions') instanceof SMap ? entry.get('versions') : new SMap();
        let want;
        if (locked && !this.update && versions.has(String(locked.get('version')))) want = String(locked.get('version'));
        else {
            const ok = versions.keys().map(String).filter((v) => sv().is_valid(v) && sv().satisfies(v, src.range === '*' ? '>=0.0.0' : src.range));
            if (!ok.length) throw rtError('No version of "' + src.name + '" fits ' + src.range + '. The registry has: ' + versions.keys().join(', '), 'PackageError');
            want = sv().max(ok);
        }
        const info = versions.get(want);
        const url = resolveRel(idx.at, String(info.get('url')));
        const bytes = await fetchBytes(url);
        const digest = await sha256(bytes);
        const expect = info.get('sha256') ? String(info.get('sha256')) : (locked && locked.get('integrity') ? String(locked.get('integrity')).replace(/^sha256:/, '') : null);
        if (expect && expect !== digest) throw rtError('The download for "' + src.name + '" ' + want + ' does not match its checksum (expected ' + expect.slice(0, 12) + '..., got ' + digest.slice(0, 12) + '...). I will not install it', 'IntegrityError');
        return { files: cleanFiles(readTar(await gunzip(bytes))), version: want, source: 'registry', resolved: url, integrity: 'sha256:' + digest };
    }
    // put one package (and everything it needs) into suave_modules
    async ensure(name, spec, chain) {
        nameOk(name);
        if (this.seen.has(name)) {
            const prev = this.seen.get(name);
            const src = parseSpec(spec);
            if (src.kind === 'registry' && src.range !== '*' && sv().is_valid(prev.version) && !sv().satisfies(prev.version, src.range)) this.warnings.push((chain.length ? chain.join(' > ') + ' > ' : '') + name + ' wants ' + src.range + ' but ' + prev.version + ' is installed (another package asked for it first)');
            return prev;
        }
        const locked = this.update || !this.oldLock ? null : this.oldLock.get(name);
        const lockedSame = locked instanceof SMap ? locked : null;
        this.say((chain.length ? '  '.repeat(chain.length) : '') + 'Getting ' + name + (spec && spec !== '*' ? ' (' + spec + ')' : '') + '…');
        const r = await this.resolve(name, spec, lockedSame && String(lockedSame.get('spec')) === String(spec) ? lockedSame : (lockedSame && parseSpec(spec).kind === 'registry' ? lockedSame : null));
        const s = sys();
        const target = joinp(this.modulesDir(), name);
        if (s.exists(target)) s.remove(target, true);
        s.mkdir(target, true);
        for (const f of r.files) { const p = joinp(target, f.path); const d = p.slice(0, p.lastIndexOf('/')); s.mkdir(d, true); s.writeBytes(p, f.data); }
        const man = readManifest(target);
        const entry = { name, version: r.version };
        this.seen.set(name, entry);
        const deps = depsOf(man, 'deps');
        const lockEntry = new SMap();
        lockEntry.set('version', r.version); lockEntry.set('source', r.source); lockEntry.set('spec', String(spec));
        if (r.resolved) lockEntry.set('resolved', r.resolved);
        if (r.integrity) lockEntry.set('integrity', r.integrity);
        if (deps.size) lockEntry.set('deps', new SMap(deps.entries()));
        this.lock.set(name, lockEntry);
        for (const [dn, dspec] of deps.entries()) await this.ensure(String(dn), String(dspec), chain.concat([name]));
        return entry;
    }
    // install everything the project asks for
    async install(only) {
        const man = readManifest(this.dir);
        if (!man) throw rtError('There is no ' + MANIFEST + ' here. Run: suave init', 'PackageError');
        const old = this.loadLock();
        const want = new SMap([...depsOf(man, 'deps').entries(), ...depsOf(man, 'dev_deps').entries()]);
        if (this.frozen) {
            for (const [n, sp] of want.entries()) {
                const l = old.get(n), ps = parseSpec(String(sp));
                if (!(l instanceof SMap) || (ps.kind === 'registry' && !sv().satisfies(String(l.get('version')), ps.range === '*' ? '>=0.0.0' : ps.range))) throw rtError(LOCK + ' is out of date for "' + n + '". Run suave install (without --frozen) and keep the new lock', 'PackageError');
            }
        }
        this.oldLock = old;          // what ensure() may reuse
        this.lock = new SMap();      // what this install actually did
        this.seen = new Map();
        for (const [n, sp] of want.entries()) { if (only && !only.includes(String(n))) continue; await this.ensure(String(n), String(sp), []); }
        // forget packages that nothing asks for any more
        const s = sys();
        const keepNames = new Set(this.lock.keys().map(String));
        if (!only && s.exists(this.modulesDir())) for (const e of s.readDir(this.modulesDir())) if (e.isDir && !keepNames.has(e.name)) s.remove(joinp(this.modulesDir(), e.name), true);
        if (!only) this.saveLock();
        return this.lock;
    }
    async add(specs, dev) {
        const dir = this.dir;
        let man = readManifest(dir);
        if (!man) { man = new SMap(); man.set('name', 'app'); man.set('version', '0.1.0'); man.set('entry', 'main.sv'); }
        const key = dev ? 'dev_deps' : 'deps';
        const deps = depsOf(man, key);
        const added = [];
        for (const raw of specs) {
            const parsed = parseSpec(raw);
            let name = parsed.kind === 'registry' ? parsed.name : null;
            let spec = raw;
            if (parsed.kind === 'path') { const m = readManifest(parsed.path.startsWith('/') ? parsed.path : joinp(dir === '.' ? '' : dir, parsed.path)); name = m ? String(m.get('name')) : parsed.path.split('/').filter(Boolean).pop(); spec = 'path:' + parsed.path; }
            else if (parsed.kind === 'url') { name = parsed.suggest || (parsed.url.split('/').pop() || 'pkg').replace(/(\.tar\.gz|\.tgz)$/, '').replace(/-\d.*$/, ''); }
            name = nameOk(name.toLowerCase().replace(/[^a-z0-9_-]/g, '-'));
            deps.set(name, spec);
            added.push(name);
        }
        man.set(key, deps);
        writeManifest(dir, man);
        await this.install(null);
        // a registry package is recorded with a compatible range (^1.2.3) instead of "*"
        const lock = this.loadLock();
        let changed = false;
        for (const name of added) {
            const sp = String(deps.get(name));
            if (parseSpec(sp).kind === 'registry' && !/@/.test(sp)) { const l = lock.get(name); if (l) { deps.set(name, name + '@^' + l.get('version')); changed = true; } }
        }
        if (changed) { man.set(key, deps); writeManifest(dir, man); this.lock = lock; this.saveLock(); }
        return added.map((n) => ({ name: n, version: String(lock.get(n).get('version')) }));
    }
    async remove(names) {
        const man = readManifest(this.dir);
        if (!man) throw rtError('There is no ' + MANIFEST + ' here', 'PackageError');
        for (const key of ['deps', 'dev_deps']) { const d = depsOf(man, key); let ch = false; for (const n of names) if (d.has(n)) { d.delete(n); ch = true; } if (ch) man.set(key, d); }
        for (const n of names) { if (!depsOf(man, 'deps').has(n) && !depsOf(man, 'dev_deps').has(n) && !this.loadLock().has(n) && !sys().exists(joinp(this.modulesDir(), n))) throw rtError('"' + n + '" is not installed here', 'PackageError'); }
        writeManifest(this.dir, man);
        await this.install(null);
    }
    // the installed packages as a list of {name, version, source, deps}
    list() {
        const lock = this.loadLock();
        const man = readManifest(this.dir);
        const direct = new Set([...depsOf(man, 'deps').keys(), ...depsOf(man, 'dev_deps').keys()].map(String));
        return lock.keys().map(String).sort().map((n) => { const l = lock.get(n); const d = l.get('deps'); return { name: n, version: String(l.get('version')), source: String(l.get('source')), direct: direct.has(n), deps: d instanceof SMap ? d.keys().map(String) : [] }; });
    }
    // pack this project into dist/<name>-<version>.tar.gz
    async pack(out) {
        const man = readManifest(this.dir);
        if (!man) throw rtError('There is no ' + MANIFEST + ' here. Run: suave init', 'PackageError');
        const name = nameOk(String(man.get('name'))), version = String(man.get('version'));
        if (!sv().is_valid(version)) throw rtError('The version "' + version + '" in ' + MANIFEST + ' is not like 1.2.3', 'PackageError');
        const entry = man.get('entry');
        const s = sys();
        if (entry && !s.exists(joinp(this.dir, String(entry)))) throw rtError('The entry file ' + entry + ' named in ' + MANIFEST + ' is missing', 'PackageError');
        const files = listFiles(this.dir === '.' ? '.' : this.dir, '');
        if (!files.some((f) => f.path === MANIFEST)) files.push({ path: MANIFEST, data: enc.encode(suvl.stringify(man)) });
        const total = files.reduce((n, f) => n + f.data.length, 0);
        if (total > 20 * 1024 * 1024) throw rtError('The package is ' + Math.round(total / 1048576) + ' MB, over the 20 MB limit', 'PackageError');
        const tgz = await gzip(writeTar(files.map((f) => ({ path: name + '-' + version + '/' + f.path, data: f.data }))));
        const outDir = out || joinp(this.dir, 'dist');
        s.mkdir(outDir, true);
        const file = joinp(outDir, name + '-' + version + '.tar.gz');
        s.writeBytes(file, tgz);
        return { file, name, version, files: files.length, bytes: tgz.length, sha256: await sha256(tgz), man };
    }
    // publish into a registry folder (host that folder anywhere, for example on a static web host)
    async publish(registryDir) {
        const s = sys();
        const idxPath = joinp(registryDir, 'index.suvl');
        let idx = new SMap();
        if (s.exists(idxPath)) idx = suvl.parse(s.readText(idxPath));
        if (!(idx instanceof SMap)) idx = new SMap();
        // look for a clash before anything is written: a published version must never change
        const man = readManifest(this.dir);
        if (!man) throw rtError('There is no ' + MANIFEST + ' here. Run: suave init', 'PackageError');
        const pname = nameOk(String(man.get('name'))), pversion = String(man.get('version'));
        const existing = idx.get('packages') instanceof SMap && idx.get('packages').get(pname) instanceof SMap ? idx.get('packages').get(pname).get('versions') : null;
        if (existing instanceof SMap && existing.has(pversion)) throw rtError(pname + ' ' + pversion + ' is already published here. Change "version" in ' + MANIFEST + ' (published versions cannot change)', 'PackageError');
        const packed = await this.pack(joinp(registryDir, 'packages'));
        if (!idx.has('name')) idx.set('name', 'suave registry');
        const pkgs = idx.get('packages') instanceof SMap ? idx.get('packages') : new SMap();
        const entry = pkgs.get(packed.name) instanceof SMap ? pkgs.get(packed.name) : new SMap();
        const versions = entry.get('versions') instanceof SMap ? entry.get('versions') : new SMap();
        const v = new SMap();
        v.set('url', 'packages/' + packed.name + '-' + packed.version + '.tar.gz'); v.set('sha256', packed.sha256);
        const d = depsOf(packed.man, 'deps'); if (d.size) v.set('deps', new SMap(d.entries()));
        versions.set(packed.version, v);
        entry.set('description', String(packed.man.get('description') || ''));
        if (packed.man.get('license')) entry.set('license', String(packed.man.get('license')));
        entry.set('versions', versions);
        pkgs.set(packed.name, entry);
        idx.set('packages', pkgs);
        s.writeText(idxPath, suvl.stringify(idx));
        return packed;
    }
    async search(text, loc) {
        const where = loc || registryLocation(this.dir);
        if (!where) throw rtError('No registry is set. Use: suave registry set <folder-or-url>', 'PackageError');
        const idx = await loadIndex(where);
        const q = String(text || '').toLowerCase();
        return idx.packages.entries().map(([n, e]) => ({ name: String(n), description: String(e.get('description') || ''), versions: e.get('versions') instanceof SMap ? e.get('versions').keys().map(String) : [] })).filter((p) => !q || p.name.includes(q) || p.description.toLowerCase().includes(q)).sort((a, b) => (a.name < b.name ? -1 : 1));
    }
}
export function initProject(dir, name) {
    const s = sys();
    const p = joinp(dir || '.', MANIFEST);
    if (s.exists(p)) throw rtError(MANIFEST + ' already exists here', 'PackageError');
    const m = new SMap();
    const nm = name || ((s.cwd().split('/').pop() || 'app').toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/^[^a-z]+/, '') || 'app');
    m.set('name', nameOk(nm)); m.set('version', '0.1.0'); m.set('description', ''); m.set('entry', 'main.sv'); m.set('deps', new SMap());
    writeManifest(dir, m);
    return m;
}
export function setRegistry(loc) {
    const s = sys();
    const dir = joinp(s.home(), '.suave'), file = dir + '/config.suvl';
    s.mkdir(dir, true);
    let cfg = new SMap();
    if (s.exists(file)) { try { const c = suvl.parse(s.readText(file)); if (c instanceof SMap) cfg = c; } catch (e) { /* start over */ } }
    cfg.set('registry', loc === null ? null : (isUrl(loc) || loc.startsWith('/') ? loc : s.realPath(loc)));
    s.writeText(file, suvl.stringify(cfg));
    return cfg.get('registry');
}

// ---------- finding an installed package when a program says: use name  /  use name.file ----------
export function findPackageFile(parts, fromFile) {
    const s = rt.sys;
    if (!s) return null;
    let dir = fromFile && fromFile.includes('/') ? fromFile.slice(0, fromFile.lastIndexOf('/')) : s.cwd();
    if (!dir.startsWith('/')) dir = s.cwd() + '/' + dir;
    for (let guard = 0; guard < 40; guard++) {
        const base = dir + '/' + MODULES + '/' + parts[0];
        const st = s.stat(base);
        if (st && st.isDir) {
            if (parts.length > 1) { const rel = base + '/' + parts.slice(1).join('/'); if (s.stat(rel + '.sv')) return rel + '.sv'; if (s.stat(rel + '/main.sv')) return rel + '/main.sv'; return null; }
            let entry = null;
            try { const m = readManifest(base); if (m && m.get('entry')) entry = String(m.get('entry')); } catch (e) { /* use the default names */ }
            for (const cand of [entry, 'main.sv', 'lib.sv', 'index.sv', parts[0] + '.sv']) if (cand && s.stat(base + '/' + cand)) return base + '/' + cand;
            return null;
        }
        const up = dir.slice(0, dir.lastIndexOf('/'));
        if (up === dir || dir === '' || dir === '/') break;
        dir = up || '/';
    }
    return null;
}
