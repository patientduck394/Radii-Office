/* The global functions every Suave program can use without a "use": print, len, str, range, and friends. */
import rt from './runtime.js';
import { call, callMethod, binop, makePool, makePartial, HOLE } from './interp.js';
import { regex, entangle } from './methods.js';
import * as CX from './complexmath.js';

const { SComplex, SPool, Tuple, tuple, SRange, SIter, SMap, SSet, SObj, SVariant, SFn, Bound, SType, VariantCtor, ResultT, ok, err, rtError, SuaveError, eq, cmp, truthy, repr, show, iterate, toArray, typeOf, formatSpec, fmtNum, sym } = rt;

function deepCopy(v) {
    if (Array.isArray(v)) { const r = Array.from(v, deepCopy); return v instanceof Tuple ? tuple(r) : r; }
    if (v instanceof SMap) { const m = new SMap(); for (const [k, x] of v.entries()) m.set(deepCopy(k), deepCopy(x)); return m; }
    if (v instanceof SSet) return new SSet(v.values().map(deepCopy));
    if (v instanceof SObj) { const f = Object.create(null); for (const k of Object.keys(v.f)) f[k] = deepCopy(v.f[k]); return new SObj(v.type, f); }
    if (v instanceof SVariant) return new SVariant(v.type, v.v, v.vals.map(deepCopy));
    if (v instanceof Date) return new Date(v.getTime());
    if (v instanceof Uint8Array) return v.slice();
    return v;
}
const isCallable = (f) => typeof f === 'function' || f instanceof SFn || f instanceof Bound || f instanceof VariantCtor || f instanceof SType;
const needNum = (x, fn) => { if (typeof x !== 'number') throw rtError(fn + ' needs a number but got ' + typeOf(x), 'TypeError'); return x; };

export function makeGlobals() {
    const g = {};
    const out = (s) => rt.write(s);
    g.print = (...a) => { out(a.map(show).join(' ') + '\n'); return null; };
    g.println = g.print;
    g.write = (...a) => { out(a.map(show).join('')); return null; };
    g.eprint = (...a) => { rt.ewrite(a.map(show).join(' ') + '\n'); return null; };
    g.input = (p) => { rt.needSys('input'); const r = rt.sys.readLine(p === undefined ? '' : show(p)); return r; };
    g.dbg = (x) => { rt.ewrite('[line ' + rt.state.line + '] ' + repr(x) + '\n'); return x; };
    g.len = (x) => {
        if (typeof x === 'string') return /[\ud800-\udfff]/.test(x) ? Array.from(x).length : x.length;
        if (Array.isArray(x) || x instanceof Uint8Array) return x.length;
        if (x instanceof SMap || x instanceof SSet) return x.size;
        if (x instanceof SRange) return x.size;
        if (x instanceof SObj && x.type.methods.has('len')) return callMethod(x, 'len', []);
        throw rtError('len does not work on a ' + typeOf(x), 'TypeError');
    };
    g.str = (x) => show(x);
    g.repr = (x) => repr(x);
    g.fmt = (x, spec) => formatSpec(x, spec);
    g.type = (x) => typeOf(x);
    g.int = (x, base) => {
        if (typeof x === 'number') { if (!Number.isFinite(x)) throw rtError('Cannot make ' + fmtNum(x) + ' a whole number', 'ValueError'); return Math.trunc(x); }
        if (typeof x === 'boolean') return x ? 1 : 0;
        if (typeof x === 'bigint') return Number(x);
        if (typeof x === 'string') { const t = x.trim().replace(/_/g, ''); const r = base ? parseInt(t, base) : (/^[+-]?0x/i.test(t) ? parseInt(t, 16) : /^[+-]?\d+(\.\d*)?([eE][+-]?\d+)?$/.test(t) ? Math.trunc(Number(t)) : NaN); if (Number.isNaN(r)) throw rtError('"' + x + '" is not a whole number', 'ValueError'); return r; }
        throw rtError('Cannot turn a ' + typeOf(x) + ' into an int', 'TypeError');
    };
    g.float = (x) => {
        if (typeof x === 'number') return x;
        if (typeof x === 'boolean') return x ? 1 : 0;
        if (typeof x === 'bigint') return Number(x);
        if (typeof x === 'string') { const t = x.trim().replace(/_/g, ''); if (/^[+-]?inf(inity)?$/i.test(t)) return t[0] === '-' ? -Infinity : Infinity; if (/^nan$/i.test(t)) return NaN; if (!/^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(t)) throw rtError('"' + x + '" is not a number', 'ValueError'); return Number(t); }
        throw rtError('Cannot turn a ' + typeOf(x) + ' into a number', 'TypeError');
    };
    g.num = g.float;
    g.bool = (x) => truthy(x);
    g.big = (x) => { try { return BigInt(typeof x === 'string' ? x.trim() : Math.trunc(x)); } catch (e) { throw rtError('Cannot make ' + repr(x) + ' a big integer', 'ValueError'); } };
    g.sym = (x) => sym(show(x));
    g.range = (a, b, c) => { if (b === undefined) return new SRange(0, needNum(a, 'range'), false, 1); return new SRange(needNum(a, 'range'), needNum(b, 'range'), false, c === undefined ? 1 : c); };
    g.list = (x) => (x === undefined ? [] : Array.from(toArray(x)));
    g.tuple = (x) => (x === undefined ? tuple([]) : tuple(Array.from(toArray(x))));
    g.set = (x) => new SSet(x === undefined ? [] : iterate(x));
    g.dict = (x) => { const m = new SMap(); if (x === undefined) return m; if (x instanceof SMap) return new SMap(x.entries()); for (const p of iterate(x)) { if (!Array.isArray(p) || p.length !== 2) throw rtError('dict needs (key, value) pairs'); m.set(p[0], p[1]); } return m; };
    g.iter = (x) => (x instanceof SIter ? x : new SIter(iterate(x)[Symbol.iterator]()));
    g.repeat = (x, n) => new SIter((function* () { if (n === undefined) for (;;) yield x; else for (let i = 0; i < n; i++) yield x; })());
    g.count_from = (a, step) => new SIter((function* () { for (let i = a === undefined ? 0 : a; ; i += step === undefined ? 1 : step) yield i; })());
    g.abs = (x) => (x instanceof SComplex ? CX.abs(x) : typeof x === 'bigint' ? (x < 0n ? -x : x) : Math.abs(needNum(x, 'abs')));
    // complex numbers: 3 + 4i, complex(3, 4), re(z), im(z), conj(z), arg(z)
    g.complex = (a, b) => { if (typeof a === 'string') return CX.parse(a); return CX.C(needNum(a, 'complex'), b === undefined ? 0 : needNum(b, 'complex')); };
    g.re = (z) => (z instanceof SComplex ? z.re : needNum(z, 're'));
    g.im = (z) => (z instanceof SComplex ? z.im : (needNum(z, 'im'), 0));
    g.conj = (z) => (z instanceof SComplex ? CX.conj(z) : z);
    g.arg = (z) => (z instanceof SComplex ? CX.arg(z) : Math.atan2(0, needNum(z, 'arg')));
    g.is_complex = (z) => z instanceof SComplex;
    g.min = (...a) => { const xs = a.length === 1 && typeof a[0] !== 'number' ? toArray(a[0]) : a; if (!xs.length) return null; return xs.reduce((m, x) => (rt.cmp(x, m) < 0 ? x : m)); };
    g.max = (...a) => { const xs = a.length === 1 && typeof a[0] !== 'number' ? toArray(a[0]) : a; if (!xs.length) return null; return xs.reduce((m, x) => (rt.cmp(x, m) > 0 ? x : m)); };
    g.sum = (x, init) => { let t = init === undefined ? 0 : init; for (const y of iterate(x)) t = binop('+', t, y); return t; };
    g.round = (x, p) => { needNum(x, 'round'); const f = Math.pow(10, p || 0); return Math.sign(x) * Math.round(Math.abs(x) * f + 1e-9) / f; };
    g.floor = (x) => Math.floor(needNum(x, 'floor')); g.ceil = (x) => Math.ceil(needNum(x, 'ceil'));
    g.sqrt = (x) => (x instanceof SComplex ? CX.sqrt(x) : (needNum(x, 'sqrt') < 0 ? CX.sqrt(CX.C(x, 0)) : Math.sqrt(x))); g.pow = (a, b) => binop('**', a, b);
    g.div = (a, b) => { if (b === 0) throw rtError('Cannot divide by zero', 'MathError'); return Math.floor(a / b); };
    g.sorted = (x, ...rest) => {
        const o = rest.find((r) => r instanceof rt.Named), pos = rest.find((r) => !(r instanceof rt.Named));
        const key = o && o.obj.key !== undefined ? o.obj.key : pos;
        const rev = !!(o && (o.obj.reverse === true || o.obj.desc === true));
        const xs = toArray(x).slice();
        const f = key !== undefined && key !== null ? (v) => call(key, [v]) : (v) => v;
        return xs.map((v) => [f(v), v]).sort((p, q) => (rev ? rt.cmp(q[0], p[0]) : rt.cmp(p[0], q[0]))).map((p) => p[1]);
    };
    // isinstance(3, int), isinstance("a", str), isinstance([1], list)
    g.isinstance = (v, T) => {
        const names = new Map([[g.int, ['num']], [g.float, ['num']], [g.num, ['num']], [g.str, ['str']], [g.bool, ['bool']], [g.list, ['list']], [g.dict, ['map']], [g.set, ['set']], [g.tuple, ['tuple']]]);
        const want = names.get(T) || (T instanceof rt.SType ? null : []);
        if (T instanceof rt.SType) return v instanceof rt.SObj && v.type === T;
        return want.includes(rt.typeOf(v)) && (T !== g.int || Number.isInteger(v));
    };
    g.reversed = (x) => (typeof x === 'string' ? Array.from(x).reverse().join('') : toArray(x).slice().reverse());
    g.enumerate = (x, start) => Array.from(iterate(x), (v, i) => tuple([i + (start || 0), v]));
    g.zip = (...xs) => { const ls = xs.map((x) => toArray(x)); const n = Math.min(...ls.map((l) => l.length)); const r = []; for (let i = 0; i < n; i++) r.push(tuple(ls.map((l) => l[i]))); return r; };
    const callable = (x) => isCallable(x);
    g.map = (f, ...xs) => {
        if (!callable(f) && xs.length === 1 && callable(xs[0])) { const t = f; f = xs[0]; xs = [t]; } if (xs.length === 1) return Array.from(iterate(xs[0]), (v) => call(f, [v])); const ls = xs.map((x) => toArray(x)); const n = Math.min(...ls.map((l) => l.length)); const r = []; for (let i = 0; i < n; i++) r.push(call(f, ls.map((l) => l[i]))); return r; };
    g.filter = (f, x) => { if (!callable(f) && callable(x)) { const t = f; f = x; x = t; } return Array.from(iterate(x)).filter((v) => truthy(call(f, [v]))); };
    g.reduce = (f, x, init) => { if (!callable(f) && callable(x)) { const t = f; f = x; x = t; } const xs = toArray(x); let i = 0, acc; if (init !== undefined) acc = init; else { if (!xs.length) return null; acc = xs[0]; i = 1; } for (; i < xs.length; i++) acc = call(f, [acc, xs[i]]); return acc; };
    g.flat_map = (f, x) => { if (!callable(f) && callable(x)) { const t = f; f = x; x = t; } const r = []; for (const v of iterate(x)) { const y = call(f, [v]); if (Array.isArray(y)) r.push(...y); else r.push(y); } return r; };
    g.any = (x, f) => { for (const v of iterate(x)) if (truthy(f === undefined ? v : call(f, [v]))) return true; return false; };
    g.all = (x, f) => { for (const v of iterate(x)) if (!truthy(f === undefined ? v : call(f, [v]))) return false; return true; };
    g.chr = (n) => String.fromCodePoint(n); g.ord = (s) => s.codePointAt(0);
    g.hex = (n) => (n < 0 ? '-0x' + (-n).toString(16) : '0x' + n.toString(16));
    g.bin = (n) => (n < 0 ? '-0b' + (-n).toString(2) : '0b' + n.toString(2));
    g.oct = (n) => (n < 0 ? '-0o' + (-n).toString(8) : '0o' + n.toString(8));
    g.ok = ok; g.err = err; g.Ok = ok; g.Err = err;
    g.is_none = (x) => x === null || x === undefined;
    g.identity = (x) => x;
    g.callable = (x) => isCallable(x);
    g.clone = deepCopy;
    g.keys = (m) => (m instanceof SMap ? m.keys() : Object.keys(m.f)); g.values = (m) => (m instanceof SMap ? m.values() : Object.keys(m.f).map((k) => m.f[k]));
    g.items = (m) => (m instanceof SMap ? m.entries() : Object.keys(m.f).map((k) => tuple([k, m.f[k]])));
    g.error = (msg, extra) => { const m = new SMap(); m.set('kind', 'Error'); m.set('message', show(msg)); if (extra instanceof SMap) for (const [k, v] of extra.entries()) m.set(k, v); return m; };
    g.panic = (msg) => { throw new SuaveError(show(msg === undefined ? 'panic' : msg), 'Panic'); };
    g.assert = (c, msg) => { if (!truthy(c)) throw new SuaveError(msg === undefined ? 'Assertion failed' : show(msg), 'AssertionError'); return null; };
    g.assert_eq = (a, b, msg) => { if (!eq(a, b)) throw new SuaveError((msg === undefined ? 'Assertion failed' : show(msg)) + '\n  left:  ' + repr(a) + '\n  right: ' + repr(b), 'AssertionError'); return null; };
    g.assert_ne = (a, b, msg) => { if (eq(a, b)) throw new SuaveError((msg === undefined ? 'Assertion failed' : show(msg)) + '\n  both: ' + repr(a), 'AssertionError'); return null; };
    g.assert_throws = (f, msg) => { try { call(f, []); } catch (e) { if (e instanceof SuaveError) return null; throw e; } throw new SuaveError(msg === undefined ? 'Expected an error but none was thrown' : show(msg), 'AssertionError'); };
    g.exit = (code) => { if (rt.sys) rt.sys.exit(code || 0); throw new SuaveError('exit ' + (code || 0), 'Exit'); };
    g.args = () => rt.argv.slice();
    g.eval = (src) => { const { runProgram, interp } = rt.engine; return runProgram(show(src), '<eval>', interp.newScope()); };
    g.regex = (p, f) => regex(p, f || '');
    g.compose = (...fs) => (x) => fs.reduceRight((acc, f) => call(f, [acc]), x);
    g.curry = (f, n) => { const k = n || (f.params ? f.params.filter((p) => !p.rest).length : f.length); const c = (acc) => (...a) => { const all = acc.concat(a); return all.length >= k ? call(f, all) : c(all); }; return c([]); };
    // partial functions: fill in some values now, the rest later!  partial(add, 1)(2)   partial(greet, "Hi", punct="!")   partial(sub, _, 1)
    const splitNamed = (a) => { const last = a[a.length - 1]; return last instanceof rt.Named ? [a.slice(0, -1), last.obj] : [a, null]; };
    g.partial = (f, ...a) => { const [pos, named] = splitNamed(a); return makePartial(f, pos, named, false); };
    g.partial_right = (f, ...a) => { const [pos, named] = splitNamed(a); return makePartial(f, pos, named, true); };
    g._ = HOLE;
    g.is_partial = (x) => typeof x === 'function' && x.partialOf !== undefined;
    g.memoize = (f) => { const cache = new SMap(); return (...a) => { const key = tuple(a); let v = cache.get(key); if (v === undefined) { v = call(f, a); cache.set(key, v); } return v; }; };
    g.sleep_ms = (ms) => { const end = Date.now() + ms; while (Date.now() < end) { /* wait */ } return null; };
    g.now = () => Date.now() / 1000;
    // pools: values that stay undecided until they are used (see docs/POOLS.md)
    g.pool = (options, o) => makePool(options, o instanceof rt.Named ? o.obj.weights : o);
    g.pool.keepPools = true;
    g.inspect = (x) => { rt.noSettle = true; try { return repr(x); } finally { rt.noSettle = false; } };
    g.inspect.keepPools = true;
    g.is_pool = (x) => x instanceof SPool; g.is_pool.keepPools = true;
    g.entangle = (...ps) => entangle(ps); g.entangle.keepPools = true;
    g.decide = (x) => (x instanceof SPool ? x.decide() : x);
    g.type.keepPools = true;
    g.dbg.keepPools = true;
    g.VERSION = '0.2.0';
    return g;
}
