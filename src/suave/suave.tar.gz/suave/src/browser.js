/* Suave in a web page: <script src="suave.js"></script> then <script type="text/suave">...</script> (or src="app.sv", app.wsv for a web page, counter.xsv with data-mount="#box" for one component).
   Several scripts share one scope, in order. A script with data-module="util.sv" is a module for "use ./util.sv" and does not run by itself. */
import Suave, { formatError, rt, VERSION } from './index.js';

const files = {};
rt.files = files;
let instance = null;
const scope = () => instance || (instance = new Suave({ files }));

function showError(e, src) {
    const text = formatError(e, src, false);
    console.error(text);
    if (typeof document === 'undefined') return;
    let box = document.getElementById('suave-error');
    if (!box) {
        box = document.createElement('pre');
        box.id = 'suave-error';
        box.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;max-height:45vh;overflow:auto;margin:0;padding:12px 14px;border-radius:10px;background:#2b0f12;color:#ffd7d7;font:13px/1.45 ui-monospace,Menlo,monospace;z-index:2147483000;white-space:pre-wrap;box-shadow:0 8px 30px rgba(0,0,0,.4)';
        document.body.appendChild(box);
    }
    box.textContent = text;
}
rt.lateError = (e) => showError(e, null);

// print() goes to the console, and also to an element with id="suave-output" when the page has one
rt.out = (s) => {
    const el = typeof document !== 'undefined' && document.getElementById('suave-output');
    if (el) { el.textContent += s; } else console.log(s.replace(/\n$/, ''));
};
rt.err = (s) => console.error(s.replace(/\n$/, ''));

function run(src, name, tag) {
    // a .wsv file is a whole web page (mounted in #app), a .xsv file on its own is a component for the element named by data-mount
    if (/\.(wsv|xsv)$/i.test(name || '')) {
        try {
            if (/\.wsv$/i.test(name)) return rt.web.mountPage(src, name);
            const sel = tag && tag.getAttribute('data-mount');
            if (sel) return rt.web.mountComponent(rt.web.compileWeb(src, name), sel, new rt.SMap());
            return null;
        } catch (e) { showError(e, src); return null; }
    }
    try {
        const r = scope().run(src, name || '<script>');
        if (r instanceof Promise) return r.catch((e) => { showError(e, src); return null; });
        return r;
    } catch (e) { showError(e, src); return null; }
}
/* Getting the text of a Suave file. A web server can just hand it over (fetch). A page opened straight from disk (file://) cannot
   read other files, so beside each file there can be a "twin" like annotator.wsv.js (made by:  suave twin annotator.wsv )
   that a normal <script> tag can load: it stores the text in window.SuaveFiles. */
const twins = (typeof window !== 'undefined' && (window.SuaveFiles = window.SuaveFiles || {})) || {};
const baseOf = (url) => String(url).split('?')[0].split('#')[0].split('/').pop();
function loadTwin(url) {
    return new Promise((res) => { const s = document.createElement('script'); s.src = url + '.js'; s.onload = () => res(true); s.onerror = () => res(false); document.head.appendChild(s); });
}
async function getSource(url) {
    const base = baseOf(url);
    if (twins[base] !== undefined) return twins[base];
    if (location.protocol !== 'file:') {
        try { const r = await fetch(url); if (r.ok) return await r.text(); } catch (e) { /* fall through to the twin */ }
    }
    if (await loadTwin(url) && twins[base] !== undefined) return twins[base];
    throw new Error('Could not load ' + url + (location.protocol === 'file:' ? '. A page opened from disk (file://) cannot read other files, so make a twin for it with:  suave twin ' + base + '   (or open the page through a web server: suave serve)' : ''));
}
// the files a Suave file brings in with use "./name.sv" (so a page from disk has them before it runs)
async function loadDeps(src, url) {
    const re = /\buse\s+["']([^"']+)["']/g; let m; const jobs = [];
    while ((m = re.exec(src))) {
        let rel = m[1]; if (!/\.[a-z]+$/i.test(rel)) rel += '.sv';
        const base = baseOf(rel);
        if (files[base] !== undefined) continue;
        const full = new URL(rel, new URL(url, location.href)).href;
        jobs.push(getSource(full).then(async (text) => { files[base] = text; await loadDeps(text, full); }));
    }
    await Promise.all(jobs);
}
async function runAll() {
    const tags = Array.from(document.querySelectorAll('script[type="text/suave"]'));
    const sources = await Promise.all(tags.map(async (t) => {
        if (t.src) { const text = await getSource(t.src); await loadDeps(text, t.src); return [text, baseOf(t.src)]; }
        const text = t.textContent.replace(/<\\\/(script)/gi, '</$1');   // suave build writes </script as <\/script inside a page
        await loadDeps(text, location.href);
        return [text, t.getAttribute('data-name') || '<script>'];
    })).catch((e) => { showError(rt.rtError(String(e.message || e), 'LoadError'), null); return []; });
    tags.forEach((t, i) => { if (sources[i] && t.hasAttribute('data-module')) files[t.getAttribute('data-module')] = sources[i][0]; });
    for (let i = 0; i < tags.length; i++) { if (sources[i] && !tags[i].hasAttribute('data-module')) await run(sources[i][0], sources[i][1], tags[i]); }
}
if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', runAll); else runAll();
}
const api = { run, eval: (src) => run(src, '<eval>'), version: VERSION, files, rt, formatError, Suave };
if (typeof window !== 'undefined') window.Suave = api;
