/* Suave runtime: the value types, equality, ordering, display, errors and scopes that every other part shares. */

const isDeno = typeof Deno !== 'undefined' && !!Deno.version;
const state = { line: 0, file: '<main>', depth: 0, maxDepth: 6000, stack: [], lines: [] };
// rt.sys is the terminal layer (files, folders, environment, processes). Deno fills it in (platform.js); in a browser it stays null.
const rt = { isDeno, isBrowser: !isDeno, state, files: null, argv: [], sys: null, out: null, err: null };
rt.needSys = function (what) {
    if (!rt.sys) throw rtError('"' + what + '" needs the terminal (Deno), so it is not there in the browser', 'EnvError');
    return rt.sys;
};

// a seedable random generator (xoshiro128**): the same seed always gives the same numbers.
// Pools, quantum measurements and std.random all draw from rt.rng, so random.seed(n) makes a whole program repeatable.
function makeRng(seed) {
    const s = new Uint32Array(4);
    const init = (x) => { let z = x >>> 0; for (let i = 0; i < 4; i++) { z = (z + 0x9e3779b9) >>> 0; let t = z ^ (z >>> 16); t = Math.imul(t, 0x21f0aaad); t ^= t >>> 15; t = Math.imul(t, 0x735a2d97); t ^= t >>> 15; s[i] = t >>> 0; } };
    if (seed === undefined || seed === null) { const b = new Uint32Array(1); if (globalThis.crypto && globalThis.crypto.getRandomValues) globalThis.crypto.getRandomValues(b); else b[0] = (Math.random() * 4294967296) >>> 0; init(b[0]); }
    else init(typeof seed === 'number' ? Math.floor(seed) : Array.from(String(seed)).reduce((h, c) => (Math.imul(h, 31) + c.charCodeAt(0)) >>> 0, 7));
    const rotl = (x, k) => (x << k) | (x >>> (32 - k));
    const next = () => { const r = Math.imul(rotl(Math.imul(s[1], 5), 7), 9) >>> 0; const t = s[1] << 9; s[2] ^= s[0]; s[3] ^= s[1]; s[1] ^= s[2]; s[0] ^= s[3]; s[2] ^= t; s[3] = rotl(s[3], 11); return r; };
    return { next, float: () => next() / 4294967296 };
}
rt.makeRng = makeRng;
rt.rng = makeRng();
const pickIndex = (weights, n) => {
    if (!weights) return Math.min(n - 1, Math.floor(rt.rng.float() * n));
    let total = 0;
    for (const w of weights) total += w;
    let r = rt.rng.float() * total;
    for (let i = 0; i < weights.length; i++) { r -= weights[i]; if (r < 0) return i; }
    return weights.length - 1;
};

// ---------- complex numbers: 3 + 4i ----------
class SComplex { constructor(re, im) { this.re = re; this.im = im; } }
function fmtComplex(z) {
    const f = (n) => (Number.isNaN(n) ? 'nan' : n === Infinity ? 'inf' : n === -Infinity ? '-inf' : String(Object.is(n, -0) ? 0 : +n.toPrecision(15)));
    const { re, im } = z;
    const ia = Math.abs(im);
    const imText = (ia === 1 ? '' : f(ia)) + 'i';
    if (re === 0 && im === 0) return '0 + 0i';
    if (re === 0) return (im < 0 ? '-' : '') + imText;
    if (im === 0) return f(re) + ' + 0i';
    return f(re) + (im < 0 || Object.is(im, -0) ? ' - ' : ' + ') + imText;
}

// ---------- pools: a value that is not decided until it is used ----------
class SPool {
    constructor(options, weights, sampler) { this.options = options; this.weights = weights || null; this.sampler = sampler || null; this.decided = false; this.value = null; this.group = null; }
    decide() {
        if (this.decided) return this.value;
        let v;
        if (this.sampler) v = this.sampler();
        else {
            if (!this.options.length) throw rtError('This pool has nothing to decide between (it is empty)', 'PoolError');
            let i;
            if (this.group) { if (this.group.index === null) this.group.index = pickIndex(this.weights, this.options.length); i = this.group.index; if (i >= this.options.length) throw rtError('Entangled pools need the same number of options', 'PoolError'); }
            else i = pickIndex(this.weights, this.options.length);
            v = this.options[i];
        }
        this.value = v; this.decided = true;
        return v;
    }
}
const settle = (v) => (v instanceof SPool ? v.decide() : v);

// ---------- value types ----------
class Sym { constructor(name) { this.name = name; } }
const symtab = new Map();
function sym(name) { let s = symtab.get(name); if (!s) { s = new Sym(name); symtab.set(name, s); } return s; }

class Tuple extends Array {}
function tuple(arr) { const t = new Tuple(arr.length); for (let i = 0; i < arr.length; i++) t[i] = arr[i]; return t; }

class SRange {
    constructor(start, end, incl, step) { this.start = start; this.end = end; this.incl = !!incl; this.step = step || 1; }
    get infinite() { return this.end === null; }
    * [Symbol.iterator]() {
        const s = this.step;
        if (s > 0) { for (let i = this.start; this.end === null || (this.incl ? i <= this.end : i < this.end); i += s) yield i; }
        else if (s < 0) { for (let i = this.start; this.incl ? i >= this.end : i > this.end; i += s) yield i; }
    }
    toArray() {
        if (this.end === null) throw rtError('This range never ends, so it cannot become a list. Use .iter().take(n) instead');
        return Array.from(this);
    }
    get size() {
        if (this.end === null) return Infinity;
        const { start, end, step, incl } = this;
        if (step > 0) { if (end < start) return 0; return incl ? Math.floor((end - start) / step) + 1 : Math.ceil((end - start) / step); }
        if (step < 0) { if (end > start) return 0; return incl ? Math.floor((start - end) / -step) + 1 : Math.ceil((start - end) / -step); }
        return 0;
    }
}

// a lazy, single-pass iterator (what .iter() gives)
class SIter {
    constructor(it) { this.it = it; }
    [Symbol.iterator]() { return this.it; }
}

// keys: any value can be a map key; strings, numbers, symbols and so on are keyed by value
function keyOf(v) {
    if (typeof v === 'string') return 's' + v;
    if (typeof v === 'number') return 'n' + v;
    if (typeof v === 'boolean') return v ? 'bT' : 'bF';
    if (v === null || v === undefined) return 'z';
    if (typeof v === 'bigint') return 'i' + v;
    if (v instanceof SPool) return keyOf(v.decide());
    if (v instanceof SComplex) return 'c' + v.re + ':' + v.im;
    if (v instanceof Sym) return 'y' + v.name;
    if (v instanceof Tuple) return 't(' + Array.from(v, keyOf).join(',') + ')';
    if (Array.isArray(v)) return 'l[' + v.map(keyOf).join(',') + ']';
    if (v instanceof SMap) return 'm{' + Array.from(v.m.keys()).sort().map((k) => k + '=' + keyOf(v.m.get(k)[1])).join(',') + '}';
    if (v instanceof SSet) return 'e{' + Array.from(v.m.keys()).sort().join(',') + '}';
    if (v instanceof SObj) return 'o' + v.type.name + '{' + Object.keys(v.f).map((k) => k + '=' + keyOf(v.f[k])).join(',') + '}';
    if (v instanceof SVariant) return 'v' + v.v.name + '(' + v.vals.map(keyOf).join(',') + ')';
    if (v instanceof SRange) return 'r' + v.start + '..' + v.end + ':' + v.step;
    return 'x' + (v.__id || (v.__id = ++idCounter));
}
let idCounter = 0;

class SMap {
    constructor(pairs) { this.m = new Map(); if (pairs) for (const [k, v] of pairs) this.set(k, v); }
    get size() { return this.m.size; }
    get(k) { const e = this.m.get(keyOf(k)); return e === undefined ? undefined : e[1]; }
    has(k) { return this.m.has(keyOf(k)); }
    set(k, v) { const kk = keyOf(k); const e = this.m.get(kk); if (e) e[1] = v; else this.m.set(kk, [k, v]); return this; }
    delete(k) { return this.m.delete(keyOf(k)); }
    keys() { return Array.from(this.m.values(), (e) => e[0]); }
    values() { return Array.from(this.m.values(), (e) => e[1]); }
    entries() { return Array.from(this.m.values(), (e) => tuple([e[0], e[1]])); }
    clear() { this.m.clear(); }
}
class SSet {
    constructor(items) { this.m = new Map(); if (items) for (const x of items) this.add(x); }
    get size() { return this.m.size; }
    add(x) { const k = keyOf(x); if (!this.m.has(k)) this.m.set(k, x); return this; }
    has(x) { return this.m.has(keyOf(x)); }
    delete(x) { return this.m.delete(keyOf(x)); }
    values() { return Array.from(this.m.values()); }
}

// user types
class SType {
    constructor(name, kind) { this.name = name; this.kind = kind; this.fields = []; this.methods = new Map(); this.statics = new Map(); this.variants = new Map(); this.traits = new Set(); this.consts = new Map(); }
}
class SObj { constructor(type, f) { this.type = type; this.f = f; } }
class SVariant { constructor(type, v, vals) { this.type = type; this.v = v; this.vals = vals; } }
class VariantCtor { constructor(type, v) { this.type = type; this.v = v; } }
class SFn {
    constructor(name, params, body, env, isLambda, ret) { this.name = name; this.params = params; this.body = body; this.env = env; this.isLambda = isLambda; this.ret = ret; this.__id = ++idCounter; }
}
class Bound { constructor(self, fn, name) { this.self = self; this.fn = fn; this.name = name; } }
class SModule { constructor(name, exports) { this.name = name; this.exports = exports; } }
class Named { constructor(obj) { this.obj = obj; } }   // named arguments handed to a native function

// Result is built in so Ok and Err work everywhere
const ResultT = new SType('Result', 'enum');
ResultT.variants.set('Ok', { name: 'Ok', fields: ['value'], idx: 0 });
ResultT.variants.set('Err', { name: 'Err', fields: ['error'], idx: 1 });
const ok = (v) => new SVariant(ResultT, ResultT.variants.get('Ok'), [v]);
const err = (v) => new SVariant(ResultT, ResultT.variants.get('Err'), [v]);

// ---------- control flow signals ----------
class Brk { constructor(v) { this.v = v; } }
class Cont { }
class Ret { constructor(v) { this.v = v; } }

// ---------- errors ----------
class SuaveError extends Error {
    constructor(value, kind) {
        super(typeof value === 'string' ? value : (value instanceof SMap && value.get('message') !== undefined ? String(value.get('message')) : show(value)));
        this.value = value; this.kind = kind || 'Error'; this.line = state.line; this.file = state.file; this.trace = state.stack.slice(-8).map((f, i, a) => ({ name: f.name || '<fn>', line: state.lines[state.stack.length - a.length + i] }));
    }
}
function rtError(msg, kind) { return new SuaveError(msg, kind || 'RuntimeError'); }
function errValue(e) {
    // what `catch e` receives
    if (e instanceof SuaveError) {
        if (e.kind === 'Thrown') return e.value;
        const m = new SMap(); m.set('kind', e.kind); m.set('message', e.message); m.set('line', e.line); m.set('file', e.file); return m;
    }
    if (e instanceof RangeError && /call stack/i.test(e.message)) { const m = new SMap(); m.set('kind', 'StackOverflow'); m.set('message', 'The program called itself too deeply (stack overflow)'); m.set('line', state.line); return m; }
    const m = new SMap(); m.set('kind', 'InternalError'); m.set('message', String(e && e.message || e)); m.set('line', state.line); return m;
}

// ---------- scopes ----------
class Env {
    constructor(parent) { this.vars = new Map(); this.parent = parent || null; this.imm = null; }
    lookup(name) {
        for (let e = this; e; e = e.parent) { const v = e.vars.get(name); if (v !== undefined) return v; }
        return undefined;
    }
    get(name) {
        for (let e = this; e; e = e.parent) { const v = e.vars.get(name); if (v !== undefined) return v; }
        throw rtError('Nothing is named "' + name + '" here', 'NameError');
    }
    def(name, v, mut) {
        this.vars.set(name, v === undefined ? null : v);
        if (!mut) { (this.imm || (this.imm = new Set())).add(name); } else if (this.imm) this.imm.delete(name);
    }
    // x = 5: changes the variable if it exists, and makes it (changeable) in this scope if it does not, like Python
    assign(name, v) {
        for (let e = this; e; e = e.parent) {
            if (e.vars.has(name)) {
                if (e.imm && e.imm.has(name)) {
                    // a locked name in THIS scope is an error; a locked name from outside (a let, a function, a built-in like items or max) is simply shadowed here
                    if (e === this) throw rtError('"' + name + '" was made with let (or const), so it cannot change. Leave off the let to make a changeable variable', 'AssignError');
                    this.vars.set(name, v === undefined ? null : v); return;
                }
                e.vars.set(name, v === undefined ? null : v); return;
            }
        }
        this.vars.set(name, v === undefined ? null : v);
    }
    set(name, v) {
        for (let e = this; e; e = e.parent) {
            if (e.vars.has(name)) {
                if (e.imm && e.imm.has(name)) throw rtError('"' + name + '" was made with let, so it cannot change. Use var if it should change', 'AssignError');
                e.vars.set(name, v === undefined ? null : v); return;
            }
        }
        throw rtError('Nothing is named "' + name + '" here, so it cannot be set. Make it first with var', 'NameError');
    }
}

// ---------- types ----------
function typeOf(v) {
    if (v === null || v === undefined) return 'none';
    switch (typeof v) {
        case 'number': return 'num'; case 'string': return 'str'; case 'boolean': return 'bool'; case 'bigint': return 'bigint';
        case 'function': return 'fn';
    }
    if (v instanceof Tuple) return 'tuple';
    if (Array.isArray(v)) return 'list';
    if (v instanceof SMap) return 'map';
    if (v instanceof SSet) return 'set';
    if (v instanceof SRange) return 'range';
    if (v instanceof Sym) return 'sym';
    if (v instanceof SFn || v instanceof Bound || v instanceof SType || v instanceof VariantCtor) return v instanceof SType ? 'type' : 'fn';
    if (v instanceof SObj) return v.type.name;
    if (v instanceof SVariant) return v.type.name;
    if (v instanceof SModule) return 'module';
    if (v instanceof SIter) return 'iter';
    if (v instanceof Date) return 'datetime';
    if (v instanceof SComplex) return 'complex';
    if (v instanceof SPool) return 'pool';
    if (typeof Promise !== 'undefined' && v instanceof Promise) return 'future';
    return 'native';
}

// ---------- equality and order ----------
function eq(a, b) {
    if (a === b) return true;
    if (a instanceof SPool) a = a.decide();
    if (b instanceof SPool) b = b.decide();
    if (a === b) return true;
    if (a instanceof SComplex) return b instanceof SComplex ? a.re === b.re && a.im === b.im : (typeof b === 'number' && a.im === 0 && a.re === b);
    if (b instanceof SComplex) return typeof a === 'number' && b.im === 0 && b.re === a;
    if (a === null || b === null || a === undefined || b === undefined) return false;
    const ta = typeof a;
    if (ta === 'number' || ta === 'bigint') return (typeof b === 'number' || typeof b === 'bigint') && a == b; // eslint-disable-line eqeqeq
    if (ta !== 'object') return false;
    if (Array.isArray(a)) {
        if (!Array.isArray(b) || a.length !== b.length || (a instanceof Tuple) !== (b instanceof Tuple)) return false;
        for (let i = 0; i < a.length; i++) if (!eq(a[i], b[i])) return false;
        return true;
    }
    if (a instanceof SMap) {
        if (!(b instanceof SMap) || a.size !== b.size) return false;
        for (const [k, e] of a.m) { const o = b.m.get(k); if (!o || !eq(e[1], o[1])) return false; }
        return true;
    }
    if (a instanceof SSet) { if (!(b instanceof SSet) || a.size !== b.size) return false; for (const k of a.m.keys()) if (!b.m.has(k)) return false; return true; }
    if (a instanceof SObj) { if (!(b instanceof SObj) || a.type !== b.type) return false; for (const k of Object.keys(a.f)) if (!eq(a.f[k], b.f[k])) return false; return true; }
    if (a instanceof SVariant) { if (!(b instanceof SVariant) || a.v !== b.v || a.type !== b.type) return false; for (let i = 0; i < a.vals.length; i++) if (!eq(a.vals[i], b.vals[i])) return false; return true; }
    if (a instanceof SRange) return b instanceof SRange && a.start === b.start && a.end === b.end && a.incl === b.incl && a.step === b.step;
    if (a instanceof Date) return b instanceof Date && a.getTime() === b.getTime();
    return false;
}
function cmp(a, b) {
    if (a instanceof SPool) a = a.decide();
    if (b instanceof SPool) b = b.decide();
    const ta = typeof a, tb = typeof b;
    if ((ta === 'number' || ta === 'bigint') && (tb === 'number' || tb === 'bigint')) return a < b ? -1 : a > b ? 1 : 0;
    if (ta === 'string' && tb === 'string') return a < b ? -1 : a > b ? 1 : 0;
    if (ta === 'boolean' && tb === 'boolean') return a === b ? 0 : a ? 1 : -1;
    if (Array.isArray(a) && Array.isArray(b)) {
        const n = Math.min(a.length, b.length);
        for (let i = 0; i < n; i++) { const c = cmp(a[i], b[i]); if (c) return c; }
        return a.length - b.length;
    }
    if (a instanceof Date && b instanceof Date) return a - b;
    if (a === null && b === null) return 0;
    throw rtError('Cannot put ' + typeOf(a) + ' and ' + typeOf(b) + ' in order', 'TypeError');
}
const truthy = (v) => { if (v instanceof SPool) v = v.decide(); return v !== false && v !== null && v !== undefined; };

// ---------- display ----------
function fmtNum(n) {
    if (Number.isNaN(n)) return 'nan';
    if (n === Infinity) return 'inf';
    if (n === -Infinity) return '-inf';
    if (Object.is(n, -0)) return '0';
    return String(n);
}
const BARE = /^[A-Za-z_][A-Za-z0-9_]*$/;
function quote(s) {
    return '"' + s.replace(/[\\"\n\r\t]/g, (c) => ({ '\\': '\\\\', '"': '\\"', '\n': '\\n', '\r': '\\r', '\t': '\\t' }[c])) + '"';
}
function repr(v, seen, depth) {
    depth = depth || 0;
    if (v instanceof SPool && !rt.noSettle) v = v.decide();
    if (v === null || v === undefined) return 'none';
    switch (typeof v) {
        case 'string': return quote(v);
        case 'number': return fmtNum(v);
        case 'boolean': return v ? 'true' : 'false';
        case 'bigint': return v + 'n';
        case 'function': return '<native fn ' + (v.name || 'anonymous') + '>';
    }
    seen = seen || new Set();
    if (typeof v === 'object') {
        if (seen.has(v)) return '...';
        seen.add(v);
        try { return reprInner(v, seen, depth); } finally { seen.delete(v); }
    }
    return String(v);
}
function reprInner(v, seen, depth) {
    const R = (x) => repr(x, seen, depth + 1);
    if (v instanceof Tuple) return '(' + Array.from(v, R).join(', ') + (v.length === 1 ? ',' : '') + ')';
    if (Array.isArray(v)) return '[' + v.map(R).join(', ') + ']';
    if (v instanceof SMap) {
        if (!v.size) return '{}';
        return '{' + Array.from(v.m.values(), ([k, x]) => (typeof k === 'string' && BARE.test(k) ? k : R(k)) + ': ' + R(x)).join(', ') + '}';
    }
    if (v instanceof SSet) return '#{' + v.values().map(R).join(', ') + '}';
    if (v instanceof SRange) return fmtNum(v.start) + (v.incl ? '..=' : '..') + (v.end === null ? '' : fmtNum(v.end)) + (v.step !== 1 ? ' by ' + v.step : '');
    if (v instanceof Sym) return ':' + v.name;
    if (v instanceof SObj) {
        const keys = Object.keys(v.f);
        if (v.type.reprFn) { try { return String(rt.call(v.type.reprFn, [v])); } catch (e) { /* fall through */ } }
        return v.type.name + (keys.length ? ' { ' + keys.map((k) => k + ': ' + R(v.f[k])).join(', ') + ' }' : ' {}');
    }
    if (v instanceof SVariant) return (v.type.name === 'Result' ? '' : v.type.name + '.') + v.v.name + (v.vals.length ? '(' + v.vals.map(R).join(', ') + ')' : '');
    if (v instanceof SFn) return '<fn ' + (v.name || 'anonymous') + '>';
    if (v instanceof Bound) return '<method ' + (v.name || '') + '>';
    if (v instanceof SType) return '<type ' + v.name + '>';
    if (v instanceof VariantCtor) return '<variant ' + v.v.name + '>';
    if (v instanceof SModule) return '<module ' + v.name + '>';
    if (v instanceof SIter) return '<iter>';
    if (v instanceof SComplex) return fmtComplex(v);
    if (v instanceof SPool) {
        const body = v.sampler ? 'pool || ...' : (v.weights ? 'pool {' + v.options.map((o, k) => repr(o, seen, depth + 1) + ': ' + v.weights[k]).join(', ') + '}' : 'pool [' + v.options.map((o) => repr(o, seen, depth + 1)).join(', ') + ']');
        return v.decided ? body + ' = ' + repr(v.value, seen, depth + 1) : body + ' (undecided)';
    }
    if (typeof Promise !== 'undefined' && v instanceof Promise) return '<future>';
    if (v instanceof Date) return v.toISOString();
    if (v instanceof Uint8Array) return '<bytes ' + v.length + '>';
    return '<' + (v.constructor && v.constructor.name || 'object') + '>';
}
function show(v) {
    if (v instanceof SPool && !rt.noSettle) v = v.decide();
    if (typeof v === 'string') return v;
    if (v instanceof SObj && v.type.showFn) { try { return String(rt.call(v.type.showFn, [v])); } catch (e) { /* fall through */ } }
    return repr(v);
}

// ---------- format specs for "{x:>8.2f}" ----------
function formatSpec(v, spec) {
    if (v instanceof SComplex) { const re = formatSpec(v.re, spec), im = formatSpec(Math.abs(v.im), spec); return re + (v.im < 0 || Object.is(v.im, -0) ? ' - ' : ' + ') + im + 'i'; }
    const m = /^(?:(.)?([<>^=]))?([+\- ])?(#)?(0)?(\d+)?(,)?(?:\.(\d+))?([a-zA-Z%])?$/.exec(spec);
    if (!m) throw rtError('"' + spec + '" is not a format spec I understand', 'FormatError');
    let [, fill, align, sign, alt, zero, width, comma, prec, type] = m;
    let s;
    if (typeof v === 'number' || typeof v === 'bigint') {
        const n = typeof v === 'bigint' ? Number(v) : v;
        let body;
        switch (type) {
            case 'f': case 'F': body = Math.abs(n).toFixed(prec === undefined ? 6 : +prec); break;
            case 'e': case 'E': body = Math.abs(n).toExponential(prec === undefined ? 6 : +prec); if (type === 'E') body = body.toUpperCase(); break;
            case 'x': body = Math.abs(Math.trunc(n)).toString(16); if (alt) body = '0x' + body; break;
            case 'X': body = Math.abs(Math.trunc(n)).toString(16).toUpperCase(); if (alt) body = '0X' + body; break;
            case 'o': body = Math.abs(Math.trunc(n)).toString(8); break;
            case 'b': body = Math.abs(Math.trunc(n)).toString(2); break;
            case '%': body = (Math.abs(n) * 100).toFixed(prec === undefined ? 0 : +prec) + '%'; break;
            case 'g': body = String(+Math.abs(n).toPrecision(prec === undefined ? 6 : +prec)); break;
            case 'c': body = String.fromCodePoint(n); break;
            default: body = prec !== undefined ? Math.abs(n).toFixed(+prec) : fmtNum(Math.abs(n));
        }
        if (comma) { const [i, d] = body.split('.'); body = i.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (d !== undefined ? '.' + d : ''); }
        const neg = n < 0 || Object.is(n, -0) && false;
        const sg = neg ? '-' : sign === '+' ? '+' : sign === ' ' ? ' ' : '';
        if (zero && width && !align) { s = sg + body.padStart(+width - sg.length, '0'); } else s = sg + body;
        if (!align) align = '>';
    } else {
        s = show(v);
        if (prec !== undefined && type !== 'f') s = s.slice(0, +prec);
        if (!align) align = '<';
    }
    if (width && s.length < +width) {
        const f = fill || ' ', n = +width - s.length;
        if (align === '<') s = s + f.repeat(n);
        else if (align === '^') { const l = Math.floor(n / 2); s = f.repeat(l) + s + f.repeat(n - l); }
        else if (align === '=') { const sg = /^[+-]/.test(s) ? s[0] : ''; s = sg + f.repeat(n) + s.slice(sg.length); }
        else s = f.repeat(n) + s;
    }
    return s;
}

// ---------- JS <-> Suave ----------
function fromJS(x) {
    if (x === undefined || x === null) return null;
    if (typeof x === 'number' || typeof x === 'string' || typeof x === 'boolean' || typeof x === 'bigint') return x;
    if (Array.isArray(x)) return x.map(fromJS);
    if (x instanceof Map) { const m = new SMap(); for (const [k, v] of x) m.set(fromJS(k), fromJS(v)); return m; }
    if (x instanceof Set) return new SSet(Array.from(x, fromJS));
    if (x instanceof Date || x instanceof Uint8Array) return x;
    if (typeof x === 'object' && Object.getPrototypeOf(x) === Object.prototype) { const m = new SMap(); for (const k of Object.keys(x)) m.set(k, fromJS(x[k])); return m; }
    return x;
}
function toJS(v) {
    if (v === null || v === undefined) return null;
    if (typeof v !== 'object') return v;
    if (Array.isArray(v)) return Array.from(v, toJS);
    if (v instanceof SMap) { const o = {}; for (const [k, x] of v.m.values()) o[typeof k === 'string' ? k : show(k)] = toJS(x); return o; }
    if (v instanceof SSet) return v.values().map(toJS);
    if (v instanceof SObj) { const o = {}; for (const k of Object.keys(v.f)) o[k] = toJS(v.f[k]); return o; }
    if (v instanceof SVariant) { return v.vals.length ? { variant: v.v.name, values: v.vals.map(toJS) } : v.v.name; }
    if (v instanceof Sym) return v.name;
    if (v instanceof SComplex) return { re: v.re, im: v.im };
    if (v instanceof SPool) return toJS(v.decide());
    if (v instanceof SRange) return v.toArray();
    return v;
}

// iterate any collection
function iterate(v) {
    if (v instanceof SPool) v = v.decide();
    if (Array.isArray(v) || typeof v === 'string' || v instanceof SRange || v instanceof SIter) return v;
    if (v instanceof SMap) return v.entries();
    if (v instanceof SSet) return v.values();
    if (v instanceof Uint8Array) return Array.from(v);
    if (v instanceof SObj && v.type.nativeIter) return v.type.nativeIter(v);
    if (v instanceof SObj && (v.type.methods.has('next') || v.type.methods.has('iter'))) {
        let it = v;
        if (!v.type.methods.has('next')) it = rt.callMethod(v, 'iter', []);
        return { * [Symbol.iterator]() { for (;;) { const x = rt.callMethod(it, 'next', []); if (x === null) return; yield x; } } };
    }
    if (v && typeof v[Symbol.iterator] === 'function') return v;
    throw rtError('Cannot loop over a ' + typeOf(v), 'TypeError');
}
function toArray(v) {
    if (Array.isArray(v)) return v;
    if (v instanceof SRange) return v.toArray();
    return Array.from(iterate(v));
}

Object.assign(rt, { SComplex, fmtComplex, SPool, settle, pickIndex, Sym, sym, Tuple, tuple, SRange, SIter, SMap, SSet, SType, SObj, SVariant, VariantCtor, SFn, Bound, SModule, Named, ResultT, ok, err, Brk, Cont, Ret, SuaveError, rtError, errValue, Env,
    typeOf, eq, cmp, truthy, fmtNum, repr, show, quote, formatSpec, fromJS, toJS, iterate, toArray, keyOf });
export default rt;
