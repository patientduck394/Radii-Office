/* The terminal layer. In Deno this gives Suave files, folders, the environment and processes; in a browser rt.sys stays empty. */
import rt from './runtime.js';

const enc = new TextEncoder();
const dec = new TextDecoder();

if (rt.isDeno) {
    const D = Deno;
    const fail = (what, p, e) => { throw rt.rtError(what + ' ' + p + ' did not work: ' + (e && e.message ? e.message.replace(/ \(os error \d+\).*$/, '').replace(/^.*?: /, '') : e), 'IOError'); };
    rt.sys = {
        cwd: () => D.cwd(),
        chdir: (p) => D.chdir(p),
        readText: (p) => { try { return D.readTextFileSync(p); } catch (e) { fail('Reading', p, e); } },
        readBytes: (p) => { try { return D.readFileSync(p); } catch (e) { fail('Reading', p, e); } },
        writeText: (p, s, append) => { try { D.writeTextFileSync(p, s, { append: !!append }); } catch (e) { fail('Writing', p, e); } },
        writeBytes: (p, b) => { try { D.writeFileSync(p, b); } catch (e) { fail('Writing', p, e); } },
        exists: (p) => { try { D.statSync(p); return true; } catch (e) { return false; } },
        stat: (p) => { try { const s = D.statSync(p); return { size: s.size, mtime: s.mtime ? s.mtime.getTime() : null, isFile: s.isFile, isDir: s.isDirectory, isLink: s.isSymlink }; } catch (e) { return null; } },
        readDir: (p) => { try { return Array.from(D.readDirSync(p), (e) => ({ name: e.name, isFile: e.isFile, isDir: e.isDirectory })); } catch (e) { fail('Listing', p, e); } },
        mkdir: (p, recursive) => { try { D.mkdirSync(p, { recursive: !!recursive }); } catch (e) { fail('Making folder', p, e); } },
        remove: (p, recursive) => { try { D.removeSync(p, { recursive: !!recursive }); } catch (e) { fail('Removing', p, e); } },
        rename: (a, b) => { try { D.renameSync(a, b); } catch (e) { fail('Renaming', a, e); } },
        copy: (a, b) => { try { D.copyFileSync(a, b); } catch (e) { fail('Copying', a, e); } },
        realPath: (p) => { try { return D.realPathSync(p); } catch (e) { fail('Finding', p, e); } },
        tempDir: () => D.makeTempDirSync({ prefix: 'suave-' }),
        env: (k) => { try { return D.env.get(k); } catch (e) { return undefined; } },
        setEnv: (k, v) => D.env.set(k, v),
        envAll: () => D.env.toObject(),
        exit: (code) => D.exit(code || 0),
        out: (s) => { const b = enc.encode(s); let o = 0; while (o < b.length) o += D.stdout.writeSync(b.subarray(o)); },
        errOut: (s) => { const b = enc.encode(s); let o = 0; while (o < b.length) o += D.stderr.writeSync(b.subarray(o)); },
        readLine: (promptText) => { const r = promptText !== undefined && promptText !== null ? prompt(promptText) : prompt(''); return r === null ? null : r; },
        readStdin: () => { const chunks = []; const buf = new Uint8Array(65536); for (;;) { const n = D.stdin.readSync(buf); if (n === null) break; chunks.push(buf.slice(0, n)); } let len = 0; for (const c of chunks) len += c.length; const all = new Uint8Array(len); let o = 0; for (const c of chunks) { all.set(c, o); o += c.length; } return dec.decode(all); },
        isTTY: () => D.stdin.isTerminal(),
        run: (cmd, args, opts) => {
            opts = opts || {};
            try {
                const c = new D.Command(cmd, { args, cwd: opts.cwd, stdin: opts.input !== undefined ? 'piped' : 'null', stdout: 'piped', stderr: 'piped', env: opts.env });
                const child = c.spawn();
                if (opts.input !== undefined) { const w = child.stdin.getWriter(); w.write(enc.encode(opts.input)); w.close(); }
                return child.output().then((o) => ({ code: o.code, stdout: dec.decode(o.stdout), stderr: dec.decode(o.stderr) }));
            } catch (e) { return Promise.reject(rt.rtError('Could not start "' + cmd + '": ' + e.message, 'IOError')); }
        },
        runSync: (cmd, args, opts) => {
            opts = opts || {};
            try {
                const o = new D.Command(cmd, { args, cwd: opts.cwd, stdin: 'null', stdout: 'piped', stderr: 'piped', env: opts.env }).outputSync();
                return { code: o.code, stdout: dec.decode(o.stdout), stderr: dec.decode(o.stderr) };
            } catch (e) { throw rt.rtError('Could not start "' + cmd + '": ' + e.message, 'IOError'); }
        },
        // runs a command with its output going straight to the terminal; gives back the exit code
        runInherit: (cmd, args, opts) => {
            opts = opts || {};
            try { return new D.Command(cmd, { args, cwd: opts.cwd, stdin: 'inherit', stdout: 'inherit', stderr: 'inherit', env: opts.env }).outputSync().code; }
            catch (e) { throw rt.rtError('Could not start "' + cmd + '": ' + e.message, 'IOError'); }
        },
        os: () => D.build.os, arch: () => D.build.arch, hostname: () => { try { return D.hostname(); } catch (e) { return 'unknown'; } },
        home: () => D.env.get('HOME') || D.env.get('USERPROFILE') || '/',
        pid: () => D.pid,
        denoVersion: () => D.version.deno,
        listen: (port, handler) => D.serve({ port, onListen() {} }, handler),
        mtime: (p) => { try { return D.statSync(p).mtime.getTime(); } catch (e) { return null; } },
        cpus: () => (navigator.hardwareConcurrency || 1),
    };
    rt.write = (s) => rt.sys.out(s);
    rt.ewrite = (s) => rt.sys.errOut(s);
    rt.argv = D.args.slice();
} else {
    const buf = [];
    rt.write = (s) => { if (rt.out) rt.out(s); else { buf.push(s); if (s.endsWith('\n')) { console.log(buf.join('').replace(/\n$/, '')); buf.length = 0; } } };
    rt.ewrite = (s) => { if (rt.err) rt.err(s); else console.error(s.replace(/\n$/, '')); };
}
export default rt;
