/* Suave: the language. Import this to run Suave code from Deno, a browser or another program. */
import rt from './runtime.js';
import './platform.js';
import { interp, hooks, runProgram, call, callMethod } from './interp.js';
import { methodsFor } from './methods.js';
import { makeGlobals } from './prelude.js';
import { stdlib } from './stdlib/index.js';
import { parse, SuaveSyntaxError } from './parser.js';
import { findPackageFile } from './pm.js';
import { compileWeb, checkWeb, mountComponent, renderComponent, renderHtml, mountPage, XComponent } from './xsv.js';

export const VERSION = '0.2.0';
hooks.methodsFor = methodsFor;
hooks.stdlib = stdlib;
hooks.findPackage = findPackageFile;
hooks.loadWeb = (src, file) => compileWeb(src, file);
rt.formatError = (e) => formatError(e, null, false);
rt.web = { checkWeb, mountComponent, renderComponent, renderHtml, mountPage, XComponent, compileWeb };
rt.engine = { interp, runProgram };
// a rejected future that nobody waited for is reported like any other late error
if (typeof globalThis.addEventListener === 'function') globalThis.addEventListener('unhandledrejection', (e) => { e.preventDefault(); if (rt.lateError) rt.lateError(e.reason); else rt.ewrite(String(e.reason && e.reason.message || e.reason) + '\n'); });

function buildGlobals() {
    const env = new rt.Env(null);
    const g = makeGlobals();
    for (const k of Object.keys(g)) env.def(k, g[k], false);
    return env;
}
interp.globals = buildGlobals();

// reads the position of an error and shows the source line with a caret
export function formatError(e, src, color) {
    const c = (code, s) => (color ? '\x1b[' + code + 'm' + s + '\x1b[0m' : s);
    const lines = src ? src.split('\n') : [];
    if (e instanceof SuaveSyntaxError) {
        let out = c('1;31', 'Syntax error') + c('1', ': ' + e.message) + '\n  ' + c('36', '--> ' + e.file + ':' + e.line + ':' + e.col);
        if (lines[e.line - 1] !== undefined) out += '\n   ' + c('34', String(e.line).padStart(4) + ' |') + ' ' + lines[e.line - 1] + '\n        ' + ' '.repeat(Math.max(0, e.col - 1)) + c('1;31', '^');
        return out;
    }
    if (e instanceof rt.SuaveError) {
        const kind = e.kind === 'Thrown' ? 'Error' : e.kind;
        let out = c('1;31', kind) + c('1', ': ' + (e.kind === 'Thrown' ? rt.show(e.value) : e.message)) + '\n  ' + c('36', '--> ' + e.file + ':' + e.line);
        if (src && e.file === rt.state.mainFile && lines[e.line - 1] !== undefined) out += '\n   ' + c('34', String(e.line).padStart(4) + ' |') + ' ' + lines[e.line - 1].trimEnd();
        if (e.trace && e.trace.length) out += '\n' + e.trace.slice().reverse().map((f) => c('2', '    in ' + f.name + ' (called at line ' + f.line + ')')).join('\n');
        return out;
    }
    if (e instanceof RangeError && /call stack/i.test(e.message)) return c('1;31', 'Stack overflow') + ': the program called itself too deeply';
    return c('1;31', 'Internal error') + ': ' + (e && e.stack || e);
}

export class Suave {
    constructor(opts) {
        opts = opts || {};
        if (opts.files) rt.files = opts.files;
        if (opts.argv) rt.argv = opts.argv;
        if (opts.out) rt.out = opts.out;
        if (opts.err) rt.err = opts.err;
        this.scope = interp.newScope();
    }
    run(src, file) { rt.state.mainFile = file || '<main>'; rt.state.depth = 0; rt.state.stack.length = 0; rt.state.lines.length = 0; return interp.run(src, file || '<main>', this.scope); }
    get tests() { return interp.tests; }
}
export function run(src, opts) { return new Suave(opts).run(src, opts && opts.file); }
export { rt, interp, call, callMethod, parse, SuaveSyntaxError, runProgram };
export default Suave;
