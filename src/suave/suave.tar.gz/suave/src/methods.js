/* Suave built-in methods: what you can call on text, lists, maps, sets, ranges, numbers, iterators and results. */
import rt from './runtime.js';
import { call, binop, slice, contains as inContains, makePool, makePartial } from './interp.js';
import * as CX from './complexmath.js';

const { SPool, Tuple, tuple, SRange, SIter, SMap, SSet, SObj, SVariant, ResultT, ok, err, rtError, eq, cmp, truthy, repr, show, iterate, toArray, typeOf, fmtNum } = rt;

const cb = (f) => { if (typeof f === 'function') return f; if (f === undefined || f === null) throw rtError('A function was expected here but there was none', 'ArgError'); return (...a) => call(f, a); };
const arr = (x) => toArray(x);
const num = (x, what) => { if (typeof x !== 'number') throw rtError((what || 'This') + ' needs a number but got ' + typeOf(x), 'TypeError'); return x; };
const int = (x, what) => { if (typeof x !== 'number' || !Number.isInteger(x)) throw rtError((what || 'This') + ' needs a whole number but got ' + repr(x), 'TypeError'); return x; };
const same = (self, out) => (self instanceof Tuple ? tuple(out) : out);
const sortStable = (a, c) => a.map((v, i) => [v, i]).sort((x, y) => c(x[0], y[0]) || x[1] - y[1]).map((x) => x[0]);
const rcmp = (a, b) => rt.cmp(a, b);
const regexCache = new Map();
export function regex(p, flags) {
    if (p instanceof RegExp) return p;
    const key = flags + '/' + p;
    let r = regexCache.get(key);
    if (!r) { try { r = new RegExp(p, flags); } catch (e) { throw rtError('This pattern is not valid: ' + e.message, 'RegexError'); } regexCache.set(key, r); }
    return r;
}
function roundTo(x, p) {
    if (!p) return Math.sign(x) * Math.round(Math.abs(x));
    const f = Math.pow(10, p);
    return Math.sign(x) * Math.round(Math.abs(x) * f + Number.EPSILON * 1e3) / f;
}
const lazy = (gen) => new SIter(gen());
const addAll = (xs) => { let t = 0; for (const x of xs) t = (typeof t === 'number' && typeof x === 'number') ? t + x : binop('+', t === 0 && typeof x !== 'number' ? (typeof x === 'string' ? '' : typeof x === 'bigint' ? 0n : t) : t, x); return t; };
const joinText = (xs, sep) => Array.from(xs, show).join(sep);

// ---------- shared list-like helpers (lists, tuples, ranges, sets, iterators) ----------
const seq = {
    map: (s, a) => { const f = cb(a[0]); return same(s, arr(s).map((x) => f(x))); },
    filter: (s, a) => { const f = cb(a[0]); return same(s, arr(s).filter((x) => truthy(f(x)))); },
    each: (s, a) => { const f = cb(a[0]); for (const x of iterate(s)) f(x); return null; },
    reduce: (s, a) => { const f = cb(a[0]); const xs = arr(s); if (a.length > 1) return xs.reduce((acc, x) => f(acc, x), a[1]); if (!xs.length) return null; return xs.slice(1).reduce((acc, x) => f(acc, x), xs[0]); },
    fold: (s, a) => { const f = cb(a[1]); let acc = a[0]; for (const x of iterate(s)) acc = f(acc, x); return acc; },
    find: (s, a) => { const f = cb(a[0]); for (const x of iterate(s)) if (truthy(f(x))) return x; return null; },
    find_index: (s, a) => { const f = cb(a[0]); let i = 0; for (const x of iterate(s)) { if (truthy(f(x))) return i; i++; } return null; },
    any: (s, a) => { const f = a.length ? cb(a[0]) : (x) => x; for (const x of iterate(s)) if (truthy(f(x))) return true; return false; },
    all: (s, a) => { const f = a.length ? cb(a[0]) : (x) => x; for (const x of iterate(s)) if (!truthy(f(x))) return false; return true; },
    count: (s, a) => { let n = 0; if (!a.length) { for (const x of iterate(s)) { void x; n++; } return n; } if (typeof a[0] === 'function' || a[0] instanceof rt.SFn || a[0] instanceof rt.Bound) { const f = cb(a[0]); for (const x of iterate(s)) if (truthy(f(x))) n++; return n; } for (const x of iterate(s)) if (eq(x, a[0])) n++; return n; },
    sum: (s) => addAll(iterate(s)),
    product: (s) => { let p = 1; for (const x of iterate(s)) p = binop('*', p, x); return p; },
    min: (s) => { let m = null; for (const x of iterate(s)) if (m === null || rcmp(x, m) < 0) m = x; return m; },
    max: (s) => { let m = null; for (const x of iterate(s)) if (m === null || rcmp(x, m) > 0) m = x; return m; },
    min_by: (s, a) => { const f = cb(a[0]); let m = null, mk = null; for (const x of iterate(s)) { const k = f(x); if (m === null || rcmp(k, mk) < 0) { m = x; mk = k; } } return m; },
    max_by: (s, a) => { const f = cb(a[0]); let m = null, mk = null; for (const x of iterate(s)) { const k = f(x); if (m === null || rcmp(k, mk) > 0) { m = x; mk = k; } } return m; },
    contains: (s, a) => { for (const x of iterate(s)) if (eq(x, a[0])) return true; return false; },
    join: (s, a) => joinText(iterate(s), a.length ? show(a[0]) : ''),
    first: (s) => { for (const x of iterate(s)) return x; return null; },
    to_set: (s) => new SSet(iterate(s)),
    to_list: (s) => arr(s).slice(),
    iter: (s) => new SIter(iterate(s)[Symbol.iterator]()),
};

// ---------- lists ----------
const list = Object.assign({}, seq, {
    len: (s) => s.length, size: (s) => s.length, is_empty: (s) => s.length === 0,
    append: (s, a) => { if (s instanceof Tuple) throw rtError('A tuple cannot be changed', 'TypeError'); s.push(a[0]); return s; },
    push: (s, a) => { if (s instanceof Tuple) throw rtError('A tuple cannot be changed', 'TypeError'); for (const x of a) s.push(x); return s; },
    pop: (s) => (s.length ? s.pop() : null),
    shift: (s) => (s.length ? s.shift() : null),
    unshift: (s, a) => { s.unshift(...a); return s; },
    insert: (s, a) => { const i = int(a[0]); s.splice(i < 0 ? s.length + i : i, 0, a[1]); return s; },
    remove: (s, a) => { const i = int(a[0]); const k = i < 0 ? s.length + i : i; if (k < 0 || k >= s.length) throw rtError('Index ' + i + ' is out of range (size ' + s.length + ')', 'IndexError'); return s.splice(k, 1)[0]; },
    delete: (s, a) => { const i = s.findIndex((x) => eq(x, a[0])); if (i >= 0) { s.splice(i, 1); return true; } return false; },
    clear: (s) => { s.length = 0; return s; },
    get: (s, a) => { const i = int(a[0]); const k = i < 0 ? s.length + i : i; return k >= 0 && k < s.length ? s[k] : (a.length > 1 ? a[1] : null); },
    last: (s, a) => (a.length ? same(s, s.slice(Math.max(0, s.length - a[0]))) : (s.length ? s[s.length - 1] : null)),
    first: (s, a) => (a.length ? same(s, s.slice(0, a[0])) : (s.length ? s[0] : null)),
    index_of: (s, a) => { const i = s.findIndex((x) => eq(x, a[0])); return i < 0 ? null : i; },
    // xs.sort() puts a list in order right where it is (like Python) and gives it back; sort(reverse=True) and sort(key=f) work too. sorted(xs) makes a sorted copy.
    sort: (s, a, named) => {
        const key = named && named.key !== undefined ? named.key : (a.length ? a[0] : null);
        const rev = !!(named && (named.reverse === true || named.desc === true));
        const f = key ? cb(key) : null;
        const keyed = s.map((x) => [f ? f(x) : x, x]);
        let out = sortStable(keyed, (p, q) => rcmp(rev ? q[0] : p[0], rev ? p[0] : q[0])).map((p) => p[1]);
        if (Array.isArray(s) && !(s instanceof Tuple)) { s.splice(0, s.length, ...out); return s; }
        return same(s, out);
    },
    sort_by: (s, a) => { const f = cb(a[0]); const keyed = s.map((x) => [f(x), x]); return same(s, sortStable(keyed, (p, q) => rcmp(p[0], q[0])).map((p) => p[1])); },
    sort_with: (s, a) => { const f = cb(a[0]); return same(s, sortStable(s, (x, y) => num(f(x, y), 'The compare function'))); },
    sort_desc: (s) => same(s, sortStable(s, (x, y) => rcmp(y, x))),
    sort_mut: (s) => { const r = sortStable(s, rcmp); for (let i = 0; i < r.length; i++) s[i] = r[i]; return s; },
    reverse: (s) => same(s, s.slice().reverse()),
    reverse_mut: (s) => { s.reverse(); return s; },
    reversed: (s) => same(s, s.slice().reverse()),
    slice: (s, a) => slice(s, new SRange(a[0] === undefined || a[0] === null ? null : a[0], a[1] === undefined || a[1] === null ? null : a[1], false, 1)),
    take: (s, a) => same(s, s.slice(0, Math.max(0, a[0]))),
    drop: (s, a) => same(s, s.slice(Math.max(0, a[0]))),
    take_while: (s, a) => { const f = cb(a[0]); const r = []; for (const x of s) { if (!truthy(f(x))) break; r.push(x); } return same(s, r); },
    drop_while: (s, a) => { const f = cb(a[0]); let i = 0; while (i < s.length && truthy(f(s[i]))) i++; return same(s, s.slice(i)); },
    zip: (s, a) => { const others = a.map(arr); const n = Math.min(s.length, ...others.map((o) => o.length)); const r = []; for (let i = 0; i < n; i++) r.push(tuple([s[i]].concat(others.map((o) => o[i])))); return r; },
    enumerate: (s, a) => { const st = a.length ? a[0] : 0; return Array.from(s, (x, i) => tuple([i + st, x])); },
    flatten: (s, a) => { const d = a.length ? a[0] : 1; const f = (xs, k) => xs.reduce((acc, x) => (Array.isArray(x) && k > 0 ? acc.concat(f(x, k - 1)) : (acc.push(x), acc)), []); return f(s, d); },
    flat_map: (s, a) => { const f = cb(a[0]); const r = []; for (const x of s) { const y = f(x); if (Array.isArray(y)) r.push(...y); else r.push(y); } return r; },
    chunk: (s, a) => { const n = int(a[0]); if (n < 1) throw rtError('A chunk needs a size of at least 1'); const r = []; for (let i = 0; i < s.length; i += n) r.push(s.slice(i, i + n)); return r; },
    window: (s, a) => { const n = int(a[0]); const r = []; for (let i = 0; i + n <= s.length; i++) r.push(s.slice(i, i + n)); return r; },
    unique: (s) => { const seen = new SSet(); const r = []; for (const x of s) if (!seen.has(x)) { seen.add(x); r.push(x); } return r; },
    unique_by: (s, a) => { const f = cb(a[0]); const seen = new SSet(); const r = []; for (const x of s) { const k = f(x); if (!seen.has(k)) { seen.add(k); r.push(x); } } return r; },
    dedup: (s) => s.filter((x, i) => i === 0 || !eq(x, s[i - 1])),
    group_by: (s, a) => { const f = cb(a[0]); const m = new SMap(); for (const x of s) { const k = f(x); const g = m.get(k); if (g) g.push(x); else m.set(k, [x]); } return m; },
    count_by: (s, a) => { const f = cb(a[0]); const m = new SMap(); for (const x of s) { const k = f(x); m.set(k, (m.get(k) || 0) + 1); } return m; },
    partition: (s, a) => { const f = cb(a[0]); const y = [], n = []; for (const x of s) (truthy(f(x)) ? y : n).push(x); return tuple([y, n]); },
    split_at: (s, a) => tuple([s.slice(0, a[0]), s.slice(a[0])]),
    rotate: (s, a) => { if (!s.length) return s.slice(); const k = ((a[0] % s.length) + s.length) % s.length; return s.slice(k).concat(s.slice(0, k)); },
    concat: (s, a) => same(s, s.concat(...a.map(arr))),
    extend: (s, a) => { for (const x of iterate(a[0])) s.push(x); return s; },
    copy: (s) => s.slice(),
    scan: (s, a) => { const f = cb(a[1]); let acc = a[0]; const r = [acc]; for (const x of s) { acc = f(acc, x); r.push(acc); } return r; },
    cumsum: (s) => { let t = 0; return s.map((x) => (t += x)); },
    step: (s, a) => s.filter((x, i) => i % a[0] === 0),
    transpose: (s) => (s.length ? s[0].map((_, i) => s.map((r) => r[i])) : []),
    product_with: (s, a) => { const r = []; for (const x of s) for (const y of arr(a[0])) r.push(tuple([x, y])); return r; },
    interleave: (s, a) => { const o = arr(a[0]); const r = []; for (let i = 0; i < Math.max(s.length, o.length); i++) { if (i < s.length) r.push(s[i]); if (i < o.length) r.push(o[i]); } return r; },
    shuffle: (s) => { const r = s.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; },
    sample: (s) => (s.length ? s[Math.floor(Math.random() * s.length)] : null),
    to_map: (s) => { const m = new SMap(); for (const p of s) { if (!Array.isArray(p) || p.length !== 2) throw rtError('to_map needs a list of (key, value) pairs'); m.set(p[0], p[1]); } return m; },
    to_tuple: (s) => tuple(s),
    binary_search: (s, a) => { let lo = 0, hi = s.length - 1; while (lo <= hi) { const mid = (lo + hi) >> 1; const c = rcmp(s[mid], a[0]); if (c === 0) return mid; if (c < 0) lo = mid + 1; else hi = mid - 1; } return null; },
});
delete list.copy_;

// ---------- text ----------
const hasSurrogates = (s) => /[\ud800-\udfff]/.test(s);
const str = {
    len: (s) => (hasSurrogates(s) ? Array.from(s).length : s.length),
    is_empty: (s) => s.length === 0,
    join: (s, a) => joinText(iterate(a[0]), s),     // Python style: ", ".join(items)
    upper: (s) => s.toUpperCase(), lower: (s) => s.toLowerCase(),
    capitalize: (s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase(),
    title: (s) => s.replace(/\b\p{L}[\p{L}\p{N}']*/gu, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()),
    swapcase: (s) => Array.from(s, (c) => (c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase())).join(''),
    startswith: (s, a) => str.starts_with(s, a), endswith: (s, a) => str.ends_with(s, a),   // Python spellings
    strip: (s, a) => (a.length ? str.trim_start(str.trim_end(s, a), a) : s.trim()), lstrip: (s, a) => str.trim_start(s, a), rstrip: (s, a) => str.trim_end(s, a),
    trim: (s, a) => (a.length ? str.trim_start(str.trim_end(s, a), a) : s.trim()),
    trim_start: (s, a) => { if (!a.length) return s.trimStart(); let i = 0; while (i < s.length && a[0].includes(s[i])) i++; return s.slice(i); },
    trim_end: (s, a) => { if (!a.length) return s.trimEnd(); let i = s.length; while (i > 0 && a[0].includes(s[i - 1])) i--; return s.slice(0, i); },
    split: (s, a) => { if (!a.length || a[0] === null) return s.split(/\s+/).filter(Boolean); const parts = s.split(a[0]); if (a.length > 1 && a[1] > 0 && parts.length > a[1]) return parts.slice(0, a[1] - 1).concat([parts.slice(a[1] - 1).join(a[0])]); return parts; },
    split_once: (s, a) => { const i = s.indexOf(a[0]); return i < 0 ? null : tuple([s.slice(0, i), s.slice(i + a[0].length)]); },
    lines: (s) => { const r = s.split(/\r?\n/); if (r.length && r[r.length - 1] === '') r.pop(); return r; },
    words: (s) => s.split(/\s+/).filter(Boolean),
    chars: (s) => Array.from(s),
    bytes: (s) => new TextEncoder().encode(s),
    starts_with: (s, a) => s.startsWith(a[0]), ends_with: (s, a) => s.endsWith(a[0]),
    contains: (s, a) => s.includes(a[0]),
    find: (s, a) => { const i = s.indexOf(a[0], a[1] || 0); return i < 0 ? null : i; },
    rfind: (s, a) => { const i = s.lastIndexOf(a[0]); return i < 0 ? null : i; },
    index_of: (s, a) => { const i = s.indexOf(a[0]); return i < 0 ? null : i; },
    count: (s, a) => (a[0] === '' ? s.length + 1 : s.split(a[0]).length - 1),
    replace: (s, a) => s.split(a[0]).join(a[1]),
    replace_first: (s, a) => s.replace(a[0], () => a[1]),
    repeat: (s, a) => s.repeat(Math.max(0, int(a[0]))),
    pad_left: (s, a) => s.padStart(a[0], a[1] === undefined ? ' ' : a[1]),
    pad_right: (s, a) => s.padEnd(a[0], a[1] === undefined ? ' ' : a[1]),
    center: (s, a) => { const w = a[0], f = a[1] === undefined ? ' ' : a[1]; if (s.length >= w) return s; const l = Math.floor((w - s.length) / 2); return f.repeat(l) + s + f.repeat(w - s.length - l); },
    reverse: (s) => Array.from(s).reverse().join(''),
    slice: (s, a) => s.slice(a[0] === null ? 0 : a[0], a[1] === undefined || a[1] === null ? undefined : a[1]),
    substr: (s, a) => s.substr(a[0], a[1]),
    strip_prefix: (s, a) => (s.startsWith(a[0]) ? s.slice(a[0].length) : s),
    strip_suffix: (s, a) => (a[0] && s.endsWith(a[0]) ? s.slice(0, -a[0].length) : s),
    to_int: (s, a) => { const r = parseInt(s.replace(/_/g, ''), a[0] || 10); return Number.isNaN(r) || !/^[\s+-]?[0-9a-zA-Z_]+\s*$/.test(s) ? null : r; },
    to_float: (s) => { const t = s.trim(); if (!/^[+-]?(\d+\.?\d*([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?|inf|nan)$/i.test(t)) return null; return /inf/i.test(t) ? (t[0] === '-' ? -Infinity : Infinity) : /nan/i.test(t) ? NaN : Number(t); },
    to_sym: (s) => rt.sym(s),
    is_digit: (s) => s.length > 0 && /^\d+$/.test(s), is_alpha: (s) => s.length > 0 && /^\p{L}+$/u.test(s), is_alnum: (s) => s.length > 0 && /^[\p{L}\p{N}]+$/u.test(s),
    is_upper: (s) => s.length > 0 && s === s.toUpperCase() && s !== s.toLowerCase(), is_lower: (s) => s.length > 0 && s === s.toLowerCase() && s !== s.toUpperCase(),
    is_space: (s) => s.length > 0 && /^\s+$/.test(s),
    matches: (s, a) => regex(a[0], a[1] || '').test(s),
    match: (s, a) => { const m = regex(a[0], '').exec(s); if (!m) return null; const r = new SMap(); r.set('text', m[0]); r.set('index', m.index); r.set('groups', Array.from(m).slice(1).map((x) => (x === undefined ? null : x))); const named = new SMap(); if (m.groups) for (const k of Object.keys(m.groups)) named.set(k, m.groups[k] === undefined ? null : m.groups[k]); r.set('named', named); return r; },
    find_all: (s, a) => Array.from(s.matchAll(regex(a[0], 'g')), (m) => m[0]),
    replace_re: (s, a) => s.replace(regex(a[0], 'g'), typeof a[1] === 'string' ? a[1] : (...m) => String(call(a[1], [m[0]]))),
    split_re: (s, a) => s.split(regex(a[0], '')),
    each_char: (s, a) => { for (const c of s) call(a[0], [c]); return null; },
    map: (s, a) => Array.from(s, (c) => call(a[0], [c])),
    filter: (s, a) => Array.from(s).filter((c) => truthy(call(a[0], [c]))).join(''),
    ord: (s) => s.codePointAt(0),
    hex: (s) => Array.from(new TextEncoder().encode(s), (b) => b.toString(16).padStart(2, '0')).join(''),
    format: (s, a) => { let i = 0; return s.replace(/\{\}/g, () => show(a[i++])); },
    snake: (s) => s.replace(/([a-z0-9])([A-Z])/g, '$1_$2').replace(/[\s\-]+/g, '_').toLowerCase(),
    camel: (s) => s.toLowerCase().replace(/[\s_\-]+(.)/g, (m, c) => c.toUpperCase()),
    kebab: (s) => s.replace(/([a-z0-9])([A-Z])/g, '$1-$2').replace(/[\s_]+/g, '-').toLowerCase(),
};

// ---------- maps ----------
const map = {
    len: (s) => s.size, size: (s) => s.size, is_empty: (s) => s.size === 0,
    get: (s, a) => { const v = s.get(a[0]); return v === undefined ? (a.length > 1 ? a[1] : null) : v; },
    get_in: (s, a) => { let cur = s; for (const k of arr(a[0])) { if (cur instanceof SMap) cur = cur.get(k); else if (Array.isArray(cur)) cur = cur[k]; else return a.length > 1 ? a[1] : null; if (cur === undefined || cur === null) return a.length > 1 ? a[1] : null; } return cur; },
    set: (s, a) => { s.set(a[0], a[1]); return s; },
    set_in: (s, a) => { const path = arr(a[0]); let cur = s; for (let i = 0; i < path.length - 1; i++) { let nx = cur.get(path[i]); if (!(nx instanceof SMap)) { nx = new SMap(); cur.set(path[i], nx); } cur = nx; } cur.set(path[path.length - 1], a[1]); return s; },
    has: (s, a) => s.has(a[0]), contains_key: (s, a) => s.has(a[0]),
    delete: (s, a) => { const v = s.get(a[0]); s.delete(a[0]); return v === undefined ? null : v; },
    remove: (s, a) => { const v = s.get(a[0]); s.delete(a[0]); return v === undefined ? null : v; },
    keys: (s) => s.keys(), values: (s) => s.values(), items: (s) => s.entries(), entries: (s) => s.entries(), to_list: (s) => s.entries(),
    merge: (s, a) => { const r = new SMap(s.entries()); for (const o of a) for (const [k, v] of o.entries()) r.set(k, v); return r; },
    deep_merge: (s, a) => { const dm = (x, y) => { const r = new SMap(x.entries()); for (const [k, v] of y.entries()) { const cur = r.get(k); r.set(k, cur instanceof SMap && v instanceof SMap ? dm(cur, v) : v); } return r; }; return a.reduce(dm, s); },
    update: (s, a) => { for (const [k, v] of a[0].entries()) s.set(k, v); return s; },
    map_values: (s, a) => { const f = cb(a[0]); const r = new SMap(); for (const [k, v] of s.entries()) r.set(k, f(v)); return r; },
    map_keys: (s, a) => { const f = cb(a[0]); const r = new SMap(); for (const [k, v] of s.entries()) r.set(f(k), v); return r; },
    map: (s, a) => { const f = cb(a[0]); return s.entries().map(([k, v]) => f(k, v)); },
    filter: (s, a) => { const f = cb(a[0]); const r = new SMap(); for (const [k, v] of s.entries()) if (truthy(f(k, v))) r.set(k, v); return r; },
    each: (s, a) => { const f = cb(a[0]); for (const [k, v] of s.entries()) f(k, v); return null; },
    any: (s, a) => s.entries().some(([k, v]) => truthy(cb(a[0])(k, v))), all: (s, a) => s.entries().every(([k, v]) => truthy(cb(a[0])(k, v))),
    count: (s, a) => (a.length ? s.entries().filter(([k, v]) => truthy(cb(a[0])(k, v))).length : s.size),
    find: (s, a) => { for (const [k, v] of s.entries()) if (truthy(cb(a[0])(k, v))) return tuple([k, v]); return null; },
    pick: (s, a) => { const r = new SMap(); for (const k of arr(a[0])) if (s.has(k)) r.set(k, s.get(k)); return r; },
    omit: (s, a) => { const drop = new SSet(arr(a[0])); const r = new SMap(); for (const [k, v] of s.entries()) if (!drop.has(k)) r.set(k, v); return r; },
    invert: (s) => { const r = new SMap(); for (const [k, v] of s.entries()) r.set(v, k); return r; },
    sort_keys: (s) => { const r = new SMap(); for (const [k, v] of sortStable(s.entries(), (x, y) => rcmp(x[0], y[0]))) r.set(k, v); return r; },
    sort_by: (s, a) => { const f = cb(a[0]); return sortStable(s.entries(), (x, y) => rcmp(f(x[0], x[1]), f(y[0], y[1]))); },
    min_by: (s, a) => { let m = null, mk = null; for (const [k, v] of s.entries()) { const x = cb(a[0])(k, v); if (m === null || rcmp(x, mk) < 0) { m = tuple([k, v]); mk = x; } } return m; },
    max_by: (s, a) => { let m = null, mk = null; for (const [k, v] of s.entries()) { const x = cb(a[0])(k, v); if (m === null || rcmp(x, mk) > 0) { m = tuple([k, v]); mk = x; } } return m; },
    clear: (s) => { s.clear(); return s; },
    copy: (s) => new SMap(s.entries()),
    to_set: (s) => new SSet(s.keys()),
    first: (s) => { const e = s.entries(); return e.length ? e[0] : null; },
};

// ---------- sets ----------
const set = {
    len: (s) => s.size, size: (s) => s.size, is_empty: (s) => s.size === 0,
    add: (s, a) => { for (const x of a) s.add(x); return s; },
    remove: (s, a) => s.delete(a[0]), delete: (s, a) => s.delete(a[0]),
    has: (s, a) => s.has(a[0]), contains: (s, a) => s.has(a[0]),
    union: (s, a) => new SSet(s.values().concat(...a.map(arr))),
    intersect: (s, a) => { const o = new SSet(arr(a[0])); return new SSet(s.values().filter((x) => o.has(x))); },
    diff: (s, a) => { const o = new SSet(arr(a[0])); return new SSet(s.values().filter((x) => !o.has(x))); },
    sym_diff: (s, a) => { const o = new SSet(arr(a[0])); return new SSet(s.values().filter((x) => !o.has(x)).concat(o.values().filter((x) => !s.has(x)))); },
    is_subset: (s, a) => { const o = new SSet(arr(a[0])); return s.values().every((x) => o.has(x)); },
    is_superset: (s, a) => arr(a[0]).every((x) => s.has(x)),
    is_disjoint: (s, a) => !arr(a[0]).some((x) => s.has(x)),
    map: (s, a) => new SSet(s.values().map((x) => cb(a[0])(x))),
    filter: (s, a) => new SSet(s.values().filter((x) => truthy(cb(a[0])(x)))),
    clear: (s) => { s.m.clear(); return s; },
    copy: (s) => new SSet(s.values()),
    sort: (s) => sortStable(s.values(), rcmp),
    to_set: (s) => s,
};
for (const k of ['each', 'reduce', 'fold', 'find', 'any', 'all', 'count', 'sum', 'product', 'min', 'max', 'min_by', 'max_by', 'join', 'first', 'to_list', 'iter', 'group_by']) set[k] = (s, a) => (list[k] || seq[k])(s.values(), a);

// ---------- ranges ----------
const range = {
    len: (s) => s.size, size: (s) => s.size, is_empty: (s) => s.size === 0,
    start: (s) => s.start, end: (s) => s.end,
    step: (s, a) => new SRange(s.start, s.end, s.incl, a[0]), by: (s, a) => new SRange(s.start, s.end, s.incl, a[0]),
    rev: (s) => { const x = s.toArray(); x.reverse(); return x; },
    contains: (s, a) => inContains(s, a[0]),
    iter: (s) => new SIter(s[Symbol.iterator]()),
    to_list: (s) => s.toArray(),
    sum: (s) => { if (s.step === 1 && Number.isInteger(s.start) && s.end !== null) { const hi = s.incl ? s.end : s.end - 1; return hi < s.start ? 0 : (s.start + hi) * (hi - s.start + 1) / 2; } return addAll(s.toArray()); },
};
for (const k of Object.keys(list)) if (!(k in range) && !['push', 'pop', 'shift', 'unshift', 'insert', 'remove', 'delete', 'clear', 'extend', 'sort_mut', 'reverse_mut', 'copy'].includes(k)) range[k] = (s, a) => list[k](s.toArray(), a);

// ---------- numbers ----------
const numM = {
    abs: (s) => Math.abs(s), floor: (s) => Math.floor(s), ceil: (s) => Math.ceil(s), trunc: (s) => Math.trunc(s),
    round: (s, a) => roundTo(s, a.length ? a[0] : 0),
    sqrt: (s) => Math.sqrt(s), cbrt: (s) => Math.cbrt(s), pow: (s, a) => Math.pow(s, a[0]),
    exp: (s) => Math.exp(s), ln: (s) => Math.log(s), log10: (s) => Math.log10(s), log2: (s) => Math.log2(s), log: (s, a) => Math.log(s) / Math.log(a[0]),
    sin: (s) => Math.sin(s), cos: (s) => Math.cos(s), tan: (s) => Math.tan(s),
    min: (s, a) => Math.min(s, ...a), max: (s, a) => Math.max(s, ...a),
    clamp: (s, a) => Math.min(Math.max(s, a[0]), a[1]),
    sign: (s) => Math.sign(s),
    div: (s, a) => { if (a[0] === 0) throw rtError('Cannot divide by zero', 'MathError'); return Math.floor(s / a[0]); },
    rem: (s, a) => s % a[0],
    mod: (s, a) => binop('%', s, a[0]),
    is_nan: (s) => Number.isNaN(s), is_int: (s) => Number.isInteger(s), is_finite: (s) => Number.isFinite(s),
    is_even: (s) => s % 2 === 0, is_odd: (s) => Math.abs(s % 2) === 1,
    to_int: (s) => Math.trunc(s), to_float: (s) => s,
    to_hex: (s) => Math.trunc(s).toString(16), to_bin: (s) => Math.trunc(s).toString(2), to_oct: (s) => Math.trunc(s).toString(8),
    to_base: (s, a) => Math.trunc(s).toString(a[0]),
    digits: (s) => Array.from(String(Math.abs(Math.trunc(s))), Number),
    times: (s, a) => { const f = cb(a[0]); for (let i = 0; i < s; i++) f(i); return null; },
    upto: (s, a) => new SRange(s, a[0], true, 1),
    lerp: (s, a) => s + (a[0] - s) * a[1],
    to_big: (s) => BigInt(Math.trunc(s)),
    to_char: (s) => String.fromCodePoint(s),
    percent: (s) => fmtNum(s * 100) + '%',
};
const bigM = {
    abs: (s) => (s < 0n ? -s : s), to_int: (s) => Number(s), to_float: (s) => Number(s), pow: (s, a) => s ** BigInt(a[0]),
    is_even: (s) => s % 2n === 0n, is_odd: (s) => s % 2n !== 0n, sign: (s) => (s > 0n ? 1 : s < 0n ? -1 : 0),
    to_hex: (s) => s.toString(16), to_bin: (s) => s.toString(2), digits: (s) => Array.from(s.toString().replace('-', ''), Number),
};


// ---------- complex numbers ----------
const cxRound = (z, p) => { const f = Math.pow(10, p || 0); const r = (x) => Math.sign(x) * Math.round(Math.abs(x) * f + 1e-9) / f; return CX.C(r(z.re), r(z.im)); };
const cxM = {
    re: (s) => s.re, im: (s) => s.im, abs: (s) => CX.abs(s), arg: (s) => CX.arg(s), norm: (s) => CX.norm2(s), conj: (s) => CX.conj(s),
    sqrt: (s) => CX.sqrt(s), exp: (s) => CX.exp(s), ln: (s) => CX.ln(s), pow: (s, a) => CX.pow(s, CX.lift(a[0])),
    sin: (s) => CX.sin(s), cos: (s) => CX.cos(s), tan: (s) => CX.tan(s), sinh: (s) => CX.sinh(s), cosh: (s) => CX.cosh(s), tanh: (s) => CX.tanh(s),
    polar: (s) => tuple([CX.abs(s), CX.arg(s)]), inv: (s) => CX.div(CX.C(1, 0), s), roots: (s, a) => CX.roots(s, a[0]),
    round: (s, a) => cxRound(s, a.length ? a[0] : 0), is_real: (s) => s.im === 0, is_nan: (s) => Number.isNaN(s.re) || Number.isNaN(s.im),
    to_real: (s) => { if (s.im !== 0) throw rtError('This number has an imaginary part (' + s.im + 'i), so it is not a real number', 'MathError'); return s.re; },
};


// ---------- pools (the receiver is the pool itself, so asking about it never decides it) ----------
const poolChances = (p) => {
    if (p.sampler) return null;
    const ws = p.weights || p.options.map(() => 1);
    const total = ws.reduce((a, b) => a + b, 0) || 1;
    const m = new SMap();
    p.options.forEach((o, i) => m.set(o, (m.get(o) || 0) + ws[i] / total));
    return m;
};
const poolRoll = (p) => (p.sampler ? p.sampler() : p.options[rt.pickIndex(p.weights, p.options.length)]);
export function entangle(pools) {
    const ps = pools.map((p) => { if (!(p instanceof SPool)) throw rtError('entangle needs pools, but got a ' + typeOf(p), 'PoolError'); if (p.sampler) throw rtError('A pool made from a function cannot be entangled', 'PoolError'); return p; });
    if (ps.some((p) => p.options.length !== ps[0].options.length)) throw rtError('Entangled pools need the same number of options, so the same position can be picked in each', 'PoolError');
    const g = { index: null, members: ps };
    for (const p of ps) { if (p.group) { for (const m of p.group.members) if (!ps.includes(m)) { g.members.push(m); } } p.group = g; }
    for (const p of g.members) p.group = g;
    return ps[0];
}
const poolM = {
    decide: (s) => s.decide(),
    peek: (s) => (s.decided ? s.value : null),
    is_decided: (s) => s.decided,
    // let it be undecided again (an entangled pool takes its partners with it)
    forget: (s) => { const all = s.group ? s.group.members : [s]; for (const p of all) { p.decided = false; p.value = null; } if (s.group) s.group.index = null; return s; },
    options: (s) => (s.options ? s.options.slice() : null), size: (s) => (s.options ? s.options.length : null),
    chances: (s) => poolChances(s),
    odds_of: (s, a) => { const m = poolChances(s); if (!m) throw rtError('A pool made from a function has no fixed odds', 'PoolError'); return m.get(a[0]) || 0; },
    most_likely: (s) => { const m = poolChances(s); if (!m) return null; let best = null, bp = -1; for (const [k, v] of m.entries()) if (v > bp) { bp = v; best = k; } return best; },
    with_weights: (s, a) => { if (s.sampler) throw rtError('A pool made from a function has no options to weigh', 'PoolError'); return makePool(s.options.slice(), a[0]); },
    // a new pool that keeps only the options that pass (still undecided)
    where: (s, a) => { if (s.sampler) { const f = cb(a[0]); return new SPool(null, null, () => { for (let i = 0; i < 10000; i++) { const v = s.sampler(); if (truthy(f(v))) return v; } throw rtError('where: no value passed the test after 10000 tries', 'PoolError'); }); } const f = cb(a[0]); const keep = s.options.map((o) => truthy(f(o))); return new SPool(s.options.filter((_, i) => keep[i]), s.weights ? s.weights.filter((_, i) => keep[i]) : null); },
    map: (s, a) => { const f = cb(a[0]); if (s.sampler) return new SPool(null, null, () => f(s.sampler())); return new SPool(s.options.map((o) => f(o)), s.weights ? s.weights.slice() : null); },
    // fresh draws that do not decide the pool
    roll: (s) => poolRoll(s), rolls: (s, a) => Array.from({ length: a[0] }, () => poolRoll(s)),
    // how often each option comes up in n fresh draws
    simulate: (s, a) => { const m = new SMap(); for (let i = 0; i < (a[0] || 1000); i++) { const v = poolRoll(s); m.set(v, (m.get(v) || 0) + 1); } return m; },
    entangle: (s, a) => entangle([s].concat(a)),
    is_entangled: (s) => !!s.group,
    copy: (s) => { const p = new SPool(s.options && s.options.slice(), s.weights && s.weights.slice(), s.sampler); return p; },
};


// ---------- futures (what an async function gives back) ----------
const futureM = {
    then: (s, a) => { const f = cb(a[0]); return s.then((v) => f(v)); },
    catch: (s, a) => { const f = cb(a[0]); return s.then(null, (e) => f(rt.errValue(e))); },
    finally: (s, a) => { const f = cb(a[0]); return s.finally(() => f()); },
};

// ---------- lazy iterators ----------
const iter = {
    next: (s) => { const r = s.it.next(); return r.done ? null : r.value; },
    map: (s, a) => { const f = cb(a[0]); return lazy(function* () { for (const x of s.it) yield f(x); }); },
    filter: (s, a) => { const f = cb(a[0]); return lazy(function* () { for (const x of s.it) if (truthy(f(x))) yield x; }); },
    take: (s, a) => lazy(function* () { let n = a[0]; if (n <= 0) return; for (const x of s.it) { yield x; if (--n <= 0) return; } }),
    skip: (s, a) => lazy(function* () { let n = a[0]; for (const x of s.it) { if (n-- > 0) continue; yield x; } }),
    take_while: (s, a) => { const f = cb(a[0]); return lazy(function* () { for (const x of s.it) { if (!truthy(f(x))) return; yield x; } }); },
    skip_while: (s, a) => { const f = cb(a[0]); return lazy(function* () { let skipping = true; for (const x of s.it) { if (skipping && truthy(f(x))) continue; skipping = false; yield x; } }); },
    enumerate: (s, a) => lazy(function* () { let i = a.length ? a[0] : 0; for (const x of s.it) yield tuple([i++, x]); }),
    zip: (s, a) => lazy(function* () { const others = a.map((o) => iterate(o)[Symbol.iterator]()); for (const x of s.it) { const row = [x]; for (const o of others) { const r = o.next(); if (r.done) return; row.push(r.value); } yield tuple(row); } }),
    chain: (s, a) => lazy(function* () { yield* s.it; for (const o of a) yield* iterate(o); }),
    flat_map: (s, a) => { const f = cb(a[0]); return lazy(function* () { for (const x of s.it) { const y = f(x); if (y !== null && typeof y === 'object' && (Array.isArray(y) || y instanceof SIter || y instanceof SRange || y instanceof SSet)) yield* iterate(y); else yield y; } }); },
    flatten: (s) => lazy(function* () { for (const x of s.it) { if (Array.isArray(x) || x instanceof SIter) yield* iterate(x); else yield x; } }),
    chunk: (s, a) => lazy(function* () { let c = []; for (const x of s.it) { c.push(x); if (c.length === a[0]) { yield c; c = []; } } if (c.length) yield c; }),
    window: (s, a) => lazy(function* () { const w = []; for (const x of s.it) { w.push(x); if (w.length > a[0]) w.shift(); if (w.length === a[0]) yield w.slice(); } }),
    step: (s, a) => lazy(function* () { let i = 0; for (const x of s.it) { if (i++ % a[0] === 0) yield x; } }),
    scan: (s, a) => { const f = cb(a[1]); return lazy(function* () { let acc = a[0]; yield acc; for (const x of s.it) { acc = f(acc, x); yield acc; } }); },
    inspect: (s, a) => { const f = cb(a[0]); return lazy(function* () { for (const x of s.it) { f(x); yield x; } }); },
    cycle: (s) => lazy(function* () { const buf = []; for (const x of s.it) { buf.push(x); yield x; } if (!buf.length) return; for (;;) yield* buf; }),
    unique: (s) => lazy(function* () { const seen = new SSet(); for (const x of s.it) if (!seen.has(x)) { seen.add(x); yield x; } }),
    collect: (s) => Array.from(s.it), to_list: (s) => Array.from(s.it),
    nth: (s, a) => { let i = 0; for (const x of s.it) { if (i++ === a[0]) return x; } return null; },
    last: (s) => { let l = null; for (const x of s.it) l = x; return l; },
    iter: (s) => s,
};
for (const k of ['each', 'reduce', 'fold', 'find', 'find_index', 'any', 'all', 'count', 'sum', 'product', 'min', 'max', 'min_by', 'max_by', 'join', 'to_set', 'contains', 'first']) {
    iter[k] = (s, a) => { if (k === 'first') { const r = s.it.next(); return r.done ? null : r.value; } return (seq[k])(Array.from(s.it), a); };
}
iter.to_map = (s) => list.to_map(Array.from(s.it));
iter.group_by = (s, a) => list.group_by(Array.from(s.it), a);

// ---------- Result ----------
const result = {
    is_ok: (s) => s.v.name === 'Ok', is_err: (s) => s.v.name === 'Err',
    unwrap: (s) => { if (s.v.name === 'Ok') return s.vals[0]; throw rtError('unwrap on an Err: ' + show(s.vals[0]), 'UnwrapError'); },
    expect: (s, a) => { if (s.v.name === 'Ok') return s.vals[0]; throw rtError(show(a[0]) + ': ' + show(s.vals[0]), 'UnwrapError'); },
    unwrap_or: (s, a) => (s.v.name === 'Ok' ? s.vals[0] : a[0]),
    unwrap_or_else: (s, a) => (s.v.name === 'Ok' ? s.vals[0] : cb(a[0])(s.vals[0])),
    unwrap_err: (s) => { if (s.v.name === 'Err') return s.vals[0]; throw rtError('unwrap_err on an Ok', 'UnwrapError'); },
    map: (s, a) => (s.v.name === 'Ok' ? ok(cb(a[0])(s.vals[0])) : s),
    map_err: (s, a) => (s.v.name === 'Err' ? err(cb(a[0])(s.vals[0])) : s),
    and_then: (s, a) => (s.v.name === 'Ok' ? cb(a[0])(s.vals[0]) : s),
    or_else: (s, a) => (s.v.name === 'Err' ? cb(a[0])(s.vals[0]) : s),
    ok: (s) => (s.v.name === 'Ok' ? s.vals[0] : null),
    err: (s) => (s.v.name === 'Err' ? s.vals[0] : null),
};

// ---------- functions, symbols, bytes, dates, objects ----------
const fnM = {
    call: (s, a, n) => call(s, a, n && null), apply: (s, a) => call(s, arr(a[0])),
    name: (s) => s.name || null,
    arity: (s) => (s.params ? s.params.filter((p) => !p.rest && !p.self).length : s.length),
    partial: (s, a, n) => makePartial(s, a, n, false), partial_right: (s, a, n) => makePartial(s, a, n, true),
    then: (s, a) => (...x) => call(a[0], [call(s, x)]),
};
const symM = { name: (s) => s.name };
const bytesM = {
    len: (s) => s.length, to_str: (s) => new TextDecoder().decode(s), to_list: (s) => Array.from(s),
    hex: (s) => Array.from(s, (b) => b.toString(16).padStart(2, '0')).join(''),
    slice: (s, a) => s.slice(a[0], a[1]), get: (s, a) => (a[0] < s.length ? s[a[0]] : null),
};
const dateM = {
    year: (s) => s.getUTCFullYear(), month: (s) => s.getUTCMonth() + 1, day: (s) => s.getUTCDate(), hour: (s) => s.getUTCHours(), minute: (s) => s.getUTCMinutes(), second: (s) => s.getUTCSeconds(),
    weekday: (s) => s.getUTCDay(), timestamp: (s) => s.getTime() / 1000, ms: (s) => s.getTime(), iso: (s) => s.toISOString(),
};
const objectM = {
    to_map: (s) => { const m = new SMap(); for (const k of Object.keys(s.f)) m.set(k, s.f[k]); return m; },
    fields: (s) => Object.keys(s.f), copy: (s) => new SObj(s.type, Object.assign(Object.create(null), s.f)),
    with: (s, a, n) => { const f = Object.assign(Object.create(null), s.f); const o = (a[0] instanceof SMap) ? Object.fromEntries(a[0].entries().map(([k, v]) => [k, v])) : (n || {}); for (const k of Object.keys(o)) { if (!(k in f)) throw rtError(s.type.name + ' has no field "' + k + '"'); f[k] = o[k]; } return new SObj(s.type, f); },
    type_name: (s) => s.type.name,
    keys: (s) => Object.keys(s.f), values: (s) => Object.keys(s.f).map((k) => s.f[k]),
};
const common = {
    to_str: (s) => show(s), repr: (s) => repr(s), type: (s) => typeOf(s),
    is_none: () => false, hash: (s) => rt.keyOf(s),
};

// bind natives so every method returns none rather than undefined
const KINDS = { future: futureM, pool: poolM, complex: cxM, list, tuple: list, str, map, set, range, num: numM, bigint: bigM, iter, result, fn: fnM, sym: symM, bytes: bytesM, datetime: dateM, object: objectM, bool: {} };
const built = {};
export function methodsFor(kind) {
    if (built[kind]) return built[kind];
    const src = KINDS[kind] || {};
    const out = {};
    const names = new Set(Object.keys(common).concat(Object.keys(src)));
    for (const k of names) {
        const f = src[k] || common[k];
        out[k] = (self, args, named) => { const r = f(self, args || [], named); return r === undefined ? null : r; };
    }
    if (kind === 'tuple') for (const k of ['push', 'pop', 'shift', 'unshift', 'insert', 'remove', 'delete', 'clear', 'extend', 'sort_mut', 'reverse_mut']) delete out[k];
    built[kind] = out;
    return out;
}
export const KIND_TABLES = KINDS;
