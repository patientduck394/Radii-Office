/* Suave lexer: turns source text into tokens. Strings keep their {interpolations} as parts for the parser. */
import rt from './runtime.js';

const KEYWORDS = new Set(['let', 'var', 'const', 'fn', 'if', 'else', 'match', 'for', 'while', 'loop', 'in', 'break', 'continue', 'return', 'try', 'catch', 'finally',
    'throw', 'struct', 'enum', 'impl', 'trait', 'use', 'as', 'pub', 'true', 'false', 'none', 'and', 'or', 'not', 'is', 'pool', 'async', 'await', 'lambda']);
// Python-style words that mean the same as Suave's own: def = fn, elif = else if, except = catch, raise = throw, import = use, True/False/None, pass = none
const ALIASES = { def: 'fn', elif: 'elif', except: 'catch', raise: 'throw', import: 'use', True: 'true', False: 'false', None: 'none', pass: 'none' };
const OPS = ['**=', '??=', '..=', '|>', '..', '**', '==', '!=', '<=', '>=', '??', '?.', '=>', '->', '+=', '-=', '*=', '/=', '%=', '#{',
    '+', '-', '*', '/', '%', '<', '>', '=', '(', ')', '[', ']', '{', '}', ',', '.', ':', ';', '?', '!', '@', '#', '&', '^', '~', '|', '$'];

export class SuaveSyntaxError extends Error {
    constructor(msg, line, col, file) { super(msg); this.line = line; this.col = col; this.file = file; this.syntax = true; }
}

const isDigit = (c) => c >= '0' && c <= '9';
const isIdStart = (c) => (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c === '_' || c > '\x7f';
const isIdPart = (c) => isIdStart(c) || isDigit(c);

const SPEC = /^[<>^=]?[+\- ]?#?0?\d*,?(\.\d+)?[a-zA-Z%]?$|^.[<>^=][+\- ]?#?0?\d*,?(\.\d+)?[a-zA-Z%]?$/;

export function lex(src, file, lineBase) {
    file = file || '<main>';
    const toks = [];
    let i = 0, line = (lineBase || 0) + 1, lineStart = 0, nl = false;
    const n = src.length;
    const fail = (msg, at) => { throw new SuaveSyntaxError(msg, line, (at === undefined ? i : at) - lineStart + 1, file); };
    const push = (t, v, extra) => { const tok = { t, v, line, col: i - lineStart + 1, nl }; if (extra) Object.assign(tok, extra); toks.push(tok); nl = false; return tok; };

    // find the end of a string started at src[i] == quote, skipping {...} interpolations
    function scanString(from, quote, interp) {
        let j = from;
        while (j < n) {
            const c = src[j];
            if (c === '\\') { j += 2; continue; }
            if (c === quote) return j;
            if (interp && c === '{') { j = skipBalanced(j); continue; }
            if (c === '\n') { if (quote === '"' || quote === "'") { /* strings may span lines */ } }
            j++;
        }
        fail('This string never ends', from - 1);
    }
    function skipBalanced(from) {
        let depth = 0, j = from;
        while (j < n) {
            const c = src[j];
            if (c === '{') depth++;
            else if (c === '}') { depth--; if (depth === 0) return j + 1; }
            else if (c === '"' || c === "'") { j = scanString(j + 1, c, c === '"') + 1; continue; }
            j++;
        }
        fail('A { in a string was never closed', from);
    }
    function splitSpec(code) {
        let depth = 0, last = -1, q = null;
        for (let k = 0; k < code.length; k++) {
            const c = code[k];
            if (q) { if (c === '\\') k++; else if (c === q) q = null; continue; }
            if (c === '"' || c === "'") q = c;
            else if (c === '(' || c === '[' || c === '{') depth++;
            else if (c === ')' || c === ']' || c === '}') depth--;
            else if (c === ':' && depth === 0) last = k;
        }
        if (last > 0) {
            const spec = code.slice(last + 1).trim();
            if (spec && SPEC.test(spec) && code[last + 1] !== ':' && code[last - 1] !== ':') return [code.slice(0, last), spec];
        }
        return [code, null];
    }
    function parts(body, interp, raw, ln) {
        if (raw) return [body];
        const out = [];
        let buf = '', k = 0, curLine = ln;
        const flush = () => { if (buf) { out.push(buf); buf = ''; } };
        while (k < body.length) {
            const c = body[k];
            if (c === '\\') {
                const d = body[k + 1];
                k += 2;
                switch (d) {
                    case 'n': buf += '\n'; break; case 't': buf += '\t'; break; case 'r': buf += '\r'; break; case '0': buf += '\0'; break;
                    case 'e': buf += '\x1b'; break;
                    case 'x': buf += String.fromCharCode(parseInt(body.substr(k, 2), 16)); k += 2; break;
                    case 'u': {
                        if (body[k] === '{') { const e = body.indexOf('}', k); buf += String.fromCodePoint(parseInt(body.slice(k + 1, e), 16)); k = e + 1; }
                        else { buf += String.fromCharCode(parseInt(body.substr(k, 4), 16)); k += 4; }
                        break;
                    }
                    case '\n': while (k < body.length && /[ \t]/.test(body[k])) k++; break; // a backslash at the end of a line joins the next
                    default: buf += d === undefined ? '\\' : d;
                }
                continue;
            }
            if (c === '{' && interp) {
                // measure the balanced braces within body
                let depth = 0, j = k, q = null;
                for (; j < body.length; j++) {
                    const ch = body[j];
                    if (q) { if (ch === '\\') j++; else if (ch === q) q = null; continue; }
                    if (ch === '"' || ch === "'") q = ch;
                    else if (ch === '{') depth++;
                    else if (ch === '}') { depth--; if (depth === 0) break; }
                }
                if (depth !== 0) fail('A { in a string was never closed (write \\{ for a plain brace)');
                const code = body.slice(k + 1, j);
                if (!code.trim()) fail('An empty {} in a string. Write \\{ \\} for plain braces');
                const [expr, spec] = splitSpec(code);
                flush();
                out.push({ src: expr, spec, line: curLine });
                k = j + 1;
                continue;
            }
            if (c === '\n') curLine++;
            buf += c; k++;
        }
        flush();
        return out;
    }
    function dedent(text) {
        let lines = text.split('\n');
        if (lines.length && /^[ \t]*$/.test(lines[0])) lines.shift();
        if (lines.length && /^[ \t]*$/.test(lines[lines.length - 1])) lines.pop();
        let min = Infinity;
        for (const l of lines) { if (!l.trim()) continue; const m = /^[ \t]*/.exec(l)[0].length; if (m < min) min = m; }
        if (min === Infinity) min = 0;
        return lines.map((l) => l.slice(min)).join('\n');
    }

    while (i < n) {
        const c = src[i];
        if (c === '\n') { i++; line++; lineStart = i; nl = true; continue; }
        if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
        if (c === '#' && src[i + 1] !== '{') { while (i < n && src[i] !== '\n') i++; continue; }   // a # comment (Python style); #{ starts a set, and #! on the first line is skipped too
        if (c === '/' && src[i + 1] === '/') { while (i < n && src[i] !== '\n') i++; continue; }
        if (c === '/' && src[i + 1] === '*') {
            let depth = 1; const at = i; i += 2;
            while (i < n && depth) {
                if (src[i] === '/' && src[i + 1] === '*') { depth++; i += 2; }
                else if (src[i] === '*' && src[i + 1] === '/') { depth--; i += 2; }
                else { if (src[i] === '\n') { line++; lineStart = i + 1; nl = true; } i++; }
            }
            if (depth) fail('This /* comment never ends', at);
            continue;
        }
        if ((c === 'f' || c === 'F') && (src[i + 1] === '"' || src[i + 1] === "'") && !(i > 0 && isIdPart(src[i - 1]))) { i++; continue; }   // f"..." is just "...": Suave strings always take {name}
        // strings: "..." (with {interpolation}), '...' (plain), """...""" (multi-line), r"..." (raw)
        if (c === '"' || c === "'" || ((c === 'r' || c === 'R') && (src[i + 1] === '"' || src[i + 1] === "'") && !(i > 0 && isIdPart(src[i - 1])))) {
            let raw = false, p = i;
            if (c === 'r' || c === 'R') { raw = true; p++; }
            const q = src[p];
            const interp = q === '"' && !raw;
            const startLine = line, startCol = i - lineStart + 1;
            if (src.startsWith(q + q + q, p)) {
                const end = (() => { let j = p + 3; while (j < n) { if (src[j] === '\\' && !raw) { j += 2; continue; } if (interp && src[j] === '{') { j = skipBalanced(j); continue; } if (src.startsWith(q + q + q, j)) return j; j++; } fail('This """ string never ends', p); })();
                const body = dedent(src.slice(p + 3, end));
                const tok = { t: 'str', v: null, parts: parts(body, interp, raw, startLine), line: startLine, col: startCol, nl };
                toks.push(tok); nl = false;
                for (let k = i; k < end + 3; k++) if (src[k] === '\n') { line++; lineStart = k + 1; }
                i = end + 3;
                continue;
            }
            const end = raw ? (() => { let j = p + 1; while (j < n && src[j] !== q) j++; if (j >= n) fail('This string never ends', p); return j; })() : scanString(p + 1, q, interp);
            const body = src.slice(p + 1, end);
            const tok = { t: 'str', v: null, parts: parts(body, interp, raw, startLine), line: startLine, col: startCol, nl };
            toks.push(tok); nl = false;
            for (let k = i; k < end; k++) if (src[k] === '\n') { line++; lineStart = k + 1; }
            i = end + 1;
            continue;
        }
        if (isDigit(c)) {
            const prev = toks[toks.length - 1];
            const afterDot = prev && prev.t === 'op' && prev.v === '.' && !nl;
            let j = i;
            if (!afterDot && c === '0' && /[xXbBoO]/.test(src[i + 1] || '')) {
                const base = { x: 16, b: 2, o: 8 }[src[i + 1].toLowerCase()];
                j = i + 2;
                while (j < n && /[0-9a-fA-F_]/.test(src[j])) j++;
                const txt = src.slice(i + 2, j).replace(/_/g, '');
                if (!txt) fail('A number like 0x needs digits after it');
                const v = parseInt(txt, base);
                push('num', v); i = j; continue;
            }
            while (j < n && (isDigit(src[j]) || (src[j] === '_' && isDigit(src[j + 1] || '')))) j++;
            let isFloat = false;
            if (!afterDot && src[j] === '.' && isDigit(src[j + 1] || '')) { isFloat = true; j++; while (j < n && (isDigit(src[j]) || (src[j] === '_' && isDigit(src[j + 1] || '')))) j++; }
            if (!afterDot && /[eE]/.test(src[j] || '') && (isDigit(src[j + 1] || '') || (/[+-]/.test(src[j + 1] || '') && isDigit(src[j + 2] || '')))) { isFloat = true; j += 2; while (j < n && isDigit(src[j])) j++; }
            const txt = src.slice(i, j).replace(/_/g, '');
            if (src[j] === 'n' && !isFloat && !afterDot && !isIdPart(src[j + 1] || ' ')) { push('big', BigInt(txt)); i = j + 1; continue; }
            if (src[j] === 'i' && !afterDot && !isIdPart(src[j + 1] || ' ')) { push('imag', Number(txt)); i = j + 1; continue; }   // 3i, 2.5i
            push('num', Number(txt));
            i = j;
            continue;
        }
        if (isIdStart(c)) {
            let j = i + 1;
            while (j < n && isIdPart(src[j])) j++;
            const w = src.slice(i, j);
            const prev = toks[toks.length - 1];
            const afterDot = prev && prev.t === 'op' && (prev.v === '.' || prev.v === '?.');
            const alias = afterDot ? undefined : ALIASES[w];
            if (alias === 'elif') { push('kw', 'else'); push('kw', 'if'); }
            else push(alias ? 'kw' : KEYWORDS.has(w) && !afterDot ? 'kw' : 'id', alias || w);
            i = j;
            continue;
        }
        // :symbol (only where a colon could not be a separator)
        if (c === ':' && isIdStart(src[i + 1] || ' ')) {
            const prev = toks[toks.length - 1];
            const before = src[i - 1];
            const sepLike = prev && !nl && ((prev.t === 'id' || prev.t === 'kw' || prev.t === 'num' || prev.t === 'str') && before !== ' ' && before !== '\t' && before !== undefined || (prev.t === 'op' && (prev.v === ')' || prev.v === ']' || prev.v === '}') && before !== ' '));
            // xs[:n] is a slice, not the symbol :n  (a [ right after a name, ) or ] is an index; after anything else it starts a list of symbols)
            const sliceStart = prev && prev.t === 'op' && prev.v === '[' && !nl && /[\w)\]"']/.test(src[i - 2] || ' ');
            if (!sepLike && !sliceStart && src[i + 1] !== ':') {
                let j = i + 2;
                while (j < n && isIdPart(src[j])) j++;
                push('sym', src.slice(i + 1, j));
                i = j;
                continue;
            }
        }
        let matched = null;
        for (const op of OPS) if (src.startsWith(op, i)) { matched = op; break; }
        if (!matched) fail('I do not know this character: ' + JSON.stringify(c));
        push('op', matched);
        i += matched.length;
    }
    toks.push({ t: 'eof', v: null, line, col: i - lineStart + 1, nl: true });
    return lineBase ? toks : blockify(toks, src);
}

/* Python-style blocks: a line that ends with a colon opens a block made of the lines indented below it (or, on one line, "if x: y").
   The blocks become the same { } tokens the parser already knows, so both ways of writing work and can be mixed. */
const BLOCK_STARTS = new Set(['if', 'else', 'while', 'for', 'loop', 'try', 'catch', 'finally', 'match', 'fn', 'impl', 'trait', 'struct', 'enum', 'async']);
function blockify(toks, src) {
    const lines = src.split('\n');
    const indentOf = (t) => { const ln = lines[t.line - 1] || ''; let w = 0; for (let k = 0; k < t.col - 1 && k < ln.length; k++) w += ln[k] === '\t' ? 4 : 1; return w; };
    const out = [], stack = [0];
    let depth = 0, pendingOpen = false, inlineOpen = false;
    const closer = (at) => ({ t: 'op', v: '}', line: at.line, col: at.col, nl: false, gen: true });
    const isStarter = (k) => {
        const t = toks[k];
        if (t.t === 'kw' && BLOCK_STARTS.has(t.v)) {
            if (t.v === 'fn') return toks[k + 1].t === 'id';                               // a named function (not an anonymous fn(x) = ...)
            if (t.v === 'async') return toks[k + 1].t === 'kw' && toks[k + 1].v === 'fn' && toks[k + 2].t === 'id';
            return true;
        }
        return (t.t === 'id' && t.v === 'class' && toks[k + 1].t === 'id') || (t.t === 'id' && t.v === 'case' && depth === 0) || (t.t === 'id' && t.v === 'test' && toks[k + 1].t === 'str');
    };
    for (let k = 0; k < toks.length; k++) {
        const t = toks[k];
        if ((t.nl || k === 0) && depth === 0) {
            if (inlineOpen) { out.push(closer(t)); inlineOpen = false; }
            const ind = t.t === 'eof' ? 0 : indentOf(t);
            if (pendingOpen) {
                pendingOpen = false;
                if (ind > stack[stack.length - 1]) stack.push(ind);
                else out.push(closer(t));                                                   // nothing indented below the colon: an empty block
            }
            while (stack.length > 1 && ind < stack[stack.length - 1]) { stack.pop(); out.push(closer(t)); }
            // is this line a block header? find its first colon outside brackets
            // a line that ends with a colon, like  task("build"):  or  watch(path):  also opens a block (a call with a trailing block)
            if (t.t !== 'eof' && !isStarter(k)) {
                let d = 0, last = -1;
                for (let m = k; m < toks.length; m++) {
                    const u = toks[m];
                    if (u.t === 'eof' || (m > k && u.nl && d === 0)) break;
                    if (u.t === 'op') { if (u.v === '(' || u.v === '[' || u.v === '{' || u.v === '#{') d++; else if (u.v === ')' || u.v === ']' || u.v === '}') d--; }
                    last = m;
                }
                if (last > k && d === 0 && toks[last].t === 'op' && toks[last].v === ':' && toks[last - 1].t === 'op' && toks[last - 1].v === ')') {
                    const c = toks[last];
                    toks[last] = { t: 'op', v: '{', line: c.line, col: c.col, nl: false, gen: true };
                    pendingOpen = true;
                }
            }
            if (t.t !== 'eof' && isStarter(k)) {
                let d = 0, colon = -1;
                for (let m = k; m < toks.length; m++) {
                    const u = toks[m];
                    if (m > k && u.nl && d === 0) break;
                    if (u.t === 'eof') break;
                    if (u.t === 'op') {
                        if (u.v === '(' || u.v === '[' || u.v === '{' || u.v === '#{') d++;
                        else if (u.v === ')' || u.v === ']' || u.v === '}') d--;
                        else if (u.v === ':' && d === 0) { colon = m; break; }
                    }
                }
                if (colon > 0) {
                    const c = toks[colon], after = toks[colon + 1];
                    toks[colon] = { t: 'op', v: '{', line: c.line, col: c.col, nl: false, gen: true };
                    if (after && after.t !== 'eof' && !after.nl) inlineOpen = true; else pendingOpen = true;
                }
            }
        }
        if (t.t === 'eof') { while (stack.length > 1) { stack.pop(); out.push(closer(t)); } if (pendingOpen) out.push(closer(t)); }
        if (t.t === 'op' && !t.gen) {
            if (t.v === '(' || t.v === '[' || t.v === '{' || t.v === '#{') depth++;
            else if (t.v === ')' || t.v === ']' || t.v === '}') depth = Math.max(0, depth - 1);
        }
        out.push(t);
    }
    return out;
}
export { KEYWORDS };
