/* std.async: working with futures (what async functions give back): wait for many, race, time out, retry, channels and locks. */
import { rt, SMap, SPool, SuaveError, opts, num, cb, call, map, nativeType, make, rtError, show, typeOf, ok, err, toArray, tuple } from './_util.js';

const A = (x) => toArray(x);
const pause = (s) => new Promise((r) => setTimeout(() => r(null), Math.max(0, num(s, 'delay')) * 1000));
const toP = (x) => Promise.resolve(rt.settle(x));
export const asyncModule = () => {
    const DeferredT = nativeType('Deferred', {
        resolve: (s, a) => { s.state.resolve(a.length ? a[0] : null); return null; },
        reject: (s, a) => { s.state.reject(a[0] instanceof SuaveError ? a[0] : rtError(show(a[0]), 'AsyncError')); return null; },
        is_done: (s) => s.state.done,
    }, { reprFn: (o) => '<Deferred ' + (o.state.done ? 'done' : 'waiting') + '>' });
    const ChannelT = nativeType('Channel', {
        send: (s, a) => { const st = s.state; if (st.closed) throw rtError('This channel is closed', 'ChannelError'); const w = st.waiters.shift(); if (w) w(a[0]); else st.queue.push(a[0]); return null; },
        // recv() gives a future for the next value (or none once the channel is closed and empty)
        recv: (s) => { const st = s.state; if (st.queue.length) return Promise.resolve(st.queue.shift()); if (st.closed) return Promise.resolve(null); return new Promise((res) => st.waiters.push(res)); },
        try_recv: (s) => { const st = s.state; return st.queue.length ? st.queue.shift() : null; },
        close: (s) => { s.state.closed = true; for (const w of s.state.waiters.splice(0)) w(null); return null; },
        len: (s) => s.state.queue.length, is_closed: (s) => s.state.closed,
    }, { reprFn: (o) => '<Channel ' + o.state.queue.length + ' waiting>' });
    const LockT = nativeType('Semaphore', {
        // acquire() gives a future that finishes when a place is free; release() frees one
        acquire: (s) => { const st = s.state; if (st.free > 0) { st.free--; return Promise.resolve(null); } return new Promise((res) => st.waiters.push(res)); },
        release: (s) => { const st = s.state; const w = st.waiters.shift(); if (w) w(null); else st.free++; return null; },
        free: (s) => s.state.free,
        // with(f): wait for a place, run the async function f, then free the place
        with: (s, a) => { const f = a[0]; return LockT.methods.get('acquire')(s).then(() => Promise.resolve().then(() => call(f, [])).finally(() => LockT.methods.get('release')(s))); },
    }, { reprFn: (o) => '<Semaphore ' + o.state.free + ' free>' });
    return {
        delay: pause, sleep: pause,
        // all([a, b, c]): wait for all of them, giving the list of results (the first failure fails the whole thing)
        all: (xs) => Promise.all(A(xs).map(toP)), gather: (xs) => Promise.all(A(xs).map(toP)),
        race: (xs) => Promise.race(A(xs).map(toP)), any: (xs) => Promise.any(A(xs).map(toP)),
        // settle([...]): wait for all, giving Ok(value) or Err(error) for each, never failing
        settle: (xs) => Promise.allSettled(A(xs).map(toP)).then((rs) => rs.map((r) => (r.status === 'fulfilled' ? ok(r.value) : err(rt.errValue(r.reason))))),
        spawn: (f, ...args) => Promise.resolve().then(() => call(f, args)),
        resolved: (v) => Promise.resolve(v), rejected: (msg) => Promise.reject(msg instanceof SuaveError ? msg : rtError(show(msg), 'AsyncError')),
        // timeout(fut, 2): fails with a TimeoutError when it takes longer than 2 seconds
        timeout: (fut, secs) => { let t; return Promise.race([toP(fut), new Promise((_, rej) => { t = setTimeout(() => rej(rtError('Timed out after ' + secs + ' seconds', 'TimeoutError')), secs * 1000); })]).finally(() => clearTimeout(t)); },
        // retry(|| fetch(), times: 3, delay: 0.5): run an async function again if it fails
        retry: (f, o) => { const op = opts(o); const times = op.times === undefined ? 3 : op.times; const d = op.delay || 0; return (async () => { let last = null; for (let i = 0; i < times; i++) { try { return await toP(call(f, f && f.params && !f.params.some((p) => !p.rest) ? [] : [i])); } catch (e) { last = e; if (i < times - 1 && d) await pause(d); } } throw last; })(); },
        // map_limit(items, 3, async |x| ...): run f on every item, at most 3 at a time; results keep their order
        map_limit: (items, limit, f) => { const xs = A(items); const out = new Array(xs.length); let next = 0; const worker = async () => { while (next < xs.length) { const i = next++; out[i] = await toP(call(f, [xs[i]])); } }; return Promise.all(Array.from({ length: Math.min(limit, xs.length) }, worker)).then(() => out); },
        // a future you finish by hand: let d = async.deferred(); d.resolve(5); await d.promise
        deferred: () => { const st = { done: false }; const promise = new Promise((res, rej) => { st.resolve = (v) => { st.done = true; res(v); }; st.reject = (e) => { st.done = true; rej(e); }; }); promise.catch(() => {}); const o = make(DeferredT, st); o.f.promise = promise; return o; },
        channel: () => make(ChannelT, { queue: [], waiters: [], closed: false }),
        semaphore: (n) => make(LockT, { free: n === undefined ? 1 : n, waiters: [] }),
        lock: () => make(LockT, { free: 1, waiters: [] }),
        is_future: (x) => x instanceof Promise,
        // give a future a plain value if it is already done? (not possible to check without waiting: use await)
        then: (fut, f) => { const g = cb(f); return toP(fut).then((v) => g(v)); },
        map: (fut, f) => { const g = cb(f); return toP(fut).then((v) => g(v)); },
        // run a function on every item at the same time and wait for all results
        each: (items, f) => Promise.all(A(items).map((x) => toP(call(f, [x])))),
        next_tick: () => Promise.resolve(null),
        now: () => Date.now() / 1000,
    };
};
