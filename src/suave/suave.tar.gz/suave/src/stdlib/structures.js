/* std.ds (stacks, queues, heaps, caches, tries), std.graph, std.iter (lazy sequences and combinatorics), std.func (functional tools), std.algo. */
import { rt, SMap, SSet, SObj, SVariant, Tuple, tuple, SRange, SIter, Named, opts, num, nums, list, cb, call, makePartial, map, nativeType, make, rtError, show, repr, eq, truthy, typeOf, ok, err, toArray, iterate, keyOf, str } from './_util.js';

const A = (x) => toArray(x);
const rcmp = (a, b) => rt.cmp(a, b);
const showList = (name, items) => name + '[' + items.map((x) => repr(x)).join(', ') + ']';

// ---------- std.ds ----------
export const dsModule = () => {
    const StackT = nativeType('Stack', {
        push: (s, a) => { for (const x of a) s.state.push(x); return s; }, pop: (s) => (s.state.length ? s.state.pop() : null), peek: (s) => (s.state.length ? s.state[s.state.length - 1] : null),
        len: (s) => s.state.length, size: (s) => s.state.length, is_empty: (s) => s.state.length === 0, clear: (s) => { s.state.length = 0; return s; }, to_list: (s) => s.state.slice(),
    }, { reprFn: (o) => showList('Stack', o.state), nativeIter: (o) => o.state.slice().reverse() });
    const QueueT = nativeType('Queue', {
        push: (s, a) => { for (const x of a) s.state.push(x); return s; }, enqueue: (s, a) => { for (const x of a) s.state.push(x); return s; },
        pop: (s) => (s.state.length ? s.state.shift() : null), dequeue: (s) => (s.state.length ? s.state.shift() : null), peek: (s) => (s.state.length ? s.state[0] : null),
        len: (s) => s.state.length, size: (s) => s.state.length, is_empty: (s) => s.state.length === 0, clear: (s) => { s.state.length = 0; return s; }, to_list: (s) => s.state.slice(),
    }, { reprFn: (o) => showList('Queue', o.state), nativeIter: (o) => o.state.slice() });
    const DequeT = nativeType('Deque', {
        push_back: (s, a) => { s.state.push(...a); return s; }, push_front: (s, a) => { s.state.unshift(...a); return s; }, pop_back: (s) => (s.state.length ? s.state.pop() : null), pop_front: (s) => (s.state.length ? s.state.shift() : null),
        peek_back: (s) => (s.state.length ? s.state[s.state.length - 1] : null), peek_front: (s) => (s.state.length ? s.state[0] : null), len: (s) => s.state.length, is_empty: (s) => s.state.length === 0,
        clear: (s) => { s.state.length = 0; return s; }, to_list: (s) => s.state.slice(), rotate: (s, a) => { const n = s.state.length; if (n) { const k = ((a[0] % n) + n) % n; s.state.push(...s.state.splice(0, k)); } return s; },
        get: (s, a) => { const i = a[0] < 0 ? s.state.length + a[0] : a[0]; return i >= 0 && i < s.state.length ? s.state[i] : null; },
    }, { reprFn: (o) => showList('Deque', o.state), nativeIter: (o) => o.state.slice() });

    // a binary heap: the smallest (by compare or key) comes out first
    const HeapT = nativeType('Heap', {
        push: (s, a) => { for (const x of a) heapPush(s.state, x); return s; },
        pop: (s) => heapPop(s.state), peek: (s) => (s.state.items.length ? s.state.items[0] : null),
        len: (s) => s.state.items.length, size: (s) => s.state.items.length, is_empty: (s) => s.state.items.length === 0, clear: (s) => { s.state.items.length = 0; return s; },
        to_list: (s) => { const copy = { items: s.state.items.slice(), less: s.state.less }; const out = []; let x; while (copy.items.length && (x = heapPop(copy)) !== undefined) out.push(x); return out; },
        push_pop: (s, a) => { heapPush(s.state, a[0]); return heapPop(s.state); },
    }, { reprFn: (o) => 'Heap(' + o.state.items.length + ' items, next ' + repr(o.state.items.length ? o.state.items[0] : null) + ')', nativeIter: (o) => { const copy = { items: o.state.items.slice(), less: o.state.less }; const out = []; while (copy.items.length) out.push(heapPop(copy)); return out; } });
    function heapPush(h, x) { const a = h.items; a.push(x); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (h.less(a[i], a[p])) { [a[i], a[p]] = [a[p], a[i]]; i = p; } else break; } }
    function heapPop(h) { const a = h.items; if (!a.length) return null; const top = a[0]; const last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { let m = i; const l = 2 * i + 1, r = l + 1; if (l < a.length && h.less(a[l], a[m])) m = l; if (r < a.length && h.less(a[r], a[m])) m = r; if (m === i) break; [a[i], a[m]] = [a[m], a[i]]; i = m; } } return top; }
    const mkHeap = (less, items) => { const h = make(HeapT, { items: [], less }); for (const x of items || []) heapPush(h.state, x); return h; };

    const LruT = nativeType('LRU', {
        get: (s, a) => { const m = s.state.map; const k = keyOf(a[0]); if (!m.has(k)) return a.length > 1 ? a[1] : null; const e = m.get(k); m.delete(k); m.set(k, e); return e[1]; },
        set: (s, a) => { const m = s.state.map; const k = keyOf(a[0]); if (m.has(k)) m.delete(k); m.set(k, [a[0], a[1]]); while (m.size > s.state.cap) m.delete(m.keys().next().value); return s; },
        has: (s, a) => s.state.map.has(keyOf(a[0])), delete: (s, a) => s.state.map.delete(keyOf(a[0])), len: (s) => s.state.map.size, clear: (s) => { s.state.map.clear(); return s; },
        keys: (s) => Array.from(s.state.map.values(), (e) => e[0]), get_or: (s, a) => { const k = keyOf(a[0]); if (s.state.map.has(k)) return LruT.methods.get('get')(s, [a[0]]); const v = call(a[1], []); LruT.methods.get('set')(s, [a[0], v]); return v; },
    }, { reprFn: (o) => 'LRU(' + o.state.map.size + '/' + o.state.cap + ')' });

    const CounterT = nativeType('Counter', {
        add: (s, a) => { for (const x of a) s.state.set(x, (s.state.get(x) || 0) + 1); return s; }, add_all: (s, a) => { for (const x of iterate(a[0])) s.state.set(x, (s.state.get(x) || 0) + 1); return s; },
        get: (s, a) => s.state.get(a[0]) || 0, count: (s, a) => s.state.get(a[0]) || 0, total: (s) => s.state.values().reduce((x, y) => x + y, 0), len: (s) => s.state.size,
        most_common: (s, a) => { const e = s.state.entries().sort((p, q) => q[1] - p[1]); return a.length && a[0] !== null ? e.slice(0, a[0]) : e; },
        least_common: (s, a) => { const e = s.state.entries().sort((p, q) => p[1] - q[1]); return a.length ? e.slice(0, a[0]) : e; },
        remove: (s, a) => { const c = s.state.get(a[0]) || 0; if (c <= 1) s.state.delete(a[0]); else s.state.set(a[0], c - 1); return s; },
        to_map: (s) => new SMap(s.state.entries()), keys: (s) => s.state.keys(), has: (s, a) => s.state.has(a[0]),
    }, { reprFn: (o) => 'Counter' + rt.repr(o.state), nativeIter: (o) => o.state.entries() });

    const TrieT = nativeType('Trie', {
        insert: (s, a) => { let n = s.state; for (const c of Array.from(str(a[0]))) { n = n.kids.get(c) || (n.kids.set(c, { kids: new Map(), end: false }), n.kids.get(c)); } n.end = true; return s; },
        has: (s, a) => { let n = s.state; for (const c of Array.from(str(a[0]))) { n = n.kids.get(c); if (!n) return false; } return n.end; },
        starts_with: (s, a) => { let n = s.state; for (const c of Array.from(str(a[0]))) { n = n.kids.get(c); if (!n) return []; } const out = []; const go = (nd, p) => { if (nd.end) out.push(p); for (const [c, k] of Array.from(nd.kids).sort((x, y) => (x[0] < y[0] ? -1 : 1))) go(k, p + c); }; go(n, a[0]); return out; },
        has_prefix: (s, a) => { let n = s.state; for (const c of Array.from(str(a[0]))) { n = n.kids.get(c); if (!n) return false; } return true; },
        words: (s) => { const out = []; const go = (nd, p) => { if (nd.end) out.push(p); for (const [c, k] of Array.from(nd.kids).sort((x, y) => (x[0] < y[0] ? -1 : 1))) go(k, p + c); }; go(s.state, ''); return out; },
    }, { reprFn: () => '<Trie>' });

    const UnionT = nativeType('UnionFind', {
        find: (s, a) => { const p = s.state.parent; let x = a[0]; while (p[x] !== x) { p[x] = p[p[x]]; x = p[x]; } return x; },
        union: (s, a) => { const f = UnionT.methods.get('find'); const x = f(s, [a[0]]), y = f(s, [a[1]]); if (x === y) return false; const p = s.state.parent, r = s.state.rank; if (r[x] < r[y]) p[x] = y; else if (r[x] > r[y]) p[y] = x; else { p[y] = x; r[x]++; } s.state.groups--; return true; },
        connected: (s, a) => UnionT.methods.get('find')(s, [a[0]]) === UnionT.methods.get('find')(s, [a[1]]), groups: (s) => s.state.groups, len: (s) => s.state.parent.length,
    }, { reprFn: (o) => 'UnionFind(' + o.state.parent.length + ' items, ' + o.state.groups + ' groups)' });

    const RingT = nativeType('Ring', {
        push: (s, a) => { for (const x of a) { s.state.items.push(x); if (s.state.items.length > s.state.cap) s.state.items.shift(); } return s; },
        to_list: (s) => s.state.items.slice(), len: (s) => s.state.items.length, last: (s) => (s.state.items.length ? s.state.items[s.state.items.length - 1] : null), first: (s) => (s.state.items.length ? s.state.items[0] : null),
        mean: (s) => (s.state.items.length ? s.state.items.reduce((x, y) => x + y, 0) / s.state.items.length : null), is_full: (s) => s.state.items.length === s.state.cap, clear: (s) => { s.state.items.length = 0; return s; },
    }, { reprFn: (o) => showList('Ring', o.state.items), nativeIter: (o) => o.state.items.slice() });

    const SetT = nativeType('SortedList', {
        add: (s, a) => { for (const x of a) { const it = s.state; let lo = 0, hi = it.length; while (lo < hi) { const mid = (lo + hi) >> 1; if (rcmp(it[mid], x) < 0) lo = mid + 1; else hi = mid; } it.splice(lo, 0, x); } return s; },
        to_list: (s) => s.state.slice(), len: (s) => s.state.length, first: (s) => (s.state.length ? s.state[0] : null), last: (s) => (s.state.length ? s.state[s.state.length - 1] : null),
        has: (s, a) => { let lo = 0, hi = s.state.length - 1; while (lo <= hi) { const mid = (lo + hi) >> 1; const c = rcmp(s.state[mid], a[0]); if (c === 0) return true; if (c < 0) lo = mid + 1; else hi = mid - 1; } return false; },
        remove: (s, a) => { const i = s.state.findIndex((x) => eq(x, a[0])); if (i >= 0) { s.state.splice(i, 1); return true; } return false; },
        pop_first: (s) => (s.state.length ? s.state.shift() : null), pop_last: (s) => (s.state.length ? s.state.pop() : null),
        at: (s, a) => { const i = a[0] < 0 ? s.state.length + a[0] : a[0]; return s.state[i] === undefined ? null : s.state[i]; },
        range: (s, a) => s.state.filter((x) => rcmp(x, a[0]) >= 0 && rcmp(x, a[1]) < 0),
    }, { reprFn: (o) => showList('SortedList', o.state), nativeIter: (o) => o.state.slice() });

    return {
        stack: (items) => { const s = make(StackT, []); if (items !== undefined) s.state.push(...A(items)); return s; },
        queue: (items) => { const s = make(QueueT, []); if (items !== undefined) s.state.push(...A(items)); return s; },
        deque: (items) => { const s = make(DequeT, []); if (items !== undefined) s.state.push(...A(items)); return s; },
        // heap() is a min-heap; heap(key: |x| x.priority) orders by a key; max_heap() puts the largest first; heap_of(list) builds one from a list
        heap: (o) => { const op = opts(o); const key = op.key; const f = key ? cb(key) : null; return mkHeap(f ? (a, b) => rcmp(f(a), f(b)) < 0 : (a, b) => rcmp(a, b) < 0); },
        min_heap: (items) => mkHeap((a, b) => rcmp(a, b) < 0, items === undefined || items instanceof Named ? [] : A(items)),
        max_heap: (items) => mkHeap((a, b) => rcmp(a, b) > 0, items === undefined || items instanceof Named ? [] : A(items)),
        heap_of: (items, o) => { const op = opts(o); const f = op.key ? cb(op.key) : null; return mkHeap(f ? (a, b) => rcmp(f(a), f(b)) < 0 : (a, b) => rcmp(a, b) < 0, A(items)); },
        lru: (cap) => make(LruT, { cap: num(cap, 'lru'), map: new Map() }),
        counter: (items) => { const c = make(CounterT, new SMap()); if (items !== undefined) for (const x of iterate(items)) c.state.set(x, (c.state.get(x) || 0) + 1); return c; },
        trie: (words) => { const t = make(TrieT, { kids: new Map(), end: false }); if (words !== undefined) for (const w of A(words)) TrieT.methods.get('insert')(t, [w]); return t; },
        union_find: (n) => make(UnionT, { parent: Array.from({ length: n }, (_, i) => i), rank: new Array(n).fill(0), groups: n }),
        ring: (cap) => make(RingT, { cap, items: [] }),
        sorted_list: (items) => { const s = make(SetT, []); if (items !== undefined) SetT.methods.get('add')(s, A(items)); return s; },
        default_map: (f) => { const g = cb(f); const m = new SMap(); return map({ get: (k) => { let v = m.get(k); if (v === undefined) { v = g(); m.set(k, v); } return v; }, set: (k, v) => { m.set(k, v); return null; }, to_map: () => m }); },
    };
};

// ---------- std.graph ----------
export const graphModule = () => {
    const GraphT = nativeType('Graph', {
        add_node: (s, a) => { const g = s.state; for (const n of a) { const k = keyOf(n); if (!g.nodes.has(k)) { g.nodes.set(k, n); g.adj.set(k, new Map()); } } return s; },
        add_edge: (s, a) => { const g = s.state; const w = a.length > 2 ? a[2] : 1; for (const n of [a[0], a[1]]) { const k = keyOf(n); if (!g.nodes.has(k)) { g.nodes.set(k, n); g.adj.set(k, new Map()); } } g.adj.get(keyOf(a[0])).set(keyOf(a[1]), w); if (!g.directed) g.adj.get(keyOf(a[1])).set(keyOf(a[0]), w); return s; },
        add_edges: (s, a) => { for (const e of A(a[0])) GraphT.methods.get('add_edge')(s, Array.from(e)); return s; },
        remove_edge: (s, a) => { const g = s.state; const m = g.adj.get(keyOf(a[0])); if (m) m.delete(keyOf(a[1])); if (!g.directed) { const m2 = g.adj.get(keyOf(a[1])); if (m2) m2.delete(keyOf(a[0])); } return s; },
        remove_node: (s, a) => { const g = s.state; const k = keyOf(a[0]); g.nodes.delete(k); g.adj.delete(k); for (const m of g.adj.values()) m.delete(k); return s; },
        has_node: (s, a) => s.state.nodes.has(keyOf(a[0])), has_edge: (s, a) => { const m = s.state.adj.get(keyOf(a[0])); return !!m && m.has(keyOf(a[1])); },
        nodes: (s) => Array.from(s.state.nodes.values()),
        edges: (s) => { const g = s.state; const out = []; const seen = new Set(); for (const [k, m] of g.adj) for (const [k2, w] of m) { const id = g.directed ? k + '>' + k2 : [k, k2].sort().join('|'); if (seen.has(id)) continue; seen.add(id); out.push(tuple([g.nodes.get(k), g.nodes.get(k2), w])); } return out; },
        neighbors: (s, a) => { const m = s.state.adj.get(keyOf(a[0])); return m ? Array.from(m.keys(), (k) => s.state.nodes.get(k)) : []; },
        weight: (s, a) => { const m = s.state.adj.get(keyOf(a[0])); const w = m && m.get(keyOf(a[1])); return w === undefined ? null : w; },
        degree: (s, a) => { const m = s.state.adj.get(keyOf(a[0])); return m ? m.size : 0; },
        len: (s) => s.state.nodes.size,
        bfs: (s, a) => { const g = s.state; const start = keyOf(a[0]); if (!g.nodes.has(start)) return []; const seen = new Set([start]); const q = [start]; const out = []; while (q.length) { const k = q.shift(); out.push(g.nodes.get(k)); for (const n of g.adj.get(k).keys()) if (!seen.has(n)) { seen.add(n); q.push(n); } } return out; },
        dfs: (s, a) => { const g = s.state; const start = keyOf(a[0]); if (!g.nodes.has(start)) return []; const seen = new Set(); const out = []; const st = [start]; while (st.length) { const k = st.pop(); if (seen.has(k)) continue; seen.add(k); out.push(g.nodes.get(k)); const ns = Array.from(g.adj.get(k).keys()).reverse(); for (const n of ns) if (!seen.has(n)) st.push(n); } return out; },
        // cheapest path with edge weights (Dijkstra): a map {distance, path}, or none when there is no way
        shortest_path: (s, a) => { const g = s.state; const src = keyOf(a[0]), dst = keyOf(a[1]); if (!g.nodes.has(src) || !g.nodes.has(dst)) return null; const dist = new Map([[src, 0]]), prev = new Map(); const pq = [[0, src]]; const done = new Set(); while (pq.length) { pq.sort((x, y) => x[0] - y[0]); const [d, k] = pq.shift(); if (done.has(k)) continue; done.add(k); if (k === dst) break; for (const [n, w] of g.adj.get(k)) { if (w < 0) throw rtError('shortest_path cannot use negative weights', 'MathError'); const nd = d + w; if (!dist.has(n) || nd < dist.get(n)) { dist.set(n, nd); prev.set(n, k); pq.push([nd, n]); } } } if (!dist.has(dst)) return null; const path = []; for (let k = dst; k !== undefined; k = prev.get(k)) path.unshift(g.nodes.get(k)); return map({ distance: dist.get(dst), path }); },
        distances: (s, a) => { const g = s.state; const src = keyOf(a[0]); const dist = new Map([[src, 0]]); const pq = [[0, src]]; const done = new Set(); while (pq.length) { pq.sort((x, y) => x[0] - y[0]); const [d, k] = pq.shift(); if (done.has(k)) continue; done.add(k); for (const [n, w] of g.adj.get(k)) { const nd = d + w; if (!dist.has(n) || nd < dist.get(n)) { dist.set(n, nd); pq.push([nd, n]); } } } const m = new SMap(); for (const [k, d] of dist) m.set(g.nodes.get(k), d); return m; },
        has_path: (s, a) => GraphT.methods.get('bfs')(s, [a[0]]).some((n) => eq(n, a[1])),
        topo_sort: (s) => { const g = s.state; const indeg = new Map(); for (const k of g.nodes.keys()) indeg.set(k, 0); for (const m of g.adj.values()) for (const k of m.keys()) indeg.set(k, indeg.get(k) + 1); const q = Array.from(indeg).filter(([, d]) => d === 0).map(([k]) => k); const out = []; while (q.length) { const k = q.shift(); out.push(g.nodes.get(k)); for (const n of g.adj.get(k).keys()) { indeg.set(n, indeg.get(n) - 1); if (indeg.get(n) === 0) q.push(n); } } if (out.length !== g.nodes.size) throw rtError('This graph has a cycle, so it cannot be put in order', 'GraphError'); return out; },
        has_cycle: (s) => { const g = s.state; if (g.directed) { const color = new Map(); const visit = (k) => { color.set(k, 1); for (const n of g.adj.get(k).keys()) { const c = color.get(n); if (c === 1) return true; if (!c && visit(n)) return true; } color.set(k, 2); return false; }; for (const k of g.nodes.keys()) if (!color.get(k) && visit(k)) return true; return false; } const seen = new Set(); const visit = (k, p) => { seen.add(k); for (const n of g.adj.get(k).keys()) { if (!seen.has(n)) { if (visit(n, k)) return true; } else if (n !== p) return true; } return false; }; for (const k of g.nodes.keys()) if (!seen.has(k) && visit(k, null)) return true; return false; },
        components: (s) => { const g = s.state; const seen = new Set(); const out = []; for (const start of g.nodes.keys()) { if (seen.has(start)) continue; const comp = []; const st = [start]; seen.add(start); while (st.length) { const k = st.pop(); comp.push(g.nodes.get(k)); const ns = new Set(g.adj.get(k).keys()); if (g.directed) for (const [k2, m] of g.adj) if (m.has(k)) ns.add(k2); for (const n of ns) if (!seen.has(n)) { seen.add(n); st.push(n); } } out.push(comp); } return out; },
        is_connected: (s) => GraphT.methods.get('components')(s, []).length <= 1,
        // a minimum spanning tree (Kruskal) as a list of (a, b, weight)
        mst: (s) => { const g = s.state; const edges = GraphT.methods.get('edges')(s, []).sort((x, y) => x[2] - y[2]); const parent = new Map(); const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; }; for (const k of g.nodes.keys()) parent.set(k, k); const out = []; for (const e of edges) { const a = find(keyOf(e[0])), b = find(keyOf(e[1])); if (a !== b) { parent.set(a, b); out.push(e); } } return out; },
        all_paths: (s, a) => { const g = s.state; const dst = keyOf(a[1]); const out = []; const go = (k, path, seen) => { if (out.length >= 10000) return; if (k === dst) { out.push(path.map((x) => g.nodes.get(x))); return; } for (const n of g.adj.get(k).keys()) if (!seen.has(n)) { seen.add(n); path.push(n); go(n, path, seen); path.pop(); seen.delete(n); } }; const start = keyOf(a[0]); if (g.nodes.has(start)) go(start, [start], new Set([start])); return out; },
        to_map: (s) => { const g = s.state; const m = new SMap(); for (const [k, ns] of g.adj) m.set(g.nodes.get(k), Array.from(ns.keys(), (x) => g.nodes.get(x))); return m; },
    }, { reprFn: (o) => 'Graph(' + o.state.nodes.size + ' nodes, ' + GraphT.methods.get('edges')(o, []).length + ' edges' + (o.state.directed ? ', directed' : '') + ')' });
    const mk = (directed) => make(GraphT, { directed, nodes: new Map(), adj: new Map() });
    return {
        new: (o) => mk(!!opts(o).directed), directed: () => mk(true), undirected: () => mk(false),
        from_edges: (edges, o) => { const g = mk(!!opts(o).directed); for (const e of A(edges)) GraphT.methods.get('add_edge')(g, Array.from(e)); return g; },
        // a grid as a graph for path finding: "." open, "#" wall; returns a Graph with (row, col) tuple nodes
        grid: (rows) => { const g = mk(false); const lines = A(rows).map((r) => (typeof r === 'string' ? Array.from(r) : A(r))); for (let r = 0; r < lines.length; r++) for (let c = 0; c < lines[r].length; c++) { if (lines[r][c] === '#') continue; GraphT.methods.get('add_node')(g, [tuple([r, c])]); for (const [dr, dc] of [[1, 0], [0, 1]]) { const r2 = r + dr, c2 = c + dc; if (lines[r2] && lines[r2][c2] !== undefined && lines[r2][c2] !== '#') GraphT.methods.get('add_edge')(g, [tuple([r, c]), tuple([r2, c2]), 1]); } } return g; },
    };
};

// ---------- std.iter ----------
const lazy = (gen) => new SIter(gen());
const permute = (arr, k) => { const out = []; const n = arr.length; const used = new Array(n).fill(false); const cur = []; const go = () => { if (cur.length === k) { out.push(cur.slice()); if (out.length > 5000000) throw rtError('Too many results. Use fewer items', 'ArgError'); return; } for (let i = 0; i < n; i++) { if (used[i]) continue; used[i] = true; cur.push(arr[i]); go(); cur.pop(); used[i] = false; } }; go(); return out; };
const combos = (arr, k, rep) => { const out = []; const cur = []; const go = (start) => { if (cur.length === k) { out.push(cur.slice()); if (out.length > 5000000) throw rtError('Too many results. Use fewer items', 'ArgError'); return; } for (let i = start; i < arr.length; i++) { cur.push(arr[i]); go(rep ? i : i + 1); cur.pop(); } }; go(0); return out; };
export const iterModule = () => ({
    count: (start, step) => lazy(function* () { for (let i = start === undefined ? 0 : start; ; i += step === undefined ? 1 : step) yield i; }),
    cycle: (xs) => lazy(function* () { const a = A(xs); if (!a.length) return; for (;;) yield* a; }),
    repeat: (x, n) => lazy(function* () { if (n === undefined) for (;;) yield x; else for (let i = 0; i < n; i++) yield x; }),
    chain: (...xs) => lazy(function* () { for (const x of xs) yield* iterate(x); }),
    // iterate(f, x): x, f(x), f(f(x)), ... (never ends: use .take(n))
    iterate: (f, x) => { const g = cb(f); return lazy(function* () { let v = x; for (;;) { yield v; v = g(v); } }); },
    // unfold(seed, |s| (value, next_seed) or none)
    unfold: (seed, f) => { const g = cb(f); return lazy(function* () { let s = seed; for (;;) { const r = g(s); if (r === null) return; yield r[0]; s = r[1]; } }); },
    zip_longest: (a, b, fill) => { const x = A(a), y = A(b); const n = Math.max(x.length, y.length); return Array.from({ length: n }, (_, i) => tuple([i < x.length ? x[i] : (fill === undefined ? null : fill), i < y.length ? y[i] : (fill === undefined ? null : fill)])); },
    zip_with: (f, a, b) => { const g = cb(f); const x = A(a), y = A(b); return Array.from({ length: Math.min(x.length, y.length) }, (_, i) => g(x[i], y[i])); },
    product: (...lists) => { let out = [[]]; for (const l of lists) { const next = []; for (const p of out) for (const x of A(l)) next.push(p.concat([x])); out = next; if (out.length > 5000000) throw rtError('Too many combinations', 'ArgError'); } return out.map(tuple); },
    permutations: (xs, k) => { const a = A(xs); return permute(a, k === undefined ? a.length : k).map(tuple); },
    combinations: (xs, k) => combos(A(xs), k, false).map(tuple),
    combinations_with_replacement: (xs, k) => combos(A(xs), k, true).map(tuple),
    powerset: (xs) => { const a = A(xs); const out = []; for (let m = 0; m < (1 << a.length); m++) out.push(a.filter((_, i) => m & (1 << i))); return out; },
    accumulate: (xs, f) => { const g = f === undefined ? (x, y) => x + y : cb(f); const a = A(xs); const out = []; let acc; a.forEach((x, i) => { acc = i === 0 ? x : g(acc, x); out.push(acc); }); return out; },
    pairwise: (xs) => { const a = A(xs); return a.slice(1).map((x, i) => tuple([a[i], x])); },
    chunks: (xs, n) => { const a = A(xs); const out = []; for (let i = 0; i < a.length; i += n) out.push(a.slice(i, i + n)); return out; },
    windows: (xs, n) => { const a = A(xs); const out = []; for (let i = 0; i + n <= a.length; i++) out.push(a.slice(i, i + n)); return out; },
    // group neighbours with the same key: [(key, [items...]), ...]
    group_adjacent: (xs, f) => { const g = f === undefined ? (x) => x : cb(f); const out = []; for (const x of A(xs)) { const k = g(x); const last = out[out.length - 1]; if (last && eq(last[0], k)) last[1].push(x); else out.push(tuple([k, [x]])); } return out; },
    run_lengths: (xs) => { const out = []; for (const x of A(xs)) { const last = out[out.length - 1]; if (last && eq(last[0], x)) last[1]++; else out.push(tuple([x, 1])); } return out; },
    take: (xs, n) => { const out = []; if (n <= 0) return out; for (const x of iterate(xs)) { out.push(x); if (out.length >= n) break; } return out; },
    islice: (xs, a, b, step) => { const arr = A(xs); const out = []; for (let i = a || 0; i < (b === undefined || b === null ? arr.length : b); i += step || 1) out.push(arr[i]); return out; },
    interleave: (...xs) => { const a = xs.map(A); const n = Math.max(...a.map((l) => l.length)); const out = []; for (let i = 0; i < n; i++) for (const l of a) if (i < l.length) out.push(l[i]); return out; },
    flatten: (xs, depth) => { const f = (a, d) => a.reduce((acc, x) => (Array.isArray(x) && d > 0 ? acc.concat(f(x, d - 1)) : (acc.push(x), acc)), []); return f(A(xs), depth === undefined ? 1 : depth); },
    partition: (xs, f) => { const g = cb(f); const y = [], n = []; for (const x of A(xs)) (truthy(g(x)) ? y : n).push(x); return tuple([y, n]); },
    unique: (xs) => { const seen = new SSet(); const out = []; for (const x of iterate(xs)) if (!seen.has(x)) { seen.add(x); out.push(x); } return out; },
    transpose: (rows) => { const a = A(rows).map(A); return a.length ? a[0].map((_, i) => a.map((r) => r[i])) : []; },
    cartesian_power: (xs, n) => { let out = [[]]; for (let i = 0; i < n; i++) { const next = []; for (const p of out) for (const x of A(xs)) next.push(p.concat([x])); out = next; } return out.map(tuple); },
    lazy: (xs) => new SIter(iterate(xs)[Symbol.iterator]()),
    range_step: (a, b, step) => { const out = []; if (step > 0) for (let x = a; x < b; x += step) out.push(x); else for (let x = a; x > b; x += step) out.push(x); return out; },
    linspace: (a, b, n) => Array.from({ length: n }, (_, i) => a + ((b - a) * i) / Math.max(1, n - 1)),
    cumulative: (xs, f) => { const g = cb(f); const out = []; let acc; for (const x of A(xs)) { acc = out.length ? g(acc, x) : x; out.push(acc); } return out; },
});

// ---------- std.func ----------
export const funcModule = () => ({
    compose: (...fs) => (...a) => { let r = call(fs[fs.length - 1], a); for (let i = fs.length - 2; i >= 0; i--) r = call(fs[i], [r]); return r; },
    pipe: (x, ...fs) => fs.reduce((acc, f) => call(f, [acc]), x),
    pipeline: (...fs) => (x) => fs.reduce((acc, f) => call(f, [acc]), x),
    partial: (f, ...a) => { const n = a[a.length - 1] instanceof Named ? a.pop().obj : null; return makePartial(f, a, n, false); },
    partial_right: (f, ...a) => { const n = a[a.length - 1] instanceof Named ? a.pop().obj : null; return makePartial(f, a, n, true); },
    curry: (f, n) => { const k = n || (f.params ? f.params.filter((p) => !p.rest && !p.def).length : f.length); const c = (acc) => (...a) => { const all = acc.concat(a); return all.length >= k ? call(f, all) : c(all); }; return c([]); },
    flip: (f) => (a, b, ...rest) => call(f, [b, a].concat(rest)),
    identity: (x) => x, constantly: (x) => () => x, complement: (f) => (...a) => !truthy(call(f, a)), negate: (f) => (...a) => !truthy(call(f, a)),
    juxt: (...fs) => (...a) => fs.map((f) => call(f, a)),
    converge: (f, ...gs) => (...a) => call(f, gs.map((g) => call(g, a))),
    once: (f) => { let done = false, v = null; return (...a) => { if (!done) { done = true; v = call(f, a); } return v; }; },
    memoize: (f) => { const cache = new SMap(); return (...a) => { const key = tuple(a); let v = cache.get(key); if (v === undefined) { v = call(f, a); cache.set(key, v); } return v; }; },
    // keeps calling the result while it is a function (Clojure's trampoline): for deep recursion without a stack
    trampoline: (f, ...args) => { let r = call(f, args); while (typeof r === 'function' || r instanceof rt.SFn) r = call(r, []); return r; },
    tap: (x, f) => { call(f, [x]); return x; },
    thunk: (f, ...a) => () => call(f, a),
    apply: (f, args) => call(f, A(args)),
    // call f only when the condition holds, otherwise give back the value untouched
    when: (cond, f) => (x) => (truthy(call(cond, [x])) ? call(f, [x]) : x),
    fix: (f) => { const g = (...a) => call(f, [g].concat(a)); return g; },
    times: (n, f) => Array.from({ length: n }, (_, i) => call(f, [i])),
    arity: (f) => (f && f.params ? f.params.filter((p) => !p.rest).length : (typeof f === 'function' ? f.length : -1)),
});

// ---------- std.algo ----------
export const algoModule = () => {
    const bis = (xs, x, right) => { const a = A(xs); let lo = 0, hi = a.length; while (lo < hi) { const mid = (lo + hi) >> 1; const c = rcmp(a[mid], x); if (right ? c <= 0 : c < 0) lo = mid + 1; else hi = mid; } return lo; };
    const msort = (a, c) => { if (a.length < 2) return a; const m = a.length >> 1; const l = msort(a.slice(0, m), c), r = msort(a.slice(m), c); const out = []; let i = 0, j = 0; while (i < l.length && j < r.length) out.push(c(l[i], r[j]) <= 0 ? l[i++] : r[j++]); return out.concat(l.slice(i), r.slice(j)); };
    return {
        bisect_left: (xs, x) => bis(xs, x, false), bisect_right: (xs, x) => bis(xs, x, true),
        insort: (xs, x) => { const i = bis(xs, x, true); xs.splice(i, 0, x); return xs; },
        merge_sort: (xs, f) => { const c = f === undefined ? rcmp : cb(f); return msort(A(xs), c); },
        quick_select: (xs, k) => { const a = A(xs).slice().sort(rcmp); return a[k]; },
        top_k: (xs, k, f) => { const g = f === undefined ? (x) => x : cb(f); return A(xs).slice().sort((a, b) => rcmp(g(b), g(a))).slice(0, k); },
        is_sorted: (xs) => { const a = A(xs); for (let i = 1; i < a.length; i++) if (rcmp(a[i - 1], a[i]) > 0) return false; return true; },
        lis: (xs) => { const a = A(xs); const tails = [], idx = [], prev = new Array(a.length).fill(-1); for (let i = 0; i < a.length; i++) { let lo = 0, hi = tails.length; while (lo < hi) { const m = (lo + hi) >> 1; if (rcmp(tails[m], a[i]) < 0) lo = m + 1; else hi = m; } tails[lo] = a[i]; idx[lo] = i; prev[i] = lo > 0 ? idx[lo - 1] : -1; } const out = []; for (let i = idx[tails.length - 1]; i !== undefined && i >= 0; i = prev[i]) out.unshift(a[i]); return out; },
        lcs: (a, b) => { const x = Array.from(A(a)), y = Array.from(A(b)); const dp = Array.from({ length: x.length + 1 }, () => new Int32Array(y.length + 1)); for (let i = x.length - 1; i >= 0; i--) for (let j = y.length - 1; j >= 0; j--) dp[i][j] = eq(x[i], y[j]) ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]); const out = []; let i = 0, j = 0; while (i < x.length && j < y.length) { if (eq(x[i], y[j])) { out.push(x[i]); i++; j++; } else if (dp[i + 1][j] >= dp[i][j + 1]) i++; else j++; } return typeof a === 'string' ? out.join('') : out; },
        knapsack: (weights, values, cap) => { const w = nums(weights), v = nums(values); const dp = new Array(cap + 1).fill(0); for (let i = 0; i < w.length; i++) for (let c = cap; c >= w[i]; c--) dp[c] = Math.max(dp[c], dp[c - w[i]] + v[i]); return dp[cap]; },
        coin_change: (coins, amount) => { const dp = new Array(amount + 1).fill(Infinity); dp[0] = 0; for (let a = 1; a <= amount; a++) for (const c of nums(coins)) if (c <= a) dp[a] = Math.min(dp[a], dp[a - c] + 1); return dp[amount] === Infinity ? null : dp[amount]; },
        count_ways: (coins, amount) => { const dp = new Array(amount + 1).fill(0); dp[0] = 1; for (const c of nums(coins)) for (let a = c; a <= amount; a++) dp[a] += dp[a - c]; return dp[amount]; },
        two_sum: (xs, target) => { const seen = new Map(); const a = nums(xs); for (let i = 0; i < a.length; i++) { if (seen.has(target - a[i])) return tuple([seen.get(target - a[i]), i]); seen.set(a[i], i); } return null; },
        max_subarray: (xs) => { const a = nums(xs); let best = a[0], cur = a[0], s = 0, bs = 0, be = 0; for (let i = 1; i < a.length; i++) { if (cur < 0) { cur = a[i]; s = i; } else cur += a[i]; if (cur > best) { best = cur; bs = s; be = i; } } return map({ sum: best, from: bs, to: be }); },
        kmp_search: (text, pat) => { const t = str(text), p = str(pat); if (!p) return []; const fail = new Array(p.length).fill(0); for (let i = 1, k = 0; i < p.length; i++) { while (k && p[i] !== p[k]) k = fail[k - 1]; if (p[i] === p[k]) k++; fail[i] = k; } const out = []; for (let i = 0, k = 0; i < t.length; i++) { while (k && t[i] !== p[k]) k = fail[k - 1]; if (t[i] === p[k]) k++; if (k === p.length) { out.push(i - k + 1); k = fail[k - 1]; } } return out; },
        n_queens: (n) => { const sols = []; const cols = [], d1 = new Set(), d2 = new Set(); const go = (r) => { if (r === n) { sols.push(cols.slice()); return; } for (let c = 0; c < n; c++) { if (cols.includes(c) || d1.has(r - c) || d2.has(r + c)) continue; cols.push(c); d1.add(r - c); d2.add(r + c); go(r + 1); cols.pop(); d1.delete(r - c); d2.delete(r + c); } }; go(0); return sols; },
        flood_fill: (grid, r, c, fill) => { const g = A(grid).map((row) => A(row).slice()); const target = g[r] && g[r][c]; if (target === undefined || eq(target, fill)) return g; const st = [[r, c]]; while (st.length) { const [y, x] = st.pop(); if (!g[y] || g[y][x] === undefined || !eq(g[y][x], target)) continue; g[y][x] = fill; st.push([y + 1, x], [y - 1, x], [y, x + 1], [y, x - 1]); } return g; },
        merge_intervals: (iv) => { const a = A(iv).map(A).sort((x, y) => x[0] - y[0]); const out = []; for (const [s, e] of a) { const last = out[out.length - 1]; if (last && s <= last[1]) last[1] = Math.max(last[1], e); else out.push([s, e]); } return out.map(tuple); },
        pascal: (n) => { const rows = [[1]]; for (let i = 1; i < n; i++) { const p = rows[i - 1]; rows.push([1].concat(p.slice(1).map((x, k) => x + p[k]), [1])); } return rows; },
        majority: (xs) => { let cand = null, c = 0; for (const x of A(xs)) { if (c === 0) { cand = x; c = 1; } else if (eq(x, cand)) c++; else c--; } const n = A(xs).filter((x) => eq(x, cand)).length; return n > A(xs).length / 2 ? cand : null; },
        subset_sum: (xs, target) => { const a = nums(xs); const reach = new Set([0]); for (const x of a) for (const r of Array.from(reach)) reach.add(r + x); return reach.has(target); },
        spiral: (m) => { const a = A(m).map(A); const out = []; let t = 0, b = a.length - 1, l = 0, r = (a[0] || []).length - 1; while (t <= b && l <= r) { for (let i = l; i <= r; i++) out.push(a[t][i]); t++; for (let i = t; i <= b; i++) out.push(a[i][r]); r--; if (t <= b) { for (let i = r; i >= l; i--) out.push(a[b][i]); b--; } if (l <= r) { for (let i = b; i >= t; i--) out.push(a[i][l]); l++; } } return out; },
        rotate_matrix: (m) => { const a = A(m).map(A); return a[0].map((_, i) => a.map((r) => r[i]).reverse()); },
        hanoi: (n) => { const moves = []; const go = (k, a, b, c) => { if (!k) return; go(k - 1, a, c, b); moves.push(tuple([a, c])); go(k - 1, b, a, c); }; go(n, 'A', 'B', 'C'); return moves; },
        gray_code: (n) => Array.from({ length: 1 << n }, (_, i) => i ^ (i >> 1)),
        luhn: (s) => { const d = Array.from(str(s).replace(/\s/g, ''), Number); if (d.some(Number.isNaN)) return false; let sum = 0; d.reverse().forEach((x, i) => { if (i % 2) { x *= 2; if (x > 9) x -= 9; } sum += x; }); return sum % 10 === 0; },
    };
};
