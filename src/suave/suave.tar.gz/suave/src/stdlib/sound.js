/* std.sound: play sounds.  Wave sounds you make from numbers (sine, square, triangle, mole) and sound files from GitHub, Mintcode or your own folders.
     use std.sound
     await sound.sine(440, 0.5)                       a 440 Hz note for half a second
     sound.file("./click.wav")                         a file beside this program (./ ../ and plain names all work)
     sound.git("user/repo/sounds/ding.wav")            a file from GitHub          sound.mint("user/repo/ding.wav")   a file from Mintcode
   Change how a sound sounds with named options on any of them: adsr (attack, decay, sustain, release), lowpass / highpass / bandpass (a pitch in Hz), eq (bass, mid, treble) and fade_in / fade_out,
     e.g.  sound.sine(220, 0.5, a=0.05, r=0.2, v=0.4)    sound.sine(440, 1, adsr: [0.02, 0.1, 0.6, 0.3], lowpass: 800)    or build a sound first:  sound.make("square", 220, 1).adsr(0.01, 0.2, 0.5, 0.4).eq(bass: 6).play()
   Every play function starts right away and gives back a future that finishes when the sound ends, so  await  waits for it and leaving it off plays in the background.
   Everything is turned into sound-file bytes first, then played the same way: a browser page uses an audio element, the terminal uses the computer's own player. */
import { rt, SMap, Named, cb, map, rtError, show, typeOf, str, toArray, ok, nativeType, make } from './_util.js';

const RATE = 44100;
const MAX_SECONDS = 120;
const TAU = Math.PI * 2;
const MOLE_MEAN = 2 / Math.PI;   // the average of |sin|, taken away so the speaker does not get a click

// ---------- the waves: a function from "how far through one cycle" (0 to 1) to a level (-1 to 1) ----------
const WAVES = {
    sine: (p) => Math.sin(TAU * p),
    square: (p) => (p < 0.5 ? 1 : -1),
    triangle: (p) => (p < 0.25 ? 4 * p : p < 0.75 ? 2 - 4 * p : 4 * p - 4),
    // mole is |sin(x)|, a row of humps (so it sounds an octave up); its average is taken out so it sits around zero like the others (and scaled so it never goes past -1)
    mole: (p) => (Math.abs(Math.sin(TAU * p)) - MOLE_MEAN) / MOLE_MEAN,
};

// positional values with named ones allowed: sine(440, 1, 0.5)  or  sine(freq: 440, seconds: 1, volume: 0.5)
function split(rest) { const n = rest.length && rest[rest.length - 1] instanceof Named ? rest[rest.length - 1].obj : {}; return [n && rest[rest.length - 1] instanceof Named ? rest.slice(0, -1) : rest, n]; }
function waveArgs(what, rest) {
    const [pos, o] = split(rest);
    const pick = (i, names, dflt) => { for (const k of names) if (o[k] !== undefined) return o[k]; return pos[i] !== undefined ? pos[i] : dflt; };
    const freq = pick(0, ['freq', 'frequency', 'hz'], 440), secs = pick(1, ['seconds', 'secs', 'time', 'length'], 0.5), vol = pick(2, ['volume', 'vol', 'v'], 0.5);
    if (typeof freq !== 'number' || !(freq > 0) || freq > 20000) throw rtError('sound.' + what + ' needs a pitch between 1 and 20000 Hz (like 440) but got ' + show(freq), 'ArgError');
    if (typeof secs !== 'number' || !(secs > 0) || secs > MAX_SECONDS) throw rtError('sound.' + what + ' needs a length in seconds between 0 and ' + MAX_SECONDS + ' but got ' + show(secs), 'ArgError');
    if (typeof vol !== 'number' || vol < 0 || vol > 1) throw rtError('sound.' + what + ' needs a volume between 0 and 1 but got ' + show(vol), 'ArgError');
    return { freq, secs, vol };
}
export function makeSamples(fn, freq, secs, vol) {
    const n = Math.max(1, Math.round(secs * RATE));
    const out = new Float32Array(n);
    const ramp = Math.min(Math.round(RATE * 0.005), Math.floor(n / 2));   // 5 ms fade in and out
    for (let i = 0; i < n; i++) {
        let phase = (i * freq / RATE) % 1;
        let v = fn(phase) * vol;
        if (i < ramp) v *= i / ramp; else if (i >= n - ramp) v *= (n - 1 - i) / ramp;
        out[i] = v;
    }
    return out;
}
// 16-bit mono WAV file bytes
export function wavBytes(samples) {
    const n = samples.length, buf = new ArrayBuffer(44 + n * 2), dv = new DataView(buf);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); dv.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
    dv.setUint32(24, RATE, true); dv.setUint32(28, RATE * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) dv.setInt16(44 + i * 2, Math.round(Math.max(-1, Math.min(1, samples[i])) * 32767), true);
    return new Uint8Array(buf);
}


// ---------- sounds as numbers: { rate, ch: [one Float32Array per channel] }, and what can be done to them ----------
const stateOf = (f32) => ({ rate: RATE, ch: [f32] });
export function wavFromState(st) {
    const nCh = st.ch.length, n = st.ch[0].length, buf = new ArrayBuffer(44 + n * nCh * 2), dv = new DataView(buf);
    const w = (o, t) => { for (let i = 0; i < t.length; i++) dv.setUint8(o + i, t.charCodeAt(i)); };
    w(0, 'RIFF'); dv.setUint32(4, 36 + n * nCh * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, nCh, true);
    dv.setUint32(24, st.rate, true); dv.setUint32(28, st.rate * nCh * 2, true); dv.setUint16(32, nCh * 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, n * nCh * 2, true);
    let o = 44;
    for (let i = 0; i < n; i++) for (let c = 0; c < nCh; c++) { dv.setInt16(o, Math.round(Math.max(-1, Math.min(1, st.ch[c][i])) * 32767), true); o += 2; }
    return new Uint8Array(buf);
}
// reads a .wav (8, 16, 24 or 32 bit whole numbers, or 32 bit decimals); other kinds need a browser to decode them
function decodeWav(b) {
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    const tag = (o) => String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3));
    if (b.length < 44 || tag(0) !== 'RIFF' || tag(8) !== 'WAVE') return null;
    let o = 12, fmt = null, data = null;
    while (o + 8 <= b.length) { const id = tag(o), size = dv.getUint32(o + 4, true); if (id === 'fmt ') fmt = { code: dv.getUint16(o + 8, true), ch: dv.getUint16(o + 10, true), rate: dv.getUint32(o + 12, true), bits: dv.getUint16(o + 22, true) }; else if (id === 'data') { data = [o + 8, Math.min(size, b.length - o - 8)]; break; } o += 8 + size + (size & 1); }
    if (!fmt || !data) throw rtError('This .wav file is damaged (no sound data found)', 'SoundError');
    let code = fmt.code; if (code === 0xFFFE) code = dv.getUint16(o + 8 + 24, true);   // "extensible" files name the real kind a little further in
    const bytes = fmt.bits / 8, n = Math.floor(data[1] / (bytes * fmt.ch));
    if (!((code === 1 && [8, 16, 24, 32].includes(fmt.bits)) || (code === 3 && fmt.bits === 32))) throw rtError('I can only change .wav files with whole-number (8, 16, 24, 32 bit) or 32 bit decimal sound', 'SoundError');
    const ch = Array.from({ length: fmt.ch }, () => new Float32Array(n));
    let p = data[0];
    for (let i = 0; i < n; i++) for (let c = 0; c < fmt.ch; c++) {
        let v;
        if (code === 3) v = dv.getFloat32(p, true);
        else if (fmt.bits === 8) v = (dv.getUint8(p) - 128) / 128;
        else if (fmt.bits === 16) v = dv.getInt16(p, true) / 32768;
        else if (fmt.bits === 24) { v = (dv.getUint8(p) | (dv.getUint8(p + 1) << 8) | (dv.getInt8(p + 2) << 16)) / 8388608; }
        else v = dv.getInt32(p, true) / 2147483648;
        ch[c][i] = v; p += bytes;
    }
    return { rate: fmt.rate, ch };
}
async function decodeBytes(bytes, ext) {
    const w = decodeWav(bytes);
    if (w) return w;
    const AC = typeof globalThis !== 'undefined' ? (globalThis.AudioContext || globalThis.webkitAudioContext) : null;
    if (!AC) throw rtError('Changing a ' + ext + ' file needs a web page (a browser can read it). In the terminal, save it as a .wav file first', 'SoundError');
    const ctx = new AC();
    try {
        const buf = await ctx.decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
        return { rate: buf.sampleRate, ch: Array.from({ length: buf.numberOfChannels }, (_, c) => Float32Array.from(buf.getChannelData(c))) };
    } catch (e) { throw rtError('The browser could not read this sound file', 'SoundError'); } finally { try { ctx.close(); } catch (e) { /* ignore */ } }
}

// ----- checking the options -----
const isNum = (x) => typeof x === 'number' && Number.isFinite(x);
const need = (x, what, lo, hi) => { if (!isNum(x) || x < lo || x > hi) throw rtError(what + ' needs a number from ' + lo + ' to ' + hi + ' but got ' + show(x), 'ArgError'); return x; };
const pairs = (m) => (m instanceof SMap ? Object.fromEntries(m.entries().map(([k, v]) => [String(k), v])) : null);
export function parseAdsr(v) {
    let a, d, s, r;
    if (Array.isArray(v)) { if (v.length !== 4) throw rtError('adsr needs four numbers: attack, decay, sustain, release (like [0.02, 0.1, 0.6, 0.3])', 'ArgError'); [a, d, s, r] = v; }
    else if (v instanceof SMap) { const o = pairs(v); a = o.attack ?? o.a ?? 0; d = o.decay ?? o.d ?? 0; s = o.sustain ?? o.s ?? 1; r = o.release ?? o.r ?? 0; }
    else throw rtError('adsr needs a list [attack, decay, sustain, release] or a map like {attack: 0.02, decay: 0.1, sustain: 0.6, release: 0.3}', 'ArgError');
    return { a: need(a, 'adsr attack (seconds)', 0, 60), d: need(d, 'adsr decay (seconds)', 0, 60), s: need(s, 'adsr sustain (a level)', 0, 1), r: need(r, 'adsr release (seconds)', 0, 60) };
}
const BANDS = { bass: ['lowshelf', 250, 0.707], mid: ['peaking', 1000, 0.8], treble: ['highshelf', 4000, 0.707] };
export function parseEq(v) {
    const out = [];
    if (v instanceof SMap) {
        for (const [k, g] of Object.entries(pairs(v))) { if (!BANDS[k]) throw rtError('eq knows bass, mid and treble, not "' + k + '"  (for your own pitches give a list like [[100, 6], [2000, -3]])', 'ArgError'); out.push([BANDS[k][0], BANDS[k][1], BANDS[k][2], need(g, 'eq ' + k + ' (dB)', -24, 24)]); }
    } else if (Array.isArray(v)) {
        for (const b of v) { if (!Array.isArray(b) || b.length < 2 || b.length > 3) throw rtError('each eq band is [pitch in Hz, boost in dB] or [pitch, boost, width]', 'ArgError'); out.push(['peaking', need(b[0], 'eq pitch (Hz)', 10, 20000), b[2] === undefined ? 1 : need(b[2], 'eq width', 0.1, 30), need(b[1], 'eq boost (dB)', -24, 24)]); }
    } else throw rtError('eq needs a map like {bass: 4, mid: 0, treble: -2} (dB) or a list of bands like [[100, 6], [2000, -3]]', 'ArgError');
    return out;
}
// the named options a play or make function accepts
export function modsFrom(o) {
    const m = {};
    // short form: a=attack, d=decay, s=sustain level, r=release  (any of them; the rest default to 0, 0, 1, 0)
    if (o.adsr !== undefined || o.a !== undefined || o.d !== undefined || o.s !== undefined || o.r !== undefined) {
        const base = o.adsr !== undefined ? parseAdsr(o.adsr) : { a: 0, d: 0, s: 1, r: 0 };
        m.adsr = parseAdsr([o.a !== undefined ? o.a : base.a, o.d !== undefined ? o.d : base.d, o.s !== undefined ? o.s : base.s, o.r !== undefined ? o.r : base.r]);
    }
    for (const [short, long] of [['hp', 'highpass'], ['lp', 'lowpass'], ['bp', 'bandpass']]) if (o[short] !== undefined && o[long] === undefined) o[long] = o[short];
    for (const k of ['highpass', 'lowpass', 'bandpass']) if (o[k] !== undefined) m[k] = need(o[k], k + ' (Hz)', 10, 20000);
    if (o.q !== undefined) m.q = need(o.q, 'q (filter sharpness)', 0.1, 30);
    if (o.eq !== undefined) m.eq = parseEq(o.eq);
    if (o.fade_in !== undefined) m.fade_in = need(o.fade_in, 'fade_in (seconds)', 0, 60);
    if (o.fade_out !== undefined) m.fade_out = need(o.fade_out, 'fade_out (seconds)', 0, 60);
    return Object.keys(m).length ? m : null;
}

// ----- the filters: one "biquad" does a low pass, high pass, band pass, a boost or cut around a pitch, or a bass / treble shelf -----
export function biquad(x, rate, type, f, q, gainDb) {
    f = Math.min(f, rate * 0.49);
    const w0 = TAU * f / rate, cs = Math.cos(w0), sn = Math.sin(w0), alpha = sn / (2 * q), A = Math.pow(10, (gainDb || 0) / 40), sq = 2 * Math.sqrt(A) * (sn / 2) * Math.SQRT2;
    let b0, b1, b2, a0, a1, a2;
    switch (type) {
        case 'lowpass': b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = b0; a0 = 1 + alpha; a1 = -2 * cs; a2 = 1 - alpha; break;
        case 'highpass': b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = b0; a0 = 1 + alpha; a1 = -2 * cs; a2 = 1 - alpha; break;
        case 'bandpass': b0 = alpha; b1 = 0; b2 = -alpha; a0 = 1 + alpha; a1 = -2 * cs; a2 = 1 - alpha; break;
        case 'peaking': b0 = 1 + alpha * A; b1 = -2 * cs; b2 = 1 - alpha * A; a0 = 1 + alpha / A; a1 = -2 * cs; a2 = 1 - alpha / A; break;
        case 'lowshelf': b0 = A * ((A + 1) - (A - 1) * cs + sq); b1 = 2 * A * ((A - 1) - (A + 1) * cs); b2 = A * ((A + 1) - (A - 1) * cs - sq); a0 = (A + 1) + (A - 1) * cs + sq; a1 = -2 * ((A - 1) + (A + 1) * cs); a2 = (A + 1) + (A - 1) * cs - sq; break;
        case 'highshelf': b0 = A * ((A + 1) + (A - 1) * cs + sq); b1 = -2 * A * ((A - 1) + (A + 1) * cs); b2 = A * ((A + 1) + (A - 1) * cs - sq); a0 = (A + 1) - (A - 1) * cs + sq; a1 = 2 * ((A - 1) - (A + 1) * cs); a2 = (A + 1) - (A - 1) * cs - sq; break;
        default: throw rtError('Unknown filter ' + type, 'ArgError');
    }
    b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
    const y = new Float32Array(x.length);
    let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (let i = 0; i < x.length; i++) { const v = b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2; x2 = x1; x1 = x[i]; y2 = y1; y1 = v; y[i] = v; }
    return y;
}
// how loud the envelope lets a note be at time t (seconds): up over the attack, down to the sustain level over the decay, hold, then down to nothing over the release at the end
export function adsrLevel(t, dur, e) {
    const r = Math.min(e.r, dur), relStart = dur - r;
    const base = (u) => (u < e.a ? (e.a > 0 ? u / e.a : 1) : u < e.a + e.d ? 1 - (1 - e.s) * ((u - e.a) / e.d) : e.s);
    if (t >= relStart && r > 0) return base(relStart) * Math.max(0, 1 - (t - relStart) / r);
    return base(t);
}
// filters and EQ first, then the envelope and fades, then volume
export function applyMods(st, mods, gain) {
    const rate = st.rate;
    const stages = [];
    if (mods) {
        const q = mods.q || 0.707;
        if (mods.highpass) stages.push(['highpass', mods.highpass, q, 0]);
        if (mods.lowpass) stages.push(['lowpass', mods.lowpass, q, 0]);
        if (mods.bandpass) stages.push(['bandpass', mods.bandpass, mods.q || 1, 0]);
        for (const b of mods.eq || []) stages.push([b[0], b[1], b[2], b[3]]);
    }
    const g = gain === undefined || gain === null ? 1 : gain;
    const ch = st.ch.map((c) => {
        let x = stages.length ? stages.reduce((acc, s) => biquad(acc, rate, s[0], s[1], s[2], s[3]), c) : Float32Array.from(c);
        if (mods && (mods.adsr || mods.fade_in || mods.fade_out)) {
            const dur = x.length / rate;
            for (let i = 0; i < x.length; i++) {
                const t = i / rate; let m = 1;
                if (mods.adsr) m *= adsrLevel(t, dur, mods.adsr);
                if (mods.fade_in && t < mods.fade_in) m *= t / mods.fade_in;
                if (mods.fade_out && t > dur - mods.fade_out) m *= Math.max(0, (dur - t) / mods.fade_out);
                x[i] *= m;
            }
        }
        if (g !== 1) for (let i = 0; i < x.length; i++) x[i] *= g;
        return x;
    });
    return { rate, ch };
}

// ---------- where sounds come from ----------
const SEG = /^[^\\?#]+$/;      // folder and file names may have spaces
const NAME = /^[A-Za-z0-9_.@-]+$/;   // owners and repos may not
function splitSpec(spec, what) {
    // "owner/repo/path/to/file.wav"  or  "owner/repo@branch/path/to/file.wav"
    const s = String(spec === undefined || spec === null ? '' : spec).trim().replace(/^\/+/, '');
    const parts = s.split('/');
    if (parts.length < 3 || !NAME.test(parts[0]) || !NAME.test(parts[1]) || !parts.every((p) => p && SEG.test(p)) || parts.some((p) => p === '..')) throw rtError('sound.' + what + ' wants "owner/repo/path/to/sound.wav" (add @branch after the repo name to pick a branch) but got ' + JSON.stringify(s), 'ArgError');
    const m = /^([^@]+)@(.+)$/.exec(parts[1]);
    return { owner: parts[0], repo: m ? m[1] : parts[1], ref: m ? m[2] : null, path: parts.slice(2).join('/') };
}
export function gitUrl(spec) {
    const raw = String(spec || '').trim();
    // links people copy from their browser also work
    let m = /^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/(?:blob|raw)\/([^/]+)\/(.+)$/.exec(raw);
    if (m) return 'https://raw.githubusercontent.com/' + m[1] + '/' + m[2] + '/' + m[3] + '/' + m[4];
    if (/^https:\/\/(raw\.githubusercontent\.com|media\.githubusercontent\.com)\//.test(raw)) return raw;
    const p = splitSpec(raw, 'git');
    return 'https://raw.githubusercontent.com/' + p.owner + '/' + p.repo + '/' + (p.ref || 'HEAD') + '/' + p.path.split('/').map(encodeURIComponent).join('/');
}
let mintServer = 'https://mintcode.radii-office.com';
export function mintParts(spec) { const p = splitSpec(String(spec || '').replace(/^https?:\/\/[^/]+\//, ''), 'mint'); return { ...p, line: p.ref || 'main' }; }

// a path for sound.file: absolute stays, everything else is looked up beside the program that asked for it
const dirOf = (p) => { const i = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')); return i < 0 ? '' : p.slice(0, i); };
function joinPath(base, rel) {
    const out = base.split('/');
    for (const seg of rel.split('/')) { if (seg === '.' || seg === '') continue; if (seg === '..') { if (out.length > 1 || (out.length === 1 && out[0] !== '')) out.pop(); } else out.push(seg); }
    return out.join('/') || '/';
}
export function filePath(p) {
    p = str(p, 'sound.file');
    if (/^~\//.test(p) && rt.sys) return rt.sys.home ? rt.sys.home() + p.slice(1) : p;
    if (/^(\/|[A-Za-z]:[\\/])/.test(p)) return p;
    const here = rt.state && rt.state.file ? String(rt.state.file) : '';
    let base = here && !/^</.test(here) ? dirOf(here.replace(/\\/g, '/')) : '';
    if (!base || !/^(\/|[A-Za-z]:[\\/])/.test(base)) { const cwd = rt.sys ? rt.sys.cwd().replace(/\\/g, '/') : ''; base = base ? joinPath(cwd, base) : cwd; }
    return joinPath(base, p.replace(/\\/g, '/'));
}
const inBrowser = () => typeof document !== 'undefined' && typeof Audio !== 'undefined';
function pageUrl(p) {
    // in a page: look beside the Suave file when it came from a file, otherwise beside the page
    const here = rt.state && rt.state.file ? String(rt.state.file) : '';
    let base = location.href;
    if (here && !/^</.test(here)) { try { base = new URL(here, location.href).href; } catch (e) { /* the page */ } }
    return new URL(p, base).href;
}
const MIMES = { wav: 'audio/wav', mp3: 'audio/mpeg', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', webm: 'audio/webm' };
const extOf = (p) => ((/\.([A-Za-z0-9]+)(?:[?#].*)?$/.exec(p) || [])[1] || 'wav').toLowerCase();

// ---------- playing bytes ----------
const active = new Set();   // things that can be stopped: { stop() }
function playInBrowser(bytes, ext, vol) {
    return new Promise((resolve, reject) => {
        // bytes is sound-file bytes, or a web address the audio element loads by itself
        const own = typeof bytes !== 'string';
        const url = own ? URL.createObjectURL(new Blob([bytes], { type: MIMES[ext] || 'audio/wav' })) : bytes;
        const free = () => { if (own) URL.revokeObjectURL(url); };
        const a = new Audio(url); a.volume = vol;
        const handle = { stop: () => { try { a.pause(); } catch (e) { /* ignore */ } done(); } };
        const done = () => { active.delete(handle); free(); resolve(null); };
        active.add(handle);
        a.onended = done;
        a.onerror = () => { active.delete(handle); free(); reject(rtError('The browser could not play this sound (is it a .wav, .mp3 or .ogg file?)', 'SoundError')); };
        const p = a.play();
        if (p && p.catch) p.catch((e) => { active.delete(handle); free(); reject(rtError(e && e.name === 'NotAllowedError' ? 'The browser only plays sound after the visitor has clicked or typed on the page. Call sound from a button or key press' : 'The browser could not play this sound: ' + (e && e.message), 'SoundError')); });
    });
}
async function playInTerminal(bytes, ext, vol) {
    const s = rt.needSys('sound');
    const dir = s.tempDir();
    const file = dir + '/sound.' + ext;
    s.writeBytes(file, bytes);
    const os = s.os();
    const v = String(Math.max(0, Math.min(1, vol)));
    const tries = os === 'darwin' ? [['afplay', ['-v', v, file]]]
        : os === 'windows' ? [['powershell', ['-NoProfile', '-Command', '(New-Object Media.SoundPlayer "' + file + '").PlaySync()']]]
        : [['paplay', [file]], ['aplay', ['-q', file]], ['ffplay', ['-nodisp', '-autoexit', '-loglevel', 'quiet', file]], ['mpg123', ['-q', file]], ['play', ['-q', file]]];
    const handle = { stop: () => { handle.stopped = true; if (handle.child) { try { handle.child.kill(); } catch (e) { /* ignore */ } } } };
    active.add(handle);
    try {
        let lastErr = null;
        for (const [cmd, args] of tries) {
            if (handle.stopped) return null;
            try {
                const r = await s.run(cmd, args, { onChild: (c) => { handle.child = c; } });
                if (handle.stopped) return null;
                if (r.code === 0) return null;
                lastErr = r.stderr || ('exit code ' + r.code);
            } catch (e) { lastErr = e && e.message; }
        }
        throw rtError('I could not find a way to play sound here (' + (os === 'darwin' ? 'afplay' : os === 'windows' ? 'PowerShell' : 'paplay, aplay, ffplay, mpg123 or play') + ' did not work' + (lastErr ? ': ' + String(lastErr).trim().slice(0, 120) : '') + ')', 'SoundError');
    } finally { active.delete(handle); try { s.remove(dir, true); } catch (e) { /* ignore */ } }
}
const play = (bytes, ext, vol) => (inBrowser() ? playInBrowser(bytes, ext, vol) : playInTerminal(bytes, ext, vol));
const volumeOf = (o) => { const v = o.volume !== undefined ? o.volume : o.vol !== undefined ? o.vol : o.v; if (v === undefined) return 1; if (typeof v !== 'number' || v < 0 || v > 1) throw rtError('sound volume needs a number between 0 and 1 but got ' + show(v), 'ArgError'); return v; };

async function download(url, what) {
    if (typeof fetch === 'undefined') throw rtError('This computer cannot reach the web from here', 'NetworkError');
    let res;
    try { res = await fetch(url); } catch (e) { throw rtError('Could not reach ' + url + (e && e.message ? ' (' + e.message + ')' : ''), 'NetworkError'); }
    if (!res.ok) throw rtError(what + ' answered "' + res.status + ' ' + (res.statusText || 'error') + '" for ' + url, 'NetworkError');
    return new Uint8Array(await res.arrayBuffer());
}
const b64 = (t) => { if (typeof atob === 'function') { const s = atob(t); const o = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) o[i] = s.charCodeAt(i); return o; } return Uint8Array.from(Buffer.from(t, 'base64')); };
async function mintBytes(spec) {
    const p = mintParts(spec);
    const base = mintServer.replace(/\/$/, '') + '/api/r/' + encodeURIComponent(p.owner) + '/' + encodeURIComponent(p.repo);
    const asJson = async (url) => { const b = await download(url, 'Mintcode'); try { return JSON.parse(new TextDecoder().decode(b)); } catch (e) { throw rtError('Mintcode sent something unexpected for ' + url, 'NetworkError'); } };
    const saves = await asJson(base + '/saves?line=' + encodeURIComponent(p.line) + '&trees=1&limit=1');
    const head = saves.saves && saves.saves[0];
    if (!head || !head.tree) throw rtError('Mintcode has no saves on the line "' + p.line + '" of ' + p.owner + '/' + p.repo, 'NetworkError');
    const hash = head.tree[p.path];
    if (!hash) throw rtError('Mintcode has no file "' + p.path + '" in ' + p.owner + '/' + p.repo + ' (line ' + p.line + ')', 'NetworkError');
    const blob = await asJson(base + '/blob/' + hash);
    return { bytes: blob.enc === 'b64' ? b64(blob.content) : new TextEncoder().encode(String(blob.content)), name: p.path };
}

export const soundModule = () => {
    const SoundT = nativeType('Sound', {
        // the same options as the play functions, one at a time:  sound.make("sine", 440, 1).adsr(0.02, 0.1, 0.6, 0.3).lowpass(800).eq(bass: 4).play()
        adsr: (me, a) => make(SoundT, applyMods(me.state, { adsr: parseAdsr(a.length === 1 ? a[0] : a.slice(0, 4)) })),
        volume: (me, a) => make(SoundT, applyMods(me.state, null, need(a[0], 'volume', 0, 4))),
        lowpass: (me, a) => make(SoundT, applyMods(me.state, { lowpass: need(a[0], 'lowpass (Hz)', 10, 20000), q: a[1] === undefined ? undefined : need(a[1], 'q', 0.1, 30) })),
        highpass: (me, a) => make(SoundT, applyMods(me.state, { highpass: need(a[0], 'highpass (Hz)', 10, 20000), q: a[1] === undefined ? undefined : need(a[1], 'q', 0.1, 30) })),
        bandpass: (me, a) => make(SoundT, applyMods(me.state, { bandpass: need(a[0], 'bandpass (Hz)', 10, 20000), q: a[1] === undefined ? undefined : need(a[1], 'q', 0.1, 30) })),
        eq: (me, a, n) => make(SoundT, applyMods(me.state, { eq: parseEq(n instanceof Object && !Array.isArray(n) && Object.keys(n).length ? map(n) : a[0]) })),
        fade_in: (me, a) => make(SoundT, applyMods(me.state, { fade_in: need(a[0], 'fade_in (seconds)', 0, 60) })),
        fade_out: (me, a) => make(SoundT, applyMods(me.state, { fade_out: need(a[0], 'fade_out (seconds)', 0, 60) })),
        play: (me, a) => play(wavFromState(me.state), 'wav', a[0] === undefined ? 1 : need(a[0], 'volume', 0, 1)),
        save: (me, a) => { const s = rt.needSys('sound save'); s.writeBytes(filePath(str(a[0], 'save')), wavFromState(me.state)); return null; },
        seconds: (me) => me.state.ch[0].length / me.state.rate, samples: (me) => Array.from(me.state.ch[0]), wav: (me) => wavFromState(me.state), channels: (me) => me.state.ch.length,
    }, { reprFn: (o) => '<Sound ' + (o.state.ch[0].length / o.state.rate).toFixed(2) + 's>' });
    // a wave's numbers, with the named options (adsr, filters, eq, fades) applied
    const buildWave = (fn, what, rest) => {
        const { freq, secs, vol } = waveArgs(what, rest);
        const mods = modsFrom(split(rest)[1]);
        const st = stateOf(makeSamples(fn, freq, secs, vol));
        return mods ? applyMods(st, mods) : st;
    };
    const customWave = (f) => { const g = cb(f); return (p) => { const v = Number(g(p)); return Number.isFinite(v) ? v : 0; }; };
    const wave = (kind) => (...rest) => play(wavFromState(buildWave(WAVES[kind], kind, rest)), 'wav', 1);
    // where a sound file comes from; wantBytes false lets a browser play an address directly
    const sources = {
        file: async (p, wantBytes) => {
            const name = str(p, 'sound.file');
            if (inBrowser()) { const url = pageUrl(name); return { bytes: wantBytes ? await download(url, 'The page') : url, ext: extOf(name) }; }
            const full = filePath(name);
            const s = rt.needSys('sound.file');
            let bytes;
            try { bytes = s.readBytes(full); } catch (e) { throw rtError('I could not find the sound file ' + full, 'IOError'); }
            return { bytes, ext: extOf(name) };
        },
        git: async (spec) => { const url = gitUrl(spec); return { bytes: await download(url, 'GitHub'), ext: extOf(url) }; },
        mint: async (spec) => { const r = await mintBytes(spec); return { bytes: r.bytes, ext: extOf(r.name) }; },
    };
    const fileLike = (kind) => async (spec, ...rest) => {
        const [, o] = split(rest);
        const v = volumeOf(o);
        const mods = modsFrom(o);
        if (!mods) { const got = await sources[kind](spec, false); return play(got.bytes, got.ext, v); }
        const got = await sources[kind](spec, true);
        return play(wavFromState(applyMods(await decodeBytes(got.bytes, got.ext), mods, v)), 'wav', 1);
    };
    const loadLike = (kind) => async (spec, ...rest) => {
        const [, o] = split(rest);
        const got = await sources[kind](spec, true);
        return make(SoundT, applyMods(await decodeBytes(got.bytes, got.ext), modsFrom(o), volumeOf(o)));
    };
    return {
        // ----- waves you make from numbers: (pitch in Hz, seconds, volume 0 to 1) -----
        sine: wave('sine'), square: wave('square'), triangle: wave('triangle'), mole: wave('mole'),
        // wave(|x| ..., 440, 1): your own wave. The function gets how far through one cycle it is (0 to 1) and gives back a level from -1 to 1
        wave: (f, ...rest) => play(wavFromState(buildWave(customWave(f), 'wave', rest)), 'wav', 1),
        // ----- sound files -----
        file: fileLike('file'), git: fileLike('git'), mint: fileLike('mint'),
        // ----- sounds you can change before playing:  make("sine", 440, 1)  or  await load("./click.wav")  (also load_git, load_mint) -----
        make: (kind, ...rest) => {
            let fn;
            if (typeof kind === 'string') { if (!WAVES[kind]) throw rtError('sound.make knows sine, square, triangle and mole, or a function, not ' + show(kind), 'ArgError'); fn = WAVES[kind]; }
            else fn = customWave(kind);
            return make(SoundT, buildWave(fn, 'make', rest));
        },
        load: loadLike('file'), load_git: loadLike('git'), load_mint: loadLike('mint'),
        // stop() ends every sound that is playing
        stop: () => { for (const h of Array.from(active)) h.stop(); return null; },
        // mint_server("https://my-mintcode.example.com") if you run your own Mintcode
        mint_server: (url) => { if (url === undefined) return mintServer; mintServer = str(url, 'sound.mint_server').replace(/\/$/, ''); return mintServer; },
        // ----- for looking at sounds instead of hearing them -----
        // samples("sine", 440, 0.01) gives the numbers of a wave;  wav("square", 220, 1) gives the bytes of a .wav file you can save with std.fs  (both take the same named options)
        samples: (kind, ...rest) => { if (!WAVES[kind]) throw rtError('sound.samples knows sine, square, triangle and mole, not ' + show(kind), 'ArgError'); return Array.from(buildWave(WAVES[kind], 'samples', rest).ch[0]); },
        wav: (kind, ...rest) => { if (!WAVES[kind]) throw rtError('sound.wav knows sine, square, triangle and mole, not ' + show(kind), 'ArgError'); return wavFromState(buildWave(WAVES[kind], 'wav', rest)); },
        git_url: (spec) => gitUrl(spec),
        file_path: (p) => (inBrowser() ? pageUrl(str(p, 'sound.file_path')) : filePath(p)),
        waves: () => Object.keys(WAVES),
    };
};
void SMap; void typeOf; void toArray; void ok;
