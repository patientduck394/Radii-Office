/* std.sound: play sounds.  Wave sounds you make from numbers (sine, square, triangle, mole) and sound files from GitHub, Mintcode or your own folders.
     use std.sound
     await sound.sine(440, 0.5)                       a 440 Hz note for half a second
     sound.file("./click.wav")                         a file beside this program (./ ../ and plain names all work)
     sound.git("user/repo/sounds/ding.wav")            a file from GitHub          sound.mint("user/repo/ding.wav")   a file from Mintcode
   Change how a sound sounds with named options on any of them: adsr (attack, decay, sustain, release), lowpass / highpass / bandpass (a pitch in Hz), eq (bass, mid, treble) and fade_in / fade_out,
     e.g.  sound.sine(220, 0.5, a=0.05, r=0.2, v=0.4)    sound.sine(440, 1, adsr: [0.02, 0.1, 0.6, 0.3], lowpass: 800)    or build a sound first:  sound.make("square", 220, 1).adsr(0.01, 0.2, 0.5, 0.4).eq(bass: 6).play()
   Reverb:  sound.sine(440, 0.1, reverb=0.4, room=0.7)     Melodies:  await sound.melody("D F A C+", octave=4, bpm=120, instrument="superchip", reverb=0.3)
   Every play function starts right away and gives back a future that finishes when the sound ends, so  await  waits for it and leaving it off plays in the background.
   Everything is turned into sound-file bytes first, then played the same way: a browser page uses an audio element, the terminal uses the computer's own player. */
import { rt, SMap, Named, cb, map, rtError, show, typeOf, str, toArray, ok, nativeType, make } from './_util.js';

const RATE = 44100;
const MAX_SECONDS = 120;
const TAU = Math.PI * 2;
const MOLE_MEAN = 2 / Math.PI;   // the average of |sin|, taken away so the speaker does not get a click

// ---------- the waves: a function from "how far through one cycle" (0 to 1) to a level (-1 to 1) ----------
const WAVES = {
    sine: (p) => Math.sin(TAU * p),
    square: (p) => (p < 0.5 ? 1 : -1),
    triangle: (p) => (p < 0.25 ? 4 * p : p < 0.75 ? 2 - 4 * p : 4 * p - 4),
    // mole is |sin(x)|, a row of humps (so it sounds an octave up); its average is taken out so it sits around zero like the others (and scaled so it never goes past -1)
    mole: (p) => (Math.abs(Math.sin(TAU * p)) - MOLE_MEAN) / MOLE_MEAN,
};

// positional values with named ones allowed: sine(440, 1, 0.5)  or  sine(freq: 440, seconds: 1, volume: 0.5)
function split(rest) { const n = rest.length && rest[rest.length - 1] instanceof Named ? rest[rest.length - 1].obj : {}; return [n && rest[rest.length - 1] instanceof Named ? rest.slice(0, -1) : rest, n]; }
function waveArgs(what, rest, dflt) {
    const [pos, o] = split(rest);
    const pick = (i, names, dflt) => { for (const k of names) if (o[k] !== undefined) return o[k]; return pos[i] !== undefined ? pos[i] : dflt; };
    const freq = pick(0, ['freq', 'frequency', 'hz'], dflt && dflt.freq !== undefined ? dflt.freq : 440), secs = pick(1, ['seconds', 'secs', 'time', 'length'], 0.5), vol = pick(2, ['volume', 'vol', 'v'], 0.5);
    if (typeof freq !== 'number' || !(freq > 0) || freq > (dflt && dflt.max ? dflt.max : 20000)) throw rtError('sound.' + what + ' needs a pitch between 1 and ' + (dflt && dflt.max ? dflt.max : 20000) + ' Hz (like 440) but got ' + show(freq), 'ArgError');
    if (typeof secs !== 'number' || !(secs > 0) || secs > MAX_SECONDS) throw rtError('sound.' + what + ' needs a length in seconds between 0 and ' + MAX_SECONDS + ' but got ' + show(secs), 'ArgError');
    if (typeof vol !== 'number' || vol < 0 || vol > 1) throw rtError('sound.' + what + ' needs a volume between 0 and 1 but got ' + show(vol), 'ArgError');
    return { freq, secs, vol };
}
export function makeSamples(fn, freq, secs, vol) {
    const n = Math.max(1, Math.round(secs * RATE));
    const out = new Float32Array(n);
    const ramp = Math.min(Math.round(RATE * 0.005), Math.floor(n / 2));   // 5 ms fade in and out
    for (let i = 0; i < n; i++) {
        let phase = (i * freq / RATE) % 1;
        let v = fn(phase) * vol;
        if (i < ramp) v *= i / ramp; else if (i >= n - ramp) v *= (n - 1 - i) / ramp;
        out[i] = v;
    }
    return out;
}
// 16-bit mono WAV file bytes
export function wavBytes(samples) {
    const n = samples.length, buf = new ArrayBuffer(44 + n * 2), dv = new DataView(buf);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); dv.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
    dv.setUint32(24, RATE, true); dv.setUint32(28, RATE * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) dv.setInt16(44 + i * 2, Math.round(Math.max(-1, Math.min(1, samples[i])) * 32767), true);
    return new Uint8Array(buf);
}


// ---------- sounds as numbers: { rate, ch: [one Float32Array per channel] }, and what can be done to them ----------
const stateOf = (f32) => ({ rate: RATE, ch: [f32] });
export function wavFromState(st) {
    const nCh = st.ch.length, n = st.ch[0].length, buf = new ArrayBuffer(44 + n * nCh * 2), dv = new DataView(buf);
    const w = (o, t) => { for (let i = 0; i < t.length; i++) dv.setUint8(o + i, t.charCodeAt(i)); };
    w(0, 'RIFF'); dv.setUint32(4, 36 + n * nCh * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, nCh, true);
    dv.setUint32(24, st.rate, true); dv.setUint32(28, st.rate * nCh * 2, true); dv.setUint16(32, nCh * 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, n * nCh * 2, true);
    let o = 44;
    for (let i = 0; i < n; i++) for (let c = 0; c < nCh; c++) { dv.setInt16(o, Math.round(Math.max(-1, Math.min(1, st.ch[c][i])) * 32767), true); o += 2; }
    return new Uint8Array(buf);
}
// reads a .wav (8, 16, 24 or 32 bit whole numbers, or 32 bit decimals); other kinds need a browser to decode them
function decodeWav(b) {
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    const tag = (o) => String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3));
    if (b.length < 44 || tag(0) !== 'RIFF' || tag(8) !== 'WAVE') return null;
    let o = 12, fmt = null, data = null;
    while (o + 8 <= b.length) { const id = tag(o), size = dv.getUint32(o + 4, true); if (id === 'fmt ') fmt = { code: dv.getUint16(o + 8, true), ch: dv.getUint16(o + 10, true), rate: dv.getUint32(o + 12, true), bits: dv.getUint16(o + 22, true) }; else if (id === 'data') { data = [o + 8, Math.min(size, b.length - o - 8)]; break; } o += 8 + size + (size & 1); }
    if (!fmt || !data) throw rtError('This .wav file is damaged (no sound data found)', 'SoundError');
    let code = fmt.code; if (code === 0xFFFE) code = dv.getUint16(o + 8 + 24, true);   // "extensible" files name the real kind a little further in
    const bytes = fmt.bits / 8, n = Math.floor(data[1] / (bytes * fmt.ch));
    if (!((code === 1 && [8, 16, 24, 32].includes(fmt.bits)) || (code === 3 && fmt.bits === 32))) throw rtError('I can only change .wav files with whole-number (8, 16, 24, 32 bit) or 32 bit decimal sound', 'SoundError');
    const ch = Array.from({ length: fmt.ch }, () => new Float32Array(n));
    let p = data[0];
    for (let i = 0; i < n; i++) for (let c = 0; c < fmt.ch; c++) {
        let v;
        if (code === 3) v = dv.getFloat32(p, true);
        else if (fmt.bits === 8) v = (dv.getUint8(p) - 128) / 128;
        else if (fmt.bits === 16) v = dv.getInt16(p, true) / 32768;
        else if (fmt.bits === 24) { v = (dv.getUint8(p) | (dv.getUint8(p + 1) << 8) | (dv.getInt8(p + 2) << 16)) / 8388608; }
        else v = dv.getInt32(p, true) / 2147483648;
        ch[c][i] = v; p += bytes;
    }
    return { rate: fmt.rate, ch };
}
async function decodeBytes(bytes, ext) {
    const w = decodeWav(bytes);
    if (w) return w;
    const AC = typeof globalThis !== 'undefined' ? (globalThis.AudioContext || globalThis.webkitAudioContext) : null;
    if (!AC) throw rtError('Changing a ' + ext + ' file needs a web page (a browser can read it). In the terminal, save it as a .wav file first', 'SoundError');
    const ctx = new AC();
    try {
        const buf = await ctx.decodeAudioData(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
        return { rate: buf.sampleRate, ch: Array.from({ length: buf.numberOfChannels }, (_, c) => Float32Array.from(buf.getChannelData(c))) };
    } catch (e) { throw rtError('The browser could not read this sound file', 'SoundError'); } finally { try { ctx.close(); } catch (e) { /* ignore */ } }
}

// ----- checking the options -----
// 0, false and none mean "switch this off" for every option that can be switched off
const isOff = (x) => x === 0 || x === false || x === null;
const isNum = (x) => typeof x === 'number' && Number.isFinite(x);
const need = (x, what, lo, hi) => { if (!isNum(x) || x < lo || x > hi) throw rtError(what + ' needs a number from ' + lo + ' to ' + hi + ' but got ' + show(x), 'ArgError'); return x; };
const pairs = (m) => (m instanceof SMap ? Object.fromEntries(m.entries().map(([k, v]) => [String(k), v])) : null);
export function parseAdsr(v) {
    let a, d, s, r;
    if (Array.isArray(v)) { if (v.length !== 4) throw rtError('adsr needs four numbers: attack, decay, sustain, release (like [0.02, 0.1, 0.6, 0.3])', 'ArgError'); [a, d, s, r] = v; }
    else if (v instanceof SMap) { const o = pairs(v); a = o.attack ?? o.a ?? 0; d = o.decay ?? o.d ?? 0; s = o.sustain ?? o.s ?? 1; r = o.release ?? o.r ?? 0; }
    else throw rtError('adsr needs a list [attack, decay, sustain, release] or a map like {attack: 0.02, decay: 0.1, sustain: 0.6, release: 0.3}', 'ArgError');
    return { a: need(a, 'adsr attack (seconds)', 0, 60), d: need(d, 'adsr decay (seconds)', 0, 60), s: need(s, 'adsr sustain (a level)', 0, 1), r: need(r, 'adsr release (seconds)', 0, 60) };
}
const BANDS = { bass: ['lowshelf', 250, 0.707], mid: ['peaking', 1000, 0.8], treble: ['highshelf', 4000, 0.707] };
export function parseEq(v) {
    const out = [];
    if (v instanceof SMap) {
        for (const [k, g] of Object.entries(pairs(v))) { if (!BANDS[k]) throw rtError('eq knows bass, mid and treble, not "' + k + '"  (for your own pitches give a list like [[100, 6], [2000, -3]])', 'ArgError'); out.push([BANDS[k][0], BANDS[k][1], BANDS[k][2], need(g, 'eq ' + k + ' (dB)', -24, 24)]); }
    } else if (Array.isArray(v)) {
        for (const b of v) { if (!Array.isArray(b) || b.length < 2 || b.length > 3) throw rtError('each eq band is [pitch in Hz, boost in dB] or [pitch, boost, width]', 'ArgError'); out.push(['peaking', need(b[0], 'eq pitch (Hz)', 10, 20000), b[2] === undefined ? 1 : need(b[2], 'eq width', 0.1, 30), need(b[1], 'eq boost (dB)', -24, 24)]); }
    } else throw rtError('eq needs a map like {bass: 4, mid: 0, treble: -2} (dB) or a list of bands like [[100, 6], [2000, -3]]', 'ArgError');
    return out;
}
// the named options a play or make function accepts
export function modsFrom(o, skipChorus) {
    const m = {};
    // short form: a=attack, d=decay, s=sustain level, r=release  (any of them; the rest default to 0, 0, 1, 0)
    if (o.adsr !== undefined && isOff(o.adsr)) { /* adsr=0 means no envelope at all */ }
    else if (o.adsr !== undefined || o.a !== undefined || o.d !== undefined || o.s !== undefined || o.r !== undefined) {
        const base = o.adsr !== undefined && !isOff(o.adsr) ? parseAdsr(o.adsr) : { a: 0, d: 0, s: 1, r: 0 };
        m.adsr = parseAdsr([o.a !== undefined ? o.a : base.a, o.d !== undefined ? o.d : base.d, o.s !== undefined ? o.s : base.s, o.r !== undefined ? o.r : base.r]);
    }
    for (const [short, long] of [['hp', 'highpass'], ['lp', 'lowpass'], ['bp', 'bandpass']]) if (o[short] !== undefined && o[long] === undefined) o[long] = o[short];
    for (const k of ['highpass', 'lowpass', 'bandpass']) if (o[k] !== undefined && !isOff(o[k])) m[k] = need(o[k], k + ' (Hz)', 10, 20000);
    if (o.q !== undefined) m.q = need(o.q, 'q (filter sharpness)', 0.1, 30);
    if (o.eq !== undefined && !isOff(o.eq)) m.eq = parseEq(o.eq);
    if (o.chorus !== undefined && !skipChorus) m.chorus = need(o.chorus, 'chorus', 0, 1);
    if (o.fade_in !== undefined && !isOff(o.fade_in)) m.fade_in = need(o.fade_in, 'fade_in (seconds)', 0, 60);
    if (o.fade_out !== undefined && !isOff(o.fade_out)) m.fade_out = need(o.fade_out, 'fade_out (seconds)', 0, 60);
    // reverb=0.3 puts the sound in a room (how much of the room you hear, 0 to 1; true means 0.3); room= is its size and damp= how soft its walls are (both 0 to 1)
    if (o.reverb !== undefined && !isOff(o.reverb)) {
        m.reverb = o.reverb === true ? 0.3 : need(o.reverb, 'reverb (how much room, 0 to 1)', 0, 1);
        if (o.room !== undefined) m.room = need(o.room, 'room (size, 0 to 1)', 0, 1);
        if (o.damp !== undefined) m.damp = need(o.damp, 'damp (how soft the walls are, 0 to 1)', 0, 1);
    }
    return Object.keys(m).length ? m : null;
}

// ----- the filters: one "biquad" does a low pass, high pass, band pass, a boost or cut around a pitch, or a bass / treble shelf -----
export function biquad(x, rate, type, f, q, gainDb) {
    f = Math.min(f, rate * 0.49);
    const w0 = TAU * f / rate, cs = Math.cos(w0), sn = Math.sin(w0), alpha = sn / (2 * q), A = Math.pow(10, (gainDb || 0) / 40), sq = 2 * Math.sqrt(A) * (sn / 2) * Math.SQRT2;
    let b0, b1, b2, a0, a1, a2;
    switch (type) {
        case 'lowpass': b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = b0; a0 = 1 + alpha; a1 = -2 * cs; a2 = 1 - alpha; break;
        case 'highpass': b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = b0; a0 = 1 + alpha; a1 = -2 * cs; a2 = 1 - alpha; break;
        case 'bandpass': b0 = alpha; b1 = 0; b2 = -alpha; a0 = 1 + alpha; a1 = -2 * cs; a2 = 1 - alpha; break;
        case 'peaking': b0 = 1 + alpha * A; b1 = -2 * cs; b2 = 1 - alpha * A; a0 = 1 + alpha / A; a1 = -2 * cs; a2 = 1 - alpha / A; break;
        case 'lowshelf': b0 = A * ((A + 1) - (A - 1) * cs + sq); b1 = 2 * A * ((A - 1) - (A + 1) * cs); b2 = A * ((A + 1) - (A - 1) * cs - sq); a0 = (A + 1) + (A - 1) * cs + sq; a1 = -2 * ((A - 1) + (A + 1) * cs); a2 = (A + 1) + (A - 1) * cs - sq; break;
        case 'highshelf': b0 = A * ((A + 1) + (A - 1) * cs + sq); b1 = -2 * A * ((A - 1) + (A + 1) * cs); b2 = A * ((A + 1) + (A - 1) * cs - sq); a0 = (A + 1) - (A - 1) * cs + sq; a1 = 2 * ((A - 1) - (A + 1) * cs); a2 = (A + 1) - (A - 1) * cs - sq; break;
        default: throw rtError('Unknown filter ' + type, 'ArgError');
    }
    b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
    const y = new Float32Array(x.length);
    let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (let i = 0; i < x.length; i++) { const v = b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2; x2 = x1; x1 = x[i]; y2 = y1; y1 = v; y[i] = v; }
    return y;
}
// how loud the envelope lets a note be at time t (seconds): up over the attack, down to the sustain level over the decay, hold, then down to nothing over the release at the end
export function adsrLevel(t, dur, e) {
    const r = Math.min(e.r, dur), relStart = dur - r;
    const base = (u) => (u < e.a ? (e.a > 0 ? u / e.a : 1) : u < e.a + e.d ? 1 - (1 - e.s) * ((u - e.a) / e.d) : e.s);
    if (t >= relStart && r > 0) return base(relStart) * Math.max(0, 1 - (t - relStart) / r);
    return base(t);
}
// ----- reverb: a room around the sound (eight "combs" and four "allpass" filters, the classic Freeverb way). It adds a quiet tail after the sound -----
const COMBS = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617], ALLPASS = [556, 441, 341, 225];
const WET = 3;
export function reverbTail(rate, room) { const fb = 0.7 + 0.28 * room; return Math.round(Math.min(4, Math.max(0.25, Math.log(0.001) / Math.log(fb) * 0.033)) * rate); }
export function reverbFx(x, rate, amount, room, damp, spread) {
    const k = rate / 44100, fb = 0.7 + 0.28 * room, d1 = damp * 0.4, d2 = 1 - d1;
    const n = x.length + reverbTail(rate, room), out = new Float32Array(n);
    const combs = COMBS.map((l) => ({ buf: new Float32Array(Math.round((l + spread) * k)), i: 0, last: 0 }));
    const aps = ALLPASS.map((l) => ({ buf: new Float32Array(Math.round((l + spread) * k)), i: 0 }));
    const dryGain = 1 - 0.3 * amount, wetGain = amount * WET;
    for (let t = 0; t < n; t++) {
        const inp = t < x.length ? x[t] : 0, feed = inp * 0.015;
        let sum = 0;
        for (const c of combs) { const y = c.buf[c.i]; c.last = y * d2 + c.last * d1; c.buf[c.i] = feed + c.last * fb; if (++c.i >= c.buf.length) c.i = 0; sum += y; }
        for (const a of aps) { const b = a.buf[a.i], y = -sum + b; a.buf[a.i] = sum + b * 0.5; if (++a.i >= a.buf.length) a.i = 0; sum = y; }
        out[t] = inp * dryGain + sum * wetGain;
    }
    return out;
}
// filters and EQ first, then the envelope and fades, then the room (reverb), then volume.  A reverb makes the sound longer: the extra tail is counted in  tail  (samples), so playing can finish at the end of the dry part
export function applyMods(st, mods, gain) {
    const rate = st.rate;
    const stages = [];
    if (mods) {
        const q = mods.q || 0.707;
        if (mods.highpass) stages.push(['highpass', mods.highpass, q, 0]);
        if (mods.lowpass) stages.push(['lowpass', mods.lowpass, q, 0]);
        if (mods.bandpass) stages.push(['bandpass', mods.bandpass, mods.q || 1, 0]);
        for (const b of mods.eq || []) stages.push([b[0], b[1], b[2], b[3]]);
    }
    const g = gain === undefined || gain === null ? 1 : gain;
    const ch = st.ch.map((c, ci) => {
        let x = stages.length ? stages.reduce((acc, s) => biquad(acc, rate, s[0], s[1], s[2], s[3]), c) : Float32Array.from(c);
        if (mods && mods.chorus) x = chorusFx(x, rate, mods.chorus);
        if (mods && (mods.adsr || mods.fade_in || mods.fade_out)) {
            const dur = x.length / rate;
            for (let i = 0; i < x.length; i++) {
                const t = i / rate; let m = 1;
                if (mods.adsr) m *= adsrLevel(t, dur, mods.adsr);
                if (mods.fade_in && t < mods.fade_in) m *= t / mods.fade_in;
                if (mods.fade_out && t > dur - mods.fade_out) m *= Math.max(0, (dur - t) / mods.fade_out);
                x[i] *= m;
            }
        }
        if (mods && mods.reverb) x = reverbFx(x, rate, mods.reverb, mods.room === undefined ? 0.5 : mods.room, mods.damp === undefined ? 0.5 : mods.damp, ci * 23);
        if (g !== 1) for (let i = 0; i < x.length; i++) x[i] *= g;
        return x;
    });
    return { rate, ch, tail: (st.tail || 0) + (ch[0].length - st.ch[0].length) };
}

// ---------- more ways to make sound from numbers: noise, harmonics, FM and a "superchip" ----------
// a small seedable random number maker (seed=1 always gives the same noise; without a seed it is different every time)
function rng(seed) { let a = (seed === undefined ? Math.floor(Math.random() * 4294967296) : Math.floor(seed)) >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const take = (o, names, dflt) => { for (const k of names) if (o[k] !== undefined) return o[k]; return dflt; };
function secsVol(what, rest, firstIsSecs) {
    const [pos, o] = split(rest);
    const secs = take(o, ['seconds', 'secs', 'time', 'length'], pos[0] !== undefined ? pos[0] : 0.5), vol = take(o, ['volume', 'vol', 'v'], pos[1] !== undefined ? pos[1] : 0.5);
    if (typeof secs !== 'number' || !(secs > 0) || secs > MAX_SECONDS) throw rtError('sound.' + what + ' needs a length in seconds between 0 and ' + MAX_SECONDS + ' but got ' + show(secs), 'ArgError');
    if (typeof vol !== 'number' || vol < 0 || vol > 1) throw rtError('sound.' + what + ' needs a volume between 0 and 1 but got ' + show(vol), 'ArgError');
    return { secs, vol, o };
}
const fadeEnds = (out, ms) => { const r = Math.min(Math.round(RATE * ms / 1000), out.length >> 1); for (let i = 0; i < r; i++) { const g = i / r; out[i] *= g; out[out.length - 1 - i] *= g; } return out; };
// noise that is not tied to a pitch: white (every level equally likely), pink (softer highs) or brown (rumbly)
export function whiteNoise(secs, vol, color, seed) {
    const n = Math.max(1, Math.round(secs * RATE)), out = new Float32Array(n), rand = rng(seed);
    if (color === 'white') for (let i = 0; i < n; i++) out[i] = (rand() * 2 - 1) * vol;
    else if (color === 'pink') { let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0; for (let i = 0; i < n; i++) { const w = rand() * 2 - 1; b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759; b2 = 0.969 * b2 + w * 0.153852; b3 = 0.8665 * b3 + w * 0.3104856; b4 = 0.55 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.016898; out[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11 * vol; b6 = w * 0.115926; } }
    else if (color === 'brown' || color === 'brownian') { let last = 0; for (let i = 0; i < n; i++) { last = (last + 0.02 * (rand() * 2 - 1)) / 1.02; out[i] = last * 3.5 * vol; } }
    else throw rtError('noise colors are white, pink and brown, not ' + show(color), 'ArgError');
    return fadeEnds(out, 5);
}
// chip noise: a shift register that is stepped "freq" times a second, so a higher number is a hissier, higher noise. The kinds are
//   retro (the long 32767-step register of old game consoles), buzz (the short 93-step register: a pitched, metallic buzz),
//   white (a new random level each step), bit (a random 1-bit level each step), crackle (rare random clicks)
export const CHIPNOISES = ['retro', 'buzz', 'white', 'bit', 'crackle'];
export function chipNoise(freq, secs, vol, type, seed) {
    if (!CHIPNOISES.includes(type)) throw rtError('chipnoise kinds are ' + CHIPNOISES.join(', ') + ', not ' + show(type), 'ArgError');
    const n = Math.max(1, Math.round(secs * RATE)), out = new Float32Array(n), rand = rng(seed);
    let reg = 1, level = 0, acc = 1;
    const step = freq / RATE;
    for (let i = 0; i < n; i++) {
        acc += step;
        while (acc >= 1) {
            acc -= 1;
            if (type === 'retro' || type === 'buzz') { const fb = (reg & 1) ^ ((reg >> (type === 'retro' ? 1 : 6)) & 1); reg = (reg >> 1) | (fb << 14); level = (reg & 1) ? 1 : -1; }
            else if (type === 'white') level = rand() * 2 - 1;
            else if (type === 'bit') level = rand() < 0.5 ? -1 : 1;
            else level = rand() < 0.06 ? (rand() < 0.5 ? -1 : 1) : 0;
        }
        out[i] = level * vol;
    }
    return fadeEnds(out, 2);
}
// a table of one cycle made from harmonics: [number of the harmonic, strength 0 to 1, phase] (the phase is optional)
const TABLE = 4096;
function tableFrom(parts, maxHarmonic) {
    const t = new Float32Array(TABLE);
    for (const [h, a, ph] of parts) { if (h > maxHarmonic || !a) continue; for (let i = 0; i < TABLE; i++) t[i] += a * Math.cos(TAU * h * i / TABLE + (ph || 0)); }
    let pk = 0; for (let i = 0; i < TABLE; i++) pk = Math.max(pk, Math.abs(t[i]));
    if (pk > 0) for (let i = 0; i < TABLE; i++) t[i] /= pk;
    return t;
}
const readTable = (t, ph) => { const x = (ph - Math.floor(ph)) * TABLE, i = Math.floor(x), f = x - i; return t[i] * (1 - f) + t[(i + 1) % TABLE] * f; };
const harmonicShapes = {
    sine: () => [1], saw: () => Array.from({ length: 32 }, (_, i) => 1 / (i + 1)), square: () => Array.from({ length: 32 }, (_, i) => ((i + 1) % 2 ? 1 / (i + 1) : 0)),
    triangle: () => Array.from({ length: 32 }, (_, i) => ((i + 1) % 2 ? 1 / ((i + 1) * (i + 1)) : 0)), organ: () => [1, 0.8, 0.6, 0.5, 0, 0.4, 0, 0.3], bell: () => [1, 0, 0, 0.7, 0, 0.5, 0.35, 0, 0.25],
};
export function harmonicList(v) {
    let list = v;
    if (typeof v === 'string') { if (!harmonicShapes[v]) throw rtError('harmonics shapes are ' + Object.keys(harmonicShapes).join(', ') + ', not "' + v + '"  (or give a list of strengths like [1, 0.5, 0.33])', 'ArgError'); list = harmonicShapes[v](); }
    if (!Array.isArray(list) || !list.length || list.length > 64) throw rtError('harmonics needs a list of 1 to 64 strengths (the first is the pitch itself, the second the octave above, then the fifth above that...) or a shape name', 'ArgError');
    list.forEach((x, i) => need(x, 'harmonic ' + (i + 1), 0, 1));
    return list;
}
// a slow wobble in pitch (in semitones) that can start late: vibrato(depth, speed Hz, delay seconds)
const vibratoAt = (o, dflt) => {
    const depth = need(take(o, ['vibrato', 'vibrato_depth'], dflt.depth), 'vibrato (semitones)', 0, 4), speed = need(take(o, ['vibrato_speed'], dflt.speed || 5.5), 'vibrato_speed (Hz)', 0.1, 30), delay = need(take(o, ['vibrato_delay'], dflt.delay || 0), 'vibrato_delay (seconds)', 0, 10);
    return depth > 0 ? (t) => depth * Math.sin(TAU * speed * t) * Math.min(1, Math.max(0, (t - delay) / 0.15 + (delay === 0 ? 1 : 0))) : () => 0;
};
function harmonicsSamples(freq, secs, vol, o) {
    const amps = harmonicList(take(o, ['h', 'harmonics', 'shape', 'strengths'], 'saw'));
    const maxH = Math.max(1, Math.floor(RATE * 0.49 / freq));
    const t = tableFrom(amps.map((a, i) => [i + 1, a, -Math.PI / 2]), maxH);
    const vib = vibratoAt(o, { depth: 0 });
    const fadeIn = need(take(o, ['fade_in'], 0), 'fade_in (seconds)', 0, 60), decay = need(take(o, ['decay'], 0), 'decay', 0, 60);
    const n = Math.max(1, Math.round(secs * RATE)), out = new Float32Array(n);
    let ph = 0;
    for (let i = 0; i < n; i++) {
        const tt = i / RATE;
        let g = 1; if (fadeIn > 0 && tt < fadeIn) g = tt / fadeIn; if (decay > 0) g *= Math.exp(-tt * decay);
        out[i] = readTable(t, ph) * vol * g;
        ph += freq * Math.pow(2, vib(tt) / 12) / RATE;
    }
    return fadeEnds(out, 5);
}
// ----- FM: operators (little sine waves) that bend each other's phase. The 15 ways of wiring four of them: carriers are the first N operators, "mods" says who bends whom
const FM_ALGOS = [
    { carriers: 1, mods: [[2, 3, 4], [], [], []] }, { carriers: 1, mods: [[2, 3], [], [4], []] }, { carriers: 1, mods: [[2], [3, 4], [], []] }, { carriers: 1, mods: [[2, 3], [4], [4], []] },
    { carriers: 1, mods: [[2], [3], [4], []] }, { carriers: 2, mods: [[3], [4], [], []] }, { carriers: 2, mods: [[], [3, 4], [], []] }, { carriers: 2, mods: [[], [3], [4], []] },
    { carriers: 2, mods: [[3], [3], [4], []] }, { carriers: 2, mods: [[3, 4], [3, 4], [], []] }, { carriers: 3, mods: [[], [], [4], []] }, { carriers: 3, mods: [[4], [4], [4], []] },
    { carriers: 4, mods: [[], [], [], []] }, { carriers: 2, mods: [[2, 3], [4], [], []] }, { carriers: 3, mods: [[2, 3, 4], [3, 4], [4], []] },
];
const FM_INDEX = 6;   // a modulator at full level bends its target by 6 radians
export function fmSamples(freq, secs, vol, o) {
    const algo = take(o, ['algorithm', 'algo'], 1);
    if (!Number.isInteger(algo) || algo < 1 || algo > FM_ALGOS.length) throw rtError('fm algorithm is a whole number from 1 to ' + FM_ALGOS.length + ' but got ' + show(algo), 'ArgError');
    const A = FM_ALGOS[algo - 1];
    const ratios = take(o, ['ratios', 'ratio'], [1, 2, 1, 1]), levels = take(o, ['levels', 'level'], [15, 8, 0, 0]);
    const four = (list, what, lo, hi) => { const l = Array.isArray(list) ? list : [list]; if (l.length > 4) throw rtError('fm ' + what + ' takes up to four numbers', 'ArgError'); return [0, 1, 2, 3].map((i) => need(l[i] === undefined ? (what === 'ratios' ? 1 : 0) : l[i], 'fm ' + what, lo, hi)); };
    const rt_ = four(ratios, 'ratios', 0.01, 200), lv = four(levels, 'levels', 0, 15);
    const decays = four(take(o, ['op_decay', 'decays'], [0, 0, 0, 0]), 'op_decay', 0, 60), vib = vibratoAt(o, { depth: 0 });
    const fb = need(take(o, ['feedback', 'fb'], 0), 'fm feedback', 0, 15), fbOp = take(o, ['feedback_op', 'fb_op'], 1);
    if (![1, 2, 3, 4].includes(fbOp)) throw rtError('fm feedback_op is 1, 2, 3 or 4', 'ArgError');
    const n = Math.max(1, Math.round(secs * RATE)), out = new Float32Array(n);
    const ph = [0, 0, 0, 0], y = [0, 0, 0, 0], prev = [0, 0, 0, 0];
    const ampSum = Math.max(1e-9, lv.slice(0, A.carriers).reduce((a, b) => a + b, 0) / 15);
    for (let i = 0; i < n; i++) {
        const tt = i / RATE, bend = Math.pow(2, vib(tt) / 12);
        const gain = decays.map((d) => (d > 0 ? Math.exp(-tt * d) : 1));   // an operator whose level fades away as the note goes on
        for (let op = 3; op >= 0; op--) {
            let m = 0;
            for (const j of A.mods[op]) m += (lv[j - 1] / 15) * gain[j - 1] * FM_INDEX * y[j - 1];
            if (fb && op === fbOp - 1) m += (fb / 15) * FM_INDEX * 0.5 * (y[op] + prev[op]);
            prev[op] = y[op];
            ph[op] += TAU * rt_[op] * freq * bend / RATE;
            y[op] = Math.sin(ph[op] + m);
        }
        let v = 0; for (let c = 0; c < A.carriers; c++) v += y[c] * lv[c] / 15 * gain[c];
        out[i] = v / ampSum;
    }
    return out;
}
// ----- superchip: a chip-style wave, doubled with a tiny detune, wobbling with a delayed vibrato, through a low pass that closes after the start of each note ("twang"), then chorus
// the "spiky" wave is a zigzag of spikes; this is its sound described as harmonics [number, strength, phase] (measured from a real UltraBox note: a strong 3rd harmonic, then the 1st and 2nd, a little 4th and 9th)
const SPIKY = [[1, 0.3, -1.05], [2, 0.176, -0.52], [3, 0.451, -3.14], [4, 0.044, 0.52], [5, 0.016, 1.05], [9, 0.05, -3.14], [15, 0.018, -3.14]];
function chorusFx(x, rate, amount) {
    if (!(amount > 0)) return x;
    const n = x.length, y = new Float32Array(n), base = [0.012, 0.019], depth = 0.0035, lfo = [0.31, 0.43], phase0 = [0, 2.1], w = amount * 0.45;
    for (let i = 0; i < n; i++) {
        let wet = 0;
        for (let k = 0; k < 2; k++) {
            const d = (base[k] + depth * Math.sin(TAU * lfo[k] * i / rate + phase0[k])) * rate, pos = i - d, i0 = Math.floor(pos), f = pos - i0;
            wet += pos < 0 ? 0 : x[i0] * (1 - f) + (x[i0 + 1] === undefined ? x[i0] : x[i0 + 1]) * f;
        }
        y[i] = x[i] * (1 - w) + wet * w * 0.5;
    }
    return y;
}
// a low pass whose cutoff may change as the sound goes on (cutoffAt gives Hz for each time in seconds)
function lowpassSweep(x, rate, cutoffAt, q) {
    const y = new Float32Array(x.length);
    let b0 = 0, b1 = 0, b2 = 0, a1 = 0, a2 = 0, x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (let i = 0; i < x.length; i++) {
        if (i % 32 === 0) {
            const f = Math.min(Math.max(cutoffAt(i / rate), 20), rate * 0.49), w0 = TAU * f / rate, cs = Math.cos(w0), al = Math.sin(w0) / (2 * q), a0 = 1 + al;
            b0 = (1 - cs) / 2 / a0; b1 = (1 - cs) / a0; b2 = b0; a1 = -2 * cs / a0; a2 = (1 - al) / a0;
        }
        const v = b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2; x2 = x1; x1 = x[i]; y2 = y1; y1 = v; y[i] = v;
    }
    return y;
}
// more chip waves: a pulse that is "up" for a fraction of each cycle, and a "double saw" (a saw plus a saw an octave up)
const chipWave = (name) => {
    const t = new Float32Array(TABLE);
    const pulse = (d) => { for (let i = 0; i < TABLE; i++) t[i] = i / TABLE < d ? 1 - d : -d; };   // the average is taken out so it sits around zero
    if (name === 'spiky') return tableFrom(SPIKY, 64);
    if (name === '1/8 pulse' || name === 'pulse8') { pulse(0.125); return t; }
    if (name === '1/4 pulse' || name === 'pulse4') { pulse(0.25); return t; }
    if (name === 'double saw' || name === 'saw2') { for (let i = 0; i < TABLE; i++) { const p = i / TABLE; t[i] = (2 * p - 1) + 0.5 * (2 * ((2 * p) % 1) - 1); } return t; }
    if (name === 'saw') { for (let i = 0; i < TABLE; i++) t[i] = 2 * i / TABLE - 1; return t; }
    if (WAVES[name]) { for (let i = 0; i < TABLE; i++) t[i] = WAVES[name](i / TABLE); return t; }
    throw rtError('chip waves are spiky, 1/8 pulse, 1/4 pulse, double saw, saw, sine, square, triangle and mole, not ' + show(name), 'ArgError');
};
export function superchipSamples(freq, secs, vol, o) {
    const wave = take(o, ['wave', 'shape'], 'spiky');
    const voices = need(take(o, ['voices', 'unison'], 2), 'superchip voices', 1, 8), spread = need(take(o, ['spread', 'detune'], 0.09), 'superchip spread (semitones)', 0, 12);
    const vib = need(take(o, ['vibrato', 'vibrato_depth'], 0.32), 'superchip vibrato (semitones)', 0, 4), vibSpeed = need(take(o, ['vibrato_speed'], 5.5), 'superchip vibrato_speed (Hz)', 0.1, 30), vibDelay = need(take(o, ['vibrato_delay'], 0.2), 'superchip vibrato_delay (seconds)', 0, 10);
    const cutoffIn = take(o, ['cutoff', 'filter'], 2828), cutoff = isOff(cutoffIn) ? 0 : need(cutoffIn, 'superchip cutoff (Hz, or 0 for no filter)', 20, 20000), twang = need(take(o, ['twang'], 2), 'superchip twang', 0, 128), chorus = need(take(o, ['chorus'], 1), 'superchip chorus', 0, 1);
    // flare: the filter closes quickly (a "scoot"); q: how much the filter rings at its cutoff; fade_in / decay shape the loudness
    const flare = need(take(o, ['flare'], 0), 'superchip flare', 0, 128), q = need(take(o, ['q'], 0.707), 'superchip q', 0.1, 30), fadeIn = need(take(o, ['fade_in'], 0), 'superchip fade_in (seconds)', 0, 60), decay = need(take(o, ['decay'], 0), 'superchip decay', 0, 60);
    const fadeOut = need(take(o, ['fade_out'], Math.min(0.25, secs / 2)), 'superchip fade_out (seconds)', 0, 60);
    const table = chipWave(wave);
    const n = Math.max(1, Math.round(secs * RATE)), out = new Float32Array(n), ph = new Float64Array(voices);
    for (let i = 0; i < n; i++) {
        const t = i / RATE;
        const vibNow = vib * Math.sin(TAU * vibSpeed * t) * Math.min(1, Math.max(0, (t - vibDelay) / 0.15 + (vibDelay === 0 ? 1 : 0)));
        let v = 0;
        for (let k = 0; k < voices; k++) {
            const off = voices === 1 ? 0 : spread * (2 * k / (voices - 1) - 1);          // the voices sit evenly from -spread to +spread semitones
            ph[k] += freq * Math.pow(2, (vibNow + off) / 12) / RATE;
            v += readTable(table, ph[k]);
        }
        out[i] = v / Math.sqrt(voices);
    }
    let y = cutoff > 0 ? lowpassSweep(out, RATE, (t) => cutoff * (twang > 0 ? Math.max(0.15, Math.exp(-t * twang * 0.25)) : 1) * (flare > 0 ? Math.exp(-t * flare * 0.16) : 1), q) : out;   // cutoff=0 switches the whole filter (and its twang / flare) off
    y = chorusFx(y, RATE, chorus);
    for (let i = 0; i < n; i++) { const t = i / RATE; if (fadeIn > 0 && t < fadeIn) y[i] *= t / fadeIn; if (decay > 0) y[i] *= Math.exp(-t * decay); }
    if (fadeOut > 0) { const r = Math.min(Math.round(fadeOut * RATE), n); for (let i = 0; i < r; i++) y[n - 1 - i] *= i / r; }
    let pk = 0; for (let i = 0; i < n; i++) pk = Math.max(pk, Math.abs(y[i]));
    if (pk > 0) for (let i = 0; i < n; i++) y[i] = y[i] / pk * vol;
    return y;
}
// an optional low pass that can sweep (cutoff in Hz, 0 = off), shared by the sounds that are not "chip" voices
function tone(out, o, vol) {
    const cutIn = take(o, ['cutoff', 'filter'], 0);
    if (isOff(cutIn)) return out;
    const cutoff = need(cutIn, 'cutoff (Hz, or 0 for no filter)', 20, 20000), twang = need(take(o, ['twang'], 0), 'twang', 0, 128), flare = need(take(o, ['flare'], 0), 'flare', 0, 128), q = need(take(o, ['q'], 0.707), 'q', 0.1, 30);
    const y = lowpassSweep(out, RATE, (t) => cutoff * (twang > 0 ? Math.max(0.15, Math.exp(-t * twang * 0.25)) : 1) * (flare > 0 ? Math.exp(-t * flare * 0.16) : 1), q);
    let pk = 0; for (let i = 0; i < y.length; i++) pk = Math.max(pk, Math.abs(y[i]));
    if (pk > 0) for (let i = 0; i < y.length; i++) y[i] = y[i] / pk * vol;
    return y;
}
// every kind of sound that can be made by name:  sound.make("fm", 440, 1, algorithm=5)   sound.start("noise", 1)
const SYNTH = {
    noise: (rest) => { const { secs, vol, o } = secsVol('noise', rest); return whiteNoise(secs, vol, String(take(o, ['color', 'type'], 'white')), o.seed); },
    chipnoise: (rest) => { const { freq, secs, vol } = waveArgs('chipnoise', rest, { freq: 4000, max: 200000 }); const o = split(rest)[1]; return chipNoise(freq, secs, vol, String(take(o, ['type', 'kind'], 'retro')), o.seed); },
    harmonics: (rest) => { const { freq, secs, vol } = waveArgs('harmonics', rest); const o = split(rest)[1]; return tone(harmonicsSamples(freq, secs, vol, o), o, vol); },
    fm: (rest) => { const { freq, secs, vol } = waveArgs('fm', rest); const out = fmSamples(freq, secs, vol, split(rest)[1]); let pk = 0; for (let i = 0; i < out.length; i++) pk = Math.max(pk, Math.abs(out[i])); for (let i = 0; i < out.length; i++) out[i] = (pk > 0 ? out[i] / pk : 0) * vol; return tone(fadeEnds(out, 5), split(rest)[1], vol); },
    superchip: (rest) => { const { freq, secs, vol } = waveArgs('superchip', rest); return superchipSamples(freq, secs, vol, split(rest)[1]); },
};
// ----- instruments: ready-made sounds, each matched by ear and by measurement to an instrument of the UltraBox song "Look at instruments".
// They take (pitch, seconds, volume) and the same named options as the kind they are built from (an option you give wins over the instrument's own).
const preset = (kind, base) => (rest) => { const [pos, o] = split(rest); return SYNTH[kind](pos.concat([new Named(Object.assign({}, base, o))])); };

// harmonic strengths of the flute, as measured: mostly the pitch itself, then the odd harmonics getting weaker
const FLUTE = [1, 0.02, 0.29, 0.05, 0.2, 0.07, 0.13, 0.05, 0.04];
SYNTH.high_superchip = preset('superchip', { wave: '1/8 pulse' });
SYNTH.flute = preset('harmonics', { h: FLUTE, vibrato: 0.3, vibrato_speed: 5.5, vibrato_delay: 0.19, fade_in: 0.02, fade_out: 0.08 });
// an electric piano: operator 1 (and 2) heard, bent by operators 3 and 4 (4 is 16 times the pitch and fades away fast, which gives the bright "tink" at the start)
SYNTH.epiano = preset('fm', { algorithm: 6, ratios: [1, 1, 1, 16], levels: [12, 6, 9, 6], op_decay: [0, 0, 0, 1.2], cutoff: 13454, twang: 2 });
SYNTH.electric_piano = SYNTH.epiano;
// scoot: a double saw (two voices a hair apart) through a ringing low pass that closes in a flash
SYNTH.scoot = preset('superchip', { wave: 'double saw', voices: 2, spread: 0.018, vibrato: 0, chorus: 0, cutoff: 707, twang: 0, flare: 55, q: 4, fade_in: 0.0125, fade_out: 0.03 });
SYNTH.high_scoot = preset('superchip', { wave: 'spiky', voices: 2, spread: 0.018, vibrato: 0, chorus: 0, cutoff: 707, twang: 0, flare: 75, q: 4, fade_in: 0.0125, fade_out: 0.03 });
// tweet: only the 4th harmonic (a sine two octaves above the pitch), wobbling heavily and dying away
SYNTH.tweet = (rest) => { const { freq, secs, vol } = waveArgs('tweet', rest); const o = split(rest)[1]; const f4 = freq * 4; if (f4 > 20000) throw rtError('sound.tweet plays four times the pitch you give, so the pitch can be at most 5000 Hz', 'ArgError'); return superchipSamples(f4, secs, vol, Object.assign({ wave: 'sine', voices: 2, spread: 0.045, vibrato: 0.45, vibrato_delay: 0, cutoff: 20000, twang: 0, chorus: 0, fade_in: 0.0575, decay: 3.9, fade_out: 0.03 }, o)); };
SYNTH.white = SYNTH.noise;
const INSTRUMENTS = ['high_superchip', 'flute', 'electric_piano', 'scoot', 'tweet', 'high_scoot'];
const KINDS = () => Object.keys(WAVES).concat(Object.keys(SYNTH).filter((k) => k !== 'white' && k !== 'epiano'));
function rawSamples(kind, rest, what) {
    if (WAVES[kind]) { const { freq, secs, vol } = waveArgs(what, rest); return makeSamples(WAVES[kind], freq, secs, vol); }
    if (!SYNTH[kind]) throw rtError('sound.' + what + ' knows ' + KINDS().join(', ') + ' (or your own wave function), not ' + show(kind), 'ArgError');
    return SYNTH[kind](rest);
}

// ---------- where sounds come from ----------
const SEG = /^[^\\?#]+$/;      // folder and file names may have spaces
const NAME = /^[A-Za-z0-9_.@-]+$/;   // owners and repos may not
function splitSpec(spec, what) {
    // "owner/repo/path/to/file.wav"  or  "owner/repo@branch/path/to/file.wav"
    const s = String(spec === undefined || spec === null ? '' : spec).trim().replace(/^\/+/, '');
    const parts = s.split('/');
    if (parts.length < 3 || !NAME.test(parts[0]) || !NAME.test(parts[1]) || !parts.every((p) => p && SEG.test(p)) || parts.some((p) => p === '..')) throw rtError('sound.' + what + ' wants "owner/repo/path/to/sound.wav" (add @branch after the repo name to pick a branch) but got ' + JSON.stringify(s), 'ArgError');
    const m = /^([^@]+)@(.+)$/.exec(parts[1]);
    return { owner: parts[0], repo: m ? m[1] : parts[1], ref: m ? m[2] : null, path: parts.slice(2).join('/') };
}
export function gitUrl(spec) {
    const raw = String(spec || '').trim();
    // links people copy from their browser also work
    let m = /^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/(?:blob|raw)\/([^/]+)\/(.+)$/.exec(raw);
    if (m) return 'https://raw.githubusercontent.com/' + m[1] + '/' + m[2] + '/' + m[3] + '/' + m[4];
    if (/^https:\/\/(raw\.githubusercontent\.com|media\.githubusercontent\.com)\//.test(raw)) return raw;
    const p = splitSpec(raw, 'git');
    return 'https://raw.githubusercontent.com/' + p.owner + '/' + p.repo + '/' + (p.ref || 'HEAD') + '/' + p.path.split('/').map(encodeURIComponent).join('/');
}
let mintServer = 'https://mintcode.radii-office.com';
export function mintParts(spec) { const p = splitSpec(String(spec || '').replace(/^https?:\/\/[^/]+\//, ''), 'mint'); return { ...p, line: p.ref || 'main' }; }

// a path for sound.file: absolute stays, everything else is looked up beside the program that asked for it
const dirOf = (p) => { const i = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')); return i < 0 ? '' : p.slice(0, i); };
function joinPath(base, rel) {
    const out = base.split('/');
    for (const seg of rel.split('/')) { if (seg === '.' || seg === '') continue; if (seg === '..') { if (out.length > 1 || (out.length === 1 && out[0] !== '')) out.pop(); } else out.push(seg); }
    return out.join('/') || '/';
}
export function filePath(p) {
    p = str(p, 'sound.file');
    if (/^~\//.test(p) && rt.sys) return rt.sys.home ? rt.sys.home() + p.slice(1) : p;
    if (/^(\/|[A-Za-z]:[\\/])/.test(p)) return p;
    const here = rt.state && rt.state.file ? String(rt.state.file) : '';
    let base = here && !/^</.test(here) ? dirOf(here.replace(/\\/g, '/')) : '';
    if (!base || !/^(\/|[A-Za-z]:[\\/])/.test(base)) { const cwd = rt.sys ? rt.sys.cwd().replace(/\\/g, '/') : ''; base = base ? joinPath(cwd, base) : cwd; }
    return joinPath(base, p.replace(/\\/g, '/'));
}
const inBrowser = () => typeof document !== 'undefined' && typeof Audio !== 'undefined';
function pageUrl(p) {
    // in a page: look beside the Suave file when it came from a file, otherwise beside the page
    const here = rt.state && rt.state.file ? String(rt.state.file) : '';
    let base = location.href;
    if (here && !/^</.test(here)) { try { base = new URL(here, location.href).href; } catch (e) { /* the page */ } }
    return new URL(p, base).href;
}
const MIMES = { wav: 'audio/wav', mp3: 'audio/mpeg', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', webm: 'audio/webm' };
const extOf = (p) => ((/\.([A-Za-z0-9]+)(?:[?#].*)?$/.exec(p) || [])[1] || 'wav').toLowerCase();

// ---------- playing bytes ----------
const active = new Set();   // things that can be stopped: { stop() }
function playInBrowser(bytes, ext, vol, holder) {
    return new Promise((resolve, reject) => {
        // bytes is sound-file bytes, or a web address the audio element loads by itself
        const own = typeof bytes !== 'string';
        const url = own ? URL.createObjectURL(new Blob([bytes], { type: MIMES[ext] || 'audio/wav' })) : bytes;
        const free = () => { if (own) URL.revokeObjectURL(url); };
        const a = new Audio(url); a.volume = vol;
        const handle = { stop: () => { try { a.pause(); } catch (e) { /* ignore */ } done(); } };
        if (holder) holder.handle = handle;
        const done = () => { active.delete(handle); free(); resolve(null); };
        active.add(handle);
        a.onended = done;
        a.onerror = () => { active.delete(handle); free(); reject(rtError('The browser could not play this sound (is it a .wav, .mp3 or .ogg file?)', 'SoundError')); };
        const p = a.play();
        if (p && p.catch) p.catch((e) => { active.delete(handle); free(); reject(rtError(e && e.name === 'NotAllowedError' ? 'The browser only plays sound after the visitor has clicked or typed on the page. Call sound from a button or key press' : 'The browser could not play this sound: ' + (e && e.message), 'SoundError')); });
    });
}
// one folder for every sound file this program makes, taken away when it ends
let tmpDir = null, tmpSeq = 0;
function sharedTemp() {
    if (!tmpDir) {
        tmpDir = rt.sys.tempDir();
        if (typeof addEventListener === 'function') addEventListener('unload', () => { try { rt.sys.remove(tmpDir, true); } catch (e) { /* gone already */ } });
    }
    return tmpDir;
}
async function playInTerminal(bytes, ext, vol, holder) {
    const s = rt.needSys('sound');
    const file = sharedTemp() + '/sound-' + (tmpSeq++) + '.' + ext;
    s.writeBytes(file, bytes);
    const os = s.os();
    const v = String(Math.max(0, Math.min(1, vol)));
    const tries = os === 'darwin' ? [['afplay', ['-v', v, file]]]
        : os === 'windows' ? [['powershell', ['-NoProfile', '-Command', '(New-Object Media.SoundPlayer "' + file + '").PlaySync()']]]
        : [['paplay', [file]], ['aplay', ['-q', file]], ['ffplay', ['-nodisp', '-autoexit', '-loglevel', 'quiet', file]], ['mpg123', ['-q', file]], ['play', ['-q', file]]];
    const handle = { stop: () => { handle.stopped = true; if (handle.child) { try { handle.child.kill(); } catch (e) { /* ignore */ } } } };
    if (holder) holder.handle = handle;
    active.add(handle);
    try {
        let lastErr = null;
        for (const [cmd, args] of tries) {
            if (handle.stopped) return null;
            try {
                const r = await s.run(cmd, args, { onChild: (c) => { handle.child = c; } });
                if (handle.stopped) return null;
                if (r.code === 0) return null;
                lastErr = r.stderr || ('exit code ' + r.code);
            } catch (e) { lastErr = e && e.message; }
        }
        throw rtError('I could not find a way to play sound here (' + (os === 'darwin' ? 'afplay' : os === 'windows' ? 'PowerShell' : 'paplay, aplay, ffplay, mpg123 or play') + ' did not work' + (lastErr ? ': ' + String(lastErr).trim().slice(0, 120) : '') + ')', 'SoundError');
    } finally { active.delete(handle); try { s.remove(file); } catch (e) { /* ignore */ } }
}
const play = (bytes, ext, vol, holder) => (inBrowser() ? playInBrowser(bytes, ext, vol, holder) : playInTerminal(bytes, ext, vol, holder));
// a browser can play numbers straight from memory with no file in between, which starts a sound right away
let audioCtx = null;
function playBufferInBrowser(st, vol, holder) {
    const dryMs = st.tail ? Math.max(0, (st.ch[0].length - st.tail) / st.rate * 1000) : 0;
    const AC = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!AC) return playInBrowser(wavFromState(st), 'wav', vol, holder);
    if (!audioCtx) audioCtx = new AC();
    const ctx = audioCtx;
    return new Promise((resolve, reject) => {
        const buf = ctx.createBuffer(st.ch.length, st.ch[0].length, st.rate);
        st.ch.forEach((c, i) => buf.copyToChannel(c, i));
        const src = ctx.createBufferSource(); src.buffer = buf;
        const gain = ctx.createGain(); gain.gain.value = vol; src.connect(gain); gain.connect(ctx.destination);
        let finished = false;
        const done = () => { if (finished) return; finished = true; active.delete(handle); resolve(null); };
        const handle = { stop: () => { try { src.stop(); } catch (e) { /* not started */ } done(); } };
        if (holder) holder.handle = handle;
        active.add(handle);
        src.onended = done;
        if (dryMs) setTimeout(() => resolve(null), dryMs);   // (a reverb tail keeps sounding after the sound itself is over)
        src.start();
        if (ctx.state !== 'running') {
            ctx.resume().catch(() => {});
            setTimeout(() => { if (!finished && ctx.state !== 'running') { finished = true; active.delete(handle); try { src.stop(); } catch (e) { /* ignore */ } reject(rtError('The browser only plays sound after the visitor has clicked or typed on the page. Call sound from a button or key press', 'SoundError')); } }, 400);
        }
    });
}
// ---------- a helper that stays running (Mac): it keeps the sound card open, so a sound starts right away instead of waiting for a new player each time ----------
let daemon = null, daemonBad = false;
function helperFile() {
    try {
        const u = new URL('./audio/suave-audio-mac', import.meta.url);
        if (u.protocol !== 'file:') return null;
        const f = decodeURIComponent(u.pathname);
        return rt.sys.exists(f) ? f : null;
    } catch (e) { return null; }
}
function getDaemon() {
    if (daemon) return daemon;
    if (daemonBad || inBrowser() || !rt.sys || !rt.sys.spawnPipe || rt.sys.os() !== 'darwin' || (rt.sys.env && rt.sys.env('SUAVE_SLOW_SOUND'))) return null;
    const f = helperFile();
    if (!f) return null;
    let proc;
    try { proc = rt.sys.spawnPipe(f, []); } catch (e) { daemonBad = true; return null; }
    const d = daemon = { proc, waiting: new Map(), next: 1, ready: false };
    const refresh = () => { if (d.waiting.size) proc.ref(); else proc.unref(); };
    d.refresh = refresh;
    const die = () => {
        if (daemon === d) daemon = null;
        if (!d.ready) daemonBad = true;   // never worked here: do not try again
        const all = Array.from(d.waiting.values()); d.waiting.clear();
        for (const r of all) r(false);
    };
    const line = (t) => {
        if (t === 'ready') { d.ready = true; return; }
        const m = /^(done|failed) (\d+)$/.exec(t);
        if (m) { const r = d.waiting.get(Number(m[2])); if (r) { d.waiting.delete(Number(m[2])); refresh(); r(m[1] === 'done'); } }
        else if (/^error/.test(t)) { proc.kill(); }
    };
    proc.unref();
    (async () => {
        const reader = proc.stdout.getReader(); const dec = new TextDecoder(); let buf = '';
        try {
            for (;;) {
                const { value, done } = await reader.read();
                if (done) break;
                buf += dec.decode(value, { stream: true });
                let i; while ((i = buf.indexOf('\n')) >= 0) { line(buf.slice(0, i).trim()); buf = buf.slice(i + 1); }
            }
        } catch (e) { /* the helper went away */ }
        die();
    })();
    proc.status.then(die, die);
    return d;
}
// sends one sound to the helper and gives back a promise: null when it ended, false when the helper could not play it.  dryMs: finish at the end of the dry sound, while a reverb tail goes on sounding
function viaDaemon(holder, send, dryMs) {
    const d = getDaemon();
    if (!d) return null;
    const id = d.next++;
    const handle = { stop: () => {
        handle.stopped = true;
        const m = new Uint8Array(5); new DataView(m.buffer).setUint32(1, id, true); m[0] = 2;
        try { d.proc.write(m).catch(() => {}); } catch (e) { /* gone */ }
    } };
    if (holder) holder.handle = handle;
    active.add(handle);
    const finish = new Promise((resolve) => { d.waiting.set(id, resolve); d.refresh(); });
    try { send(d, id); } catch (e) { d.waiting.delete(id); d.refresh(); active.delete(handle); return null; }
    const real = finish.then((ok) => { active.delete(handle); return ok || handle.stopped ? null : false; });
    if (!dryMs) return real;
    return new Promise((resolve) => {
        let fin = false;
        const t = setTimeout(() => { if (!fin) { fin = true; resolve(null); } }, dryMs);
        real.then((r) => { clearTimeout(t); if (!fin) { fin = true; resolve(r); } });
    });
}
function playViaDaemon(st, vol, holder) {
    const frames = st.ch[0].length, nch = st.ch.length;
    if (!frames) return Promise.resolve(null);
    return viaDaemon(holder, (d, id) => {
        const head = new Uint8Array(21); const dv = new DataView(head.buffer);
        dv.setUint8(0, 1); dv.setUint32(1, id, true); dv.setUint32(5, Math.round(st.rate), true); dv.setUint32(9, nch, true); dv.setUint32(13, frames, true); dv.setFloat32(17, vol, true);
        d.proc.write(head).catch(() => {});
        for (const c of st.ch) { const f = c instanceof Float32Array ? c : Float32Array.from(c); d.proc.write(new Uint8Array(f.buffer, f.byteOffset, f.byteLength)).catch(() => {}); }
    }, st.tail ? Math.max(0, (frames - st.tail) / st.rate * 1000) : 0);
}
// a sound file on disk (wav, mp3, m4a, aac, flac, aiff): the helper opens and plays it itself
function playFileViaDaemon(path, vol, holder) {
    return viaDaemon(holder, (d, id) => {
        const pb = new TextEncoder().encode(path);
        const head = new Uint8Array(13); const dv = new DataView(head.buffer);
        dv.setUint8(0, 3); dv.setUint32(1, id, true); dv.setUint32(5, pb.length, true); dv.setFloat32(9, vol, true);
        d.proc.write(head).catch(() => {}); d.proc.write(pb).catch(() => {});
    }, 0);
}

// ---------- Windows: one PowerShell kept running (starting a new one for each sound takes a good half second). It plays one sound at a time; a sound that starts while it is busy uses a PowerShell of its own, as before ----------
const WIN_SCRIPT = "$p = New-Object System.Media.SoundPlayer; [Console]::Out.WriteLine('ready'); [Console]::Out.Flush(); while (($l = [Console]::In.ReadLine()) -ne $null) { $i = $l.IndexOf(' '); $id = $l.Substring(0, $i); $f = $l.Substring($i + 1); try { $p.SoundLocation = $f; $p.Load(); $p.PlaySync() } catch { }; [Console]::Out.WriteLine('done ' + $id); [Console]::Out.Flush() }";
let win = null, winBad = false;
function getWin() {
    if (win) return win;
    if (winBad || inBrowser() || !rt.sys || !rt.sys.spawnPipe || rt.sys.os() !== 'windows' || (rt.sys.env && rt.sys.env('SUAVE_SLOW_SOUND'))) return null;
    let proc;
    try { proc = rt.sys.spawnPipe('powershell', ['-NoProfile', '-NonInteractive', '-Command', WIN_SCRIPT]); } catch (e) { winBad = true; return null; }
    const w = win = { proc, ready: false, busy: null, next: 1 };
    const die = () => { if (win === w) win = null; if (!w.ready) winBad = true; const b = w.busy; w.busy = null; if (b) b(false); };
    proc.unref();
    (async () => {
        const reader = proc.stdout.getReader(); const dec = new TextDecoder(); let buf = '';
        try {
            for (;;) {
                const { value, done } = await reader.read();
                if (done) break;
                buf += dec.decode(value, { stream: true });
                let i; while ((i = buf.indexOf('\n')) >= 0) {
                    const t = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
                    if (t === 'ready') w.ready = true; else if (/^done \d+$/.test(t)) { const b = w.busy; w.busy = null; proc.unref(); if (b) b(true); }
                }
            }
        } catch (e) { /* gone */ }
        die();
    })();
    proc.status.then(die, die);
    return w;
}
function playViaWindows(st, vol, holder) {
    const w = getWin();
    if (!w || w.busy) return null;
    const s = rt.sys, file = sharedTemp() + '/sound-' + (tmpSeq++) + '.wav';
    s.writeBytes(file, wavFromState(vol === 1 ? st : applyMods(st, null, vol)));
    const id = w.next++;
    const handle = { stop: () => { handle.stopped = true; if (win === w) win = null; w.proc.kill(); const b = w.busy; w.busy = null; if (b) b(true); } };
    if (holder) holder.handle = handle;
    active.add(handle);
    const finish = new Promise((resolve) => { w.busy = resolve; });
    w.proc.ref();
    try { w.proc.write(new TextEncoder().encode(id + ' ' + file + '\n')).catch(() => {}); } catch (e) { w.busy = null; active.delete(handle); return null; }
    return finish.then((ok) => { active.delete(handle); try { s.remove(file); } catch (e) { /* ignore */ } return ok || handle.stopped ? null : false; });
}
function playState(st, vol, holder) {
    if (inBrowser()) return playBufferInBrowser(st, vol, holder);
    const darwin = rt.sys && rt.sys.os && rt.sys.os() === 'darwin';
    const old = () => playInTerminal(wavFromState(darwin || vol === 1 ? st : applyMods(st, null, vol)), 'wav', vol, holder);   // (only the Mac's player takes a volume; the others get a quieter sound instead)
    const fast = darwin ? playViaDaemon(st, vol, holder) : playViaWindows(st, vol, holder);
    // if the helper cannot play it, the old way does
    return fast ? fast.then((r) => (r === false ? old() : null)) : old();
}
const volumeOf = (o) => { const v = o.volume !== undefined ? o.volume : o.vol !== undefined ? o.vol : o.v; if (v === undefined) return 1; if (typeof v !== 'number' || v < 0 || v > 1) throw rtError('sound volume needs a number between 0 and 1 but got ' + show(v), 'ArgError'); return v; };

async function download(url, what) {
    if (typeof fetch === 'undefined') throw rtError('This computer cannot reach the web from here', 'NetworkError');
    let res;
    try { res = await fetch(url); } catch (e) { throw rtError('Could not reach ' + url + (e && e.message ? ' (' + e.message + ')' : ''), 'NetworkError'); }
    if (!res.ok) throw rtError(what + ' answered "' + res.status + ' ' + (res.statusText || 'error') + '" for ' + url, 'NetworkError');
    return new Uint8Array(await res.arrayBuffer());
}
// downloaded sound files are kept for the rest of the program, so playing one again is instant
const downloads = new Map();
async function cached(key, fn) {
    if (downloads.has(key)) return downloads.get(key);
    const v = await fn();
    downloads.set(key, v);
    if (downloads.size > 40) downloads.delete(downloads.keys().next().value);
    return v;
}
const b64 = (t) => { if (typeof atob === 'function') { const s = atob(t); const o = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) o[i] = s.charCodeAt(i); return o; } return Uint8Array.from(Buffer.from(t, 'base64')); };
async function mintBytes(spec) {
    const p = mintParts(spec);
    const base = mintServer.replace(/\/$/, '') + '/api/r/' + encodeURIComponent(p.owner) + '/' + encodeURIComponent(p.repo);
    const asJson = async (url) => { const b = await download(url, 'Mintcode'); try { return JSON.parse(new TextDecoder().decode(b)); } catch (e) { throw rtError('Mintcode sent something unexpected for ' + url, 'NetworkError'); } };
    const saves = await asJson(base + '/saves?line=' + encodeURIComponent(p.line) + '&trees=1&limit=1');
    const head = saves.saves && saves.saves[0];
    if (!head || !head.tree) throw rtError('Mintcode has no saves on the line "' + p.line + '" of ' + p.owner + '/' + p.repo, 'NetworkError');
    const hash = head.tree[p.path];
    if (!hash) throw rtError('Mintcode has no file "' + p.path + '" in ' + p.owner + '/' + p.repo + ' (line ' + p.line + ')', 'NetworkError');
    const blob = await asJson(base + '/blob/' + hash);
    return { bytes: blob.enc === 'b64' ? b64(blob.content) : new TextEncoder().encode(String(blob.content)), name: p.path };
}

// ---------- melodies:  "D F A C+"  ----------
// a note is a letter (C D E F G A B, either case), then # (sharp) or b (flat), then an octave number if it should not be the default one, then + or - to go up or down an octave;
// :2 after it is how many beats it lasts, r (or _) is a rest, and notes joined with / make a chord (C/E/G)
const SEMI = { c: 0, d: 2, e: 4, f: 5, g: 7, a: 9, b: 11 };
const NOTE = /^([A-Ga-g])([#b]?)(\d+)?([+-]*)$/;
function parseMelody(text, octave, what) {
    const toks = (Array.isArray(text) ? text.map(String).join(' ') : String(text === undefined || text === null ? '' : text)).split(/[\s|]+/).filter(Boolean);
    const events = []; let beat = 0;
    for (const tok of toks) {
        let body = tok, beats = 1;
        const dm = /:(\d*\.?\d+)$/.exec(tok);
        if (dm) { beats = Number(dm[1]); body = tok.slice(0, dm.index); }
        if (!(beats > 0) || beats > 64) throw rtError('sound.' + what + ': "' + tok + '" lasts ' + beats + ' beats, and a note can last from a little over 0 to 64 beats', 'ArgError');
        if (/^(r|_)$/i.test(body)) { events.push({ at: beat, beats, freqs: [] }); beat += beats; continue; }
        const freqs = body.split('/').map((part) => {
            const m = NOTE.exec(part);
            if (!m) throw rtError('sound.' + what + ' does not understand the note "' + tok + '". Write notes like C  D#  Bb  A4  C+ (one octave up)  G- (one down), a rest as r, lengths like C:2 (two beats) and chords like C/E/G', 'ArgError');
            const oct = m[3] === undefined ? octave : Number(m[3]);
            const shift = Array.from(m[4]).reduce((acc, c) => acc + (c === '+' ? 1 : -1), 0);
            const midi = 12 * (oct + shift + 1) + SEMI[m[1].toLowerCase()] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
            const f = 440 * Math.pow(2, (midi - 69) / 12);
            if (f < 8 || f > 20000) throw rtError('sound.' + what + ': the note "' + tok + '" is ' + Math.round(f) + ' Hz, which is too low or too high to make (8 to 20000 Hz)', 'ArgError');
            return f;
        });
        events.push({ at: beat, beats, freqs }); beat += beats;
    }
    if (!events.length) throw rtError('sound.' + what + ' needs some notes, like "D F A C+"', 'ArgError');
    return { events, beats: beat };
}
const MELODY_OWN = new Set(['octave', 'bpm', 'instrument', 'synth', 'kind', 'volume', 'vol', 'v', 'reverb', 'room', 'damp']);

export const soundModule = () => {
    try { getDaemon(); } catch (e) { /* the old way still works */ }   // start the helper now, so it is ready by the time the first sound plays
    const SoundT = nativeType('Sound', {
        // the same options as the play functions, one at a time:  sound.make("sine", 440, 1).adsr(0.02, 0.1, 0.6, 0.3).lowpass(800).eq(bass: 4).play()
        adsr: (me, a) => make(SoundT, applyMods(me.state, { adsr: parseAdsr(a.length === 1 ? a[0] : a.slice(0, 4)) })),
        volume: (me, a) => make(SoundT, applyMods(me.state, null, need(a[0], 'volume', 0, 4))),
        lowpass: (me, a) => make(SoundT, applyMods(me.state, { lowpass: need(a[0], 'lowpass (Hz)', 10, 20000), q: a[1] === undefined ? undefined : need(a[1], 'q', 0.1, 30) })),
        highpass: (me, a) => make(SoundT, applyMods(me.state, { highpass: need(a[0], 'highpass (Hz)', 10, 20000), q: a[1] === undefined ? undefined : need(a[1], 'q', 0.1, 30) })),
        bandpass: (me, a) => make(SoundT, applyMods(me.state, { bandpass: need(a[0], 'bandpass (Hz)', 10, 20000), q: a[1] === undefined ? undefined : need(a[1], 'q', 0.1, 30) })),
        eq: (me, a, n) => make(SoundT, applyMods(me.state, { eq: parseEq(n instanceof Object && !Array.isArray(n) && Object.keys(n).length ? map(n) : a[0]) })),
        fade_in: (me, a) => make(SoundT, applyMods(me.state, { fade_in: need(a[0], 'fade_in (seconds)', 0, 60) })),
        fade_out: (me, a) => make(SoundT, applyMods(me.state, { fade_out: need(a[0], 'fade_out (seconds)', 0, 60) })),
        reverb: (me, a, n) => { const o = n instanceof Object && !Array.isArray(n) ? n : {}; return make(SoundT, applyMods(me.state, modsFrom({ reverb: a[0] === undefined ? (o.reverb === undefined ? 0.3 : o.reverb) : a[0], room: a[1] === undefined ? o.room : a[1], damp: a[2] === undefined ? o.damp : a[2] }) || {})); },
        play: (me, a) => playState(me.state, a[0] === undefined ? 1 : need(a[0], 'volume', 0, 1)),
        start: (me, a) => startState(me.state, a[0] === undefined ? 1 : need(a[0], 'volume', 0, 1)),
        save: (me, a) => { const s = rt.needSys('sound save'); s.writeBytes(filePath(str(a[0], 'save')), wavFromState(me.state)); return null; },
        seconds: (me) => me.state.ch[0].length / me.state.rate, samples: (me) => Array.from(me.state.ch[0]), wav: (me) => wavFromState(me.state), channels: (me) => me.state.ch.length,
    }, { reprFn: (o) => '<Sound ' + (o.state.ch[0].length / o.state.rate).toFixed(2) + 's>' });
    // the numbers of any kind of sound, with the named options (adsr, filters, eq, fades...) applied
    const render = (kind, rest, what) => {
        const mods = modsFrom(split(rest)[1], kind === 'superchip');
        const st = stateOf(rawSamples(kind, rest, what));
        return mods ? applyMods(st, mods) : st;
    };
    const buildWave = (fn, what, rest) => {
        const { freq, secs, vol } = waveArgs(what, rest);
        const mods = modsFrom(split(rest)[1]);
        const st = stateOf(makeSamples(fn, freq, secs, vol));
        return mods ? applyMods(st, mods) : st;
    };
    const customWave = (f) => { const g = cb(f); return (p) => { const v = Number(g(p)); return Number.isFinite(v) ? v : 0; }; };
    const wave = (kind) => (...rest) => playState(render(kind, rest, kind), 1);
    // start() plays at once and hands back a Playing right away, so the program goes on while the sound plays
    const PlayingT = nativeType('Playing', {
        stop: (me) => { if (me.state.holder.handle) me.state.holder.handle.stop(); return null; },
        wait: (me) => me.state.promise,
        playing: (me) => !me.state.done,
    }, { reprFn: (o) => (o.state.done ? '<Playing finished>' : '<Playing>') });
    const startState = (st, vol) => {
        const holder = {}; const state = { holder, done: false, promise: null };
        state.promise = playState(st, vol, holder);
        state.promise.then(() => { state.done = true; }, () => { state.done = true; });
        return make(PlayingT, state);
    };
    // where a sound file comes from; wantBytes false lets a browser play an address directly
    const sources = {
        file: async (p, wantBytes) => {
            const name = str(p, 'sound.file');
            if (inBrowser()) { const url = pageUrl(name); return cached('page:' + url, async () => ({ bytes: await download(url, 'The page'), ext: extOf(name) })); }
            const full = filePath(name);
            const s = rt.needSys('sound.file');
            let bytes;
            try { bytes = s.readBytes(full); } catch (e) { throw rtError('I could not find the sound file ' + full, 'IOError'); }
            return { bytes, ext: extOf(name), path: full };
        },
        git: async (spec) => { const url = gitUrl(spec); return cached('git:' + url, async () => ({ bytes: await download(url, 'GitHub'), ext: extOf(url) })); },
        mint: async (spec) => cached('mint:' + String(spec), async () => { const r = await mintBytes(spec); return { bytes: r.bytes, ext: extOf(r.name) }; }),
    };
    // plays the bytes of a sound file with no changes. A page decodes it to numbers and plays them from memory; a Mac hands the file to the helper (any format);
    // other computers play .wav files from numbers, and everything else with the computer's own player
    const playFileBytes = async (got, v) => {
        if (inBrowser()) {
            let st = null;
            try { st = await decodeBytes(got.bytes, got.ext); } catch (e) { st = null; }   // (a kind of file the browser cannot read: the audio element may still manage)
            return st ? playState(st, v) : play(got.bytes, got.ext, v);
        }
        if (getDaemon()) {
            if (!got.path) { got.path = sharedTemp() + '/file-' + (tmpSeq++) + '.' + got.ext; rt.sys.writeBytes(got.path, got.bytes); }
            if ((await playFileViaDaemon(got.path, v, null)) !== false) return null;
        }
        let st = null;
        try { st = decodeWav(got.bytes); } catch (e) { st = null; }
        return st ? playState(st, v) : play(got.bytes, got.ext, v);
    };
    const fileLike = (kind) => async (spec, ...rest) => {
        const [, o] = split(rest);
        const v = volumeOf(o);
        const mods = modsFrom(o);
        const got = await sources[kind](spec, true);
        if (!mods) return playFileBytes(got, v);
        return playState(applyMods(await decodeBytes(got.bytes, got.ext), mods, v), 1);
    };
    const loadLike = (kind) => async (spec, ...rest) => {
        const [, o] = split(rest);
        const got = await sources[kind](spec, true);
        return make(SoundT, applyMods(await decodeBytes(got.bytes, got.ext), modsFrom(o), volumeOf(o)));
    };
    // a whole tune as one sound: every note is made with the options you give, then they are laid one after another (chords on top of each other); reverb goes over the whole tune
    const buildMelody = (text, rest, what) => {
        const [pos, o] = split(rest);
        const octave = need(o.octave !== undefined ? o.octave : pos[0] !== undefined ? pos[0] : 4, 'octave', -1, 9), bpm = need(o.bpm !== undefined ? o.bpm : 120, 'bpm (beats a minute)', 20, 600);
        const kind = String(o.instrument !== undefined ? o.instrument : o.synth !== undefined ? o.synth : o.kind !== undefined ? o.kind : 'sine');
        const vol = need(take(o, ['volume', 'vol', 'v'], 0.5), 'volume', 0, 1);
        const { events, beats } = parseMelody(text, Math.round(octave), what);
        const beatSecs = 60 / bpm, total = beats * beatSecs;
        if (total > MAX_SECONDS) throw rtError('sound.' + what + ' makes ' + total.toFixed(0) + ' seconds of sound, and the most is ' + MAX_SECONDS + ' (try a faster bpm or fewer notes)', 'ArgError');
        const mix = new Float32Array(Math.round(total * RATE) + 1);
        const noteOpts = {}; for (const k of Object.keys(o)) if (!MELODY_OWN.has(k)) noteOpts[k] = o[k];
        for (const ev of events) {
            if (!ev.freqs.length) continue;
            const secs = ev.beats * beatSecs, from = Math.round(ev.at * beatSecs * RATE), each = vol / Math.sqrt(ev.freqs.length);
            for (const f of ev.freqs) {
                const x = render(kind, [f, secs, each, new Named(Object.assign({}, noteOpts))], what).ch[0];
                for (let i = 0; i < x.length && from + i < mix.length; i++) mix[from + i] += x[i];
            }
        }
        const st = { rate: RATE, ch: [mix] };
        const roomOpts = {}; for (const k of ['reverb', 'room', 'damp']) if (o[k] !== undefined) roomOpts[k] = o[k];
        const rv = modsFrom(roomOpts);
        return rv ? applyMods(st, rv) : st;
    };
    return {
        // ----- melodies: melody("D F A C+", octave=4, bpm=120, instrument="superchip", reverb=0.3) plays them, make_melody(...) gives a Sound, note("A4") is the pitch in Hz -----
        melody: (text, ...rest) => playState(buildMelody(text, rest, 'melody'), 1),
        make_melody: (text, ...rest) => make(SoundT, buildMelody(text, rest, 'make_melody')),
        note: (name, ...rest) => { const [pos, o] = split(rest); return parseMelody(name, Math.round(need(o.octave !== undefined ? o.octave : pos[0] !== undefined ? pos[0] : 4, 'octave', -1, 9)), 'note').events[0].freqs[0]; },
        // ----- waves you make from numbers: (pitch in Hz, seconds, volume 0 to 1) -----
        sine: wave('sine'), square: wave('square'), triangle: wave('triangle'), mole: wave('mole'),
        // noise(seconds, volume, color: "white" | "pink" | "brown");  chipnoise(rate, seconds, volume, type: "retro" | "buzz" | "white" | "bit" | "crackle")   (seed=1 makes the same noise every time)
        noise: wave('noise'), white: wave('noise'), chipnoise: wave('chipnoise'),
        // harmonics(220, 1, h=[1, 0.5, 0.33]): sines at 1x, 2x, 3x... the pitch;  fm(220, 1, algorithm=5, ratios=[1, 2, 3, 1], levels=[15, 9, 4, 0], feedback=3);  superchip(440, 1)
        harmonics: wave('harmonics'), fm: wave('fm'), superchip: wave('superchip'),
        // ready-made instruments (pitch in Hz, seconds, volume): high_superchip flute electric_piano (or epiano) scoot tweet high_scoot;  instruments() lists them
        high_superchip: wave('high_superchip'), flute: wave('flute'), electric_piano: wave('electric_piano'), epiano: wave('electric_piano'), scoot: wave('scoot'), tweet: wave('tweet'), high_scoot: wave('high_scoot'),
        instruments: () => INSTRUMENTS.slice(),
        // start("sine", 440, 5)  or  start(a_sound): starts playing right now and gives back a Playing (stop(), wait(), playing()) instead of waiting for the end
        start: (what, ...rest) => {
            const vol = 1;
            if (what instanceof Object && what.state && Array.isArray(what.state.ch)) return startState(what.state, rest.length && !(rest[0] instanceof Named) ? need(rest[0], 'volume', 0, 1) : vol);
            if (typeof what === 'string') return startState(render(what, rest, what), 1);
            return startState(buildWave(customWave(what), 'start', rest), 1);
        },
        // wave(|x| ..., 440, 1): your own wave. The function gets how far through one cycle it is (0 to 1) and gives back a level from -1 to 1
        wave: (f, ...rest) => play(wavFromState(buildWave(customWave(f), 'wave', rest)), 'wav', 1),
        // ----- sound files -----
        file: fileLike('file'), git: fileLike('git'), mint: fileLike('mint'),
        // ----- sounds you can change before playing:  make("sine", 440, 1)  or  await load("./click.wav")  (also load_git, load_mint) -----
        make: (kind, ...rest) => {
            if (typeof kind === 'string') return make(SoundT, render(kind, rest, 'make'));
            return make(SoundT, buildWave(customWave(kind), 'make', rest));
        },
        load: loadLike('file'), load_git: loadLike('git'), load_mint: loadLike('mint'),
        // stop() ends every sound that is playing
        stop: () => { for (const h of Array.from(active)) h.stop(); return null; },
        // mint_server("https://my-mintcode.example.com") if you run your own Mintcode
        mint_server: (url) => { if (url === undefined) return mintServer; mintServer = str(url, 'sound.mint_server').replace(/\/$/, ''); return mintServer; },
        // ----- for looking at sounds instead of hearing them -----
        // samples("sine", 440, 0.01) gives the numbers of a wave;  wav("square", 220, 1) gives the bytes of a .wav file you can save with std.fs  (both take the same named options)
        samples: (kind, ...rest) => Array.from(render(String(kind), rest, 'samples').ch[0]),
        wav: (kind, ...rest) => wavFromState(render(String(kind), rest, 'wav')),
        git_url: (spec) => gitUrl(spec),
        file_path: (p) => (inBrowser() ? pageUrl(str(p, 'sound.file_path')) : filePath(p)),
        waves: () => KINDS(),
    };
};
void SMap; void typeOf; void toArray; void ok;
