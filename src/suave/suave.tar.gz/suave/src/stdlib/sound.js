/* std.sound: play sounds.  Wave sounds you make from numbers (sine, square, triangle, mole) and sound files from GitHub, Mintcode or your own folders.
     use std.sound
     await sound.sine(440, 0.5)                       a 440 Hz note for half a second
     sound.file("./click.wav")                         a file beside this program (./ ../ and plain names all work)
     sound.git("user/repo/sounds/ding.wav")            a file from GitHub          sound.mint("user/repo/ding.wav")   a file from Mintcode
   Every play function starts right away and gives back a future that finishes when the sound ends, so  await  waits for it and leaving it off plays in the background.
   Everything is turned into sound-file bytes first, then played the same way: a browser page uses an audio element, the terminal uses the computer's own player. */
import { rt, SMap, Named, cb, map, rtError, show, typeOf, str, toArray, ok } from './_util.js';

const RATE = 44100;
const MAX_SECONDS = 120;
const TAU = Math.PI * 2;
const MOLE_MEAN = 2 / Math.PI;   // the average of |sin|, taken away so the speaker does not get a click

// ---------- the waves: a function from "how far through one cycle" (0 to 1) to a level (-1 to 1) ----------
const WAVES = {
    sine: (p) => Math.sin(TAU * p),
    square: (p) => (p < 0.5 ? 1 : -1),
    triangle: (p) => (p < 0.25 ? 4 * p : p < 0.75 ? 2 - 4 * p : 4 * p - 4),
    // mole is |sin(x)|, a row of humps (so it sounds an octave up); its average is taken out so it sits around zero like the others (and scaled so it never goes past -1)
    mole: (p) => (Math.abs(Math.sin(TAU * p)) - MOLE_MEAN) / MOLE_MEAN,
};

// positional values with named ones allowed: sine(440, 1, 0.5)  or  sine(freq: 440, seconds: 1, volume: 0.5)
function split(rest) { const n = rest.length && rest[rest.length - 1] instanceof Named ? rest[rest.length - 1].obj : {}; return [n && rest[rest.length - 1] instanceof Named ? rest.slice(0, -1) : rest, n]; }
function waveArgs(what, rest) {
    const [pos, o] = split(rest);
    const pick = (i, names, dflt) => { for (const k of names) if (o[k] !== undefined) return o[k]; return pos[i] !== undefined ? pos[i] : dflt; };
    const freq = pick(0, ['freq', 'frequency', 'hz'], 440), secs = pick(1, ['seconds', 'secs', 'time', 'length'], 0.5), vol = pick(2, ['volume', 'vol'], 0.5);
    if (typeof freq !== 'number' || !(freq > 0) || freq > 20000) throw rtError('sound.' + what + ' needs a pitch between 1 and 20000 Hz (like 440) but got ' + show(freq), 'ArgError');
    if (typeof secs !== 'number' || !(secs > 0) || secs > MAX_SECONDS) throw rtError('sound.' + what + ' needs a length in seconds between 0 and ' + MAX_SECONDS + ' but got ' + show(secs), 'ArgError');
    if (typeof vol !== 'number' || vol < 0 || vol > 1) throw rtError('sound.' + what + ' needs a volume between 0 and 1 but got ' + show(vol), 'ArgError');
    return { freq, secs, vol };
}
export function makeSamples(fn, freq, secs, vol) {
    const n = Math.max(1, Math.round(secs * RATE));
    const out = new Float32Array(n);
    const ramp = Math.min(Math.round(RATE * 0.005), Math.floor(n / 2));   // 5 ms fade in and out
    for (let i = 0; i < n; i++) {
        let phase = (i * freq / RATE) % 1;
        let v = fn(phase) * vol;
        if (i < ramp) v *= i / ramp; else if (i >= n - ramp) v *= (n - 1 - i) / ramp;
        out[i] = v;
    }
    return out;
}
// 16-bit mono WAV file bytes
export function wavBytes(samples) {
    const n = samples.length, buf = new ArrayBuffer(44 + n * 2), dv = new DataView(buf);
    const w = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); dv.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
    dv.setUint32(24, RATE, true); dv.setUint32(28, RATE * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true); w(36, 'data'); dv.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) dv.setInt16(44 + i * 2, Math.round(Math.max(-1, Math.min(1, samples[i])) * 32767), true);
    return new Uint8Array(buf);
}

// ---------- where sounds come from ----------
const SEG = /^[^\\?#]+$/;      // folder and file names may have spaces
const NAME = /^[A-Za-z0-9_.@-]+$/;   // owners and repos may not
function splitSpec(spec, what) {
    // "owner/repo/path/to/file.wav"  or  "owner/repo@branch/path/to/file.wav"
    const s = String(spec === undefined || spec === null ? '' : spec).trim().replace(/^\/+/, '');
    const parts = s.split('/');
    if (parts.length < 3 || !NAME.test(parts[0]) || !NAME.test(parts[1]) || !parts.every((p) => p && SEG.test(p)) || parts.some((p) => p === '..')) throw rtError('sound.' + what + ' wants "owner/repo/path/to/sound.wav" (add @branch after the repo name to pick a branch) but got ' + JSON.stringify(s), 'ArgError');
    const m = /^([^@]+)@(.+)$/.exec(parts[1]);
    return { owner: parts[0], repo: m ? m[1] : parts[1], ref: m ? m[2] : null, path: parts.slice(2).join('/') };
}
export function gitUrl(spec) {
    const raw = String(spec || '').trim();
    // links people copy from their browser also work
    let m = /^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/(?:blob|raw)\/([^/]+)\/(.+)$/.exec(raw);
    if (m) return 'https://raw.githubusercontent.com/' + m[1] + '/' + m[2] + '/' + m[3] + '/' + m[4];
    if (/^https:\/\/(raw\.githubusercontent\.com|media\.githubusercontent\.com)\//.test(raw)) return raw;
    const p = splitSpec(raw, 'git');
    return 'https://raw.githubusercontent.com/' + p.owner + '/' + p.repo + '/' + (p.ref || 'HEAD') + '/' + p.path.split('/').map(encodeURIComponent).join('/');
}
let mintServer = 'https://mintcode.radii-office.com';
export function mintParts(spec) { const p = splitSpec(String(spec || '').replace(/^https?:\/\/[^/]+\//, ''), 'mint'); return { ...p, line: p.ref || 'main' }; }

// a path for sound.file: absolute stays, everything else is looked up beside the program that asked for it
const dirOf = (p) => { const i = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')); return i < 0 ? '' : p.slice(0, i); };
function joinPath(base, rel) {
    const out = base.split('/');
    for (const seg of rel.split('/')) { if (seg === '.' || seg === '') continue; if (seg === '..') { if (out.length > 1 || (out.length === 1 && out[0] !== '')) out.pop(); } else out.push(seg); }
    return out.join('/') || '/';
}
export function filePath(p) {
    p = str(p, 'sound.file');
    if (/^~\//.test(p) && rt.sys) return rt.sys.home ? rt.sys.home() + p.slice(1) : p;
    if (/^(\/|[A-Za-z]:[\\/])/.test(p)) return p;
    const here = rt.state && rt.state.file ? String(rt.state.file) : '';
    let base = here && !/^</.test(here) ? dirOf(here.replace(/\\/g, '/')) : '';
    if (!base || !/^(\/|[A-Za-z]:[\\/])/.test(base)) { const cwd = rt.sys ? rt.sys.cwd().replace(/\\/g, '/') : ''; base = base ? joinPath(cwd, base) : cwd; }
    return joinPath(base, p.replace(/\\/g, '/'));
}
const inBrowser = () => typeof document !== 'undefined' && typeof Audio !== 'undefined';
function pageUrl(p) {
    // in a page: look beside the Suave file when it came from a file, otherwise beside the page
    const here = rt.state && rt.state.file ? String(rt.state.file) : '';
    let base = location.href;
    if (here && !/^</.test(here)) { try { base = new URL(here, location.href).href; } catch (e) { /* the page */ } }
    return new URL(p, base).href;
}
const MIMES = { wav: 'audio/wav', mp3: 'audio/mpeg', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', webm: 'audio/webm' };
const extOf = (p) => ((/\.([A-Za-z0-9]+)(?:[?#].*)?$/.exec(p) || [])[1] || 'wav').toLowerCase();

// ---------- playing bytes ----------
const active = new Set();   // things that can be stopped: { stop() }
function playInBrowser(bytes, ext, vol) {
    return new Promise((resolve, reject) => {
        // bytes is sound-file bytes, or a web address the audio element loads by itself
        const own = typeof bytes !== 'string';
        const url = own ? URL.createObjectURL(new Blob([bytes], { type: MIMES[ext] || 'audio/wav' })) : bytes;
        const free = () => { if (own) URL.revokeObjectURL(url); };
        const a = new Audio(url); a.volume = vol;
        const handle = { stop: () => { try { a.pause(); } catch (e) { /* ignore */ } done(); } };
        const done = () => { active.delete(handle); free(); resolve(null); };
        active.add(handle);
        a.onended = done;
        a.onerror = () => { active.delete(handle); free(); reject(rtError('The browser could not play this sound (is it a .wav, .mp3 or .ogg file?)', 'SoundError')); };
        const p = a.play();
        if (p && p.catch) p.catch((e) => { active.delete(handle); free(); reject(rtError(e && e.name === 'NotAllowedError' ? 'The browser only plays sound after the visitor has clicked or typed on the page. Call sound from a button or key press' : 'The browser could not play this sound: ' + (e && e.message), 'SoundError')); });
    });
}
async function playInTerminal(bytes, ext, vol) {
    const s = rt.needSys('sound');
    const dir = s.tempDir();
    const file = dir + '/sound.' + ext;
    s.writeBytes(file, bytes);
    const os = s.os();
    const v = String(Math.max(0, Math.min(1, vol)));
    const tries = os === 'darwin' ? [['afplay', ['-v', v, file]]]
        : os === 'windows' ? [['powershell', ['-NoProfile', '-Command', '(New-Object Media.SoundPlayer "' + file + '").PlaySync()']]]
        : [['paplay', [file]], ['aplay', ['-q', file]], ['ffplay', ['-nodisp', '-autoexit', '-loglevel', 'quiet', file]], ['mpg123', ['-q', file]], ['play', ['-q', file]]];
    const handle = { stop: () => { handle.stopped = true; if (handle.child) { try { handle.child.kill(); } catch (e) { /* ignore */ } } } };
    active.add(handle);
    try {
        let lastErr = null;
        for (const [cmd, args] of tries) {
            if (handle.stopped) return null;
            try {
                const r = await s.run(cmd, args, { onChild: (c) => { handle.child = c; } });
                if (handle.stopped) return null;
                if (r.code === 0) return null;
                lastErr = r.stderr || ('exit code ' + r.code);
            } catch (e) { lastErr = e && e.message; }
        }
        throw rtError('I could not find a way to play sound here (' + (os === 'darwin' ? 'afplay' : os === 'windows' ? 'PowerShell' : 'paplay, aplay, ffplay, mpg123 or play') + ' did not work' + (lastErr ? ': ' + String(lastErr).trim().slice(0, 120) : '') + ')', 'SoundError');
    } finally { active.delete(handle); try { s.remove(dir, true); } catch (e) { /* ignore */ } }
}
const play = (bytes, ext, vol) => (inBrowser() ? playInBrowser(bytes, ext, vol) : playInTerminal(bytes, ext, vol));
const volumeOf = (o) => { const v = o.volume !== undefined ? o.volume : o.vol; if (v === undefined) return 1; if (typeof v !== 'number' || v < 0 || v > 1) throw rtError('sound volume needs a number between 0 and 1 but got ' + show(v), 'ArgError'); return v; };

async function download(url, what) {
    if (typeof fetch === 'undefined') throw rtError('This computer cannot reach the web from here', 'NetworkError');
    let res;
    try { res = await fetch(url); } catch (e) { throw rtError('Could not reach ' + url + (e && e.message ? ' (' + e.message + ')' : ''), 'NetworkError'); }
    if (!res.ok) throw rtError(what + ' answered "' + res.status + ' ' + (res.statusText || 'error') + '" for ' + url, 'NetworkError');
    return new Uint8Array(await res.arrayBuffer());
}
const b64 = (t) => { if (typeof atob === 'function') { const s = atob(t); const o = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) o[i] = s.charCodeAt(i); return o; } return Uint8Array.from(Buffer.from(t, 'base64')); };
async function mintBytes(spec) {
    const p = mintParts(spec);
    const base = mintServer.replace(/\/$/, '') + '/api/r/' + encodeURIComponent(p.owner) + '/' + encodeURIComponent(p.repo);
    const asJson = async (url) => { const b = await download(url, 'Mintcode'); try { return JSON.parse(new TextDecoder().decode(b)); } catch (e) { throw rtError('Mintcode sent something unexpected for ' + url, 'NetworkError'); } };
    const saves = await asJson(base + '/saves?line=' + encodeURIComponent(p.line) + '&trees=1&limit=1');
    const head = saves.saves && saves.saves[0];
    if (!head || !head.tree) throw rtError('Mintcode has no saves on the line "' + p.line + '" of ' + p.owner + '/' + p.repo, 'NetworkError');
    const hash = head.tree[p.path];
    if (!hash) throw rtError('Mintcode has no file "' + p.path + '" in ' + p.owner + '/' + p.repo + ' (line ' + p.line + ')', 'NetworkError');
    const blob = await asJson(base + '/blob/' + hash);
    return { bytes: blob.enc === 'b64' ? b64(blob.content) : new TextEncoder().encode(String(blob.content)), name: p.path };
}

export const soundModule = () => {
    const wave = (kind) => (...rest) => {
        const { freq, secs, vol } = waveArgs(kind, rest);
        return play(wavBytes(makeSamples(WAVES[kind], freq, secs, vol)), 'wav', 1);
    };
    const fileLike = (what, get) => async (spec, ...rest) => {
        const [, o] = split(rest);
        const v = volumeOf(o);
        const got = await get(spec);
        return play(got.bytes, got.ext, v);
    };
    return {
        // ----- waves you make from numbers: (pitch in Hz, seconds, volume 0 to 1) -----
        sine: wave('sine'), square: wave('square'), triangle: wave('triangle'), mole: wave('mole'),
        // wave(|x| ..., 440, 1): your own wave. The function gets how far through one cycle it is (0 to 1) and gives back a level from -1 to 1
        wave: (f, ...rest) => {
            const g = cb(f);
            const { freq, secs, vol } = waveArgs('wave', rest);
            return play(wavBytes(makeSamples((p) => { const v = Number(g(p)); return Number.isFinite(v) ? v : 0; }, freq, secs, vol)), 'wav', 1);
        },
        // ----- sound files -----
        file: fileLike('file', async (p) => {
            const name = str(p, 'sound.file');
            if (inBrowser()) {
                // the audio element loads the address itself, so a page opened from disk works too
                return { bytes: pageUrl(name), ext: extOf(name) };
            }
            const full = filePath(name);
            const s = rt.needSys('sound.file');
            let bytes;
            try { bytes = s.readBytes(full); } catch (e) { throw rtError('I could not find the sound file ' + full, 'IOError'); }
            return { bytes, ext: extOf(name) };
        }),
        git: fileLike('git', async (spec) => { const url = gitUrl(spec); return { bytes: await download(url, 'GitHub'), ext: extOf(url) }; }),
        mint: fileLike('mint', async (spec) => { const r = await mintBytes(spec); return { bytes: r.bytes, ext: extOf(r.name) }; }),
        // stop() ends every sound that is playing
        stop: () => { for (const h of Array.from(active)) h.stop(); return null; },
        // mint_server("https://my-mintcode.example.com") if you run your own Mintcode
        mint_server: (url) => { if (url === undefined) return mintServer; mintServer = str(url, 'sound.mint_server').replace(/\/$/, ''); return mintServer; },
        // ----- for looking at sounds instead of hearing them -----
        // samples("sine", 440, 0.01) gives the numbers of a wave;  wav("square", 220, 1) gives the bytes of a .wav file you can save with std.fs
        samples: (kind, ...rest) => { if (!WAVES[kind]) throw rtError('sound.samples knows sine, square, triangle and mole, not ' + show(kind), 'ArgError'); const { freq, secs, vol } = waveArgs('samples', rest); return Array.from(makeSamples(WAVES[kind], freq, secs, vol)); },
        wav: (kind, ...rest) => { if (!WAVES[kind]) throw rtError('sound.wav knows sine, square, triangle and mole, not ' + show(kind), 'ArgError'); const { freq, secs, vol } = waveArgs('wav', rest); return wavBytes(makeSamples(WAVES[kind], freq, secs, vol)); },
        git_url: (spec) => gitUrl(spec),
        file_path: (p) => (inBrowser() ? pageUrl(str(p, 'sound.file_path')) : filePath(p)),
        waves: () => Object.keys(WAVES),
    };
};
void SMap; void map; void typeOf; void toArray; void ok;
