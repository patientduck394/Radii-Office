/* Helpers the standard library modules share. */
import rt from '../runtime.js';
import { call } from '../interp.js';

export const { SMap, SSet, SObj, SType, SVariant, Tuple, tuple, SRange, SIter, Named, ok, err, rtError, show, repr, eq, truthy, typeOf, toArray, iterate, fromJS, toJS, keyOf, SPool, SComplex, SuaveError } = rt;
import { makePartial } from '../interp.js';
export { call, rt, makePartial };

// options may arrive as named arguments (indent: 2) or as a map
export function opts(o) {
    if (o instanceof Named) return o.obj;
    if (o && typeof o === 'object' && Object.getPrototypeOf(o) === Object.prototype) return o;   // named arguments given to a native method
    if (o instanceof SMap) { const r = {}; for (const [k, v] of o.entries()) r[String(k)] = v; return r; }
    return {};
}
// take the options off the end of a rest-args array
export function takeOpts(args) { return args.length && (args[args.length - 1] instanceof Named) ? args.pop().obj : {}; }
export function str(x, what) { if (typeof x !== 'string') throw rtError((what || 'This') + ' needs text but got ' + typeOf(x), 'TypeError'); return x; }
export function num(x, what) { if (typeof x !== 'number') throw rtError((what || 'This') + ' needs a number but got ' + typeOf(x), 'TypeError'); return x; }
export function list(x, what) { if (!Array.isArray(x)) { if (x instanceof SRange || x instanceof SSet || x instanceof SIter) return toArray(x); throw rtError((what || 'This') + ' needs a list but got ' + typeOf(x), 'TypeError'); } return x; }
export function nums(x, what) { const a = list(x, what); for (const v of a) if (typeof v !== 'number') throw rtError((what || 'This') + ' needs a list of numbers but found ' + repr(v), 'TypeError'); return a; }
export const cb = (f) => { if (typeof f === 'function') return f; if (f === undefined || f === null) throw rtError('A function was expected here', 'ArgError'); return (...a) => call(f, a); };
export const map = (obj) => { const m = new SMap(); for (const k of Object.keys(obj)) m.set(k, obj[k]); return m; };
export const bytesOf = (x) => (typeof x === 'string' ? new TextEncoder().encode(x) : x instanceof Uint8Array ? x : Array.isArray(x) ? Uint8Array.from(x) : (() => { throw rtError('This needs text or bytes but got ' + typeOf(x), 'TypeError'); })());

// a native type: an object type with JS methods. methods: { name(self, args, named) }
export function nativeType(name, methods, extra) {
    const T = new SType(name, 'struct');
    for (const k of Object.keys(methods)) T.methods.set(k, methods[k]);
    if (extra) Object.assign(T, extra);
    return T;
}
export function make(T, state) { const o = new SObj(T, Object.create(null)); o.state = state; return o; }

// deliver a callback result later, without blocking the program
export function later(f) { return setTimeout(() => { try { f(); } catch (e) { reportLate(e); } }, 0); }
export function reportLate(e) {
    if (rt.lateError) { rt.lateError(e); return; }
    rt.ewrite((e && e.message ? e.kind + ': ' + e.message : String(e)) + '\n');
}
export const guard = (f) => (...a) => { try { return f(...a); } catch (e) { reportLate(e); return null; } };
