/* The web: std.http (requests, a server, a router), std.dom (pages, plus a tiny app framework), std.canvas (drawing). */
import { rt, SMap, SSet, SObj, Tuple, tuple, SRange, SIter, Named, opts, num, nums, list, cb, call, map, nativeType, make, guard, reportLate, rtError, show, repr, eq, truthy, typeOf, ok, err, toArray, iterate, keyOf, str, bytesOf } from './_util.js';
import { regex } from '../methods.js';

const A = (x) => toArray(x);
const MIME = { html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8', css: 'text/css; charset=utf-8', js: 'text/javascript; charset=utf-8', mjs: 'text/javascript; charset=utf-8', json: 'application/json; charset=utf-8', txt: 'text/plain; charset=utf-8', md: 'text/markdown; charset=utf-8', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', ico: 'image/x-icon', wasm: 'application/wasm', xml: 'application/xml', pdf: 'application/pdf', mp3: 'audio/mpeg', mp4: 'video/mp4', woff2: 'font/woff2', sv: 'text/plain; charset=utf-8', csv: 'text/csv; charset=utf-8' };
const mimeOf = (p) => MIME[((/\.([A-Za-z0-9]+)$/.exec(p) || [])[1] || '').toLowerCase()] || 'application/octet-stream';

// ---------- std.http ----------
function headersToMap(h) { const m = new SMap(); h.forEach((v, k) => m.set(k, v)); return m; }
function respMap(res, body, url) { return map({ status: res.status, ok: res.ok, status_text: res.statusText, headers: headersToMap(res.headers), body, url: url || res.url }); }
function fetchWith(method, url, body, o, done) {
    const op = opts(o);
    const headers = {};
    if (op.headers instanceof SMap) for (const [k, v] of op.headers.entries()) headers[show(k)] = show(v);
    let payload;
    if (body !== undefined && body !== null) {
        if (typeof body === 'string' || body instanceof Uint8Array) payload = body;
        else { payload = JSON.stringify(rt.toJS(body)); if (!Object.keys(headers).some((h) => h.toLowerCase() === 'content-type')) headers['Content-Type'] = 'application/json'; }
    }
    if (op.bearer) headers.Authorization = 'Bearer ' + op.bearer;
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), (op.timeout || 30) * 1000);
    fetch(str(url, 'http'), { method, headers, body: payload, signal: ctl.signal, redirect: op.follow === false ? 'manual' : 'follow' })
        .then((res) => res.text().then((text) => { clearTimeout(timer); done(ok(respMap(res, text, url))); }))
        .catch((e) => { clearTimeout(timer); done(err(e && e.name === 'AbortError' ? 'The request took too long (timeout)' : 'The request failed: ' + (e && e.message ? e.message : e))); });
}
const respond = (v) => {
    // what a handler may give back: text, a map {status, headers, body}, or any data (sent as JSON)
    const H = { headers: {}, status: 200, body: '' };
    if (typeof v === 'string') { H.body = v; H.headers['content-type'] = /^\s*</.test(v) ? MIME.html : MIME.txt; }
    else if (v === null || v === undefined) { H.status = 204; }
    else if (v instanceof Uint8Array) { H.body = v; H.headers['content-type'] = 'application/octet-stream'; }
    else if (v instanceof SMap && (v.has('body') || v.has('status') || v.has('redirect') || v.has('file'))) {
        H.status = v.get('status') || (v.has('redirect') ? 302 : 200);
        const hs = v.get('headers'); if (hs instanceof SMap) for (const [k, x] of hs.entries()) H.headers[String(k).toLowerCase()] = show(x);
        if (v.has('redirect')) H.headers.location = v.get('redirect');
        if (v.has('file')) { try { H.body = rt.sys.readBytes(v.get('file')); H.headers['content-type'] = H.headers['content-type'] || mimeOf(v.get('file')); } catch (e) { H.status = 404; H.body = 'Not found'; } }
        else { const b = v.get('body'); if (typeof b === 'string' || b instanceof Uint8Array) { H.body = b; if (!H.headers['content-type']) H.headers['content-type'] = typeof b === 'string' && /^\s*</.test(b) ? MIME.html : MIME.txt; } else if (b !== undefined && b !== null) { H.body = JSON.stringify(rt.toJS(b)); H.headers['content-type'] = MIME.json; } }
    } else { H.body = JSON.stringify(rt.toJS(v)); H.headers['content-type'] = MIME.json; }
    return H;
};
function requestMap(req, body, url) {
    const u = new URL(req.url);
    const query = new SMap(); for (const [k, v] of u.searchParams) { const cur = query.get(k); if (cur === undefined) query.set(k, v); else if (Array.isArray(cur)) cur.push(v); else query.set(k, [cur, v]); }
    let json = null;
    if (/json/i.test(req.headers.get('content-type') || '') && body) { try { json = rt.fromJS(JSON.parse(body)); } catch (e) { json = null; } }
    return map({ method: req.method, path: decodeURIComponent(u.pathname), url: req.url, query, headers: headersToMap(req.headers), body, json, params: new SMap(), ip: null });
}
function routeToRe(path) { const names = []; const re = '^' + path.replace(/[.+^$()|\\]/g, '\\$&').replace(/:(\w+)/g, (m, n) => { names.push(n); return '([^/]+)'; }).replace(/\*/g, '(.*)') + '/?$'; return { re: new RegExp(re), names }; }
export const httpModule = () => {
    const AppT = nativeType('App', {
        get: (s, a) => add(s, 'GET', a), post: (s, a) => add(s, 'POST', a), put: (s, a) => add(s, 'PUT', a), delete: (s, a) => add(s, 'DELETE', a), patch: (s, a) => add(s, 'PATCH', a), any: (s, a) => add(s, '*', a),
        use: (s, a) => { s.state.middleware.push(a[0]); return s; },
        // static("/files", "./public") serves a folder
        static: (s, a) => { s.state.statics.push({ prefix: a[0].replace(/\/$/, ''), dir: a[1] }); return s; },
        not_found: (s, a) => { s.state.notFound = a[0]; return s; },
        listen: (s, a, n) => serve(s.state, a[0], a[1], n), handle: (s, a) => dispatch(s.state, a[0]),
    }, { reprFn: (o) => '<App ' + o.state.routes.length + ' routes>' });
    function add(s, method, a) { const { re, names } = routeToRe(a[0]); s.state.routes.push({ method, re, names, f: a[1] }); return s; }
    function dispatch(app, req) {
        const path = req.get('path'), method = req.get('method');
        for (const m of app.middleware) { const r = call(m, [req]); if (r !== null && r !== undefined) return r; }
        for (const st of app.statics) {
            if (path === st.prefix || path.startsWith(st.prefix + '/')) {
                let rel = path.slice(st.prefix.length).replace(/^\/+/, '');
                if (rel.split('/').includes('..')) return map({ status: 403, body: 'Forbidden' });
                let p = st.dir.replace(/\/$/, '') + '/' + rel;
                const stt = rt.sys.stat(p);
                if (stt && stt.isDir) p = p.replace(/\/$/, '') + '/index.html';
                if (rt.sys.stat(p)) return map({ file: p });
            }
        }
        for (const r of app.routes) {
            if (r.method !== '*' && r.method !== method && !(r.method === 'GET' && method === 'HEAD')) continue;
            const m = r.re.exec(path);
            if (!m) continue;
            const params = req.get('params');
            r.names.forEach((n, i) => params.set(n, decodeURIComponent(m[i + 1])));
            return call(r.f, [req]);
        }
        if (app.notFound) return call(app.notFound, [req]);
        return map({ status: 404, body: 'Not found: ' + method + ' ' + path });
    }
    function serve(app, port, ready, named) {
        const s = rt.needSys('http.listen');
        const p = port === undefined || port === null ? 8000 : port;
        s.listen(p, async (request) => {
            let body = '';
            try { if (!['GET', 'HEAD'].includes(request.method)) body = await request.text(); } catch (e) { /* no body */ }
            let out;
            try { out = respond(dispatch(app, requestMap(request, body))); }
            catch (e) { if (rt.sys && e && e.message !== undefined) { rt.ewrite((e.kind || 'Error') + ': ' + e.message + '\n'); } out = { status: 500, headers: { 'content-type': MIME.txt }, body: 'Internal error: ' + (e && e.message ? e.message : e) }; }
            return new Response(request.method === 'HEAD' ? null : out.body, { status: out.status, headers: out.headers });
        });
        if (ready !== undefined && ready !== null && !(ready instanceof Named)) guard(cb(ready))(); else rt.write('Listening on http://localhost:' + p + '\n');
        return null;
    }
    const mkApp = () => make(AppT, { routes: [], middleware: [], statics: [], notFound: null });
    const req = (method) => (url, ...rest) => {
        const f = rest.filter((x) => !(x instanceof Named)).pop();
        const named = rest.find((x) => x instanceof Named);
        const hasBody = method !== 'GET' && method !== 'DELETE' && method !== 'HEAD';
        const body = hasBody ? rest[0] : undefined;
        const callback = hasBody ? rest[1] : rest[0];
        void f;
        if (callback === undefined || callback instanceof Named) throw rtError('http.' + method.toLowerCase() + ' needs a function at the end that receives the result, like |res| ...', 'ArgError');
        const g = guard(cb(callback));
        fetchWith(method, url, body, named, g);
        return null;
    };
    return {
        // fetch(url) is the awaitable way: let res = await http.fetch("https://..."); a failed request throws
        fetch: (url, ...rest) => new Promise((resolve, reject) => { const named = rest.find((x) => x instanceof Named); const body = rest.find((x) => !(x instanceof Named)); fetchWith(named && named.obj.method ? String(named.obj.method).toUpperCase() : (body !== undefined ? 'POST' : 'GET'), url, body, named, (r) => (r.v.name === 'Ok' ? resolve(r.vals[0]) : reject(rtError(r.vals[0], 'NetworkError')))); }),
        fetch_text: (url, o) => new Promise((resolve, reject) => fetchWith('GET', url, undefined, o, (r) => (r.v.name === 'Ok' ? resolve(r.vals[0].get('body')) : reject(rtError(r.vals[0], 'NetworkError'))))),
        fetch_json: (url, o) => new Promise((resolve, reject) => fetchWith('GET', url, undefined, o, (r) => { if (r.v.name === 'Err') return reject(rtError(r.vals[0], 'NetworkError')); try { resolve(rt.fromJS(JSON.parse(r.vals[0].get('body')))); } catch (e) { reject(rtError('The reply was not JSON: ' + e.message, 'ParseError')); } })),
        get: req('GET'), post: req('POST'), put: req('PUT'), delete: req('DELETE'), patch: req('PATCH'), head: req('HEAD'),
        // get_json(url, |result| ...) hands over the parsed data inside Ok, or an Err
        get_json: (url, f, o) => { const g = guard(cb(f)); fetchWith('GET', url, undefined, o, (r) => { if (r.v.name === 'Err') return g(r); const res = r.vals[0]; try { g(ok(rt.fromJS(JSON.parse(res.get('body'))))); } catch (e) { g(err('The reply was not JSON: ' + e.message)); } }); return null; },
        post_json: (url, body, f, o) => { const g = guard(cb(f)); fetchWith('POST', url, body, o, (r) => { if (r.v.name === 'Err') return g(r); const res = r.vals[0]; try { g(ok(rt.fromJS(JSON.parse(res.get('body'))))); } catch (e) { g(err('The reply was not JSON: ' + e.message)); } }); return null; },
        request: (spec, f) => { const g = guard(cb(f)); const o = spec instanceof SMap ? spec : new SMap(); fetchWith(String(o.get('method') || 'GET').toUpperCase(), o.get('url'), o.get('body'), new Named({ headers: o.get('headers'), timeout: o.get('timeout'), bearer: o.get('bearer') }), g); return null; },
        // an app with routes: app = http.app(); app.get("/", |req| "hi"); app.listen(8080)
        app: mkApp,
        serve: (port, handler, ready) => { const app = mkApp(); app.state.routes.push({ method: '*', re: /^.*$/, names: [], f: handler }); return AppT.methods.get('listen')(app, [port, ready]); },
        json: (v, status) => map({ status: status === undefined ? 200 : status, headers: map({ 'content-type': MIME.json }), body: JSON.stringify(rt.toJS(v)) }),
        html: (s, status) => map({ status: status === undefined ? 200 : status, headers: map({ 'content-type': MIME.html }), body: str(s) }),
        text: (s, status) => map({ status: status === undefined ? 200 : status, headers: map({ 'content-type': MIME.txt }), body: show(s) }),
        redirect: (url, status) => map({ status: status || 302, headers: map({ location: url }), body: '' }),
        file: (path) => map({ file: str(path) }),
        status: (code, body) => map({ status: code, body: body === undefined ? '' : body }),
        mime: (path) => mimeOf(str(path)),
        // a ready-made static file server
        serve_dir: (dir, port) => { const app = mkApp(); AppT.methods.get('static')(app, ['', dir === undefined ? '.' : dir]); return AppT.methods.get('listen')(app, [port === undefined ? 8000 : port]); },
        status_text: (code) => ({ 200: 'OK', 201: 'Created', 204: 'No Content', 301: 'Moved Permanently', 302: 'Found', 400: 'Bad Request', 401: 'Unauthorized', 403: 'Forbidden', 404: 'Not Found', 500: 'Internal Server Error' }[code] || ''),
    };
};

// ---------- std.dom ----------
const needDom = () => { if (typeof document === 'undefined') throw rtError('std.dom needs a web page. Run this program in a browser (suave build --web)', 'EnvError'); return document; };
const EL = (x) => { if (typeof Element !== 'undefined' && x instanceof Element) return x; if (typeof Node !== 'undefined' && x instanceof Node) return x; throw rtError('This needs a page element but got ' + typeOf(x), 'TypeError'); };
function eventMap(e) { const m = new SMap(); m.set('type', e.type); m.set('target', e.target); const t = e.target; if (t && 'value' in t) m.set('value', t.value); if (t && 'checked' in t) m.set('checked', t.checked); if (e.key !== undefined) { m.set('key', e.key); m.set('code', e.code); m.set('shift', e.shiftKey); m.set('ctrl', e.ctrlKey); m.set('alt', e.altKey); m.set('meta', e.metaKey); } if (e.clientX !== undefined) { m.set('x', e.clientX); m.set('y', e.clientY); } m.set('prevent', () => { e.preventDefault(); return null; }); m.set('stop', () => { e.stopPropagation(); return null; }); if (e.clientX !== undefined) { m.set('client_x', e.clientX); m.set('client_y', e.clientY); const ct = e.currentTarget; if (ct && ct.getBoundingClientRect) { const r = ct.getBoundingClientRect(); m.set('x', e.clientX - r.left); m.set('y', e.clientY - r.top); } m.set('button', e.button); m.set('buttons', e.buttons); if (e.pointerId !== undefined) { m.set('pointer_id', e.pointerId); m.set('pressure', e.pressure); } } return m; }
export function setProps(el, props, prevProps) {
    if (!(props instanceof SMap)) return;
    const prev = prevProps instanceof SMap ? prevProps : null;
    for (const [k, v] of props.entries()) {
        const key = String(k);
        if (key.startsWith('on_')) {
            const ev = key.slice(3);
            el.__h = el.__h || {};
            if (el.__h[ev]) el.removeEventListener(ev, el.__h[ev]);
            const g = guard(cb(v));
            el.__h[ev] = (e) => { if (ev === 'submit') e.preventDefault(); if (ev === 'pointerdown' && e.currentTarget && e.currentTarget.setPointerCapture) { try { e.currentTarget.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } } g(eventMap(e)); };   // a form handled by Suave does not reload the page
            el.addEventListener(ev, el.__h[ev]);
        } else if (key === 'class') el.setAttribute('class', Array.isArray(v) ? v.filter(Boolean).join(' ') : show(v));   // setAttribute works on SVG too
        else if (key === 'style') { if (v instanceof SMap) { el.removeAttribute('style'); for (const [sk, sv] of v.entries()) el.style.setProperty(String(sk).replace(/[A-Z]/g, (c) => '-' + c.toLowerCase()), show(sv)); } else el.setAttribute('style', show(v)); }
        else if (key === 'value') { if (el.value !== show(v)) el.value = show(v === null ? '' : v); }
        else if (key === 'checked') el.checked = truthy(v);
        else if (key === 'text') el.textContent = show(v);
        else if (key === 'html') { const h = show(v); if (el.__html !== h) { el.__html = h; el.innerHTML = h; } }   // only touched when the HTML changed, so a drawn-in widget keeps its state
        else if (key === 'foreign') el.__foreign = truthy(v);   // foreign: another library owns what is inside, Suave leaves the children alone
        else if (typeof v === 'boolean') { if (v) el.setAttribute(key, ''); else el.removeAttribute(key); }
        else if (v === null) el.removeAttribute(key);
        else el.setAttribute(key, show(v));
    }
    if (prev) for (const k of prev.keys()) { if (!props.has(k)) { const key = String(k); if (key.startsWith('on_')) { if (el.__h && el.__h[key.slice(3)]) { el.removeEventListener(key.slice(3), el.__h[key.slice(3)]); delete el.__h[key.slice(3)]; } } else el.removeAttribute(key === 'class' ? 'class' : key); } }
}
// virtual nodes are maps {tag, props, children}; strings and numbers are text
const isV = (x) => x instanceof SMap && x.has('tag');
export function build(v) {
    const d = needDom();
    if (v === null || v === undefined || v === false) return d.createComment('');
    if (typeof v === 'string' || typeof v === 'number' || typeof v === 'bigint' || v === true) return d.createTextNode(String(v));
    if (Array.isArray(v)) { const f = d.createDocumentFragment(); for (const c of v) f.appendChild(build(c)); return f; }
    if (typeof Node !== 'undefined' && v instanceof Node) return v;
    if (!isV(v)) return d.createTextNode(show(v));
    const tag = v.get('tag');
    const svgTags = /^(svg|path|circle|rect|line|polyline|polygon|g|text|defs|use|ellipse)$/;
    const el = svgTags.test(tag) ? d.createElementNS('http://www.w3.org/2000/svg', tag) : d.createElement(tag);
    const props0 = v.get('props');
    setProps(el, props0, null);
    if (!el.__foreign && !(props0 instanceof SMap && props0.has('html')) && !(props0 instanceof SMap && props0.has('text'))) for (const c of flat(v.get('children'))) el.appendChild(build(c));
    el.__v = v;
    return el;
}
export const flat = (c) => (c === null || c === undefined ? [] : Array.isArray(c) ? c.reduce((a, x) => a.concat(Array.isArray(x) ? flat(x) : [x]), []) : [c]);
export function patch(parent, node, v, index) {
    const d = needDom();
    const cur = node;
    const isText = (x) => typeof x === 'string' || typeof x === 'number' || typeof x === 'bigint' || x === true;
    if (!cur) { parent.appendChild(build(v)); return; }
    if (isText(v)) { if (cur.nodeType === 3) { if (cur.data !== String(v)) cur.data = String(v); } else parent.replaceChild(build(v), cur); return; }
    if (v === null || v === undefined || v === false) { if (cur.nodeType !== 8) parent.replaceChild(d.createComment(''), cur); return; }
    if (!isV(v) || Array.isArray(v)) { parent.replaceChild(build(v), cur); return; }
    if (cur.nodeType !== 1 || cur.localName !== String(v.get('tag')).toLowerCase() && cur.nodeName.toLowerCase() !== String(v.get('tag')).toLowerCase()) { parent.replaceChild(build(v), cur); return; }
    setProps(cur, v.get('props'), cur.__v ? cur.__v.get('props') : null);
    if (cur.__foreign || (v.get('props') instanceof SMap && (v.get('props').has('html') || v.get('props').has('text')))) { cur.__v = v; return; }
    const kids = flat(v.get('children'));
    for (let i = 0; i < kids.length; i++) patch(cur, cur.childNodes[i], kids[i], i);
    while (cur.childNodes.length > kids.length) cur.removeChild(cur.lastChild);
    cur.__v = v;
}
let AppDomT = null;
const compOf = (c) => { const x = c && c.web ? c.web : c; if (!(x instanceof rt.web.XComponent)) throw rtError('This needs a web component: bring one in with  use "./name.xsv"', 'TypeError'); return x; };
export const domModule = () => {
    const q = (sel, root) => needDom().querySelector.call(root ? EL(root) : needDom(), str(sel));
    const style = (el, k, v) => { if (v === undefined) return getComputedStyle(EL(el)).getPropertyValue(str(k)); EL(el).style.setProperty(str(k), show(v)); return null; };
    const mod = {
        query: (sel, root) => q(sel, root), query_all: (sel, root) => Array.from((root ? EL(root) : needDom()).querySelectorAll(str(sel))), by_id: (id) => needDom().getElementById(str(id)),
        body: () => needDom().body, head: () => needDom().head, document: () => needDom().documentElement,
        // create("button", {class: "big", on_click: |e| ...}, ["Click me"])
        create: (tag, props, children) => build(map({ tag, props: props instanceof SMap ? props : new SMap(), children: children === undefined ? [] : children })),
        // h("div", {class: "box"}, [h("p", {}, ["text"])]): a virtual node for render and app
        h: (tag, props, children) => map({ tag, props: props instanceof SMap ? props : new SMap(), children: children === undefined || children === null ? [] : (Array.isArray(children) ? children : [children]) }),
        render: (v) => build(v),
        append: (parent, ...kids) => { for (const k of kids) EL(parent).appendChild(build(k)); return parent; }, prepend: (parent, k) => { EL(parent).prepend(build(k)); return parent; },
        remove: (el) => { EL(el).remove(); return null; }, clear: (el) => { EL(el).textContent = ''; return el; },
        replace: (el, v) => { EL(el).replaceWith(build(v)); return null; }, insert_after: (el, v) => { EL(el).after(build(v)); return null; }, insert_before: (el, v) => { EL(el).before(build(v)); return null; },
        text: (el, s) => { if (s === undefined) return EL(el).textContent; EL(el).textContent = show(s); return el; },
        html: (el, s) => { if (s === undefined) return EL(el).innerHTML; EL(el).innerHTML = show(s); return el; },
        attr: (el, k, v) => { if (v === undefined) { const x = EL(el).getAttribute(str(k)); return x === null ? null : x; } if (v === null) EL(el).removeAttribute(str(k)); else EL(el).setAttribute(str(k), show(v)); return el; },
        has_attr: (el, k) => EL(el).hasAttribute(str(k)),
        value: (el, v) => { if (v === undefined) return EL(el).value; EL(el).value = show(v); return el; }, checked: (el, v) => { if (v === undefined) return EL(el).checked; EL(el).checked = !!v; return el; },
        add_class: (el, ...c) => { EL(el).classList.add(...c); return el; }, remove_class: (el, ...c) => { EL(el).classList.remove(...c); return el; }, toggle_class: (el, c, force) => EL(el).classList.toggle(c, force), has_class: (el, c) => EL(el).classList.contains(c),
        style, hide: (el) => { EL(el).style.display = 'none'; return el; }, show: (el, display) => { EL(el).style.display = display === undefined ? '' : display; return el; },
        focus: (el) => { EL(el).focus(); return null; }, scroll_to: (el) => { EL(el).scrollIntoView({ behavior: 'smooth' }); return null; },
        parent: (el) => EL(el).parentElement, children: (el) => Array.from(EL(el).children), next: (el) => EL(el).nextElementSibling, prev: (el) => EL(el).previousElementSibling, closest: (el, sel) => EL(el).closest(str(sel)),
        matches: (el, sel) => EL(el).matches(str(sel)), tag: (el) => EL(el).tagName.toLowerCase(), rect: (el) => { const r = EL(el).getBoundingClientRect(); return map({ x: r.x, y: r.y, width: r.width, height: r.height, top: r.top, left: r.left, right: r.right, bottom: r.bottom }); },
        // on(el, "click", |e| ...) -> a function that removes the listener
        on: (el, ev, f) => { const g = guard(cb(f)); const h = (e) => g(eventMap(e)); EL(el).addEventListener(str(ev), h); return () => { EL(el).removeEventListener(ev, h); return null; }; },
        // on_each("button.buy", "click", |e| ...) catches clicks on elements added later too
        delegate: (root, sel, ev, f) => { const g = guard(cb(f)); const h = (e) => { const t = e.target.closest && e.target.closest(str(sel)); if (t && EL(root).contains(t)) { const m = eventMap(e); m.set('target', t); g(m); } }; EL(root).addEventListener(str(ev), h); return () => { EL(root).removeEventListener(ev, h); return null; }; },
        ready: (f) => { const g = guard(cb(f)); if (needDom().readyState !== 'loading') g(); else needDom().addEventListener('DOMContentLoaded', () => g()); return null; },
        title: (s) => { if (s === undefined) return needDom().title; needDom().title = show(s); return null; },
        location: () => map({ href: location.href, path: location.pathname, hash: location.hash, search: location.search }), navigate: (url) => { location.href = str(url); return null; },
        set_hash: (h) => { location.hash = show(h); return null; }, on_hash: (f) => { const g = guard(cb(f)); addEventListener('hashchange', () => g(location.hash)); return null; },
        alert: (s) => { alert(show(s)); return null; }, confirm: (s) => confirm(show(s)), prompt: (s, d) => prompt(show(s), d === undefined ? '' : show(d)),
        copy_text: (s) => { if (navigator.clipboard) navigator.clipboard.writeText(show(s)); return null; },
        add_style: (css) => { const s = needDom().createElement('style'); s.textContent = show(css); needDom().head.appendChild(s); return s; },
        load_script: (url, f) => { const s = needDom().createElement('script'); s.src = str(url); const g = f === undefined ? null : guard(cb(f)); s.onload = () => g && g(ok(true)); s.onerror = () => g && g(err('Could not load ' + url)); needDom().head.appendChild(s); return null; },
        // download("notes.txt", "text") offers a file to save
        download: (name, content, mime) => { const b = new Blob([typeof content === 'string' ? content : bytesOf(content)], { type: mime || 'text/plain' }); const a = needDom().createElement('a'); a.href = URL.createObjectURL(b); a.download = str(name); a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); return null; },
        // mount(Counter, "#app", {start: 5}) draws a web component (a .xsv file, brought in with  use "./counter.xsv" ) and keeps it alive
        mount: (comp, target, props) => rt.web.mountComponent(compOf(comp), target, props instanceof SMap ? props : new SMap()),
        // render_html(Counter, {start: 5}) gives the component's HTML as text (no browser needed)
        render_html: (comp, props) => rt.web.renderHtml(rt.web.renderComponent(compOf(comp), props instanceof SMap ? props : new SMap())),
        // app("#root", state, view, update): state in, a view that draws it, an update that changes it
        //   view(state, dispatch) -> a virtual node;  update(state, msg) -> the new state;  dispatch(msg) runs update and redraws
        app: (root, state, view, update) => {
            const el = typeof root === 'string' ? q(root) : EL(root);
            if (!el) throw rtError('I could not find the page element ' + show(root), 'ArgError');
            let st = state;
            const vf = cb(view), uf = update === undefined ? null : cb(update);
            const dispatch = (msg) => { try { st = uf ? uf(st, msg) : msg; } catch (e) { reportLate(e); return null; } draw(); return null; };
            const draw = () => { try { const v = vf(st, dispatch); const kids = flat(Array.isArray(v) ? v : [v]); for (let i = 0; i < kids.length; i++) patch(el, el.childNodes[i], kids[i], i); while (el.childNodes.length > kids.length) el.removeChild(el.lastChild); } catch (e) { reportLate(e); } };
            draw();
            return map({ dispatch, state: () => st, redraw: () => { draw(); return null; }, set_state: (s) => { st = s; draw(); return null; } });
        },
    };
    for (const t of ['div', 'span', 'p', 'a', 'button', 'input', 'textarea', 'select', 'option', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'img', 'form', 'label', 'table', 'tr', 'td', 'th', 'thead', 'tbody', 'section', 'header', 'footer', 'nav', 'main', 'pre', 'code', 'strong', 'em', 'br', 'hr', 'canvas', 'svg']) {
        mod['h_' + t] = (props, children) => map({ tag: t, props: props instanceof SMap ? props : new SMap(), children: children === undefined || children === null ? [] : (Array.isArray(children) ? children : [children]) });
    }
    void AppDomT;
    return mod;
};

// ---------- std.canvas ----------
export const canvasModule = () => {
    const CanvasT = nativeType('Canvas', {
        fill_style: (c, a) => { c.state.ctx.fillStyle = show(a[0]); return c; }, stroke_style: (c, a) => { c.state.ctx.strokeStyle = show(a[0]); return c; }, line_width: (c, a) => { c.state.ctx.lineWidth = a[0]; return c; },
        font: (c, a) => { c.state.ctx.font = show(a[0]); return c; }, alpha: (c, a) => { c.state.ctx.globalAlpha = a[0]; return c; }, align: (c, a) => { c.state.ctx.textAlign = show(a[0]); return c; },
        clear: (c, a) => { const x = c.state.ctx; if (a.length) { x.fillStyle = show(a[0]); x.fillRect(0, 0, c.state.el.width, c.state.el.height); } else x.clearRect(0, 0, c.state.el.width, c.state.el.height); return c; },
        rect: (c, a) => { c.state.ctx.strokeRect(a[0], a[1], a[2], a[3]); return c; }, fill_rect: (c, a) => { c.state.ctx.fillRect(a[0], a[1], a[2], a[3]); return c; },
        circle: (c, a) => { const x = c.state.ctx; x.beginPath(); x.arc(a[0], a[1], a[2], 0, Math.PI * 2); x.stroke(); return c; }, fill_circle: (c, a) => { const x = c.state.ctx; x.beginPath(); x.arc(a[0], a[1], a[2], 0, Math.PI * 2); x.fill(); return c; },
        line: (c, a) => { const x = c.state.ctx; x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(a[2], a[3]); x.stroke(); return c; },
        text: (c, a) => { c.state.ctx.fillText(show(a[0]), a[1], a[2]); return c; }, stroke_text: (c, a) => { c.state.ctx.strokeText(show(a[0]), a[1], a[2]); return c; },
        begin: (c) => { c.state.ctx.beginPath(); return c; }, move_to: (c, a) => { c.state.ctx.moveTo(a[0], a[1]); return c; }, line_to: (c, a) => { c.state.ctx.lineTo(a[0], a[1]); return c; }, close: (c) => { c.state.ctx.closePath(); return c; },
        arc: (c, a) => { c.state.ctx.arc(a[0], a[1], a[2], a[3], a[4]); return c; }, curve_to: (c, a) => { c.state.ctx.bezierCurveTo(a[0], a[1], a[2], a[3], a[4], a[5]); return c; }, fill: (c) => { c.state.ctx.fill(); return c; }, stroke: (c) => { c.state.ctx.stroke(); return c; },
        polygon: (c, a) => { const x = c.state.ctx; const p = A(a[0]); x.beginPath(); p.forEach((pt, i) => (i ? x.lineTo(pt[0], pt[1]) : x.moveTo(pt[0], pt[1]))); x.closePath(); x.fill(); return c; },
        save: (c) => { c.state.ctx.save(); return c; }, restore: (c) => { c.state.ctx.restore(); return c; }, translate: (c, a) => { c.state.ctx.translate(a[0], a[1]); return c; }, rotate: (c, a) => { c.state.ctx.rotate(a[0]); return c; }, scale: (c, a) => { c.state.ctx.scale(a[0], a[1] === undefined ? a[0] : a[1]); return c; },
        width: (c) => c.state.el.width, height: (c) => c.state.el.height, element: (c) => c.state.el, to_data_url: (c) => c.state.el.toDataURL('image/png'),
        pixel: (c, a) => { const d = c.state.ctx.getImageData(a[0], a[1], 1, 1).data; return tuple([d[0], d[1], d[2], d[3]]); },
        // loop(|dt| ...): runs every frame; dt is seconds since the last one. Give back "stop" (or call cancel) to end it
        loop: (c, a) => { const g = cb(a[0]); let last = performance.now(); let stop = false; const tick = (now) => { if (stop) return; const dt = (now - last) / 1000; last = now; try { const r = g(dt); if (r === 'stop') return; } catch (e) { reportLate(e); return; } requestAnimationFrame(tick); }; requestAnimationFrame(tick); return () => { stop = true; return null; }; },
        on_click: (c, a) => { const g = guard(cb(a[0])); c.state.el.addEventListener('click', (e) => { const r = c.state.el.getBoundingClientRect(); g((e.clientX - r.left) * (c.state.el.width / r.width), (e.clientY - r.top) * (c.state.el.height / r.height)); }); return c; },
        on_move: (c, a) => { const g = guard(cb(a[0])); c.state.el.addEventListener('mousemove', (e) => { const r = c.state.el.getBoundingClientRect(); g((e.clientX - r.left) * (c.state.el.width / r.width), (e.clientY - r.top) * (c.state.el.height / r.height)); }); return c; },
        on_key: (c, a) => { const g = guard(cb(a[0])); document.addEventListener('keydown', (e) => g(e.key)); return c; },
    }, { reprFn: (o) => '<Canvas ' + o.state.el.width + 'x' + o.state.el.height + '>' });
    return {
        // new(400, 300) makes a canvas and adds it to the page (in #root if there is one, or to a parent you pass)
        new: (w, h, parent) => { const d = needDom(); const el = d.createElement('canvas'); el.width = w; el.height = h; (parent ? EL(parent) : (d.getElementById('root') || d.body)).appendChild(el); return make(CanvasT, { el, ctx: el.getContext('2d') }); },
        from: (el) => make(CanvasT, { el: EL(el), ctx: EL(el).getContext('2d') }),
        rgb: (r, g, b, a) => (a === undefined ? 'rgb(' + r + ',' + g + ',' + b + ')' : 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')'), hsl: (h, s, l) => 'hsl(' + h + ',' + s + '%,' + l + '%)',
    };
};
