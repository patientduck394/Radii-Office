/* Talking to the machine: std.fs, std.path, std.os, std.env, std.process, std.io, std.term, std.time, std.date, std.log, std.cli, std.test, std.events, std.storage. */
import { rt, SMap, SSet, SObj, Tuple, tuple, Named, opts, takeOpts, num, nums, list, cb, call, map, nativeType, make, later, guard, reportLate, rtError, show, repr, eq, truthy, typeOf, ok, err, toArray, iterate, str, bytesOf } from './_util.js';

const A = (x) => toArray(x);
const sys = (what) => rt.needSys(what);

// ---------- std.path ----------
const norm = (p) => {
    const abs = p.startsWith('/');
    const out = [];
    for (const seg of p.split('/')) { if (seg === '' || seg === '.') continue; if (seg === '..') { if (out.length && out[out.length - 1] !== '..') out.pop(); else if (!abs) out.push('..'); } else out.push(seg); }
    return (abs ? '/' : '') + out.join('/') || (abs ? '/' : '.');
};
const baseOf = (p) => { const t = p.replace(/\/+$/, ''); return t.slice(t.lastIndexOf('/') + 1); };
export const pathModule = () => ({
    sep: '/',
    join: (...a) => norm(a.map((x) => str(x, 'path.join')).filter((x) => x !== '').join('/')),
    normalize: (p) => norm(str(p, 'path.normalize')),
    dirname: (p) => { const t = str(p, 'path.dirname').replace(/\/+$/, ''); const i = t.lastIndexOf('/'); return i < 0 ? '.' : i === 0 ? '/' : t.slice(0, i); },
    basename: (p, ext) => { const b = baseOf(str(p, 'path.basename')); return ext && b.endsWith(ext) ? b.slice(0, -ext.length) : b; },
    ext: (p) => { const b = baseOf(str(p, 'path.ext')); const i = b.lastIndexOf('.'); return i <= 0 ? '' : b.slice(i); },
    stem: (p) => { const b = baseOf(str(p, 'path.stem')); const i = b.lastIndexOf('.'); return i <= 0 ? b : b.slice(0, i); },
    with_ext: (p, e) => { const b = str(p); const i = b.lastIndexOf('.'); const s = b.lastIndexOf('/'); return (i > s + 1 ? b.slice(0, i) : b) + (e.startsWith('.') || e === '' ? e : '.' + e); },
    is_absolute: (p) => str(p).startsWith('/'),
    split: (p) => tuple([ (() => { const t = str(p).replace(/\/+$/, ''); const i = t.lastIndexOf('/'); return i < 0 ? '' : i === 0 ? '/' : t.slice(0, i); })(), baseOf(p) ]),
    parts: (p) => str(p).split('/').filter(Boolean),
    resolve: (p) => (str(p).startsWith('/') ? norm(p) : norm((rt.sys ? rt.sys.cwd() : '/') + '/' + p)),
    relative: (from, to) => { const a = norm(str(from)).split('/').filter(Boolean), b = norm(str(to)).split('/').filter(Boolean); let i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++; return a.slice(i).map(() => '..').concat(b.slice(i)).join('/') || '.'; },
    matches: (p, pattern) => globRe(str(pattern)).test(str(p)),
});
function globRe(g) {
    let re = '^';
    for (let i = 0; i < g.length; i++) {
        const c = g[i];
        if (c === '*') { if (g[i + 1] === '*') { re += '.*'; i++; if (g[i + 1] === '/') i++; } else re += '[^/]*'; }
        else if (c === '?') re += '[^/]';
        else if (c === '{') { const e = g.indexOf('}', i); re += '(' + g.slice(i + 1, e).split(',').map((x) => x.replace(/[.+^$()|[\]\\]/g, '\\$&')).join('|') + ')'; i = e; }
        else re += c.replace(/[.+^$()|[\]\\]/g, '\\$&');
    }
    return new RegExp(re + '$');
}

// ---------- std.fs ----------
export const fsModule = () => {
    const walk = (dir, out, depth, max) => { const s = sys('fs.walk'); for (const e of s.readDir(dir).sort((a, b) => (a.name < b.name ? -1 : 1))) { const p = (dir === '.' ? '' : dir.replace(/\/$/, '') + '/') + e.name; out.push(p); if (e.isDir && depth < max) walk(p, out, depth + 1, max); } };
    return {
        read: (p) => sys('fs.read').readText(str(p, 'fs.read')),
        write: (p, t) => { sys('fs.write').writeText(str(p, 'fs.write'), show(t)); return null; },
        append: (p, t) => { sys('fs.append').writeText(str(p, 'fs.append'), show(t), true); return null; },
        read_lines: (p) => { const t = sys('fs.read_lines').readText(str(p)); const l = t.split(/\r?\n/); if (l.length && l[l.length - 1] === '') l.pop(); return l; },
        write_lines: (p, lines) => { sys('fs.write_lines').writeText(str(p), A(lines).map(show).join('\n') + '\n'); return null; },
        read_bytes: (p) => sys('fs.read_bytes').readBytes(str(p)), write_bytes: (p, b) => { sys('fs.write_bytes').writeBytes(str(p), bytesOf(b)); return null; },
        exists: (p) => sys('fs.exists').exists(str(p)),
        is_file: (p) => { const s = sys('fs.is_file').stat(str(p)); return !!s && s.isFile; }, is_dir: (p) => { const s = sys('fs.is_dir').stat(str(p)); return !!s && s.isDir; },
        list: (p) => sys('fs.list').readDir(p === undefined ? '.' : str(p)).map((e) => e.name).sort(),
        list_full: (p) => sys('fs.list_full').readDir(p === undefined ? '.' : str(p)).map((e) => map({ name: e.name, is_dir: e.isDir, is_file: e.isFile })),
        mkdir: (p, parents) => { sys('fs.mkdir').mkdir(str(p), parents !== false); return null; },
        remove: (p, recursive) => { sys('fs.remove').remove(str(p), !!recursive); return null; },
        rename: (a, b) => { sys('fs.rename').rename(str(a), str(b)); return null; }, move: (a, b) => { sys('fs.move').rename(str(a), str(b)); return null; },
        copy: (a, b) => { sys('fs.copy').copy(str(a), str(b)); return null; },
        touch: (p) => { const s = sys('fs.touch'); if (!s.exists(p)) s.writeText(p, ''); return null; },
        stat: (p) => { const s = sys('fs.stat').stat(str(p)); return s ? map({ size: s.size, modified: s.mtime === null ? null : s.mtime / 1000, is_file: s.isFile, is_dir: s.isDir, is_link: s.isLink }) : null; },
        size: (p) => { const s = sys('fs.size').stat(str(p)); return s ? s.size : null; },
        modified: (p) => { const m = sys('fs.modified').mtime(str(p)); return m === null ? null : m / 1000; },
        // every file and folder below a folder (relative paths), optionally filtered with a glob like "**/*.sv"
        walk: (p, o) => { const op = opts(o); const out = []; walk(p === undefined ? '.' : str(p), out, 0, op.depth === undefined ? 64 : op.depth); return op.pattern ? out.filter((x) => globRe(op.pattern).test(x)) : out; },
        glob: (pattern) => { const g = str(pattern, 'fs.glob'); const m = /^([^*?{]*\/)?/.exec(g); const base = (m && m[1]) ? m[1].replace(/\/$/, '') || '/' : '.'; const out = []; walk(base, out, 0, 64); const re = globRe(g.startsWith('./') ? g.slice(2) : g); return out.filter((x) => re.test(x)); },
        temp_dir: () => sys('fs.temp_dir').tempDir(), home: () => sys('fs.home').home(), cwd: () => sys('fs.cwd').cwd(), chdir: (p) => { sys('fs.chdir').chdir(str(p)); return null; },
        real_path: (p) => sys('fs.real_path').realPath(str(p)),
        // copy a whole folder
        copy_dir: (a, b) => { const s = sys('fs.copy_dir'); const go = (x, y) => { s.mkdir(y, true); for (const e of s.readDir(x)) { if (e.isDir) go(x + '/' + e.name, y + '/' + e.name); else s.copy(x + '/' + e.name, y + '/' + e.name); } }; go(str(a), str(b)); return null; },
        // run f for each line without loading everything into a list
        each_line: (p, f) => { const g = cb(f); const t = sys('fs.each_line').readText(str(p)); for (const l of t.split(/\r?\n/)) g(l); return null; },
        du: (p) => { const s = sys('fs.du'); const go = (x) => { const st = s.stat(x); if (!st) return 0; if (!st.isDir) return st.size; return s.readDir(x).reduce((t, e) => t + go(x + '/' + e.name), 0); }; return go(str(p)); },
    };
};

// ---------- std.os, std.env, std.process ----------
export const osModule = () => ({
    name: () => (rt.sys ? rt.sys.os() : 'browser'), arch: () => (rt.sys ? rt.sys.arch() : 'unknown'), hostname: () => sys('os.hostname').hostname(),
    home: () => sys('os.home').home(), pid: () => sys('os.pid').pid(), cpus: () => (rt.sys ? rt.sys.cpus() : (globalThis.navigator ? navigator.hardwareConcurrency : 1)),
    is_windows: () => !!rt.sys && rt.sys.os() === 'windows', is_mac: () => !!rt.sys && rt.sys.os() === 'darwin', is_linux: () => !!rt.sys && rt.sys.os() === 'linux',
    eol: () => (rt.sys && rt.sys.os() === 'windows' ? '\r\n' : '\n'), runtime: () => (rt.sys ? 'deno ' + rt.sys.denoVersion() : 'browser'),
    is_browser: () => !rt.sys, temp_dir: () => sys('os.temp_dir').tempDir(),
});
function parseDotenv(text) {
    const m = new SMap();
    for (const raw of text.split(/\r?\n/)) {
        const line = raw.trim();
        if (!line || line.startsWith('#')) continue;
        const e = /^(?:export\s+)?([A-Za-z_][\w.]*)\s*=\s*(.*)$/.exec(line);
        if (!e) continue;
        let v = e[2];
        if (/^".*"$/.test(v)) v = v.slice(1, -1).replace(/\\n/g, '\n').replace(/\\"/g, '"'); else if (/^'.*'$/.test(v)) v = v.slice(1, -1); else v = v.replace(/\s+#.*$/, '');
        m.set(e[1], v);
    }
    return m;
}
export const envModule = () => ({
    get: (k, d) => { const v = rt.sys ? rt.sys.env(str(k, 'env.get')) : undefined; return v === undefined ? (d === undefined ? null : d) : v; },
    set: (k, v) => { sys('env.set').setEnv(str(k), show(v)); return null; },
    has: (k) => !!rt.sys && rt.sys.env(str(k)) !== undefined,
    all: () => { const m = new SMap(); if (rt.sys) { const o = rt.sys.envAll(); for (const k of Object.keys(o).sort()) m.set(k, o[k]); } return m; },
    require: (k) => { const v = rt.sys ? rt.sys.env(str(k)) : undefined; if (v === undefined) throw rtError('The environment variable ' + k + ' is not set', 'EnvError'); return v; },
    parse: (text) => parseDotenv(str(text, 'env.parse')),
    load: (path) => { const m = parseDotenv(sys('env.load').readText(path === undefined ? '.env' : str(path))); for (const [k, v] of m.entries()) if (rt.sys.env(k) === undefined) rt.sys.setEnv(k, v); return m; },
    int: (k, d) => { const v = rt.sys ? rt.sys.env(str(k)) : undefined; const n = v === undefined ? NaN : Number(v); return Number.isNaN(n) ? (d === undefined ? null : d) : n; },
    bool: (k, d) => { const v = rt.sys ? rt.sys.env(str(k)) : undefined; return v === undefined ? !!d : /^(1|true|yes|on)$/i.test(v); },
});
// options for starting a program: cwd, input, env (a map of extra environment variables)
const procOpts = (o) => { const op = Object.assign({}, opts(o)); if (op.env instanceof SMap) { const e = {}; for (const [k, v] of op.env.entries()) e[String(k)] = show(v); op.env = e; } return op; };
export const processModule = () => {
    const toMap = (r) => map({ code: r.code, ok: r.code === 0, stdout: r.stdout, stderr: r.stderr });
    return {
        args: () => rt.argv.slice(), exit: (c) => { sys('process.exit').exit(c || 0); return null; }, cwd: () => sys('process.cwd').cwd(), pid: () => sys('process.pid').pid(),
        // run("git", ["status"]) -> {code, ok, stdout, stderr}; options: cwd, input
        run: (cmd, args, o) => toMap(sys('process.run').runSync(str(cmd, 'process.run'), args === undefined || args instanceof Named ? [] : A(args).map(show), procOpts(args instanceof Named ? args : o))),
        shell: (cmdline, o) => { const s = sys('process.shell'); const win = s.os() === 'windows'; return toMap(s.runSync(win ? 'cmd' : 'sh', win ? ['/c', str(cmdline)] : ['-c', str(cmdline)], procOpts(o))); },
        // the text a command prints, or an error if it fails
        output: (cmd, args) => { const r = sys('process.output').runSync(str(cmd), args === undefined ? [] : A(args).map(show), {}); if (r.code !== 0) throw rtError(cmd + ' failed (code ' + r.code + '): ' + r.stderr.trim(), 'ProcessError'); return r.stdout; },
        // run without waiting: spawn("sleep", ["1"], |result| print(result.code))
        spawn: (cmd, args, f) => { const s = sys('process.spawn'); const g = guard(cb(f)); s.run(str(cmd), A(args || []).map(show), {}).then((r) => g(toMap(r)), (e) => g(map({ code: -1, ok: false, stdout: '', stderr: String(e.message || e) }))); return null; },
        which: (cmd) => { const s = sys('process.which'); const path = (s.env('PATH') || '').split(s.os() === 'windows' ? ';' : ':'); for (const d of path) { const p = d + '/' + cmd; const st = s.stat(p); if (st && st.isFile) return p; } return null; },
        // exec("git", ["status"]) is run() that you can await: it gives a future for {code, ok, stdout, stderr}
        exec: (cmd, args, o) => sys('process.exec').run(str(cmd), args === undefined || args instanceof Named ? [] : A(args).map(show), procOpts(args instanceof Named ? args : o)).then(toMap),
        stdin: () => sys('process.stdin').readStdin(), is_tty: () => !!rt.sys && rt.sys.isTTY(),
    };
};

// ---------- std.io ----------
export const ioModule = () => ({
    print: (...a) => { rt.write(a.map(show).join(' ') + '\n'); return null; }, write: (...a) => { rt.write(a.map(show).join('')); return null; }, eprint: (...a) => { rt.ewrite(a.map(show).join(' ') + '\n'); return null; },
    read_line: (p) => (rt.sys ? rt.sys.readLine(p === undefined ? '' : show(p)) : (typeof prompt === 'function' ? prompt(p === undefined ? '' : show(p)) : null)),
    read_all: () => sys('io.read_all').readStdin(),
    read_lines: () => { const t = sys('io.read_lines').readStdin(); const l = t.split(/\r?\n/); if (l.length && l[l.length - 1] === '') l.pop(); return l; },
    ask: (q, d) => { const r = rt.sys ? rt.sys.readLine(show(q) + (d !== undefined ? ' [' + show(d) + ']' : '') + ' ') : prompt(show(q)); return r === null || r === '' ? (d === undefined ? r : d) : r; },
    confirm: (q, d) => { const r = sys('io.confirm').readLine(show(q) + (d === false ? ' [y/N] ' : ' [Y/n] ')); if (r === null || r.trim() === '') return d !== false; return /^y(es)?$/i.test(r.trim()); },
    select: (q, options) => { const o = A(options); rt.write(show(q) + '\n'); o.forEach((x, i) => rt.write('  ' + (i + 1) + ') ' + show(x) + '\n')); for (;;) { const r = sys('io.select').readLine('> '); if (r === null) return null; const n = parseInt(r, 10); if (n >= 1 && n <= o.length) return o[n - 1]; rt.write('Please type a number from 1 to ' + o.length + '\n'); } },
    number: (q) => { for (;;) { const r = sys('io.number').readLine(show(q) + ' '); if (r === null) return null; const n = Number(r); if (r.trim() !== '' && !Number.isNaN(n)) return n; rt.write('That is not a number. Try again.\n'); } },
});

// ---------- std.term ----------
const CODES = { reset: 0, bold: 1, dim: 2, italic: 3, underline: 4, blink: 5, inverse: 7, hidden: 8, strike: 9, black: 30, red: 31, green: 32, yellow: 33, blue: 34, magenta: 35, cyan: 36, white: 37, gray: 90, bright_red: 91, bright_green: 92, bright_yellow: 93, bright_blue: 94, bright_magenta: 95, bright_cyan: 96, bright_white: 97, bg_black: 40, bg_red: 41, bg_green: 42, bg_yellow: 43, bg_blue: 44, bg_magenta: 45, bg_cyan: 46, bg_white: 47 };
const ANSI = /\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07/g;
export const termModule = () => {
    const mod = {};
    for (const k of Object.keys(CODES)) mod[k] = (t) => '\x1b[' + CODES[k] + 'm' + show(t) + '\x1b[0m';
    return Object.assign(mod, {
        style: (t, spec) => { const codes = str(spec, 'term.style').split(/[\s,+]+/).filter(Boolean).map((n) => { if (!(n in CODES)) throw rtError('"' + n + '" is not a style I know. Try bold red bg_blue underline', 'ArgError'); return CODES[n]; }); return '\x1b[' + codes.join(';') + 'm' + show(t) + '\x1b[0m'; },
        rgb: (t, r, g, b) => '\x1b[38;2;' + r + ';' + g + ';' + b + 'm' + show(t) + '\x1b[0m', bg_rgb: (t, r, g, b) => '\x1b[48;2;' + r + ';' + g + ';' + b + 'm' + show(t) + '\x1b[0m',
        color256: (t, n) => '\x1b[38;5;' + n + 'm' + show(t) + '\x1b[0m',
        strip: (t) => str(t).replace(ANSI, ''), visible_len: (t) => Array.from(str(t).replace(ANSI, '')).length,
        clear: () => { rt.write('\x1b[2J\x1b[H'); return null; }, clear_line: () => { rt.write('\r\x1b[2K'); return null; },
        move_to: (x, y) => { rt.write('\x1b[' + (y + 1) + ';' + (x + 1) + 'H'); return null; }, up: (n) => { rt.write('\x1b[' + (n || 1) + 'A'); return null; }, down: (n) => { rt.write('\x1b[' + (n || 1) + 'B'); return null; },
        hide_cursor: () => { rt.write('\x1b[?25l'); return null; }, show_cursor: () => { rt.write('\x1b[?25h'); return null; },
        width: () => { try { return Deno.consoleSize().columns; } catch (e) { return 80; } }, height: () => { try { return Deno.consoleSize().rows; } catch (e) { return 24; } },
        is_tty: () => !!rt.sys && rt.sys.isTTY(), bell: () => { rt.write('\x07'); return null; }, title: (t) => { rt.write('\x1b]0;' + show(t) + '\x07'); return null; },
        link: (text, url) => '\x1b]8;;' + url + '\x1b\\' + show(text) + '\x1b]8;;\x1b\\',
        hr: (w, ch) => (ch === undefined ? '─' : ch).repeat(w === undefined ? (() => { try { return Deno.consoleSize().columns; } catch (e) { return 80; } })() : w),
        progress: (value, max, width) => { const w = width || 30; const f = Math.max(0, Math.min(1, value / max)); const n = Math.round(f * w); return '[' + '█'.repeat(n) + '░'.repeat(w - n) + '] ' + String(Math.round(f * 100)).padStart(3) + '%'; },
        spinner_frames: () => ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'],
        // draw a one-line status that overwrites itself: term.status("Working 40%")
        status: (t) => { rt.write('\r\x1b[2K' + show(t)); return null; },
    });
};

// ---------- std.time ----------
let timerId = 0;
const timers = new Map();
const sleepBlock = (ms) => { if (ms <= 0) return; try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch (e) { const end = Date.now() + ms; while (Date.now() < end) { /* wait */ } } };
export function parseDuration(s) {
    if (typeof s === 'number') return s;
    const t = str(s, 'duration').trim();
    let total = 0, found = false;
    const re = /(\d+(?:\.\d+)?)\s*(ms|sec|min|hr|s|m|h|d|w|y)(?![a-zA-Z])/gi;
    let m;
    while ((m = re.exec(t))) { found = true; total += Number(m[1]) * { ms: 0.001, s: 1, sec: 1, m: 60, min: 60, h: 3600, hr: 3600, d: 86400, w: 604800, y: 31557600 }[m[2].toLowerCase()]; }
    if (!found) { const c = /^(\d+):(\d\d)(?::(\d\d))?$/.exec(t); if (c) return c[3] ? +c[1] * 3600 + +c[2] * 60 + +c[3] : +c[1] * 60 + +c[2]; if (/^\d+(\.\d+)?$/.test(t)) return Number(t); throw rtError('"' + s + '" is not a duration like 1h30m, 90s or 1:30', 'ValueError'); }
    return total;
}
export const timeModule = () => {
    let StopwatchT = null;
    StopwatchT = nativeType('Stopwatch', {
        elapsed: (s) => (s.state.stopped === null ? performance.now() : s.state.stopped) / 1000 - s.state.start / 1000,
        lap: (s) => { const now = performance.now(); const d = (now - s.state.lapAt) / 1000; s.state.lapAt = now; return d; },
        reset: (s) => { s.state.start = performance.now(); s.state.lapAt = s.state.start; s.state.stopped = null; return null; },
        stop: (s) => { s.state.stopped = performance.now(); return (s.state.stopped - s.state.start) / 1000; },
    }, { reprFn: (o) => '<Stopwatch ' + ((performance.now() - o.state.start) / 1000).toFixed(3) + 's>' });
    return {
        now: () => Date.now() / 1000, now_ms: () => Date.now(), clock: () => performance.now(),
        // delay(1.5) waits without blocking: use it with await (sleep blocks everything)
        delay: (s) => new Promise((r) => setTimeout(() => r(null), Math.max(0, num(s, 'delay')) * 1000)),
        sleep: (s) => { sleepBlock(num(s, 'sleep') * 1000); return null; }, sleep_ms: (ms) => { sleepBlock(num(ms)); return null; },
        // measure(|| work()) -> (result, seconds)
        measure: (f) => { const g = cb(f); const t = performance.now(); const r = g(); return tuple([r, (performance.now() - t) / 1000]); },
        bench: (f, n) => { const g = cb(f); const runs = n || 100; const ts = []; for (let i = 0; i < runs; i++) { const t = performance.now(); g(); ts.push((performance.now() - t) / 1000); } ts.sort((a, b) => a - b); return map({ runs, mean: ts.reduce((a, b) => a + b, 0) / runs, min: ts[0], max: ts[runs - 1], median: ts[Math.floor(runs / 2)] }); },
        stopwatch: () => { const s = make(StopwatchT, { start: performance.now(), lapAt: performance.now(), stopped: null }); return s; },
        // after(1.5, || print("hi")) runs later without stopping the program; every(1, f) repeats. Both return an id for cancel(id)
        after: (s, f) => { const g = cb(f); const id = ++timerId; timers.set(id, setTimeout(() => { timers.delete(id); try { g(); } catch (e) { reportLate(e); } }, num(s, 'after') * 1000)); return id; },
        every: (s, f) => { const g = cb(f); const id = ++timerId; timers.set(id, setInterval(() => { try { g(); } catch (e) { reportLate(e); } }, Math.max(1, num(s, 'every') * 1000))); return id; },
        cancel: (id) => { const t = timers.get(id); if (t === undefined) return false; clearTimeout(t); clearInterval(t); timers.delete(id); return true; },
        parse_duration: parseDuration,
        format_duration: (s) => { s = num(s); if (s < 1) return Math.round(s * 1000) + 'ms'; s = Math.round(s); if (s < 60) return s + 's'; const parts = []; for (const [u, k] of [['d', 86400], ['h', 3600], ['m', 60], ['s', 1]]) if (s >= k) { parts.push(Math.floor(s / k) + u); s %= k; } return parts.join(' '); },
        // run f again if it fails: retry(3, |i| work(), delay: 0.5)
        retry: (n, f, o) => { const noArg = f && f.params && !f.params.some((p) => !p.rest); const g = noArg ? () => call(f, []) : cb(f); const d = opts(o).delay || 0; let last = null; for (let i = 0; i < n; i++) { try { return g(i); } catch (e) { last = e; if (i < n - 1 && d) sleepBlock(d * 1000); } } throw last; },
        // wait until f gives a truthy value (polling), or fail after the timeout
        wait_for: (f, timeout, every) => { const g = cb(f); const end = Date.now() + (timeout || 5) * 1000; while (Date.now() < end) { const r = g(); if (truthy(r)) return r; sleepBlock((every || 0.05) * 1000); } throw rtError('wait_for gave up after ' + (timeout || 5) + ' seconds', 'TimeoutError'); },
    };
};

// ---------- std.date (all times are UTC unless you pass a tz offset in minutes) ----------
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
const dim = (y, m) => [31, isLeap(y) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
const D = (x) => { if (x instanceof Date) return x; if (typeof x === 'number') return new Date(x * 1000); throw rtError('This needs a date but got ' + typeOf(x), 'TypeError'); };
const p2 = (n) => String(n).padStart(2, '0');
function dayOfYear(d) { return Math.floor((Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) - Date.UTC(d.getUTCFullYear(), 0, 0)) / 86400000); }
function isoWeek(d) { const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())); const dn = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - dn); const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return Math.ceil(((t - y0) / 86400000 + 1) / 7); }
function formatDate(dt, fmt, tz) {
    const d = new Date(dt.getTime() + (tz || 0) * 60000);
    return fmt.replace(/%([A-Za-z%])/g, (m, c) => {
        switch (c) {
            case 'Y': return String(d.getUTCFullYear()); case 'y': return p2(d.getUTCFullYear() % 100); case 'm': return p2(d.getUTCMonth() + 1); case 'd': return p2(d.getUTCDate());
            case 'e': return String(d.getUTCDate()).padStart(2, ' '); case 'H': return p2(d.getUTCHours()); case 'I': return p2(d.getUTCHours() % 12 || 12); case 'M': return p2(d.getUTCMinutes());
            case 'S': return p2(d.getUTCSeconds()); case 'f': return String(d.getUTCMilliseconds()).padStart(3, '0'); case 'p': return d.getUTCHours() < 12 ? 'AM' : 'PM';
            case 'b': return MONTHS[d.getUTCMonth()].slice(0, 3); case 'B': return MONTHS[d.getUTCMonth()]; case 'a': return DAYS[d.getUTCDay()].slice(0, 3); case 'A': return DAYS[d.getUTCDay()];
            case 'j': return String(dayOfYear(d)).padStart(3, '0'); case 'u': return String(d.getUTCDay() || 7); case 'w': return String(d.getUTCDay()); case 'V': return p2(isoWeek(d));
            case 's': return String(Math.floor(dt.getTime() / 1000)); case 'Z': return tz ? (tz < 0 ? '-' : '+') + p2(Math.floor(Math.abs(tz) / 60)) + ':' + p2(Math.abs(tz) % 60) : 'UTC';
            case 'z': return tz ? (tz < 0 ? '-' : '+') + p2(Math.floor(Math.abs(tz) / 60)) + p2(Math.abs(tz) % 60) : '+0000';
            case 'F': return d.getUTCFullYear() + '-' + p2(d.getUTCMonth() + 1) + '-' + p2(d.getUTCDate()); case 'T': return p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()) + ':' + p2(d.getUTCSeconds());
            case '%': return '%';
        }
        return m;
    });
}
function parseDate(s, fmt) {
    s = str(s, 'date.parse').trim();
    if (fmt) {
        const names = []; let re = '^' + fmt.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%([YmdHMSyfbBeIp])/g, (m, c) => { names.push(c); return { Y: '(\\d{4})', y: '(\\d{2})', m: '(\\d{1,2})', d: '(\\d{1,2})', e: '\\s?(\\d{1,2})', H: '(\\d{1,2})', I: '(\\d{1,2})', M: '(\\d{2})', S: '(\\d{2})', f: '(\\d{1,3})', b: '([A-Za-z]{3})', B: '([A-Za-z]+)', p: '(AM|PM|am|pm)' }[c]; }) + '$';
        const m = new RegExp(re).exec(s);
        if (!m) throw rtError('"' + s + '" does not match the date format "' + fmt + '"', 'ValueError');
        let y = 1970, mo = 1, d = 1, h = 0, mi = 0, se = 0, ms = 0, pm = null;
        names.forEach((c, i) => { const v = m[i + 1]; if (c === 'Y') y = +v; else if (c === 'y') y = 2000 + +v; else if (c === 'm') mo = +v; else if (c === 'd' || c === 'e') d = +v; else if (c === 'H' || c === 'I') h = +v; else if (c === 'M') mi = +v; else if (c === 'S') se = +v; else if (c === 'f') ms = +v; else if (c === 'b') mo = MONTHS.findIndex((x) => x.slice(0, 3).toLowerCase() === v.toLowerCase()) + 1; else if (c === 'B') mo = MONTHS.findIndex((x) => x.toLowerCase() === v.toLowerCase()) + 1; else if (c === 'p') pm = /pm/i.test(v); });
        if (pm !== null) { if (pm && h < 12) h += 12; if (!pm && h === 12) h = 0; }
        return new Date(Date.UTC(y, mo - 1, d, h, mi, se, ms));
    }
    let d;
    if (/^\d{4}-\d\d-\d\d$/.test(s)) d = new Date(s + 'T00:00:00Z');
    else if (/^\d{4}-\d\d-\d\d[T ]\d\d:\d\d(:\d\d(\.\d+)?)?$/.test(s)) d = new Date(s.replace(' ', 'T') + 'Z');
    else d = new Date(s);
    if (Number.isNaN(d.getTime())) throw rtError('I could not read "' + s + '" as a date', 'ValueError');
    return d;
}
export const dateModule = () => {
    const add = (dt, o) => { const p = opts(o); let d = new Date(D(dt).getTime()); if (p.years || p.months) { const y = d.getUTCFullYear() + (p.years || 0), m0 = d.getUTCMonth() + (p.months || 0); const yy = y + Math.floor(m0 / 12), mm = ((m0 % 12) + 12) % 12; d = new Date(Date.UTC(yy, mm, Math.min(d.getUTCDate(), dim(yy, mm + 1)), d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds(), d.getUTCMilliseconds())); } return new Date(d.getTime() + ((p.weeks || 0) * 7 + (p.days || 0)) * 86400000 + (p.hours || 0) * 3600000 + (p.minutes || 0) * 60000 + (p.seconds || 0) * 1000); };
    return {
        now: () => new Date(), today: () => { const n = new Date(); return new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate())); },
        make: (y, m, d, h, mi, s) => new Date(Date.UTC(y, (m === undefined ? 1 : m) - 1, d === undefined ? 1 : d, h || 0, mi || 0, s || 0)),
        parse: (s, fmt) => parseDate(s, fmt), format: (dt, fmt, tz) => formatDate(D(dt), fmt === undefined ? '%Y-%m-%d %H:%M:%S' : str(fmt), tz),
        iso: (dt) => D(dt).toISOString(), date_text: (dt) => formatDate(D(dt), '%Y-%m-%d'),
        from_timestamp: (s) => new Date(num(s) * 1000), to_timestamp: (dt) => D(dt).getTime() / 1000, from_ms: (ms) => new Date(ms),
        add, sub: (dt, o) => { const p = opts(o); const n = {}; for (const k of Object.keys(p)) n[k] = -p[k]; return add(dt, new Named(n)); },
        diff: (a, b, unit) => { const ms = D(a).getTime() - D(b).getTime(); const u = unit === undefined ? 'days' : unit; const div = { seconds: 1000, minutes: 60000, hours: 3600000, days: 86400000, weeks: 604800000, ms: 1 }[u]; if (!div) throw rtError('diff units: seconds, minutes, hours, days, weeks, ms', 'ArgError'); return ms / div; },
        weekday: (dt) => D(dt).getUTCDay(), weekday_name: (dt) => DAYS[D(dt).getUTCDay()], month_name: (dt) => MONTHS[(dt instanceof Date ? dt.getUTCMonth() : dt - 1)],
        is_leap: (y) => isLeap(y instanceof Date ? y.getUTCFullYear() : y), days_in_month: (y, m) => dim(y, m), day_of_year: (dt) => dayOfYear(D(dt)), week: (dt) => isoWeek(D(dt)), quarter: (dt) => Math.floor(D(dt).getUTCMonth() / 3) + 1,
        is_weekend: (dt) => [0, 6].includes(D(dt).getUTCDay()),
        start_of: (dt, unit) => { const d = D(dt); const y = d.getUTCFullYear(), m = d.getUTCMonth(), dd = d.getUTCDate(); switch (unit) { case 'year': return new Date(Date.UTC(y, 0, 1)); case 'month': return new Date(Date.UTC(y, m, 1)); case 'week': return new Date(Date.UTC(y, m, dd - ((d.getUTCDay() + 6) % 7))); case 'day': return new Date(Date.UTC(y, m, dd)); case 'hour': return new Date(Date.UTC(y, m, dd, d.getUTCHours())); case 'minute': return new Date(Date.UTC(y, m, dd, d.getUTCHours(), d.getUTCMinutes())); } throw rtError('start_of units: year, month, week, day, hour, minute', 'ArgError'); },
        end_of: (dt, unit) => { const d = D(dt); const y = d.getUTCFullYear(), m = d.getUTCMonth(); switch (unit) { case 'month': return new Date(Date.UTC(y, m, dim(y, m + 1), 23, 59, 59, 999)); case 'year': return new Date(Date.UTC(y, 11, 31, 23, 59, 59, 999)); case 'day': return new Date(Date.UTC(y, m, d.getUTCDate(), 23, 59, 59, 999)); } throw rtError('end_of units: year, month, day', 'ArgError'); },
        range: (a, b, step) => { const out = []; const st = (step === undefined ? 1 : step) * 86400000; for (let t = D(a).getTime(); t <= D(b).getTime() && out.length < 100000; t += st) out.push(new Date(t)); return out; },
        age: (birth, on) => { const b = D(birth), n = on === undefined ? new Date() : D(on); let a = n.getUTCFullYear() - b.getUTCFullYear(); if (n.getUTCMonth() < b.getUTCMonth() || (n.getUTCMonth() === b.getUTCMonth() && n.getUTCDate() < b.getUTCDate())) a--; return a; },
        // "3 hours ago", "in 2 days"
        relative: (dt, now) => { const s = (D(dt).getTime() - (now === undefined ? Date.now() : D(now).getTime())) / 1000; const a = Math.abs(s); const units = [[31557600, 'year'], [2629800, 'month'], [604800, 'week'], [86400, 'day'], [3600, 'hour'], [60, 'minute']]; if (a < 45) return 'just now'; for (const [k, name] of units) if (a >= k) { const n = Math.round(a / k); return s < 0 ? n + ' ' + name + (n === 1 ? '' : 's') + ' ago' : 'in ' + n + ' ' + name + (n === 1 ? '' : 's'); } return 'just now'; },
        calendar: (y, m) => { const first = new Date(Date.UTC(y, m - 1, 1)).getUTCDay(); const days = dim(y, m); const title = MONTHS[m - 1] + ' ' + y; const lines = [title.padStart(Math.floor((20 + title.length) / 2)), 'Su Mo Tu We Th Fr Sa']; let row = '   '.repeat(first); for (let d = 1; d <= days; d++) { row += String(d).padStart(2) + ' '; if ((first + d) % 7 === 0) { lines.push(row.trimEnd()); row = ''; } } if (row.trim()) lines.push(row.trimEnd()); return lines.join('\n'); },
        months: () => MONTHS.slice(), days: () => DAYS.slice(),
        components: (dt) => { const d = D(dt); return map({ year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(), hour: d.getUTCHours(), minute: d.getUTCMinutes(), second: d.getUTCSeconds(), weekday: d.getUTCDay() }); },
    };
};

// ---------- std.log ----------
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
export const logModule = () => {
    let level = 20, file = null, color = true, json = false;
    let LoggerT = null;
    const emit = (name, lvl, msg, extra) => {
        if (LEVELS[lvl] < level) return null;
        const fields = extra instanceof Named ? Object.keys(extra.obj).map((k) => k + '=' + (typeof extra.obj[k] === 'string' && /\s/.test(extra.obj[k]) ? repr(extra.obj[k]) : show(extra.obj[k]))).join(' ') : '';
        const ts = new Date().toISOString();
        let line;
        if (json) { const o = { time: ts, level: lvl, msg: show(msg) }; if (name) o.logger = name; if (extra instanceof Named) Object.assign(o, rt.toJS(map(extra.obj))); line = JSON.stringify(o); }
        else {
            const tag = lvl.toUpperCase().padEnd(5);
            const c = { debug: '90', info: '36', warn: '33', error: '31' }[lvl];
            line = ts.slice(11, 19) + ' ' + (color && rt.sys ? '\x1b[' + c + 'm' + tag + '\x1b[0m' : tag) + ' ' + (name ? '[' + name + '] ' : '') + show(msg) + (fields ? '  ' + fields : '');
        }
        rt.ewrite(line + '\n');
        if (file && rt.sys) rt.sys.writeText(file, line.replace(ANSI, '') + '\n', true);
        return null;
    };
    LoggerT = nativeType('Logger', Object.fromEntries(Object.keys(LEVELS).map((l) => [l, (s, a, n) => emit(s.state.name, l, a[0], n || a[1])])), { reprFn: (o) => '<Logger ' + o.state.name + '>' });
    const mod = { set_level: (l) => { if (!(l in LEVELS)) throw rtError('levels: debug, info, warn, error', 'ArgError'); level = LEVELS[l]; return null; }, to_file: (p) => { file = p === null ? null : str(p); return null; }, color: (b) => { color = !!b; return null; }, json: (b) => { json = b !== false; return null; }, logger: (name) => make(LoggerT, { name: show(name) }) };
    for (const l of Object.keys(LEVELS)) mod[l] = (msg, extra) => emit('', l, msg, extra);
    return mod;
};

// ---------- std.cli ----------
export const cliModule = () => ({
    // parse(args, {name: {short: "n", type: "int", default: 1, help: "...", required: true}, verbose: {short: "v", type: "bool"}})
    parse: (args, spec) => {
        const a = args === undefined ? rt.argv : A(args).map(show);
        const specs = spec instanceof SMap ? spec.entries().map(([k, v]) => [String(k), v instanceof SMap ? opts(v) : {}]) : [];
        const byName = new Map(specs), byShort = new Map();
        for (const [k, v] of specs) if (v.short) byShort.set(v.short, k);
        const out = new SMap(), pos = [];
        for (const [k, v] of specs) { if (v.default !== undefined) out.set(k, v.default); else if (v.type === 'bool') out.set(k, false); else if (v.multiple) out.set(k, []); }
        const conv = (k, v, raw) => { const t = v.type || 'str'; if (t === 'int') { const n = Number(raw); if (!Number.isInteger(n)) throw rtError('--' + k + ' needs a whole number but got "' + raw + '"', 'ArgError'); return n; } if (t === 'float' || t === 'num') { const n = Number(raw); if (Number.isNaN(n)) throw rtError('--' + k + ' needs a number but got "' + raw + '"', 'ArgError'); return n; } return raw; };
        const set = (k, v, raw) => { const val = conv(k, v, raw); if (v.multiple) { const cur = out.get(k); (Array.isArray(cur) ? cur : (() => { const n = []; out.set(k, n); return n; })()).push(val); } else out.set(k, val); };
        let i = 0;
        for (; i < a.length; i++) {
            const x = a[i];
            if (x === '--') { pos.push(...a.slice(i + 1)); break; }
            let m;
            if ((m = /^--no-([\w-]+)$/.exec(x)) && byName.has(m[1]) && (byName.get(m[1]).type === 'bool')) { out.set(m[1], false); continue; }
            if ((m = /^--([\w-]+)(?:=(.*))?$/.exec(x))) {
                const k = m[1];
                if (!byName.has(k)) { let best = null, bd = 3; for (const n of byName.keys()) { let d = 0; const l = (p, q) => { const dp = Array.from({ length: p.length + 1 }, (_, r) => [r]); for (let c = 1; c <= q.length; c++) dp[0][c] = c; for (let r = 1; r <= p.length; r++) for (let c = 1; c <= q.length; c++) dp[r][c] = Math.min(dp[r - 1][c] + 1, dp[r][c - 1] + 1, dp[r - 1][c - 1] + (p[r - 1] === q[c - 1] ? 0 : 1)); return dp[p.length][q.length]; }; d = l(k, n); if (d < bd) { bd = d; best = n; } } throw rtError('I do not know the option --' + k + (best ? '. Did you mean --' + best + '?' : ''), 'ArgError'); }
                const v = byName.get(k);
                if (v.type === 'bool') { out.set(k, m[2] === undefined ? true : /^(1|true|yes|on)$/i.test(m[2])); continue; }
                const raw = m[2] !== undefined ? m[2] : a[++i];
                if (raw === undefined) throw rtError('--' + k + ' needs a value', 'ArgError');
                set(k, v, raw); continue;
            }
            if ((m = /^-([A-Za-z]+)$/.exec(x))) {
                const letters = m[1].split('');
                for (let li = 0; li < letters.length; li++) {
                    const k = byShort.get(letters[li]);
                    if (!k) throw rtError('I do not know the option -' + letters[li], 'ArgError');
                    const v = byName.get(k);
                    if (v.type === 'bool') { out.set(k, true); continue; }
                    const rest = letters.slice(li + 1).join('');
                    const raw = rest || a[++i];
                    if (raw === undefined) throw rtError('-' + letters[li] + ' needs a value', 'ArgError');
                    set(k, v, raw); break;
                }
                continue;
            }
            pos.push(x);
        }
        for (const [k, v] of specs) if (v.required && !out.has(k)) throw rtError('The option --' + k + ' is required', 'ArgError');
        out.set('args', pos);
        return out;
    },
    usage: (program, spec, description) => {
        const specs = spec instanceof SMap ? spec.entries().map(([k, v]) => [String(k), v instanceof SMap ? opts(v) : {}]) : [];
        const lines = ['Usage: ' + show(program) + (specs.length ? ' [options]' : '') + ' [args]'];
        if (description) lines.splice(0, 0, show(description), '');
        if (specs.length) { lines.push('', 'Options:'); const rows = specs.map(([k, v]) => [(v.short ? '-' + v.short + ', ' : '    ') + '--' + k + (v.type && v.type !== 'bool' ? ' <' + v.type + '>' : ''), (v.help || '') + (v.default !== undefined && v.type !== 'bool' ? ' (default ' + show(v.default) + ')' : '') + (v.required ? ' (required)' : '')]); const w = Math.max(...rows.map((r) => r[0].length)); for (const [l, r] of rows) lines.push('  ' + l.padEnd(w + 2) + r); }
        return lines.join('\n');
    },
    args: () => rt.argv.slice(),
});

// ---------- std.test ----------
export const testModule = () => ({
    approx: (a, b, eps) => Math.abs(a - b) <= (eps === undefined ? 1e-9 : eps) * Math.max(1, Math.abs(a), Math.abs(b)),
    assert_approx: (a, b, eps) => { if (!(Math.abs(a - b) <= (eps === undefined ? 1e-9 : eps) * Math.max(1, Math.abs(a), Math.abs(b)))) throw new rt.SuaveError('Not close enough: ' + repr(a) + ' and ' + repr(b), 'AssertionError'); return null; },
    fail: (msg) => { throw new rt.SuaveError(show(msg === undefined ? 'Test failed' : msg), 'AssertionError'); },
    assert_contains: (coll, x) => { const has = typeof coll === 'string' ? coll.includes(x) : A(coll).some((y) => eq(x, y)); if (!has) throw new rt.SuaveError(repr(coll) + ' does not contain ' + repr(x), 'AssertionError'); return null; },
    assert_err: (r) => { if (!(r instanceof rt.SVariant && r.v.name === 'Err')) throw new rt.SuaveError('Expected an Err but got ' + repr(r), 'AssertionError'); return null; },
    assert_ok: (r) => { if (!(r instanceof rt.SVariant && r.v.name === 'Ok')) throw new rt.SuaveError('Expected an Ok but got ' + repr(r), 'AssertionError'); return r.vals[0]; },
    assert_type: (x, t) => { if (typeOf(x) !== t) throw new rt.SuaveError('Expected a ' + t + ' but got a ' + typeOf(x), 'AssertionError'); return null; },
    assert_len: (x, n) => { const l = typeof x === 'string' || Array.isArray(x) ? x.length : x.size; if (l !== n) throw new rt.SuaveError('Expected length ' + n + ' but got ' + l, 'AssertionError'); return null; },
    // run f and return the error it throws (or none)
    catch: (f) => { try { cb(f)(); return null; } catch (e) { if (e instanceof rt.SuaveError) return rt.errValue(e); throw e; } },
});

// ---------- std.events ----------
export const eventsModule = () => {
    const EmitterT = nativeType('Emitter', {
        on: (s, a) => { const l = s.state.listeners; if (!l.has(a[0])) l.set(a[0], []); l.get(a[0]).push({ f: a[1], once: false }); return s; },
        once: (s, a) => { const l = s.state.listeners; if (!l.has(a[0])) l.set(a[0], []); l.get(a[0]).push({ f: a[1], once: true }); return s; },
        off: (s, a) => { const arr = s.state.listeners.get(a[0]); if (!arr) return s; s.state.listeners.set(a[0], a[1] === undefined ? [] : arr.filter((x) => x.f !== a[1])); return s; },
        emit: (s, a) => { const arr = (s.state.listeners.get(a[0]) || []).slice(); for (const x of arr) { if (x.once) s.state.listeners.set(a[0], s.state.listeners.get(a[0]).filter((y) => y !== x)); call(x.f, a.slice(1)); } return arr.length; },
        count: (s, a) => (s.state.listeners.get(a[0]) || []).length, names: (s) => Array.from(s.state.listeners.keys()).filter((k) => s.state.listeners.get(k).length),
        clear: (s) => { s.state.listeners.clear(); return s; },
    }, { reprFn: () => '<Emitter>' });
    return { new: () => make(EmitterT, { listeners: new Map() }), emitter: () => make(EmitterT, { listeners: new Map() }) };
};

// ---------- std.storage: a small key-value store (the browser's localStorage, or a .suave-storage.json file) ----------
export const storageModule = () => {
    const FILE = '.suave-storage.json';
    const load = () => { if (typeof localStorage !== 'undefined' && !rt.sys) { const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith('suave:')) o[k.slice(6)] = JSON.parse(localStorage.getItem(k)); } return o; } try { return rt.sys.exists(FILE) ? JSON.parse(rt.sys.readText(FILE)) : {}; } catch (e) { return {}; } };
    const save = (o) => { if (typeof localStorage !== 'undefined' && !rt.sys) return; rt.sys.writeText(FILE, JSON.stringify(o, null, 2)); };
    return {
        get: (k, d) => { const o = load(); return Object.prototype.hasOwnProperty.call(o, k) ? rt.fromJS(o[k]) : (d === undefined ? null : d); },
        set: (k, v) => { if (typeof localStorage !== 'undefined' && !rt.sys) { localStorage.setItem('suave:' + k, JSON.stringify(rt.toJS(v))); return null; } const o = load(); o[k] = rt.toJS(v); save(o); return null; },
        remove: (k) => { if (typeof localStorage !== 'undefined' && !rt.sys) { localStorage.removeItem('suave:' + k); return null; } const o = load(); delete o[k]; save(o); return null; },
        has: (k) => Object.prototype.hasOwnProperty.call(load(), k), keys: () => Object.keys(load()).sort(),
        clear: () => { if (typeof localStorage !== 'undefined' && !rt.sys) { for (const k of Object.keys(load())) localStorage.removeItem('suave:' + k); return null; } save({}); return null; },
    };
};
