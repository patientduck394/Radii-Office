/* std.laker: talk to the desktop shell from a page that runs inside a Laker app (see src/laker.js).
     use std.laker
     greeting = await laker.invoke("greet", {name: "Ada"})     # runs  def greet(name):  from backend.sv
   Outside a Laker window these calls fail with a clear message, so the same page still works in a normal browser for everything else. */
import rt from '../runtime.js';
import { toJs } from './jsmod.js';

const need = () => { if (typeof fetch === 'undefined' || typeof location === 'undefined') throw rt.rtError('std.laker works inside a Laker app window (laker dev, or a built app)', 'EnvError'); };
async function call(path, body) {
    need();
    const res = await fetch('/__laker/' + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body === undefined ? {} : body) });
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok || (data && data.error)) throw rt.rtError((data && data.error) || ('Laker said ' + res.status + '. Is this page running inside a Laker app?'), 'LakerError');
    return rt.fromJS(data ? data.value : null);
}
export const lakerModule = () => ({
    // invoke("name", {key: value}) or invoke("name", [a, b]): runs a function from backend.sv and gives back its answer
    invoke: (name, args) => call('invoke/' + encodeURIComponent(String(name)), { args: toJs(args === undefined ? null : args) }),
    info: () => call('info'),
    quit: () => call('quit'),
    open_url: (url) => call('open-url', { url: String(url) }),
    // a native file picker (the app's backend asks the operating system)
    pick_file: (prompt) => call('pick-file', { prompt: prompt === undefined ? 'Choose a file' : String(prompt) }),
    pick_save: (name) => call('pick-save', { name: name === undefined ? 'untitled' : String(name) }),
    read_file: (path) => call('read-file', { path: String(path) }),
    write_file: (path, text) => call('write-file', { path: String(path), text: String(text) }),
    is_desktop: () => typeof location !== 'undefined' && location.search.indexOf('laker') >= 0 || (typeof window !== 'undefined' && window.__laker === true),
});
