/* std.json, std.yaml, std.toml, std.suvl, std.csv and std.data: reading and writing data in every format. */
import * as json from '../formats/json.js';
import * as yaml from '../formats/yaml.js';
import * as toml from '../formats/toml.js';
import * as suvl from '../formats/suvl.js';
import * as csv from '../formats/csv.js';
import { rt, opts, str, SMap, ok, err, rtError, show, tuple } from './_util.js';

const KINDS = { json, yaml, yml: yaml, toml, suvl, csv, tsv: csv, jsonl: json };
const extOf = (p) => { const m = /\.([A-Za-z0-9]+)$/.exec(p); return m ? m[1].toLowerCase() : ''; };

// build one module for a format. read/write use files (terminal only).
function formatModule(name, f, extra) {
    const parse = (text, o) => f.parse(str(text, name + '.parse'), opts(o));
    const stringify = (v, o) => f.stringify(v, opts(o));
    return Object.assign({
        parse,
        stringify,
        // try_parse gives an Ok/Err result instead of an error
        try_parse: (text, o) => { try { return ok(parse(text, o)); } catch (e) { if (e instanceof rt.SuaveError) return err(e.message); throw e; } },
        valid: (text, o) => { try { parse(text, o); return true; } catch (e) { if (e instanceof rt.SuaveError) return false; throw e; } },
        read: (path, o) => parse(rt.needSys(name + '.read').readText(str(path, name + '.read')), o),
        write: (path, v, o) => { rt.needSys(name + '.write').writeText(str(path, name + '.write'), stringify(v, o)); return null; },
        pretty: (v, o) => stringify(v, o),
    }, extra || {});
}

export const jsonModule = () => formatModule('json', json, {
    parse_lines: (text, o) => json.parseLines(str(text, 'json.parse_lines'), opts(o)),
    stringify_lines: (items, o) => rt.toArray(items).map((x) => json.stringify(x, opts(o))).join('\n') + '\n',
    compact: (v) => json.stringify(v, {}),
    pretty: (v, o) => json.stringify(v, Object.assign({ indent: 2 }, opts(o))),
    minify: (text) => json.stringify(json.parse(str(text, 'json.minify'), { lenient: true }), {}),
});
export const yamlModule = () => formatModule('yaml', yaml, { parse_all: (text, o) => yaml.parse(str(text, 'yaml.parse_all'), Object.assign({}, opts(o), { all: true })) });
export const tomlModule = () => formatModule('toml', toml);
export const suvlModule = () => formatModule('suvl', suvl, {
    parse_raw: (text) => suvl.parse(str(text, 'suvl.parse_raw'), { raw: true }),
});
export const csvModule = () => formatModule('csv', csv, {
    parse_rows: (text, o) => csv.parse(str(text, 'csv.parse_rows'), Object.assign({}, opts(o), { header: false })),
    tsv: { parse: (text, o) => csv.parse(str(text), Object.assign({ sep: '\t' }, opts(o))), stringify: (rows, o) => csv.stringify(rows, Object.assign({ sep: '\t' }, opts(o))) },
});

export const dataModule = () => {
    const pick = (kind) => { const f = KINDS[String(kind).toLowerCase()]; if (!f) throw rtError('I do not know the format "' + kind + '". Use json, yaml, toml, suvl or csv', 'ArgError'); return f; };
    const sepFor = (k) => (String(k).toLowerCase() === 'tsv' ? { sep: '\t' } : {});
    return {
        formats: () => ['json', 'yaml', 'toml', 'suvl', 'csv'],
        // data.convert(text, "yaml", "json", indent: 2)
        convert: (text, from, to, o) => {
            const v = pick(from).parse(str(text, 'data.convert'), Object.assign(sepFor(from), { lenient: true }));
            return pick(to).stringify(v, Object.assign({ indent: 2 }, sepFor(to), opts(o)));
        },
        parse: (text, kind, o) => pick(kind).parse(str(text, 'data.parse'), Object.assign(sepFor(kind), opts(o))),
        stringify: (v, kind, o) => pick(kind).stringify(v, Object.assign({}, sepFor(kind), opts(o))),
        // data.load("config.toml") picks the format from the file name
        load: (path, o) => { const f = pick(extOf(str(path, 'data.load'))); return f.parse(rt.needSys('data.load').readText(path), Object.assign(sepFor(extOf(path)), opts(o))); },
        save: (path, v, o) => { const f = pick(extOf(str(path, 'data.save'))); rt.needSys('data.save').writeText(path, f.stringify(v, Object.assign({ indent: 2 }, sepFor(extOf(path)), opts(o)))); return null; },
        detect: (text) => {
            const t = str(text, 'data.detect').trim();
            for (const k of ['json', 'toml', 'suvl', 'yaml']) { try { KINDS[k].parse(t, k === 'json' ? {} : {}); if (k === 'json' && !/^[\[{"\d-]|^(true|false|null)/.test(t)) continue; return k; } catch (e) { /* try the next */ } }
            return null;
        },
    };
};
export { show, tuple, SMap };
