/* std.table (data frames), std.plot (charts in text and SVG), std.geometry, std.xml, std.ini. */
import { rt, SMap, SSet, SObj, Tuple, tuple, SRange, SIter, Named, opts, num, nums, list, cb, call, map, nativeType, make, rtError, show, repr, eq, truthy, typeOf, ok, err, toArray, iterate, keyOf, str } from './_util.js';
import * as csv from '../formats/csv.js';

const A = (x) => toArray(x);
const rcmp = (a, b) => rt.cmp(a, b);

// ---------- std.table: rows of named columns, like a spreadsheet or a data frame ----------
const num0 = (v) => (typeof v === 'number' ? v : Number(v));
const AGG = {
    sum: (v) => v.reduce((a, b) => a + num0(b), 0), count: (v) => v.length, mean: (v) => (v.length ? v.reduce((a, b) => a + num0(b), 0) / v.length : null),
    min: (v) => (v.length ? v.reduce((a, b) => (rcmp(b, a) < 0 ? b : a)) : null), max: (v) => (v.length ? v.reduce((a, b) => (rcmp(b, a) > 0 ? b : a)) : null),
    first: (v) => (v.length ? v[0] : null), last: (v) => (v.length ? v[v.length - 1] : null), list: (v) => v, unique: (v) => new SSet(v).values(), n_unique: (v) => new SSet(v).size,
    median: (v) => { const s = v.map(num0).sort((a, b) => a - b); if (!s.length) return null; const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; },
    std: (v) => { const x = v.map(num0); if (x.length < 2) return null; const m = x.reduce((a, b) => a + b, 0) / x.length; return Math.sqrt(x.reduce((a, b) => a + (b - m) ** 2, 0) / (x.length - 1)); },
    product: (v) => v.reduce((a, b) => a * num0(b), 1),
};
export const tableModule = () => {
    const rowsOf = (t) => t.state.rows;
    const mk = (rows, cols) => { const t = make(TableT, { rows, cols: cols || colsFrom(rows) }); return t; };
    const colsFrom = (rows) => { const seen = new Set(); const cols = []; for (const r of rows) for (const k of r.keys()) if (!seen.has(k)) { seen.add(k); cols.push(k); } return cols; };
    const get = (r, c) => { const v = r.get(c); return v === undefined ? null : v; };
    const colList = (t, c) => rowsOf(t).map((r) => get(r, c));
    const text = (t, max) => {
        const rows = rowsOf(t), cols = t.state.cols;
        const shown = rows.slice(0, max === undefined ? 20 : max);
        const cells = shown.map((r) => cols.map((c) => { const v = get(r, c); return typeof v === 'number' ? String(+v.toFixed(6)) : show(v); }));
        const widths = cols.map((c, i) => Math.max(show(c).length, ...cells.map((r) => r[i].length)));
        const isNum = cols.map((c, i) => shown.length > 0 && shown.every((r) => typeof get(r, c) === 'number' || get(r, c) === null));
        const line = (r) => '│ ' + r.map((x, i) => (isNum[i] ? x.padStart(widths[i]) : x.padEnd(widths[i]))).join(' │ ') + ' │';
        const rule = (l, m, r) => l + widths.map((w) => '─'.repeat(w + 2)).join(m) + r;
        const out = [rule('┌', '┬', '┐'), '│ ' + cols.map((c, i) => show(c).padEnd(widths[i])).join(' │ ') + ' │', rule('├', '┼', '┤')].concat(cells.map(line));
        out.push(rule('└', '┴', '┘'));
        if (rows.length > shown.length) out.push('… ' + (rows.length - shown.length) + ' more rows (' + rows.length + ' total)');
        return out.join('\n');
    };
    const sortRows = (rows, keys, desc) => rows.map((r, i) => [r, i]).sort((x, y) => { for (const k of keys) { const a = get(x[0], k), b = get(y[0], k); if (a === null && b !== null) return 1; if (b === null && a !== null) return -1; const c = rcmp(a, b); if (c) return desc ? -c : c; } return x[1] - y[1]; }).map((p) => p[0]);
    const aggregate = (rows, spec) => { const out = new SMap(); for (const [name, def] of (spec instanceof SMap ? spec.entries() : Object.entries(spec))) { const [col, fn] = Array.from(def); const f = typeof fn === 'string' ? AGG[fn] : null; if (!f && typeof fn === 'string') throw rtError('I do not know the summary "' + fn + '". Use ' + Object.keys(AGG).join(', '), 'ArgError'); const vals = col === '*' ? rows : rows.map((r) => get(r, col)).filter((v) => v !== null); out.set(name, f ? f(vals) : call(fn, [vals])); } return out; };
    const TableT = nativeType('Table', {
        len: (t) => rowsOf(t).length, size: (t) => rowsOf(t).length, is_empty: (t) => rowsOf(t).length === 0,
        rows: (t) => rowsOf(t).map((r) => new SMap(r.entries())), cols: (t) => t.state.cols.slice(), columns: (t) => t.state.cols.slice(),
        col: (t, a) => { if (!t.state.cols.some((c) => eq(c, a[0]))) throw rtError('The table has no column "' + show(a[0]) + '". It has: ' + t.state.cols.map(show).join(', '), 'NameError'); return colList(t, a[0]); },
        row: (t, a) => { const r = rowsOf(t)[a[0] < 0 ? rowsOf(t).length + a[0] : a[0]]; return r ? new SMap(r.entries()) : null; },
        get: (t, a) => { const r = rowsOf(t)[a[0]]; return r ? new SMap(r.entries()) : null; },
        select: (t, a) => { const cols = a.length === 1 && Array.isArray(a[0]) ? a[0] : a; return mk(rowsOf(t).map((r) => { const m = new SMap(); for (const c of cols) m.set(c, get(r, c)); return m; }), cols.slice()); },
        drop: (t, a) => { const dr = new SSet(a.length === 1 && Array.isArray(a[0]) ? a[0] : a); return mk(rowsOf(t).map((r) => { const m = new SMap(); for (const [k, v] of r.entries()) if (!dr.has(k)) m.set(k, v); return m; }), t.state.cols.filter((c) => !dr.has(c))); },
        rename: (t, a) => { const m = a[0]; const re = (c) => (m.has(c) ? m.get(c) : c); return mk(rowsOf(t).map((r) => { const n = new SMap(); for (const [k, v] of r.entries()) n.set(re(k), v); return n; }), t.state.cols.map(re)); },
        // where(|row| row.age > 30)
        where: (t, a) => { const f = cb(a[0]); return mk(rowsOf(t).filter((r) => truthy(f(r))), t.state.cols); },
        filter: (t, a) => { const f = cb(a[0]); return mk(rowsOf(t).filter((r) => truthy(f(r))), t.state.cols); },
        sort_by: (t, a, n) => { const o = opts(n || (a[1] instanceof SMap ? a[1] : undefined)); const keys = Array.isArray(a[0]) ? a[0] : [a[0]]; return mk(sortRows(rowsOf(t), keys, !!o.desc), t.state.cols); },
        head: (t, a) => mk(rowsOf(t).slice(0, a.length ? a[0] : 5), t.state.cols), tail: (t, a) => mk(rowsOf(t).slice(-(a.length ? a[0] : 5)), t.state.cols),
        slice: (t, a) => mk(rowsOf(t).slice(a[0], a[1]), t.state.cols),
        // add_col("total", |row| row.price * row.qty)
        add_col: (t, a) => { const f = cb(a[1]); const name = a[0]; const rows = rowsOf(t).map((r) => { const m = new SMap(r.entries()); m.set(name, f(r)); return m; }); return mk(rows, t.state.cols.some((c) => eq(c, name)) ? t.state.cols : t.state.cols.concat([name])); },
        map_col: (t, a) => { const f = cb(a[1]); return mk(rowsOf(t).map((r) => { const m = new SMap(r.entries()); m.set(a[0], f(get(r, a[0]))); return m; }), t.state.cols); },
        // group_by("city", total: ["amount", "sum"], n: ["*", "count"])  or group_by(["a", "b"], aggs_map)
        group_by: (t, a, named) => { const keys = Array.isArray(a[0]) ? a[0] : [a[0]]; const spec = named ? named.obj || named : (a[1] instanceof SMap ? a[1] : {}); const groups = new Map(); for (const r of rowsOf(t)) { const id = keyOf(tuple(keys.map((k) => get(r, k)))); if (!groups.has(id)) groups.set(id, { first: r, rows: [] }); groups.get(id).rows.push(r); } const rows = []; for (const g of groups.values()) { const m = new SMap(); for (const k of keys) m.set(k, get(g.first, k)); const specEntries = spec instanceof SMap ? spec : map(spec); const out = aggregate(g.rows, specEntries); for (const [k, v] of out.entries()) m.set(k, v); if (!out.size) m.set('count', g.rows.length); rows.push(m); } return mk(rows, keys.concat(spec instanceof SMap ? spec.keys() : Object.keys(spec)).concat(!(spec instanceof SMap ? spec.size : Object.keys(spec).length) ? ['count'] : [])); },
        // summarize(total: ["amount", "sum"]) over the whole table -> a map
        summarize: (t, a, named) => aggregate(rowsOf(t), named ? map(named.obj || named) : a[0]),
        join: (t, a, named) => { const other = a[0], on = a[1]; const o = opts(named || a[2]); const kind = o.kind || 'inner'; const keys = Array.isArray(on) ? on : [on]; const idx = new Map(); for (const r of rowsOf(other)) { const id = keyOf(tuple(keys.map((k) => get(r, k)))); if (!idx.has(id)) idx.set(id, []); idx.get(id).push(r); } const out = []; const extra = other.state.cols.filter((c) => !keys.some((k) => eq(k, c))); for (const r of rowsOf(t)) { const id = keyOf(tuple(keys.map((k) => get(r, k)))); const ms = idx.get(id); if (ms) for (const m of ms) { const n = new SMap(r.entries()); for (const c of extra) n.set(t.state.cols.some((x) => eq(x, c)) ? show(c) + '_2' : c, get(m, c)); out.push(n); } else if (kind === 'left') { const n = new SMap(r.entries()); for (const c of extra) n.set(c, null); out.push(n); } } return mk(out); },
        concat: (t, a) => mk(rowsOf(t).concat(...a.map((o) => rowsOf(o)))),
        unique: (t, a) => { if (a.length) { const seen = new SSet(); const out = []; for (const r of rowsOf(t)) { const v = get(r, a[0]); if (!seen.has(v)) { seen.add(v); out.push(v); } } return out; } const seen = new SSet(); return mk(rowsOf(t).filter((r) => { const k = tuple(t.state.cols.map((c) => get(r, c))); if (seen.has(k)) return false; seen.add(k); return true; }), t.state.cols); },
        value_counts: (t, a) => { const m = new SMap(); for (const v of colList(t, a[0])) m.set(v, (m.get(v) || 0) + 1); return mk(m.entries().sort((x, y) => y[1] - x[1]).map(([k, v]) => { const r = new SMap(); r.set(a[0], k); r.set('count', v); return r; }), [a[0], 'count']); },
        sum: (t, a) => AGG.sum(colList(t, a[0]).filter((v) => v !== null)), mean: (t, a) => AGG.mean(colList(t, a[0]).filter((v) => v !== null)), min: (t, a) => AGG.min(colList(t, a[0]).filter((v) => v !== null)), max: (t, a) => AGG.max(colList(t, a[0]).filter((v) => v !== null)), median: (t, a) => AGG.median(colList(t, a[0]).filter((v) => v !== null)),
        count: (t, a) => (a.length ? colList(t, a[0]).filter((v) => v !== null).length : rowsOf(t).length),
        describe: (t) => { const rows = []; for (const c of t.state.cols) { const v = colList(t, c).filter((x) => typeof x === 'number'); if (!v.length) continue; const m = new SMap(); m.set('column', c); m.set('count', v.length); m.set('mean', AGG.mean(v)); m.set('std', AGG.std(v)); m.set('min', AGG.min(v)); m.set('median', AGG.median(v)); m.set('max', AGG.max(v)); rows.push(m); } return mk(rows, ['column', 'count', 'mean', 'std', 'min', 'median', 'max']); },
        fill_none: (t, a) => mk(rowsOf(t).map((r) => { const m = new SMap(r.entries()); if (a.length > 1) { if (get(m, a[0]) === null) m.set(a[0], a[1]); } else for (const c of t.state.cols) if (get(m, c) === null) m.set(c, a[0]); return m; }), t.state.cols),
        drop_none: (t) => mk(rowsOf(t).filter((r) => t.state.cols.every((c) => get(r, c) !== null)), t.state.cols),
        sample: (t, a) => { const rows = rowsOf(t).slice(); for (let i = rows.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [rows[i], rows[j]] = [rows[j], rows[i]]; } return mk(rows.slice(0, a[0]), t.state.cols); },
        to_csv: (t, a, n) => csv.stringify(rowsOf(t), Object.assign({ columns: t.state.cols }, opts(n))),
        to_list: (t) => rowsOf(t).map((r) => new SMap(r.entries())), to_text: (t, a) => text(t, a[0]), print: (t, a) => { rt.write(text(t, a[0]) + '\n'); return null; },
        transpose_cols: (t) => { const m = new SMap(); for (const c of t.state.cols) m.set(c, colList(t, c)); return m; },
        pluck: (t, a) => colList(t, a[0]),
        corr: (t, a) => { const x = colList(t, a[0]).map(Number), y = colList(t, a[1]).map(Number); const mx = x.reduce((p, q) => p + q, 0) / x.length, my = y.reduce((p, q) => p + q, 0) / y.length; let n = 0, dx = 0, dy = 0; for (let i = 0; i < x.length; i++) { n += (x[i] - mx) * (y[i] - my); dx += (x[i] - mx) ** 2; dy += (y[i] - my) ** 2; } return n / Math.sqrt(dx * dy); },
        each: (t, a) => { const f = cb(a[0]); for (const r of rowsOf(t)) f(r); return null; },
        map: (t, a) => { const f = cb(a[0]); return rowsOf(t).map((r) => f(r)); },
    }, { reprFn: (t) => text(t, 8), nativeIter: (t) => rowsOf(t).map((r) => new SMap(r.entries())) });
    const toRows = (data) => A(data).map((r) => { if (r instanceof SMap) return new SMap(r.entries()); if (r instanceof SObj) return new SMap(Object.keys(r.f).map((k) => [k, r.f[k]])); throw rtError('A table is made from a list of maps', 'TypeError'); });
    return {
        new: (data) => mk(data === undefined ? [] : toRows(data)),
        from: (data) => mk(toRows(data)),
        from_columns: (m) => { const cols = m.keys(); const n = Math.max(0, ...m.values().map((v) => A(v).length)); const rows = []; for (let i = 0; i < n; i++) { const r = new SMap(); for (const c of cols) r.set(c, A(m.get(c))[i] === undefined ? null : A(m.get(c))[i]); rows.push(r); } return mk(rows, cols); },
        from_csv: (text, o) => mk(csv.parse(str(text, 'table.from_csv'), Object.assign({ infer: true }, opts(o)))),
        read_csv: (path, o) => mk(csv.parse(rt.needSys('table.read_csv').readText(str(path)), Object.assign({ infer: true }, opts(o)))),
        write_csv: (t, path) => { rt.needSys('table.write_csv').writeText(str(path), csv.stringify(rowsOf(t), { columns: t.state.cols })); return null; },
    };
};

// ---------- std.plot: charts in the terminal, and SVG for pages ----------
const BLOCKS = ['▁', '▂', '▃', '▄', '▅', '▆', '▇', '█'];
export const plotModule = () => {
    const pairs = (data) => (data instanceof SMap ? data.entries() : A(data).map((x) => (Array.isArray(x) ? x : tuple([String(x), x]))));
    const svgWrap = (w, h, body, title) => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '" font-family="system-ui, sans-serif" font-size="12">' + '<rect width="100%" height="100%" fill="#fff"/>' + (title ? '<text x="' + w / 2 + '" y="18" text-anchor="middle" font-weight="bold" font-size="14">' + String(title).replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</text>' : '') + body + '</svg>';
    const PAL = ['#2563eb', '#f97316', '#16a34a', '#dc2626', '#9333ea', '#0891b2', '#ca8a04', '#db2777'];
    const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    return {
        sparkline: (xs) => { const a = nums(xs); const lo = Math.min(...a), hi = Math.max(...a); return a.map((v) => BLOCKS[hi === lo ? 3 : Math.min(7, Math.floor(((v - lo) / (hi - lo)) * 8))]).join(''); },
        // bar({a: 3, b: 5}) or bar([("a", 3), ("b", 5)], width: 30): horizontal bars
        bar: (data, o) => { const p = pairs(data); const op = opts(o); const w = op.width || 40; const max = Math.max(...p.map((x) => x[1]), 1e-9); const lw = Math.max(...p.map((x) => show(x[0]).length)); return p.map(([k, v]) => show(k).padEnd(lw) + ' │' + '█'.repeat(Math.round((v / max) * w)) + ' ' + (Number.isInteger(v) ? v : +v.toFixed(2))).join('\n'); },
        column: (data, o) => { const p = pairs(data); const op = opts(o); const h = op.height || 10; const max = Math.max(...p.map((x) => x[1]), 1e-9); const rows = []; for (let r = h; r >= 1; r--) rows.push(p.map(([, v]) => ((v / max) * h >= r - 0.25 ? ' ██ ' : '    ')).join('')); rows.push(p.map(([k]) => show(k).slice(0, 3).padStart(2).padEnd(4)).join('')); return rows.join('\n'); },
        histogram: (xs, o) => { const a = nums(xs); const op = opts(o); const bins = op.bins || 10; const lo = Math.min(...a), hi = Math.max(...a); const w = (hi - lo) / bins || 1; const c = new Array(bins).fill(0); for (const v of a) c[Math.min(bins - 1, Math.floor((v - lo) / w))]++; const max = Math.max(...c); const width = op.width || 40; return c.map((n, i) => (lo + i * w).toFixed(2).padStart(8) + ' │' + '█'.repeat(Math.round((n / max) * width)) + ' ' + n).join('\n'); },
        // line(values, width: 60, height: 12) draws a curve with dots
        line: (xs, o) => { const a = nums(xs); const op = opts(o); const w = op.width || Math.min(60, a.length), h = op.height || 12; const lo = Math.min(...a), hi = Math.max(...a); const grid = Array.from({ length: h }, () => new Array(w).fill(' ')); for (let x = 0; x < w; x++) { const v = a[Math.min(a.length - 1, Math.round((x / Math.max(1, w - 1)) * (a.length - 1)))]; const y = hi === lo ? h >> 1 : Math.round(((v - lo) / (hi - lo)) * (h - 1)); grid[h - 1 - y][x] = '●'; } return grid.map((r, i) => ((i === 0 ? hi.toFixed(1) : i === h - 1 ? lo.toFixed(1) : '').padStart(8)) + ' │' + r.join('')).join('\n') + '\n' + ' '.repeat(9) + '└' + '─'.repeat(w); },
        scatter: (points, o) => { const pts = A(points); const op = opts(o); const w = op.width || 50, h = op.height || 16; const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]); const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys); const grid = Array.from({ length: h }, () => new Array(w).fill(' ')); for (const [x, y] of pts) { const gx = x1 === x0 ? 0 : Math.round(((x - x0) / (x1 - x0)) * (w - 1)), gy = y1 === y0 ? 0 : Math.round(((y - y0) / (y1 - y0)) * (h - 1)); grid[h - 1 - gy][gx] = '•'; } return grid.map((r, i) => ((i === 0 ? y1.toFixed(1) : i === h - 1 ? y0.toFixed(1) : '').padStart(8)) + ' │' + r.join('')).join('\n') + '\n' + ' '.repeat(9) + '└' + '─'.repeat(w) + '\n' + ' '.repeat(9) + x0.toFixed(1) + ' '.repeat(Math.max(1, w - 8)) + x1.toFixed(1); },
        pie: (data) => { const p = pairs(data); const total = p.reduce((s, x) => s + x[1], 0); return p.map(([k, v]) => show(k).padEnd(Math.max(...p.map((x) => show(x[0]).length))) + ' ' + '▓'.repeat(Math.round((v / total) * 30)).padEnd(30, '░') + ' ' + ((v / total) * 100).toFixed(1) + '%').join('\n'); },
        heatmap: (rows) => { const a = A(rows).map(A); const flat = a.flat(); const lo = Math.min(...flat), hi = Math.max(...flat); const shades = ' ░▒▓█'; return a.map((r) => r.map((v) => { const s = shades[hi === lo ? 2 : Math.min(4, Math.floor(((v - lo) / (hi - lo)) * 5))]; return s + s; }).join('')).join('\n'); },
        // SVG strings: save them with fs.write("chart.svg", plot.svg_bar(...))
        svg_bar: (data, o) => { const p = pairs(data); const op = opts(o); const w = op.width || 480, h = op.height || 300, m = 40; const max = Math.max(...p.map((x) => x[1]), 1e-9); const bw = (w - m * 2) / p.length; let body = '<line x1="' + m + '" y1="' + (h - m) + '" x2="' + (w - m / 2) + '" y2="' + (h - m) + '" stroke="#999"/>'; p.forEach(([k, v], i) => { const bh = (v / max) * (h - m * 2); body += '<rect x="' + (m + i * bw + bw * 0.1) + '" y="' + (h - m - bh) + '" width="' + bw * 0.8 + '" height="' + bh + '" fill="' + (op.color || PAL[0]) + '" rx="3"/><text x="' + (m + i * bw + bw / 2) + '" y="' + (h - m + 16) + '" text-anchor="middle">' + esc(show(k)) + '</text><text x="' + (m + i * bw + bw / 2) + '" y="' + (h - m - bh - 5) + '" text-anchor="middle" font-size="11">' + (Number.isInteger(v) ? v : +v.toFixed(2)) + '</text>'; }); return svgWrap(w, h, body, op.title); },
        svg_line: (series, o) => { const op = opts(o); const w = op.width || 480, h = op.height || 300, m = 40; const list2 = A(series).length && Array.isArray(A(series)[0]) && typeof A(series)[0][0] !== 'number' ? A(series) : [A(series)]; const all = list2.flat().map((v) => (Array.isArray(v) ? v[1] : v)); const lo = Math.min(...all), hi = Math.max(...all); let body = '<line x1="' + m + '" y1="' + (h - m) + '" x2="' + (w - m / 2) + '" y2="' + (h - m) + '" stroke="#999"/><line x1="' + m + '" y1="' + m / 2 + '" x2="' + m + '" y2="' + (h - m) + '" stroke="#999"/>'; list2.forEach((s, si) => { const pts = s.map((v, i) => { const y = Array.isArray(v) ? v[1] : v; const x = Array.isArray(v) ? v[0] : i; return [x, y]; }); const x0 = Math.min(...pts.map((p) => p[0])), x1 = Math.max(...pts.map((p) => p[0])); const d = pts.map((p, i) => (i ? 'L' : 'M') + (m + (x1 === x0 ? 0 : ((p[0] - x0) / (x1 - x0)) * (w - m * 1.5))).toFixed(1) + ' ' + (h - m - (hi === lo ? 0 : ((p[1] - lo) / (hi - lo)) * (h - m * 1.5))).toFixed(1)).join(' '); body += '<path d="' + d + '" fill="none" stroke="' + PAL[si % PAL.length] + '" stroke-width="2"/>'; }); body += '<text x="' + (m - 5) + '" y="' + (m / 2 + 4) + '" text-anchor="end">' + +hi.toFixed(2) + '</text><text x="' + (m - 5) + '" y="' + (h - m) + '" text-anchor="end">' + +lo.toFixed(2) + '</text>'; return svgWrap(w, h, body, op.title); },
        svg_pie: (data, o) => { const p = pairs(data); const op = opts(o); const w = op.width || 360, h = op.height || 300; const total = p.reduce((s, x) => s + x[1], 0); const cx = w / 2, cy = h / 2 + 8, r = Math.min(w, h) / 2 - 40; let ang = -Math.PI / 2; let body = ''; p.forEach(([k, v], i) => { const a2 = ang + (v / total) * Math.PI * 2; const large = a2 - ang > Math.PI ? 1 : 0; body += '<path d="M' + cx + ' ' + cy + ' L' + (cx + r * Math.cos(ang)).toFixed(1) + ' ' + (cy + r * Math.sin(ang)).toFixed(1) + ' A' + r + ' ' + r + ' 0 ' + large + ' 1 ' + (cx + r * Math.cos(a2)).toFixed(1) + ' ' + (cy + r * Math.sin(a2)).toFixed(1) + ' Z" fill="' + PAL[i % PAL.length] + '"/>'; const mid = (ang + a2) / 2; body += '<text x="' + (cx + (r + 16) * Math.cos(mid)).toFixed(1) + '" y="' + (cy + (r + 16) * Math.sin(mid)).toFixed(1) + '" text-anchor="middle">' + esc(show(k)) + '</text>'; ang = a2; }); return svgWrap(w, h, body, op.title); },
        svg_scatter: (points, o) => { const op = opts(o); const w = op.width || 480, h = op.height || 300, m = 40; const pts = A(points); const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]); const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys); let body = '<line x1="' + m + '" y1="' + (h - m) + '" x2="' + (w - m / 2) + '" y2="' + (h - m) + '" stroke="#999"/><line x1="' + m + '" y1="' + m / 2 + '" x2="' + m + '" y2="' + (h - m) + '" stroke="#999"/>'; for (const [x, y] of pts) body += '<circle cx="' + (m + (x1 === x0 ? 0 : ((x - x0) / (x1 - x0)) * (w - m * 1.5))).toFixed(1) + '" cy="' + (h - m - (y1 === y0 ? 0 : ((y - y0) / (y1 - y0)) * (h - m * 1.5))).toFixed(1) + '" r="4" fill="' + PAL[0] + '" fill-opacity="0.7"/>'; return svgWrap(w, h, body, op.title); },
    };
};

// ---------- std.geometry ----------
export const geometryModule = () => {
    const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
    const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const area = (poly) => { const p = A(poly); let s = 0; for (let i = 0; i < p.length; i++) { const q = p[(i + 1) % p.length]; s += p[i][0] * q[1] - q[0] * p[i][1]; } return Math.abs(s) / 2; };
    const seg = (p1, p2, p3, p4) => { const d1 = cross(p3, p4, p1), d2 = cross(p3, p4, p2), d3 = cross(p1, p2, p3), d4 = cross(p1, p2, p4); return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0)); };
    return {
        distance: dist, distance3: (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]), manhattan: (a, b) => Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]),
        midpoint: (a, b) => tuple([(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]), angle: (a, b) => (Math.atan2(b[1] - a[1], b[0] - a[0]) * 180) / Math.PI,
        rotate: (p, deg, origin) => { const o = origin || [0, 0]; const r = (deg * Math.PI) / 180; const dx = p[0] - o[0], dy = p[1] - o[1]; return tuple([o[0] + dx * Math.cos(r) - dy * Math.sin(r), o[1] + dx * Math.sin(r) + dy * Math.cos(r)]); },
        polygon_area: area, polygon_perimeter: (poly) => { const p = A(poly); return p.reduce((s, a, i) => s + dist(a, p[(i + 1) % p.length]), 0); },
        centroid: (poly) => { const p = A(poly); return tuple([p.reduce((s, a) => s + a[0], 0) / p.length, p.reduce((s, a) => s + a[1], 0) / p.length]); },
        bounding_box: (pts) => { const p = A(pts); const xs = p.map((a) => a[0]), ys = p.map((a) => a[1]); return map({ min_x: Math.min(...xs), min_y: Math.min(...ys), max_x: Math.max(...xs), max_y: Math.max(...ys) }); },
        convex_hull: (pts) => { const p = A(pts).map((a) => [a[0], a[1]]).sort((a, b) => a[0] - b[0] || a[1] - b[1]); if (p.length < 3) return p.map(tuple); const lo = []; for (const a of p) { while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], a) <= 0) lo.pop(); lo.push(a); } const up = []; for (const a of p.slice().reverse()) { while (up.length >= 2 && cross(up[up.length - 2], up[up.length - 1], a) <= 0) up.pop(); up.push(a); } return lo.slice(0, -1).concat(up.slice(0, -1)).map(tuple); },
        point_in_polygon: (pt, poly) => { const p = A(poly); let inside = false; for (let i = 0, j = p.length - 1; i < p.length; j = i++) { if ((p[i][1] > pt[1]) !== (p[j][1] > pt[1]) && pt[0] < ((p[j][0] - p[i][0]) * (pt[1] - p[i][1])) / (p[j][1] - p[i][1]) + p[i][0]) inside = !inside; } return inside; },
        segments_intersect: seg,
        line_intersection: (p1, p2, p3, p4) => { const d = (p1[0] - p2[0]) * (p3[1] - p4[1]) - (p1[1] - p2[1]) * (p3[0] - p4[0]); if (d === 0) return null; const t = ((p1[0] - p3[0]) * (p3[1] - p4[1]) - (p1[1] - p3[1]) * (p3[0] - p4[0])) / d; return tuple([p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1])]); },
        triangle_area: (a, b, c) => Math.abs(cross(a, b, c)) / 2, circle_area: (r) => Math.PI * r * r, circle_circumference: (r) => 2 * Math.PI * r, sphere_volume: (r) => (4 / 3) * Math.PI * r ** 3,
        rect_overlap: (a, b) => a[0] < b[0] + b[2] && a[0] + a[2] > b[0] && a[1] < b[1] + b[3] && a[1] + a[3] > b[1],
        haversine: (lat1, lon1, lat2, lon2) => { const R = 6371.0088, r = Math.PI / 180; const dLat = (lat2 - lat1) * r, dLon = (lon2 - lon1) * r; const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLon / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(a)); },
        closest_pair: (pts) => { const p = A(pts); let best = Infinity, pair = null; for (let i = 0; i < p.length; i++) for (let j = i + 1; j < p.length; j++) { const d = dist(p[i], p[j]); if (d < best) { best = d; pair = tuple([p[i], p[j]]); } } return pair; },
    };
};

// ---------- std.xml ----------
function decodeEntities(s) { return s.replace(/&(#x[0-9a-fA-F]+|#\d+|lt|gt|amp|quot|apos);/g, (m, e) => (e[0] === '#' ? String.fromCodePoint(e[1] === 'x' ? parseInt(e.slice(2), 16) : +e.slice(1)) : { lt: '<', gt: '>', amp: '&', quot: '"', apos: "'" }[e])); }
const encode = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const encodeAttr = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function parseXml(src) {
    let i = 0; const n = src.length;
    const err2 = (m) => { let line = 1, col = 1; for (let k = 0; k < i && k < n; k++) { if (src[k] === '\n') { line++; col = 1; } else col++; } return rtError('XML error at line ' + line + ', column ' + col + ': ' + m, 'ParseError'); };
    const ws = () => { while (i < n && /\s/.test(src[i])) i++; };
    function skipMisc() { for (;;) { ws(); if (src.startsWith('<?', i)) { const e = src.indexOf('?>', i); if (e < 0) throw err2('A <? was never closed'); i = e + 2; } else if (src.startsWith('<!--', i)) { const e = src.indexOf('-->', i); if (e < 0) throw err2('A comment never ends'); i = e + 3; } else if (src.startsWith('<!DOCTYPE', i)) { const e = src.indexOf('>', i); i = e + 1; } else break; } }
    function element() {
        if (src[i] !== '<') throw err2('A tag was expected');
        i++;
        const nm = /^[^\s/>]+/.exec(src.slice(i, i + 200));
        if (!nm) throw err2('A tag name was expected');
        const tag = nm[0]; i += tag.length;
        const attrs = new SMap();
        for (;;) {
            ws();
            if (src[i] === '/' && src[i + 1] === '>') { i += 2; return map({ tag, attrs, children: [], text: '' }); }
            if (src[i] === '>') { i++; break; }
            const a = /^([^\s=/>]+)\s*=\s*("([^"]*)"|'([^']*)')/.exec(src.slice(i, i + 4000));
            if (!a) throw err2('An attribute like name="value" was expected in <' + tag + '>');
            attrs.set(a[1], decodeEntities(a[3] !== undefined ? a[3] : a[4])); i += a[0].length;
        }
        const children = []; let text = '';
        for (;;) {
            if (i >= n) throw err2('<' + tag + '> was never closed');
            if (src.startsWith('</', i)) { const e = src.indexOf('>', i); const close = src.slice(i + 2, e).trim(); if (close !== tag) throw err2('</' + close + '> does not match <' + tag + '>'); i = e + 1; break; }
            if (src.startsWith('<!--', i)) { const e = src.indexOf('-->', i); i = e + 3; continue; }
            if (src.startsWith('<![CDATA[', i)) { const e = src.indexOf(']]>', i); text += src.slice(i + 9, e); i = e + 3; continue; }
            if (src[i] === '<') { children.push(element()); continue; }
            const e = src.indexOf('<', i); const chunk = src.slice(i, e < 0 ? n : e); text += decodeEntities(chunk); i = e < 0 ? n : e;
        }
        return map({ tag, attrs, children, text: children.length ? text.trim() : text });
    }
    skipMisc();
    const root = element();
    skipMisc();
    if (i < n) throw err2('Extra text after the last tag');
    return root;
}
function xmlString(node, indent, level) {
    const pad = indent ? ' '.repeat(indent * level) : '', nl = indent ? '\n' : '';
    const tag = node.get('tag'), attrs = node.get('attrs'), kids = node.get('children') || [], text = node.get('text') || '';
    const at = attrs instanceof SMap ? attrs.entries().map(([k, v]) => ' ' + k + '="' + encodeAttr(show(v)) + '"').join('') : '';
    if (!kids.length && text === '') return pad + '<' + tag + at + '/>';
    if (!kids.length) return pad + '<' + tag + at + '>' + encode(text) + '</' + tag + '>';
    return pad + '<' + tag + at + '>' + nl + (text ? pad + ' '.repeat(indent || 0) + encode(text) + nl : '') + kids.map((k) => xmlString(k, indent, level + 1)).join(nl) + nl + pad + '</' + tag + '>';
}
export const xmlModule = () => {
    const findAll = (node, tag, out) => { if (node.get('tag') === tag || tag === '*') out.push(node); for (const k of node.get('children')) findAll(k, tag, out); return out; };
    return {
        parse: (text) => parseXml(str(text, 'xml.parse')), stringify: (node, o) => xmlString(node, opts(o).indent === undefined ? 2 : opts(o).indent, 0) + '\n',
        read: (path) => parseXml(rt.needSys('xml.read').readText(str(path))),
        find_all: (node, tag) => findAll(node, tag, []), find: (node, tag) => findAll(node, tag, [])[0] || null,
        // select(node, "channel/item/title"): follow tag names down the tree
        select: (node, path) => { let cur = [node]; for (const part of str(path).split('/').filter(Boolean)) { const next = []; for (const c of cur) for (const k of c.get('children')) if (k.get('tag') === part || part === '*') next.push(k); cur = next; } return cur; },
        text_of: (node) => { const go = (n) => n.get('text') + n.get('children').map(go).join(''); return go(node); },
        attr: (node, name, d) => { const v = node.get('attrs').get(name); return v === undefined ? (d === undefined ? null : d) : v; },
        element: (tag, attrs, children, text) => map({ tag, attrs: attrs instanceof SMap ? attrs : new SMap(), children: children === undefined ? [] : A(children), text: text === undefined ? '' : show(text) }),
        escape: (s) => encode(str(s)), unescape: (s) => decodeEntities(str(s)),
        to_map: (node) => { const go = (n) => { const m = new SMap(); for (const [k, v] of n.get('attrs').entries()) m.set('@' + k, v); const kids = n.get('children'); if (!kids.length) { if (!m.size) return n.get('text'); m.set('#text', n.get('text')); return m; } for (const k of kids) { const key = k.get('tag'); const v = go(k); if (m.has(key)) { const cur = m.get(key); if (Array.isArray(cur)) cur.push(v); else m.set(key, [cur, v]); } else m.set(key, v); } return m; }; const out = new SMap(); out.set(node.get('tag'), go(node)); return out; },
    };
};

// ---------- std.ini ----------
function parseIni(text, o) {
    const out = new SMap();
    let cur = out;
    const val = (s) => { s = s.trim(); if (o.types === false) return s; if (/^".*"$/.test(s) || /^'.*'$/.test(s)) return s.slice(1, -1); if (/^(true|yes|on)$/i.test(s)) return true; if (/^(false|no|off)$/i.test(s)) return false; if (/^-?\d+$/.test(s)) return Number(s); if (/^-?\d*\.\d+$/.test(s)) return Number(s); return s; };
    let n = 0;
    for (const raw of text.split(/\r?\n/)) {
        n++;
        const line = raw.trim();
        if (!line || line.startsWith(';') || line.startsWith('#')) continue;
        let m;
        if ((m = /^\[([^\]]+)\]$/.exec(line))) { cur = new SMap(); out.set(m[1].trim(), cur); continue; }
        if ((m = /^([^=:]+?)\s*[=:]\s*(.*)$/.exec(line))) { const v = m[2].replace(/\s+[;#].*$/, ''); cur.set(m[1].trim(), val(v)); continue; }
        throw rtError('INI error on line ' + n + ': I could not understand "' + line.slice(0, 40) + '"', 'ParseError');
    }
    return out;
}
export const iniModule = () => ({
    parse: (text, o) => parseIni(str(text, 'ini.parse'), opts(o)),
    stringify: (m) => { const lines = []; const put = (k, v) => lines.push(k + ' = ' + (v === null ? '' : show(v))); for (const [k, v] of m.entries()) if (!(v instanceof SMap)) put(k, v); for (const [k, v] of m.entries()) if (v instanceof SMap) { if (lines.length) lines.push(''); lines.push('[' + k + ']'); for (const [k2, v2] of v.entries()) put(k2, v2); } return lines.join('\n') + '\n'; },
    read: (path, o) => parseIni(rt.needSys('ini.read').readText(str(path)), opts(o)),
});
