/* Words and codes: std.text, std.fmt, std.regex, std.encoding, std.hash, std.crypto, std.uuid, std.url, std.markdown, std.template, std.color, std.unit, std.diff, std.semver. */
import { rt, SMap, SSet, SObj, Tuple, tuple, Named, opts, num, nums, list, cb, call, map, bytesOf, rtError, show, repr, eq, truthy, typeOf, ok, err, toArray, str } from './_util.js';
import { regex } from '../methods.js';

const A = (x) => toArray(x);

// ---------- std.text ----------
function levenshtein(a, b) {
    const x = Array.from(a), y = Array.from(b);
    let prev = Array.from({ length: y.length + 1 }, (_, i) => i);
    for (let i = 1; i <= x.length; i++) {
        const cur = [i];
        for (let j = 1; j <= y.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1));
        prev = cur;
    }
    return prev[y.length];
}
function jaro(a, b) {
    if (a === b) return 1;
    const la = a.length, lb = b.length;
    if (!la || !lb) return 0;
    const md = Math.max(0, Math.floor(Math.max(la, lb) / 2) - 1);
    const ma = new Array(la).fill(false), mb = new Array(lb).fill(false);
    let m = 0;
    for (let i = 0; i < la; i++) for (let j = Math.max(0, i - md); j < Math.min(lb, i + md + 1); j++) if (!mb[j] && a[i] === b[j]) { ma[i] = mb[j] = true; m++; break; }
    if (!m) return 0;
    let t = 0, k = 0;
    for (let i = 0; i < la; i++) if (ma[i]) { while (!mb[k]) k++; if (a[i] !== b[k]) t++; k++; }
    return (m / la + m / lb + (m - t / 2) / m) / 3;
}
export const textModule = () => ({
    wrap: (s, width) => { const out = []; for (const para of str(s, 'wrap').split('\n')) { let line = ''; for (const w of para.split(/\s+/).filter(Boolean)) { if (line && (line + ' ' + w).length > width) { out.push(line); line = w; } else line = line ? line + ' ' + w : w; } out.push(line); } return out.join('\n'); },
    indent: (s, n, ch) => str(s).split('\n').map((l) => (l ? (ch === undefined ? ' ' : ch).repeat(n) + l : l)).join('\n'),
    dedent: (s) => { const lines = str(s).split('\n'); let min = Infinity; for (const l of lines) { if (!l.trim()) continue; min = Math.min(min, /^[ \t]*/.exec(l)[0].length); } return lines.map((l) => l.slice(min === Infinity ? 0 : min)).join('\n'); },
    truncate: (s, n, tail) => { const t = tail === undefined ? '…' : tail; s = str(s); return s.length <= n ? s : s.slice(0, Math.max(0, n - t.length)) + t; },
    slug: (s) => str(s).normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''),
    snake: (s) => str(s).replace(/([a-z0-9])([A-Z])/g, '$1_$2').replace(/[\s\-]+/g, '_').toLowerCase(),
    kebab: (s) => str(s).replace(/([a-z0-9])([A-Z])/g, '$1-$2').replace(/[\s_]+/g, '-').toLowerCase(),
    camel: (s) => str(s).replace(/[-_\s]+(.)?/g, (m, c) => (c ? c.toUpperCase() : '')).replace(/^(.)/, (c) => c.toLowerCase()),
    pascal: (s) => str(s).replace(/(^|[-_\s]+)(.)/g, (m, a, c) => c.toUpperCase()),
    title: (s) => str(s).replace(/\b\p{L}[\p{L}\p{N}']*/gu, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase()),
    levenshtein: (a, b) => levenshtein(str(a), str(b)),
    similarity: (a, b) => { a = str(a); b = str(b); const m = Math.max(a.length, b.length); return m ? 1 - levenshtein(a, b) / m : 1; },
    jaro: (a, b) => jaro(str(a), str(b)),
    closest: (s, options, max) => { let best = null, bd = max === undefined ? Infinity : max + 1; for (const o of A(options)) { const d = levenshtein(str(s), o); if (d < bd) { bd = d; best = o; } } return best; },
    count_words: (s) => (str(s).match(/\S+/g) || []).length,
    word_freq: (s) => { const m = new SMap(); for (const w of (str(s).toLowerCase().match(/[\p{L}\p{N}']+/gu) || [])) m.set(w, (m.get(w) || 0) + 1); return m; },
    ordinal: (n) => { const v = Math.abs(n) % 100; return n + (v >= 11 && v <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][Math.abs(n) % 10] || 'th'); },
    pluralize: (n, one, many) => (n === 1 ? n + ' ' + one : n + ' ' + (many === undefined ? one + 's' : many)),
    human_number: (n) => { const a = Math.abs(n); const u = [[1e12, 'T'], [1e9, 'B'], [1e6, 'M'], [1e3, 'K']]; for (const [v, s] of u) if (a >= v) return +(n / v).toFixed(1) + s; return String(n); },
    human_bytes: (n) => { const u = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']; let i = 0; let v = n; while (Math.abs(v) >= 1024 && i < u.length - 1) { v /= 1024; i++; } return (i ? +v.toFixed(1) : v) + ' ' + u[i]; },
    human_duration: (s) => { s = Math.round(s); if (s < 60) return s + 's'; const parts = []; for (const [u, k] of [['d', 86400], ['h', 3600], ['m', 60], ['s', 1]]) { if (s >= k) { parts.push(Math.floor(s / k) + u); s %= k; } } return parts.join(' '); },
    rot13: (s) => str(s).replace(/[a-z]/gi, (c) => String.fromCharCode((c <= 'Z' ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26)),
    caesar: (s, k) => str(s).replace(/[a-z]/gi, (c) => { const b = c <= 'Z' ? 65 : 97; return String.fromCharCode(((c.charCodeAt(0) - b + k) % 26 + 26) % 26 + b); }),
    is_palindrome: (s) => { const t = str(s).toLowerCase().replace(/[^\p{L}\p{N}]/gu, ''); return t === Array.from(t).reverse().join(''); },
    is_anagram: (a, b) => { const n = (s) => Array.from(str(s).toLowerCase().replace(/[^\p{L}\p{N}]/gu, '')).sort().join(''); return n(a) === n(b); },
    reverse_words: (s) => str(s).split(/\s+/).reverse().join(' '),
    remove_accents: (s) => str(s).normalize('NFKD').replace(/[̀-ͯ]/g, ''),
    lorem: (n) => { const w = 'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua'.split(' '); const r = []; for (let i = 0; i < n; i++) r.push(w[i % w.length]); const s = r.join(' '); return s[0].toUpperCase() + s.slice(1) + '.'; },
    soundex: (s) => { const t = str(s).toUpperCase().replace(/[^A-Z]/g, ''); if (!t) return ''; const codes = { B: 1, F: 1, P: 1, V: 1, C: 2, G: 2, J: 2, K: 2, Q: 2, S: 2, X: 2, Z: 2, D: 3, T: 3, L: 4, M: 5, N: 5, R: 6 }; let out = t[0], last = codes[t[0]] || 0; for (const c of t.slice(1)) { const d = codes[c] || 0; if (d && d !== last) out += d; if (c !== 'H' && c !== 'W') last = d; } return (out + '000').slice(0, 4); },
    columns: (items, cols, gap) => { const a = A(items).map(show); const w = Math.max(0, ...a.map((x) => x.length)) + (gap === undefined ? 2 : gap); const rows = Math.ceil(a.length / cols); const out = []; for (let r = 0; r < rows; r++) { let line = ''; for (let c = 0; c < cols; c++) { const k = c * rows + r; if (k < a.length) line += a[k].padEnd(w); } out.push(line.trimEnd()); } return out.join('\n'); },
    between: (s, a, b) => { s = str(s); const i = s.indexOf(a); if (i < 0) return null; const j = s.indexOf(b, i + a.length); return j < 0 ? null : s.slice(i + a.length, j); },
    squeeze: (s) => str(s).replace(/\s+/g, ' ').trim(),
    char_count: (s) => { const m = new SMap(); for (const c of str(s)) m.set(c, (m.get(c) || 0) + 1); return m; },
    initials: (s) => str(s).split(/\s+/).filter(Boolean).map((w) => w[0].toUpperCase()).join(''),
});

// ---------- std.fmt ----------
const ROMAN = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
const ONES = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
const TENS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
function words(n) {
    if (n < 0) return 'minus ' + words(-n);
    if (n < 20) return ONES[n];
    if (n < 100) return TENS[Math.floor(n / 10)] + (n % 10 ? '-' + ONES[n % 10] : '');
    if (n < 1000) return ONES[Math.floor(n / 100)] + ' hundred' + (n % 100 ? ' and ' + words(n % 100) : '');
    for (const [v, name] of [[1e12, 'trillion'], [1e9, 'billion'], [1e6, 'million'], [1e3, 'thousand']]) if (n >= v) return words(Math.floor(n / v)) + ' ' + name + (n % v ? (n % v < 100 ? ' and ' : ' ') + words(n % v) : '');
    return String(n);
}
export const fmtModule = () => {
    const thousands = (n, sep) => { const txt = typeof n === 'string' ? n.replace(/^-/, '') : String(Math.abs(n)); const neg = typeof n === 'string' ? n.startsWith('-') : n < 0; const [i, d] = txt.split('.'); return (neg ? '-' : '') + i.replace(/\B(?=(\d{3})+(?!\d))/g, sep === undefined ? ',' : sep) + (d ? '.' + d : ''); };
    return {
        // printf-style: sprintf("%5.2f|%-6s|%03d|%x|%%", 3.14159, "ab", 7, 255)
        sprintf: (f, ...args) => { let k = 0; return str(f, 'sprintf').replace(/%([-+ 0#]*)(\d+)?(?:\.(\d+))?([sdifexXobc%])/g, (m, flags, w, p, t) => { if (t === '%') return '%'; if (k >= args.length) throw rtError('sprintf has more % places than values', 'ArgError'); const v = args[k++]; let s; switch (t) { case 'd': case 'i': s = String(Math.trunc(Number(v))); break; case 'f': s = Number(v).toFixed(p === undefined ? 6 : +p); break; case 'e': s = Number(v).toExponential(p === undefined ? 6 : +p); break; case 'x': s = Math.trunc(v).toString(16); break; case 'X': s = Math.trunc(v).toString(16).toUpperCase(); break; case 'o': s = Math.trunc(v).toString(8); break; case 'b': s = Math.trunc(v).toString(2); break; case 'c': s = String.fromCodePoint(v); break; default: s = show(v); if (p !== undefined) s = s.slice(0, +p); } if (flags.includes('+') && Number(v) >= 0 && 'dfie'.includes(t)) s = '+' + s; if (w) { const width = +w; if (flags.includes('-')) s = s.padEnd(width); else if (flags.includes('0') && 'dfiexXob'.includes(t)) { const sg = /^[-+]/.test(s) ? s[0] : ''; s = sg + s.slice(sg.length).padStart(width - sg.length, '0'); } else s = s.padStart(width); } return s; }); },
        thousands, money: (n, symbol, places) => (n < 0 ? '-' : '') + (symbol === undefined ? '$' : symbol) + thousands(Math.abs(n).toFixed(places === undefined ? 2 : places)),
        percent: (x, places) => (x * 100).toFixed(places === undefined ? 1 : places) + '%',
        fixed: (x, places) => Number(x).toFixed(places === undefined ? 2 : places),
        sci: (x, places) => Number(x).toExponential(places === undefined ? 2 : places),
        roman: (n) => { if (!Number.isInteger(n) || n < 1 || n > 3999) throw rtError('roman needs a whole number from 1 to 3999', 'ArgError'); let r = ''; for (const [v, s] of ROMAN) while (n >= v) { r += s; n -= v; } return r; },
        from_roman: (s) => { let t = 0; const m = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 }; const u = str(s).toUpperCase(); for (let i = 0; i < u.length; i++) { const a = m[u[i]], b = m[u[i + 1]]; if (!a) throw rtError('"' + s + '" is not a Roman numeral', 'ValueError'); t += b > a ? -a : a; } return t; },
        words: (n) => words(Math.trunc(n)),
        ordinal: (n) => { const v = Math.abs(n) % 100; return n + (v >= 11 && v <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][Math.abs(n) % 10] || 'th'); },
        pad_left: (s, n, ch) => show(s).padStart(n, ch === undefined ? ' ' : ch), pad_right: (s, n, ch) => show(s).padEnd(n, ch === undefined ? ' ' : ch),
        center: (s, n, ch) => { s = show(s); if (s.length >= n) return s; const l = Math.floor((n - s.length) / 2); const f = ch === undefined ? ' ' : ch; return f.repeat(l) + s + f.repeat(n - s.length - l); },
        // a text table: rows as lists, or a list of maps
        table: (rows, o) => {
            const op = opts(o); let data = A(rows); let head = op.header ? A(op.header) : null;
            if (data.length && data[0] instanceof SMap) { head = head || data[0].keys(); data = data.map((r) => head.map((h) => (r.get(h) === undefined ? '' : r.get(h)))); }
            const cells = data.map((r) => A(r).map(show));
            const heads = head ? head.map(show) : null;
            const widths = (heads || cells[0] || []).map((_, i) => Math.max(...(heads ? [heads[i].length] : []), ...cells.map((r) => (r[i] || '').length)));
            const line = (r) => '│ ' + r.map((c, i) => (/^-?[\d.,]+%?$/.test(c) ? c.padStart(widths[i]) : c.padEnd(widths[i]))).join(' │ ') + ' │';
            const rule = (l, m, r) => l + widths.map((w) => '─'.repeat(w + 2)).join(m) + r;
            const out = [rule('┌', '┬', '┐')];
            if (heads) { out.push(line(heads)); out.push(rule('├', '┼', '┤')); }
            for (const r of cells) out.push(line(r));
            out.push(rule('└', '┴', '┘'));
            return out.join('\n');
        },
        box: (text, o) => { const op = opts(o); const lines = show(text).split('\n'); const w = Math.max(...lines.map((l) => l.length), op.title ? String(op.title).length + 2 : 0); const t = op.title ? '─ ' + op.title + ' ' : ''; return ['╭' + t + '─'.repeat(w + 2 - t.length) + '╮'].concat(lines.map((l) => '│ ' + l.padEnd(w) + ' │'), ['╰' + '─'.repeat(w + 2) + '╯']).join('\n'); },
        bar: (value, max, width) => { const w = width || 20; const n = Math.round(Math.max(0, Math.min(1, value / max)) * w); return '█'.repeat(n) + '░'.repeat(w - n); },
        spec: (v, s) => rt.formatSpec(v, s),
        bool: (b) => (b ? 'yes' : 'no'),
        list: (xs, conj) => { const a = A(xs).map(show); const c = conj === undefined ? 'and' : conj; if (a.length <= 1) return a.join(''); if (a.length === 2) return a[0] + ' ' + c + ' ' + a[1]; return a.slice(0, -1).join(', ') + ', ' + c + ' ' + a[a.length - 1]; },
    };
};

// ---------- std.regex ----------
export const regexModule = () => {
    const conv = (m) => { if (!m) return null; const r = new SMap(); r.set('text', m[0]); r.set('index', m.index); r.set('groups', Array.from(m).slice(1).map((x) => (x === undefined ? null : x))); const named = new SMap(); if (m.groups) for (const k of Object.keys(m.groups)) named.set(k, m.groups[k] === undefined ? null : m.groups[k]); r.set('named', named); return r; };
    const fl = (o) => { const p = opts(o); return (p.ignore_case ? 'i' : '') + (p.multiline ? 'm' : '') + (p.dot_all ? 's' : '') + (p.unicode === false ? '' : 'u'); };
    return {
        test: (p, s, o) => regex(p, fl(o)).test(str(s)),
        match: (p, s, o) => conv(regex(p, fl(o)).exec(str(s))),
        find_all: (p, s, o) => Array.from(str(s).matchAll(regex(p, fl(o) + 'g')), (m) => m[0]),
        matches: (p, s, o) => Array.from(str(s).matchAll(regex(p, fl(o) + 'g')), conv),
        replace: (p, s, r, o) => str(s).replace(regex(p, fl(o) + 'g'), typeof r === 'string' ? r : (...m) => String(call(r, [m[0]]))),
        replace_first: (p, s, r, o) => str(s).replace(regex(p, fl(o)), typeof r === 'string' ? r : (...m) => String(call(r, [m[0]]))),
        split: (p, s, o) => str(s).split(regex(p, fl(o))),
        escape: (s) => str(s).replace(/[.*+?^${}()|[\]\\\/-]/g, '\\$&'),
        is_valid: (p) => { try { new RegExp(p, 'u'); return true; } catch (e) { return false; } },
        EMAIL: '^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$', URL: '^https?://[^\\s/$.?#].[^\\s]*$', INT: '^-?\\d+$', FLOAT: '^-?\\d+(\\.\\d+)?$', HEX_COLOR: '^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$', IPV4: '^(\\d{1,3}\\.){3}\\d{1,3}$',
    };
};

// ---------- std.encoding ----------
const b64 = (b, url) => { let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); let r = btoa(s); if (url) r = r.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); return r; };
const unb64 = (s, url) => { let t = str(s).replace(/\s+/g, ''); if (url) t = t.replace(/-/g, '+').replace(/_/g, '/'); while (t.length % 4) t += '='; try { const bin = atob(t); return Uint8Array.from(bin, (c) => c.charCodeAt(0)); } catch (e) { throw rtError('This is not valid base64', 'ValueError'); } };
export const encodingModule = () => ({
    base64: (x) => b64(bytesOf(x), false), base64_decode: (s) => new TextDecoder().decode(unb64(s, false)), base64_bytes: (s) => unb64(s, false),
    base64url: (x) => b64(bytesOf(x), true), base64url_decode: (s) => new TextDecoder().decode(unb64(s, true)),
    hex: (x) => Array.from(bytesOf(x), (b) => b.toString(16).padStart(2, '0')).join(''),
    hex_decode: (s) => { const t = str(s).replace(/\s+/g, ''); if (t.length % 2 || /[^0-9a-fA-F]/.test(t)) throw rtError('This is not valid hex', 'ValueError'); return Uint8Array.from(t.match(/../g) || [], (h) => parseInt(h, 16)); },
    utf8: (s) => new TextEncoder().encode(str(s)), utf8_decode: (b) => new TextDecoder().decode(bytesOf(b)),
    url_encode: (s) => encodeURIComponent(str(s)), url_decode: (s) => { try { return decodeURIComponent(str(s).replace(/\+/g, ' ')); } catch (e) { throw rtError('This is not valid percent-encoding', 'ValueError'); } },
    html_escape: (s) => str(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
    html_unescape: (s) => str(s).replace(/&(amp|lt|gt|quot|#39|#x27|nbsp|apos);|&#(\d+);|&#x([0-9a-fA-F]+);/g, (m, n, d, h) => (d ? String.fromCodePoint(+d) : h ? String.fromCodePoint(parseInt(h, 16)) : ({ amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", '#x27': "'", nbsp: ' ', apos: "'" }[n]))),
    base32: (x) => { const b = bytesOf(x); const al = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = 0, v = 0, out = ''; for (const byte of b) { v = (v << 8) | byte; bits += 8; while (bits >= 5) { out += al[(v >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) out += al[(v << (5 - bits)) & 31]; while (out.length % 8) out += '='; return out; },
    rot: (s, n) => str(s).replace(/[a-z]/gi, (c) => { const b = c <= 'Z' ? 65 : 97; return String.fromCharCode(((c.charCodeAt(0) - b + n) % 26 + 26) % 26 + b); }),
    morse: (s) => { const m = { a: '.-', b: '-...', c: '-.-.', d: '-..', e: '.', f: '..-.', g: '--.', h: '....', i: '..', j: '.---', k: '-.-', l: '.-..', m: '--', n: '-.', o: '---', p: '.--.', q: '--.-', r: '.-.', s: '...', t: '-', u: '..-', v: '...-', w: '.--', x: '-..-', y: '-.--', z: '--..', 0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.' }; return str(s).toLowerCase().split('').map((c) => (c === ' ' ? '/' : m[c] || '?')).join(' '); },
});

// ---------- std.hash (pure JavaScript, so it works in the browser too) ----------
function sha256(bytes) {
    const K = new Uint32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
    const H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
    const l = bytes.length, bitLen = l * 8;
    const total = (((l + 9 + 63) >> 6) << 6);
    const m = new Uint8Array(total);
    m.set(bytes); m[l] = 0x80;
    const dv = new DataView(m.buffer);
    dv.setUint32(total - 8, Math.floor(bitLen / 4294967296)); dv.setUint32(total - 4, bitLen >>> 0);
    const w = new Uint32Array(64);
    const rr = (x, n) => (x >>> n) | (x << (32 - n));
    for (let o = 0; o < total; o += 64) {
        for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
        for (let i = 16; i < 64; i++) { const s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0; }
        let [a, b, c, d, e, f, g, h] = H;
        for (let i = 0; i < 64; i++) { const S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K[i] + w[i]) | 0, S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = (S0 + mj) | 0; h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0; }
        H[0] += a; H[1] += b; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
    }
    const out = new Uint8Array(32); const od = new DataView(out.buffer);
    for (let i = 0; i < 8; i++) od.setUint32(i * 4, H[i]);
    return out;
}
function sha1(bytes) {
    let h0 = 0x67452301, h1 = 0xEFCDAB89, h2 = 0x98BADCFE, h3 = 0x10325476, h4 = 0xC3D2E1F0;
    const l = bytes.length, total = (((l + 9 + 63) >> 6) << 6);
    const m = new Uint8Array(total); m.set(bytes); m[l] = 0x80;
    const dv = new DataView(m.buffer); dv.setUint32(total - 8, Math.floor(l * 8 / 4294967296)); dv.setUint32(total - 4, (l * 8) >>> 0);
    const w = new Uint32Array(80); const rl = (x, n) => (x << n) | (x >>> (32 - n));
    for (let o = 0; o < total; o += 64) {
        for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
        for (let i = 16; i < 80; i++) w[i] = rl(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
        let a = h0, b = h1, c = h2, d = h3, e = h4;
        for (let i = 0; i < 80; i++) { let f, k; if (i < 20) { f = (b & c) | (~b & d); k = 0x5A827999; } else if (i < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; } else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; } else { f = b ^ c ^ d; k = 0xCA62C1D6; } const t = (rl(a, 5) + f + e + k + w[i]) | 0; e = d; d = c; c = rl(b, 30); b = a; a = t; }
        h0 = (h0 + a) | 0; h1 = (h1 + b) | 0; h2 = (h2 + c) | 0; h3 = (h3 + d) | 0; h4 = (h4 + e) | 0;
    }
    const out = new Uint8Array(20); const od = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((v, i) => od.setUint32(i * 4, v >>> 0));
    return out;
}
function md5(bytes) {
    const S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const K = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
    let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
    const l = bytes.length, total = (((l + 9 + 63) >> 6) << 6);
    const m = new Uint8Array(total); m.set(bytes); m[l] = 0x80;
    const dv = new DataView(m.buffer); dv.setUint32(total - 8, (l * 8) >>> 0, true); dv.setUint32(total - 4, Math.floor(l * 8 / 4294967296), true);
    for (let o = 0; o < total; o += 64) {
        let A1 = a0, B = b0, C = c0, D = d0;
        for (let i = 0; i < 64; i++) {
            let F, g;
            if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; } else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
            F = (F + A1 + K[i] + dv.getUint32(o + g * 4, true)) | 0;
            A1 = D; D = C; C = B; B = (B + ((F << S[i]) | (F >>> (32 - S[i])))) | 0;
        }
        a0 = (a0 + A1) | 0; b0 = (b0 + B) | 0; c0 = (c0 + C) | 0; d0 = (d0 + D) | 0;
    }
    const out = new Uint8Array(16); const od = new DataView(out.buffer);
    [a0, b0, c0, d0].forEach((v, i) => od.setUint32(i * 4, v >>> 0, true));
    return out;
}
const crcTable = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const hex = (b) => Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
function hmac(hash, block, key, msg) {
    let k = key.length > block ? hash(key) : key;
    const kk = new Uint8Array(block); kk.set(k);
    const ipad = kk.map((b) => b ^ 0x36), opad = kk.map((b) => b ^ 0x5c);
    const inner = hash(Uint8Array.from([...ipad, ...msg]));
    return hash(Uint8Array.from([...opad, ...inner]));
}
export const hashModule = () => ({
    sha256: (x) => hex(sha256(bytesOf(x))), sha1: (x) => hex(sha1(bytesOf(x))), md5: (x) => hex(md5(bytesOf(x))),
    sha256_bytes: (x) => sha256(bytesOf(x)),
    hmac_sha256: (key, msg) => hex(hmac(sha256, 64, bytesOf(key), bytesOf(msg))),
    crc32: (x) => { let c = 0xFFFFFFFF; for (const b of bytesOf(x)) c = crcTable[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; },
    fnv1a: (x) => { let h = 0x811c9dc5; for (const b of bytesOf(x)) { h ^= b; h = Math.imul(h, 0x01000193) >>> 0; } return h; },
    adler32: (x) => { let a = 1, b = 0; for (const v of bytesOf(x)) { a = (a + v) % 65521; b = (b + a) % 65521; } return ((b << 16) | a) >>> 0; },
    djb2: (x) => { let h = 5381; for (const ch of Array.from(str(x))) h = ((h << 5) + h + ch.codePointAt(0)) >>> 0; return h; },
    short: (x, n) => hex(sha256(bytesOf(x))).slice(0, n || 8),
    verify: (x, digest) => hex(sha256(bytesOf(x))) === String(digest).toLowerCase(),
});

// ---------- std.crypto and std.uuid ----------
const rand = (n) => { const b = new Uint8Array(n); (globalThis.crypto || { getRandomValues: (a) => { for (let i = 0; i < a.length; i++) a[i] = (Math.random() * 256) | 0; } }).getRandomValues(b); return b; };
function uuid4() { const b = rand(16); b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80; const h = hex(b); return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20); }
function uuid7() { const b = rand(16); let t = BigInt(Date.now()); for (let i = 5; i >= 0; i--) { b[i] = Number(t & 255n); t >>= 8n; } b[6] = (b[6] & 0x0f) | 0x70; b[8] = (b[8] & 0x3f) | 0x80; const h = hex(b); return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20); }
export const cryptoModule = () => ({
    random_bytes: (n) => rand(n), random_hex: (n) => hex(rand(n)), token: (n) => hex(rand(n || 16)),
    random_int: (a, b) => { const r = rand(4); const x = new DataView(r.buffer).getUint32(0) / 4294967296; return b === undefined ? Math.floor(x * a) : a + Math.floor(x * (b - a + 1)); },
    password: (n, o) => { const p = opts(o); let al = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; if (p.symbols) al += '!@#$%^&*()-_=+[]{}'; const r = rand(n || 16); return Array.from(r, (b) => al[b % al.length]).join(''); },
    constant_time_eq: (a, b) => { const x = bytesOf(a), y = bytesOf(b); if (x.length !== y.length) return false; let d = 0; for (let i = 0; i < x.length; i++) d |= x[i] ^ y[i]; return d === 0; },
    uuid: uuid4, sha256: (x) => hex(sha256(bytesOf(x))),
    pbkdf: (password, salt, rounds) => { let h = hmac(sha256, 64, bytesOf(password), bytesOf(salt)); let acc = h; for (let i = 1; i < (rounds || 1000); i++) { h = hmac(sha256, 64, bytesOf(password), h); acc = acc.map((b, k) => b ^ h[k]); } return hex(acc); },
});
export const uuidModule = () => ({
    v4: uuid4, v7: uuid7, new: uuid4, nil: () => '00000000-0000-0000-0000-000000000000',
    is_valid: (s) => typeof s === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s),
    short: () => hex(rand(6)),
});

// ---------- std.url ----------
function parseQuery(q) { const m = new SMap(); if (!q) return m; for (const part of q.replace(/^\?/, '').split('&')) { if (!part) continue; const i = part.indexOf('='); const k = decodeURIComponent((i < 0 ? part : part.slice(0, i)).replace(/\+/g, ' ')); const v = i < 0 ? '' : decodeURIComponent(part.slice(i + 1).replace(/\+/g, ' ')); const cur = m.get(k); if (cur === undefined) m.set(k, v); else if (Array.isArray(cur)) cur.push(v); else m.set(k, [cur, v]); } return m; }
function buildQuery(m) { const parts = []; for (const [k, v] of (m instanceof SMap ? m.entries() : [])) for (const x of Array.isArray(v) ? v : [v]) parts.push(encodeURIComponent(show(k)) + '=' + encodeURIComponent(show(x))); return parts.join('&'); }
export const urlModule = () => ({
    parse: (s) => { const m = /^(?:([A-Za-z][\w+.-]*):)?(?:\/\/(?:([^@/?#]*)@)?([^:/?#]*)(?::(\d+))?)?([^?#]*)(?:\?([^#]*))?(?:#(.*))?$/.exec(str(s, 'url.parse')); if (!m) throw rtError('This is not a URL', 'ValueError'); return map({ scheme: m[1] || null, user: m[2] || null, host: m[3] || null, port: m[4] ? Number(m[4]) : null, path: m[5] || '', query: parseQuery(m[6] || ''), hash: m[7] || null, raw_query: m[6] || '' }); },
    build: (p) => { const g = (k) => p.get(k); let u = ''; if (g('scheme')) u += g('scheme') + ':'; if (g('host')) { u += '//'; if (g('user')) u += g('user') + '@'; u += g('host'); if (g('port')) u += ':' + g('port'); } u += g('path') || ''; const q = g('query') instanceof SMap ? buildQuery(g('query')) : (g('query') || ''); if (q) u += '?' + q; if (g('hash')) u += '#' + g('hash'); return u; },
    query_parse: (s) => parseQuery(str(s)), query_build: (m) => buildQuery(m),
    encode: (s) => encodeURIComponent(str(s)), decode: (s) => decodeURIComponent(str(s).replace(/\+/g, ' ')),
    join: (base, rel) => { try { return new URL(rel, base).toString(); } catch (e) { throw rtError('Cannot join these URLs', 'ValueError'); } },
    is_valid: (s) => { try { new URL(s); return true; } catch (e) { return false; } },
    domain: (s) => { try { return new URL(s).hostname; } catch (e) { return null; } },
});

// ---------- std.markdown ----------
function inlineMd(s) {
    const codes = [];
    s = s.replace(/`([^`]+)`/g, (m, c) => { codes.push(c); return '\u0000' + (codes.length - 1) + '\u0000'; });
    s = s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g, (m, a, u, t) => '<img src="' + u + '" alt="' + a + '"' + (t ? ' title="' + t + '"' : '') + '>');
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g, (m, a, u, t) => '<a href="' + u + '"' + (t ? ' title="' + t + '"' : '') + '>' + a + '</a>');
    s = s.replace(/\*\*([^*]+)\*\*|__([^_]+)__/g, (m, a, b) => '<strong>' + (a || b) + '</strong>').replace(/\*([^*\s][^*]*)\*|(?<![\w])_([^_]+)_(?![\w])/g, (m, a, b) => '<em>' + (a || b) + '</em>').replace(/~~([^~]+)~~/g, '<del>$1</del>');
    return s.replace(/\u0000(\d+)\u0000/g, (m, i) => '<code>' + codes[i].replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</code>');
}
function markdownToHtml(md) {
    const lines = md.replace(/\r\n/g, '\n').split('\n');
    const out = [];
    let i = 0;
    const flushPara = (buf) => { if (buf.length) out.push('<p>' + inlineMd(buf.join(' ')) + '</p>'); buf.length = 0; };
    const para = [];
    while (i < lines.length) {
        const l = lines[i];
        let m;
        if ((m = /^```(\w*)\s*$/.exec(l))) { flushPara(para); const code = []; i++; while (i < lines.length && !/^```\s*$/.test(lines[i])) code.push(lines[i++]); i++; out.push('<pre><code' + (m[1] ? ' class="language-' + m[1] + '"' : '') + '>' + code.join('\n').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</code></pre>'); continue; }
        if ((m = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(l))) { flushPara(para); out.push('<h' + m[1].length + '>' + inlineMd(m[2]) + '</h' + m[1].length + '>'); i++; continue; }
        if (/^(\*{3,}|-{3,}|_{3,})\s*$/.test(l)) { flushPara(para); out.push('<hr>'); i++; continue; }
        if (/^>\s?/.test(l)) { flushPara(para); const q = []; while (i < lines.length && /^>\s?/.test(lines[i])) q.push(lines[i++].replace(/^>\s?/, '')); out.push('<blockquote>' + markdownToHtml(q.join('\n')) + '</blockquote>'); continue; }
        if (/^\s*([-*+]|\d+[.)])\s+/.test(l)) {
            flushPara(para);
            const ordered = /^\s*\d+[.)]\s+/.test(l);
            const items = [];
            while (i < lines.length && /^\s*([-*+]|\d+[.)])\s+/.test(lines[i])) { const t = lines[i].replace(/^\s*([-*+]|\d+[.)])\s+/, ''); const task = /^\[([ xX])\]\s+(.*)/.exec(t); items.push(task ? '<input type="checkbox" disabled' + (task[1] !== ' ' ? ' checked' : '') + '> ' + inlineMd(task[2]) : inlineMd(t)); i++; }
            out.push((ordered ? '<ol>' : '<ul>') + items.map((x) => '<li>' + x + '</li>').join('') + (ordered ? '</ol>' : '</ul>'));
            continue;
        }
        if (/^\|.*\|\s*$/.test(l) && i + 1 < lines.length && /^\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/.test(lines[i + 1])) {
            flushPara(para);
            const cells = (r) => r.replace(/^\||\|\s*$/g, '').split('|').map((c) => c.trim());
            const head = cells(l); i += 2; const rows = [];
            while (i < lines.length && /^\|.*\|\s*$/.test(lines[i])) rows.push(cells(lines[i++]));
            out.push('<table><thead><tr>' + head.map((h) => '<th>' + inlineMd(h) + '</th>').join('') + '</tr></thead><tbody>' + rows.map((r) => '<tr>' + r.map((c) => '<td>' + inlineMd(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table>');
            continue;
        }
        if (l.trim() === '') { flushPara(para); i++; continue; }
        para.push(l.trim());
        i++;
    }
    flushPara(para);
    return out.join('\n');
}
export const markdownModule = () => ({
    to_html: (s) => markdownToHtml(str(s, 'markdown.to_html')),
    strip: (s) => str(s).replace(/```[\s\S]*?```/g, '').replace(/^#{1,6}\s+/gm, '').replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[*_~`>]/g, '').replace(/^\s*[-+]\s+/gm, '').trim(),
    headings: (s) => str(s).split('\n').map((l) => /^(#{1,6})\s+(.*?)\s*$/.exec(l)).filter(Boolean).map((m) => map({ level: m[1].length, text: m[2] })),
    toc: (s) => str(s).split('\n').map((l) => /^(#{1,6})\s+(.*?)\s*$/.exec(l)).filter(Boolean).map((m) => '  '.repeat(m[1].length - 1) + '- ' + m[2]).join('\n'),
    links: (s) => Array.from(str(s).matchAll(/\[([^\]]+)\]\(([^)\s]+)/g), (m) => tuple([m[1], m[2]])),
    escape: (s) => str(s).replace(/([\\`*_{}\[\]()#+\-.!|>~])/g, '\\$1'),
});

// ---------- std.template: {{name}}, {{#if x}}...{{else}}...{{/if}}, {{#each xs}}{{this}} {{@index}}{{/each}}, {{{raw}}} ----------
function lookup(ctx, path) {
    if (path === 'this' || path === '.') return ctx[ctx.length - 1];
    for (let k = ctx.length - 1; k >= 0; k--) {
        let cur = ctx[k], ok2 = true;
        for (const part of path.split('.')) {
            if (cur instanceof SMap) { cur = cur.get(part); } else if (cur instanceof SObj) cur = cur.f[part]; else if (Array.isArray(cur) && /^\d+$/.test(part)) cur = cur[+part]; else { ok2 = false; break; }
            if (cur === undefined) { ok2 = false; break; }
        }
        if (ok2) return cur;
        if (!path.includes('.') && ctx[k] instanceof SMap) continue;
    }
    return null;
}
function renderTemplate(src, data, esc) {
    const tokens = [];
    const re = /\{\{\{\s*([^}]+?)\s*\}\}\}|\{\{\s*([#\/]?)\s*([^}]*?)\s*\}\}/g;
    let last = 0, m;
    while ((m = re.exec(src))) { if (m.index > last) tokens.push({ t: 'text', v: src.slice(last, m.index) }); if (m[1] !== undefined) tokens.push({ t: 'raw', v: m[1] }); else if (m[2] === '#') { const [kind, ...rest] = m[3].split(/\s+/); tokens.push({ t: 'open', kind, v: rest.join(' ') }); } else if (m[2] === '/') tokens.push({ t: 'close', v: m[3] }); else if (m[3] === 'else') tokens.push({ t: 'else' }); else tokens.push({ t: 'var', v: m[3] }); last = re.lastIndex; }
    if (last < src.length) tokens.push({ t: 'text', v: src.slice(last) });
    let p = 0;
    function block(stop) {
        const nodes = [];
        while (p < tokens.length) {
            const t = tokens[p];
            if (t.t === 'close') { if (stop) { p++; return { nodes, els: null }; } throw rtError('Template: a {{/' + t.v + '}} has no matching {{#...}}', 'TemplateError'); }
            if (t.t === 'else') { if (!stop) throw rtError('Template: {{else}} outside a block', 'TemplateError'); p++; const els = block(true); return { nodes, els: els.nodes }; }
            if (t.t === 'open') { p++; const body = block(true); nodes.push({ t: 'blk', kind: t.kind, v: t.v, body: body.nodes, els: body.els }); continue; }
            nodes.push(t); p++;
        }
        if (stop) throw rtError('Template: a {{#...}} block was never closed', 'TemplateError');
        return { nodes, els: null };
    }
    const tree = block(false).nodes;
    const html = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    function run(nodes, ctx, extra) {
        let out = '';
        for (const n of nodes) {
            if (n.t === 'text') out += n.v;
            else if (n.t === 'raw') out += show(lookup(ctx, n.v) ?? '');
            else if (n.t === 'var') { if (n.v === '@index' && extra) out += extra.index; else if (n.v === '@first' && extra) out += extra.first; else if (n.v === '@last' && extra) out += extra.last; else if (n.v === '@key' && extra) out += show(extra.key); else { const v = lookup(ctx, n.v); const s = v === null ? '' : show(v); out += esc ? html(s) : s; } }
            else if (n.t === 'blk') {
                const v = lookup(ctx, n.v);
                if (n.kind === 'if') out += truthy(v) && !(Array.isArray(v) && !v.length) ? run(n.body, ctx, extra) : (n.els ? run(n.els, ctx, extra) : '');
                else if (n.kind === 'unless') out += !truthy(v) || (Array.isArray(v) && !v.length) ? run(n.body, ctx, extra) : (n.els ? run(n.els, ctx, extra) : '');
                else if (n.kind === 'each') {
                    const items = v instanceof SMap ? v.entries() : (v === null ? [] : A(v));
                    if (!items.length) out += n.els ? run(n.els, ctx, extra) : '';
                    items.forEach((it, i) => { const isMapIt = v instanceof SMap; out += run(n.body, ctx.concat([isMapIt ? it[1] : it]), { index: i, first: i === 0, last: i === items.length - 1, key: isMapIt ? it[0] : i }); });
                } else if (n.kind === 'with') out += run(n.body, ctx.concat([v]), extra);
                else throw rtError('Template: I do not know {{#' + n.kind + '}}', 'TemplateError');
            }
        }
        return out;
    }
    return run(tree, [data], null);
}
export const templateModule = () => ({
    render: (src, data, o) => renderTemplate(str(src, 'template.render'), data, opts(o).escape !== false),
    render_text: (src, data) => renderTemplate(str(src, 'template.render_text'), data, false),
    // "Hello {name}" style with simple replacement
    fill: (src, data) => str(src).replace(/\{([\w.]+)\}/g, (m, k) => { const v = lookup([data], k); return v === null ? m : show(v); }),
    compile: (src) => { const s = str(src); return (data) => renderTemplate(s, data, true); },
});

// ---------- std.color ----------
const NAMED = { black: '#000000', white: '#ffffff', red: '#ff0000', green: '#008000', lime: '#00ff00', blue: '#0000ff', yellow: '#ffff00', cyan: '#00ffff', magenta: '#ff00ff', gray: '#808080', grey: '#808080', silver: '#c0c0c0', maroon: '#800000', olive: '#808000', purple: '#800080', teal: '#008080', navy: '#000080', orange: '#ffa500', pink: '#ffc0cb', brown: '#a52a2a', gold: '#ffd700', coral: '#ff7f50', salmon: '#fa8072', crimson: '#dc143c', indigo: '#4b0082', violet: '#ee82ee', turquoise: '#40e0d0', tan: '#d2b48c', khaki: '#f0e68c', skyblue: '#87ceeb' };
function parseColor(x) {
    if (Array.isArray(x)) return [x[0], x[1], x[2], x[3] === undefined ? 1 : x[3]];
    let s = str(x, 'color').trim().toLowerCase();
    if (NAMED[s]) s = NAMED[s];
    let m;
    if ((m = /^#([0-9a-f]{3,4})$/.exec(s))) { const h = m[1]; return [parseInt(h[0] + h[0], 16), parseInt(h[1] + h[1], 16), parseInt(h[2] + h[2], 16), h[3] ? parseInt(h[3] + h[3], 16) / 255 : 1]; }
    if ((m = /^#([0-9a-f]{6})([0-9a-f]{2})?$/.exec(s))) return [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4, 6), 16), m[2] ? parseInt(m[2], 16) / 255 : 1];
    if ((m = /^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)(?:[\s,/]+([\d.]+))?\s*\)$/.exec(s))) return [+m[1], +m[2], +m[3], m[4] === undefined ? 1 : +m[4]];
    if ((m = /^hsla?\(\s*([\d.]+)[\s,]+([\d.]+)%[\s,]+([\d.]+)%(?:[\s,/]+([\d.]+))?\s*\)$/.exec(s))) { const [r, g, b] = hslToRgb(+m[1], +m[2] / 100, +m[3] / 100); return [r, g, b, m[4] === undefined ? 1 : +m[4]]; }
    throw rtError('"' + x + '" is not a color I know (try #ff8800, rgb(255,136,0), hsl(30,100%,50%) or a name)', 'ValueError');
}
function hslToRgb(h, s, l) { h = ((h % 360) + 360) % 360; const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = l - c / 2; let r = 0, g = 0, b = 0; if (h < 60) [r, g, b] = [c, x, 0]; else if (h < 120) [r, g, b] = [x, c, 0]; else if (h < 180) [r, g, b] = [0, c, x]; else if (h < 240) [r, g, b] = [0, x, c]; else if (h < 300) [r, g, b] = [x, 0, c]; else [r, g, b] = [c, 0, x]; return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)]; }
function rgbToHsl(r, g, b) { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0; const l = (mx + mn) / 2; if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); if (mx === r) h = (g - b) / d + (g < b ? 6 : 0); else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; } return [Math.round(h), Math.round(s * 100), Math.round(l * 100)]; }
const toHex = (c) => '#' + c.slice(0, 3).map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
export const colorModule = () => {
    const adjust = (x, dl) => { const c = parseColor(x); const [h, s, l] = rgbToHsl(c[0], c[1], c[2]); return toHex(hslToRgb(h, s / 100, Math.max(0, Math.min(1, l / 100 + dl)))); };
    const mix = (a, b, t) => { const x = parseColor(a), y = parseColor(b); const k = t === undefined ? 0.5 : t; return toHex([0, 1, 2].map((i) => x[i] + (y[i] - x[i]) * k)); };
    return {
        parse: (x) => { const c = parseColor(x); return map({ r: c[0], g: c[1], b: c[2], a: c[3] }); },
        to_hex: (x) => toHex(parseColor(x)), to_rgb: (x) => { const c = parseColor(x); return tuple(c.slice(0, 3)); }, to_hsl: (x) => { const c = parseColor(x); return tuple(rgbToHsl(c[0], c[1], c[2])); },
        rgb: (r, g, b) => toHex([r, g, b]), hsl: (h, s, l) => toHex(hslToRgb(h, s / 100, l / 100)),
        css_rgb: (x) => { const c = parseColor(x); return 'rgb(' + c[0] + ', ' + c[1] + ', ' + c[2] + ')'; }, css_hsl: (x) => { const c = parseColor(x); const [h, s, l] = rgbToHsl(c[0], c[1], c[2]); return 'hsl(' + h + ', ' + s + '%, ' + l + '%)'; },
        mix, lighten: (x, amount) => adjust(x, amount === undefined ? 0.1 : amount), darken: (x, amount) => adjust(x, -(amount === undefined ? 0.1 : amount)),
        invert: (x) => { const c = parseColor(x); return toHex([255 - c[0], 255 - c[1], 255 - c[2]]); },
        grayscale: (x) => { const c = parseColor(x); const g = Math.round(0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]); return toHex([g, g, g]); },
        luminance: (x) => lum(parseColor(x)),
        contrast: (a, b) => { const l1 = lum(parseColor(a)), l2 = lum(parseColor(b)); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); },
        readable_on: (bg) => (lum(parseColor(bg)) > 0.179 ? '#000000' : '#ffffff'),
        gradient: (a, b, steps) => { const n = Math.max(2, steps); return Array.from({ length: n }, (_, i) => mix(a, b, i / (n - 1))); },
        palette: (n, o) => { const p = opts(o); const s = p.saturation === undefined ? 70 : p.saturation, l = p.lightness === undefined ? 55 : p.lightness; return Array.from({ length: n }, (_, i) => toHex(hslToRgb((i * 360) / n + (p.hue || 0), s / 100, l / 100))); },
        complement: (x) => { const c = parseColor(x); const [h, s, l] = rgbToHsl(c[0], c[1], c[2]); return toHex(hslToRgb(h + 180, s / 100, l / 100)); },
        names: () => Object.keys(NAMED),
        ansi: (text, x) => { const c = parseColor(x); return '\x1b[38;2;' + c[0] + ';' + c[1] + ';' + c[2] + 'm' + show(text) + '\x1b[0m'; },
    };
};

// ---------- std.unit ----------
const UNITS = {
    length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, um: 1e-6, nm: 1e-9, mi: 1609.344, yd: 0.9144, ft: 0.3048, in: 0.0254, nmi: 1852, ly: 9.4607e15, au: 1.495978707e11 },
    mass: { kg: 1, g: 0.001, mg: 1e-6, t: 1000, lb: 0.45359237, oz: 0.028349523125, st: 6.35029318 },
    time: { s: 1, ms: 0.001, us: 1e-6, min: 60, h: 3600, d: 86400, wk: 604800, yr: 31557600 },
    data: { B: 1, KB: 1000, MB: 1e6, GB: 1e9, TB: 1e12, KiB: 1024, MiB: 1048576, GiB: 1073741824, TiB: 1099511627776, bit: 0.125 },
    volume: { l: 1, ml: 0.001, m3: 1000, gal: 3.785411784, qt: 0.946352946, pt: 0.473176473, cup: 0.2365882365, floz: 0.0295735295625, tbsp: 0.0147867647813, tsp: 0.00492892159375 },
    area: { m2: 1, km2: 1e6, cm2: 1e-4, ha: 10000, acre: 4046.8564224, ft2: 0.09290304, in2: 0.00064516, mi2: 2589988.110336 },
    speed: { 'm/s': 1, 'km/h': 1 / 3.6, mph: 0.44704, kn: 0.514444, 'ft/s': 0.3048 },
    energy: { J: 1, kJ: 1000, cal: 4.184, kcal: 4184, Wh: 3600, kWh: 3.6e6, eV: 1.602176634e-19, BTU: 1055.05585 },
    pressure: { Pa: 1, kPa: 1000, bar: 100000, atm: 101325, psi: 6894.757293168, mmHg: 133.322387415 },
    angle: { rad: 1, deg: Math.PI / 180, grad: Math.PI / 200, turn: Math.PI * 2 },
};
export const unitModule = () => {
    const find = (u) => { for (const [kind, t] of Object.entries(UNITS)) if (u in t) return [kind, t[u]]; return null; };
    const temp = { C: [(x) => x, (x) => x], F: [(x) => ((x - 32) * 5) / 9, (x) => (x * 9) / 5 + 32], K: [(x) => x - 273.15, (x) => x + 273.15] };
    return {
        convert: (v, from, to) => { if (from in temp && to in temp) return temp[to][1](temp[from][0](v)); const a = find(from), b = find(to); if (!a) throw rtError('I do not know the unit "' + from + '"', 'ArgError'); if (!b) throw rtError('I do not know the unit "' + to + '"', 'ArgError'); if (a[0] !== b[0]) throw rtError('Cannot convert ' + a[0] + ' (' + from + ') to ' + b[0] + ' (' + to + ')', 'ArgError'); return (v * a[1]) / b[1]; },
        units: (kind) => (kind === undefined ? Object.keys(UNITS) : Object.keys(UNITS[kind] || {})),
        kinds: () => Object.keys(UNITS),
        c_to_f: (c) => (c * 9) / 5 + 32, f_to_c: (f) => ((f - 32) * 5) / 9, c_to_k: (c) => c + 273.15, k_to_c: (k) => k - 273.15,
        km_to_mi: (x) => x / 1.609344, mi_to_km: (x) => x * 1.609344, kg_to_lb: (x) => x / 0.45359237, lb_to_kg: (x) => x * 0.45359237,
    };
};

// ---------- std.diff ----------
function lcsDiff(a, b) {
    const n = a.length, m = b.length;
    const dp = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    const ops = [];
    let i = 0, j = 0;
    while (i < n && j < m) { if (a[i] === b[j]) { ops.push(['=', a[i]]); i++; j++; } else if (dp[i + 1][j] >= dp[i][j + 1]) ops.push(['-', a[i++]]); else ops.push(['+', b[j++]]); }
    while (i < n) ops.push(['-', a[i++]]);
    while (j < m) ops.push(['+', b[j++]]);
    return ops;
}
export const diffModule = () => ({
    lines: (a, b) => lcsDiff(str(a).split('\n'), str(b).split('\n')).map(([op, t]) => tuple([op, t])),
    words: (a, b) => lcsDiff(str(a).split(/(\s+)/).filter((x) => x !== ''), str(b).split(/(\s+)/).filter((x) => x !== '')).map(([op, t]) => tuple([op, t])),
    chars: (a, b) => lcsDiff(Array.from(str(a)), Array.from(str(b))).map(([op, t]) => tuple([op, t])),
    // a unified-style patch text
    unified: (a, b, o) => { const p = opts(o); const ops = lcsDiff(str(a).split('\n'), str(b).split('\n')); const out = ['--- ' + (p.from || 'a'), '+++ ' + (p.to || 'b')]; for (const [op, t] of ops) out.push((op === '=' ? ' ' : op) + t); return out.join('\n'); },
    stats: (a, b) => { const ops = lcsDiff(str(a).split('\n'), str(b).split('\n')); return map({ added: ops.filter((o) => o[0] === '+').length, removed: ops.filter((o) => o[0] === '-').length, same: ops.filter((o) => o[0] === '=').length }); },
    similar: (a, b) => { const x = str(a).split('\n'), y = str(b).split('\n'); const same = lcsDiff(x, y).filter((o) => o[0] === '=').length; return (2 * same) / Math.max(1, x.length + y.length); },
    apply: (a, patch) => { const lines = []; for (const [op, t] of A(patch)) if (op !== '-') lines.push(t); return lines.join('\n'); },
});

// ---------- std.semver ----------
function parseVer(s) { const m = /^v?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+([0-9A-Za-z.-]+))?$/.exec(str(s, 'semver').trim()); if (!m) throw rtError('"' + s + '" is not a version like 1.2.3', 'ValueError'); return { major: +m[1], minor: +m[2], patch: +m[3], pre: m[4] || null, build: m[5] || null }; }
function cmpVer(a, b) { for (const k of ['major', 'minor', 'patch']) if (a[k] !== b[k]) return a[k] < b[k] ? -1 : 1; if (a.pre === b.pre) return 0; if (!a.pre) return 1; if (!b.pre) return -1; const x = a.pre.split('.'), y = b.pre.split('.'); for (let i = 0; i < Math.max(x.length, y.length); i++) { if (x[i] === undefined) return -1; if (y[i] === undefined) return 1; const nx = /^\d+$/.test(x[i]), ny = /^\d+$/.test(y[i]); if (nx && ny) { if (+x[i] !== +y[i]) return +x[i] < +y[i] ? -1 : 1; } else if (nx) return -1; else if (ny) return 1; else if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1; } return 0; }
const verStr = (v) => v.major + '.' + v.minor + '.' + v.patch + (v.pre ? '-' + v.pre : '') + (v.build ? '+' + v.build : '');
export const semverModule = () => ({
    parse: (s) => { const v = parseVer(s); return map(v); },
    compare: (a, b) => cmpVer(parseVer(a), parseVer(b)),
    is_valid: (s) => { try { parseVer(s); return true; } catch (e) { return false; } },
    bump: (s, part) => { const v = parseVer(s); if (part === 'major') return verStr({ major: v.major + 1, minor: 0, patch: 0 }); if (part === 'minor') return verStr({ major: v.major, minor: v.minor + 1, patch: 0 }); if (part === 'patch') return verStr({ major: v.major, minor: v.minor, patch: v.patch + 1 }); throw rtError('bump needs "major", "minor" or "patch"', 'ArgError'); },
    sort: (xs) => A(xs).slice().sort((a, b) => cmpVer(parseVer(a), parseVer(b))),
    max: (xs) => A(xs).reduce((m, x) => (m === null || cmpVer(parseVer(x), parseVer(m)) > 0 ? x : m), null),
    // satisfies("1.4.2", "^1.2.0"), also ~1.2.0, >=1.0.0 <2.0.0, 1.x
    satisfies: (v, range) => { const ver = parseVer(v); return str(range).split('||').some((alt) => alt.trim().split(/\s+/).filter(Boolean).every((c) => { let m = /^(\^|~|>=|<=|>|<|=)?v?(\d+)(?:\.(\d+|x|\*))?(?:\.(\d+|x|\*))?/.exec(c); if (!m) throw rtError('I do not understand the range "' + c + '"', 'ArgError'); const op = m[1] || '='; const t = { major: +m[2], minor: m[3] === undefined || /[x*]/.test(m[3]) ? null : +m[3], patch: m[4] === undefined || /[x*]/.test(m[4]) ? null : +m[4], pre: null }; const lo = { major: t.major, minor: t.minor || 0, patch: t.patch || 0, pre: null }; if (op === '^') { const hi = t.major > 0 ? { major: t.major + 1, minor: 0, patch: 0, pre: null } : t.minor ? { major: 0, minor: t.minor + 1, patch: 0, pre: null } : { major: 0, minor: 0, patch: (t.patch || 0) + 1, pre: null }; return cmpVer(ver, lo) >= 0 && cmpVer(ver, hi) < 0; } if (op === '~') { const hi = t.minor === null ? { major: t.major + 1, minor: 0, patch: 0, pre: null } : { major: t.major, minor: t.minor + 1, patch: 0, pre: null }; return cmpVer(ver, lo) >= 0 && cmpVer(ver, hi) < 0; } if (op === '=') { if (t.minor === null) return ver.major === t.major; if (t.patch === null) return ver.major === t.major && ver.minor === t.minor; return cmpVer(ver, lo) === 0; } const c2 = cmpVer(ver, lo); return op === '>=' ? c2 >= 0 : op === '<=' ? c2 <= 0 : op === '>' ? c2 > 0 : c2 < 0; })); },
});
