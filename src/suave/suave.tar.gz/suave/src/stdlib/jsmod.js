/* std.js: reach the browser's JavaScript from Suave (pdf.js, canvas, files, anything on window).
     use std.js
     lib = await js.import("https://cdn.jsdelivr.net/npm/pdfjs-dist@5/build/pdf.min.mjs")
     doc = await js.get(js.call(lib, "getDocument", {url: "a.pdf"}), "promise")
   JavaScript objects stay opaque: you hold them and pass them back to js.get, js.set, js.call, js.new.
   Suave maps and lists become plain JavaScript objects and arrays on the way in, functions become JavaScript functions,
   Objects coming out stay opaque (js.to_suave(x) makes a map of a plain one). Promises are Suave futures, so await works on them. */
import rt from '../runtime.js';

const { SMap, SFn, Tuple, rtError } = rt;

const isPlain = (x) => x !== null && typeof x === 'object' && Object.prototype.toString.call(x) === '[object Object]' && (Object.getPrototypeOf(x) === Object.prototype || Object.getPrototypeOf(x) === null);
// Suave -> JavaScript
export function toJs(v) {
    if (v === undefined) return null;
    if (v === null || typeof v !== 'object' && typeof v !== 'function') return v;
    if (typeof v === 'function') return v;
    if (v instanceof SFn || v instanceof rt.Bound || v instanceof rt.VariantCtor) return (...a) => toJs(rt.call(v, a.map(fromJs)));
    if (v instanceof SMap) { const o = {}; for (const [k, x] of v.entries()) o[String(k)] = toJs(x); return o; }
    if (v instanceof Uint8Array) return v;
    if (Array.isArray(v) || v instanceof Tuple) return Array.from(v, toJs);
    if (v instanceof rt.SSet) return Array.from(v.values(), toJs);
    return v;
}
// JavaScript -> Suave: numbers, text, lists and promises pass straight through, and every object stays opaque (so libraries like PDFLib keep working).
// js.to_suave(x) turns a plain JavaScript object (like parsed JSON) into a Suave map when you want one.
export function fromJs(x) {
    if (x === undefined) return null;
    if (x instanceof Promise) return x.then(fromJs);
    return x;
}
export function deepFromJs(x) {
    if (x === undefined) return null;
    if (isPlain(x)) { const m = new SMap(); for (const k of Object.keys(x)) m.set(k, deepFromJs(x[k])); return m; }
    if (Array.isArray(x)) return x.map(deepFromJs);
    if (x instanceof Promise) return x.then(deepFromJs);
    return x;
}
const walk = (o, path) => String(path).split('.').filter(Boolean).reduce((a, k) => (a === null || a === undefined ? undefined : a instanceof SMap ? a.get(k) : a[k]), o);
const here = () => (typeof globalThis !== 'undefined' ? globalThis : {});
const named = (args) => args.filter((a) => !(a instanceof rt.Named));

export const jsModule = () => ({
    // window (or the global object)
    window: () => here(),
    global: (name) => fromJs(name === undefined ? here() : walk(here(), name)),
    get: (o, path) => fromJs(path === undefined ? o : walk(o, path)),
    set: (o, path, v) => { const parts = String(path).split('.').filter(Boolean); const last = parts.pop(); const target = parts.length ? walk(o, parts.join('.')) : o; if (target === null || target === undefined) throw rtError('There is nothing at ' + path + ' to set', 'JsError'); target[last] = toJs(v); return null; },
    // js.call(obj, "method.name", args...): calls a method on a JavaScript object
    call: (o, path, ...args) => {
        const parts = String(path).split('.').filter(Boolean); const last = parts.pop();
        const target = parts.length ? walk(o, parts.join('.')) : o;
        const f = target === null || target === undefined ? undefined : target[last];
        if (typeof f !== 'function') throw rtError('JavaScript has no function ' + path + ' there', 'JsError');
        try { return fromJs(f.apply(target, named(args).map(toJs))); } catch (e) { if (e && e.syntax !== undefined || e instanceof rt.SuaveError) throw e; throw rtError('JavaScript said: ' + (e && e.message ? e.message : String(e)), 'JsError'); }
    },
    // js.invoke(fn, args...): calls a JavaScript function you hold
    invoke: (f, ...args) => { if (typeof f !== 'function') throw rtError('js.invoke needs a JavaScript function', 'TypeError'); try { return fromJs(f(...named(args).map(toJs))); } catch (e) { throw rtError('JavaScript said: ' + (e && e.message ? e.message : String(e)), 'JsError'); } },
    // js.new("Uint8Array", buffer)  or  js.new(PDFLib.PDFDocument)
    new: (ctor, ...args) => { const C = typeof ctor === 'string' ? walk(here(), ctor) : ctor; if (typeof C !== 'function') throw rtError('I do not know a JavaScript class called ' + rt.show(ctor), 'JsError'); try { return fromJs(new C(...named(args).map(toJs))); } catch (e) { throw rtError('JavaScript said: ' + (e && e.message ? e.message : String(e)), 'JsError'); } },
    // import a module from a URL (a future)
    import: (url) => new Function('u', 'return import(u)')(String(url)).then(fromJs),
    // load a classic <script src> (a future that finishes when it is ready)
    load_script: (url) => new Promise((res, rej) => { if (typeof document === 'undefined') return rej(rtError('load_script needs a web page', 'EnvError')); const s = document.createElement('script'); s.src = String(url); s.onload = () => res(true); s.onerror = () => rej(rtError('Could not load ' + url, 'JsError')); document.head.appendChild(s); }),
    typeof: (x) => (x === null || x === undefined ? 'null' : typeof x),
    is_null: (x) => x === null || x === undefined,
    to_js: toJs, to_suave: deepFromJs,
    // js.fn(|a, b| ...) makes a function JavaScript can call
    fn: (f) => toJs(f),
});
