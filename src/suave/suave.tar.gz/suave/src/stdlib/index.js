/* The standard library: every module you can "use std.name". Each module is a function that returns its exports. */
import { jsonModule, yamlModule, tomlModule, suvlModule, csvModule, dataModule } from './formats.js';
import { mathModule, statsModule, linalgModule, randomModule, bitsModule, bigintModule, complexModule, rationalModule } from './numeric.js';
import { textModule, fmtModule, regexModule, encodingModule, hashModule, cryptoModule, uuidModule, urlModule, markdownModule, templateModule, colorModule, unitModule, diffModule, semverModule } from './textmods.js';
import { pathModule, fsModule, osModule, envModule, processModule, ioModule, termModule, timeModule, dateModule, logModule, cliModule, testModule, eventsModule, storageModule } from './system.js';
import { dsModule, graphModule, iterModule, funcModule, algoModule } from './structures.js';
import { tableModule, plotModule, geometryModule, xmlModule, iniModule } from './datamods.js';
import { httpModule, domModule, canvasModule } from './web.js';
import { webModule } from './easyweb.js';
import { jsModule } from './jsmod.js';
import { lakerModule } from './lakermod.js';
import { poolModule } from './pools.js';
import { quantumModule } from './quantum.js';
import { qmModule } from './qm.js';
import { asyncModule } from './asyncmod.js';

export const stdlib = {
    'std.json': jsonModule, 'std.yaml': yamlModule, 'std.toml': tomlModule, 'std.suvl': suvlModule, 'std.csv': csvModule, 'std.data': dataModule,
    'std.math': mathModule, 'std.stats': statsModule, 'std.linalg': linalgModule, 'std.random': randomModule, 'std.bits': bitsModule, 'std.bigint': bigintModule, 'std.complex': complexModule, 'std.rational': rationalModule,
    'std.text': textModule, 'std.fmt': fmtModule, 'std.regex': regexModule, 'std.encoding': encodingModule, 'std.hash': hashModule, 'std.crypto': cryptoModule, 'std.uuid': uuidModule, 'std.url': urlModule,
    'std.markdown': markdownModule, 'std.template': templateModule, 'std.color': colorModule, 'std.unit': unitModule, 'std.diff': diffModule, 'std.semver': semverModule,
    'std.path': pathModule, 'std.fs': fsModule, 'std.os': osModule, 'std.env': envModule, 'std.process': processModule, 'std.io': ioModule, 'std.term': termModule,
    'std.time': timeModule, 'std.date': dateModule, 'std.log': logModule, 'std.cli': cliModule, 'std.test': testModule, 'std.events': eventsModule, 'std.storage': storageModule,
    'std.ds': dsModule, 'std.graph': graphModule, 'std.iter': iterModule, 'std.func': funcModule, 'std.algo': algoModule,
    'std.table': tableModule, 'std.plot': plotModule, 'std.geometry': geometryModule, 'std.xml': xmlModule, 'std.ini': iniModule,
    'std.quantum': quantumModule, 'std.qm': qmModule, 'std.async': asyncModule, 'std.pool': poolModule, 'std.http': httpModule, 'std.web': webModule, 'std.dom': domModule, 'std.js': jsModule, 'std.laker': lakerModule, 'std.canvas': canvasModule,
};
