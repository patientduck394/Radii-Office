/* std.qm: quantum mechanics. Constants, hydrogen, particles in boxes, oscillators, tunneling, a 1D Schrodinger equation solver,
   wave packets moving through time, spin, and small complex matrices (Hermitian eigenvalues, commutators, density matrices).
   Numbers are SI unless a name says otherwise (_ev, _nm). Wave functions are lists of numbers or complex numbers. */
import { rt, SMap, Tuple, tuple, opts, num, nums, list, cb, call, map, rtError, show, typeOf, toArray, str } from './_util.js';
import * as CX from '../complexmath.js';

const A = (x) => toArray(x);
const C = CX.C, L = CX.lift;

// ---------- constants (CODATA 2018) ----------
const h = 6.62607015e-34, hbar = h / (2 * Math.PI), c0 = 299792458, e = 1.602176634e-19;
const m_e = 9.1093837015e-31, m_p = 1.67262192369e-27, m_n = 1.67492749804e-27, eps0 = 8.8541878128e-12, k_B = 1.380649e-23;
const a0 = 5.29177210903e-11, R_inf = 10973731.568160, alpha = 7.2973525693e-3;
const CONSTANTS = { h, hbar, c: c0, e, m_e, m_p, m_n, eps0, mu0: 1.25663706212e-6, k_B, N_A: 6.02214076e23, a0, alpha, R_inf, eV: e, amu: 1.66053906660e-27, mu_B: 9.2740100783e-24, G: 6.67430e-11 };

const fact = (n) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };
// generalized Laguerre polynomial L_n^a(x)
function laguerre(n, a, x) { if (n === 0) return 1; let l0 = 1, l1 = 1 + a - x; for (let k = 1; k < n; k++) { const l2 = ((2 * k + 1 + a - x) * l1 - (k + a) * l0) / (k + 1); l0 = l1; l1 = l2; } return l1; }
// Hermite polynomial H_n(x) (physicists')
function hermite(n, x) { if (n === 0) return 1; let h0 = 1, h1 = 2 * x; for (let k = 1; k < n; k++) { const h2 = 2 * x * h1 - 2 * k * h0; h0 = h1; h1 = h2; } return h1; }

// ---------- tridiagonal eigenvalues (Sturm bisection) and vectors (inverse iteration) ----------
function sturmCount(d, e2, x) { let count = 0, q = d[0] - x; if (q < 0) count++; for (let i = 1; i < d.length; i++) { if (q === 0) q = 1e-300; q = d[i] - x - e2[i - 1] / q; if (q < 0) count++; } return count; }
function tridiagEigenvalue(d, off, k, lo, hi) {
    const e2 = off.map((x) => x * x);
    for (let it = 0; it < 200; it++) { const mid = (lo + hi) / 2; if (sturmCount(d, e2, mid) > k) hi = mid; else lo = mid; if (hi - lo < 1e-14 * Math.max(1, Math.abs(lo) + Math.abs(hi))) break; }
    return (lo + hi) / 2;
}
function tridiagSolve(d, off, mu, b) {
    const n = d.length;
    const cp = new Float64Array(n), dp = new Float64Array(n);
    let piv = d[0] - mu; if (Math.abs(piv) < 1e-300) piv = 1e-300;
    cp[0] = off[0] / piv; dp[0] = b[0] / piv;
    for (let i = 1; i < n; i++) { let den = (d[i] - mu) - off[i - 1] * cp[i - 1]; if (Math.abs(den) < 1e-300) den = 1e-300; cp[i] = i < n - 1 ? off[i] / den : 0; dp[i] = (b[i] - off[i - 1] * dp[i - 1]) / den; }
    const x = new Float64Array(n); x[n - 1] = dp[n - 1];
    for (let i = n - 2; i >= 0; i--) x[i] = dp[i] - cp[i] * x[i + 1];
    return x;
}
function tridiagEigenvector(d, off, lambda) {
    const n = d.length;
    let v = Float64Array.from({ length: n }, (_, i) => Math.sin(1.3 * i + 0.7) + 0.3);
    const scale = Math.max(1, Math.abs(lambda));
    for (let it = 0; it < 4; it++) {
        v = tridiagSolve(d, off, lambda + 1e-9 * scale, v);
        let nrm = 0; for (let i = 0; i < n; i++) nrm += v[i] * v[i]; nrm = Math.sqrt(nrm);
        for (let i = 0; i < n; i++) v[i] /= nrm;
    }
    return v;
}

// ---------- in-place FFT on float arrays (for the time evolution) ----------
function fftInPlace(re, im, inverse) {
    const n = re.length;
    if (n & (n - 1)) throw rtError('The wave function needs a power-of-two number of points (64, 128, 256, ...) to evolve in time', 'QMError');
    for (let i = 1, j = 0; i < n; i++) { let bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; } }
    for (let len = 2; len <= n; len <<= 1) {
        const ang = ((inverse ? 2 : -2) * Math.PI) / len, wr = Math.cos(ang), wi = Math.sin(ang);
        for (let i = 0; i < n; i += len) {
            let cr = 1, ci = 0;
            for (let k = 0; k < len / 2; k++) {
                const a = i + k, b = i + k + len / 2;
                const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
                re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
                const nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
            }
        }
    }
    if (inverse) for (let i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
}

// ---------- small complex matrices ----------
const toM = (m) => A(m).map((r) => A(r).map(L));
const fromM = (m) => m;
const mmul = (a, b) => a.map((row) => b[0].map((_, j) => row.reduce((s, x, k) => CX.add(s, CX.mul(x, b[k][j])), C(0, 0))));
const dagger = (a) => a[0].map((_, j) => a.map((row) => CX.conj(row[j])));
const kron = (a, b) => { const out = []; for (const ra of a) for (const rb of b) { const row = []; for (const x of ra) for (const y of rb) row.push(CX.mul(x, y)); out.push(row); } return out; };
const madd = (a, b, sign) => a.map((row, i) => row.map((x, j) => (sign < 0 ? CX.sub(x, b[i][j]) : CX.add(x, b[i][j]))));
const vecL = (v) => A(v).map(L);
const inner = (a, b) => a.reduce((s, x, i) => CX.add(s, CX.mul(CX.conj(x), b[i])), C(0, 0));
const matvec = (m, v) => m.map((row) => row.reduce((s, x, k) => CX.add(s, CX.mul(x, v[k])), C(0, 0)));
function isHermitian(m, tol) { for (let i = 0; i < m.length; i++) for (let j = 0; j < m.length; j++) { const d = CX.sub(m[i][j], CX.conj(m[j][i])); if (CX.abs(d) > (tol || 1e-9)) return false; } return true; }
// eigenvalues and eigenvectors of a Hermitian matrix: embed H = A + iB in the real symmetric [[A, -B], [B, A]] and use Jacobi rotations
function eigh(m) {
    const n = m.length;
    if (!isHermitian(m, 1e-8)) throw rtError('eigh needs a Hermitian matrix (equal to its conjugate transpose)', 'QMError');
    const N = 2 * n;
    const a = Array.from({ length: N }, () => new Float64Array(N));
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { a[i][j] = m[i][j].re; a[i + n][j + n] = m[i][j].re; a[i + n][j] = m[i][j].im; a[i][j + n] = -m[i][j].im; }
    const v = Array.from({ length: N }, (_, i) => { const r = new Float64Array(N); r[i] = 1; return r; });
    for (let sweep = 0; sweep < 100; sweep++) {
        let off = 0; for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) off += a[i][j] * a[i][j];
        if (off < 1e-26) break;
        for (let p = 0; p < N - 1; p++) for (let q = p + 1; q < N; q++) {
            if (Math.abs(a[p][q]) < 1e-300) continue;
            const theta = (a[q][q] - a[p][p]) / (2 * a[p][q]);
            const t = Math.sign(theta || 1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
            const cs = 1 / Math.sqrt(t * t + 1), sn = t * cs;
            for (let k = 0; k < N; k++) { const akp = a[k][p], akq = a[k][q]; a[k][p] = cs * akp - sn * akq; a[k][q] = sn * akp + cs * akq; }
            for (let k = 0; k < N; k++) { const apk = a[p][k], aqk = a[q][k]; a[p][k] = cs * apk - sn * aqk; a[q][k] = sn * apk + cs * aqk; }
            for (let k = 0; k < N; k++) { const vkp = v[k][p], vkq = v[k][q]; v[k][p] = cs * vkp - sn * vkq; v[k][q] = sn * vkp + cs * vkq; }
        }
    }
    const order = Array.from({ length: N }, (_, i) => i).sort((x, y) => a[x][x] - a[y][y]);
    const values = [], vectors = [];
    for (const idx of order) {
        // the complex vector is (u + i w) from the two halves of the real eigenvector
        const vec = Array.from({ length: n }, (_, k) => C(v[k][idx], v[k + n][idx]));
        for (const prev of vectors) { const ip = inner(prev, vec); for (let k = 0; k < n; k++) vec[k] = CX.sub(vec[k], CX.mul(ip, prev[k])); }
        const nrm = Math.sqrt(vec.reduce((s, z) => s + CX.norm2(z), 0));
        if (nrm < 1e-6) continue;
        for (let k = 0; k < n; k++) vec[k] = C(vec[k].re / nrm, vec[k].im / nrm);
        vectors.push(vec); values.push(a[idx][idx]);
        if (values.length === n) break;
    }
    return { values, vectors };
}

const ORBITALS = ['s', 'p', 'd', 'f', 'g', 'h', 'i'];
const MADELUNG = [[1, 0], [2, 0], [2, 1], [3, 0], [3, 1], [4, 0], [3, 2], [4, 1], [5, 0], [4, 2], [5, 1], [6, 0], [4, 3], [5, 2], [6, 1], [7, 0], [5, 3], [6, 2], [7, 1]];

export const qmModule = () => {
    const potentialFn = (V, x) => (typeof V === 'number' ? V : (() => { const f = cb(V); return f(x); })());
    const norm = (psi, dx) => Math.sqrt(psi.reduce((s, z) => s + CX.norm2(z), 0) * dx);
    return Object.assign({}, CONSTANTS, {
        constants: map(CONSTANTS),
        // ----- light and matter waves -----
        photon_energy_ev: (nm) => (h * c0) / (nm * 1e-9) / e, photon_wavelength_nm: (ev) => ((h * c0) / (ev * e)) * 1e9, photon_frequency: (nm) => c0 / (nm * 1e-9), photon_momentum: (nm) => h / (nm * 1e-9),
        de_broglie: (mass_kg, velocity) => h / (mass_kg * velocity),
        // the wavelength of an electron sped up through some volts (in metres)
        electron_wavelength: (volts) => h / Math.sqrt(2 * m_e * e * volts),
        compton_wavelength: (mass_kg) => h / (mass_kg * c0),
        // the smallest spread in momentum for a spread dx in position (Heisenberg): dp >= hbar / (2 dx)
        min_momentum_spread: (dx) => hbar / (2 * dx), min_energy_spread: (dt) => hbar / (2 * dt),
        // ----- hydrogen (energies in eV, lengths in metres, with the nucleus' charge z) -----
        hydrogen_energy: (n, z) => (-R_inf * h * c0 * (z === undefined ? 1 : z) ** 2) / (n * n) / e,
        hydrogen_radius: (n, z) => (n * n * a0) / (z === undefined ? 1 : z),
        hydrogen_degeneracy: (n) => 2 * n * n,
        // hydrogen_transition(3, 2) is the H-alpha line: {energy_ev, wavelength_nm, frequency_hz, series}
        hydrogen_transition: (hi, lo) => { if (hi <= lo) throw rtError('The electron falls from a higher level (' + hi + ') to a lower one (' + lo + ')', 'QMError'); const ev = (R_inf * h * c0 * (1 / (lo * lo) - 1 / (hi * hi))) / e; const series = { 1: 'Lyman', 2: 'Balmer', 3: 'Paschen', 4: 'Brackett', 5: 'Pfund' }[lo] || 'level ' + lo; return map({ energy_ev: ev, wavelength_nm: ((h * c0) / (ev * e)) * 1e9, frequency_hz: (ev * e) / h, series }); },
        rydberg_wavelength_nm: (lo, hi) => (1e9 / (R_inf * (1 / (lo * lo) - 1 / (hi * hi)))),
        // the radial wave function R_nl(r) with r in Bohr radii (a0 = 1); r^2 R^2 is the chance of finding the electron at distance r
        hydrogen_radial: (n, l, r) => { if (l < 0 || l >= n) throw rtError('l must be from 0 to n-1', 'QMError'); const rho = (2 * r) / n; return Math.sqrt(Math.pow(2 / n, 3) * fact(n - l - 1) / (2 * n * fact(n + l))) * Math.exp(-rho / 2) * Math.pow(rho, l) * laguerre(n - l - 1, 2 * l + 1, rho); },
        hydrogen_density: (n, l, r) => { const rho = (2 * r) / n; const R = Math.sqrt(Math.pow(2 / n, 3) * fact(n - l - 1) / (2 * n * fact(n + l))) * Math.exp(-rho / 2) * Math.pow(rho, l) * laguerre(n - l - 1, 2 * l + 1, rho); return r * r * R * R; },
        orbital_name: (n, l) => n + ORBITALS[l],
        // every allowed (n, l, m, spin) of a shell
        quantum_numbers: (n) => { const out = []; for (let l = 0; l < n; l++) for (let m = -l; m <= l; m++) for (const s of [0.5, -0.5]) out.push(tuple([n, l, m, s])); return out; },
        // the Madelung filling order; a few real atoms (Cr, Cu...) differ
        electron_configuration: (z) => { let left = z; const parts = []; for (const [n, l] of MADELUNG) { if (left <= 0) break; const k = Math.min(left, 2 * (2 * l + 1)); parts.push(n + ORBITALS[l] + k); left -= k; } return parts.join(' '); },
        // ----- particle in a box (a well of width L with hard walls) -----
        box_energy: (n, L, m) => (n * n * h * h) / (8 * (m === undefined ? m_e : m) * L * L),
        box_energy_ev: (n, L, m) => (n * n * h * h) / (8 * (m === undefined ? m_e : m) * L * L) / e,
        box_psi: (n, L, x) => (x < 0 || x > L ? 0 : Math.sqrt(2 / L) * Math.sin((n * Math.PI * x) / L)),
        // the chance of finding the particle between x1 and x2
        box_probability: (n, L, x1, x2) => (x2 - x1) / L - (Math.sin((2 * n * Math.PI * x2) / L) - Math.sin((2 * n * Math.PI * x1) / L)) / (2 * n * Math.PI),
        // ----- harmonic oscillator -----
        oscillator_energy: (n, omega, hb) => (hb === undefined ? hbar : hb) * omega * (n + 0.5),
        oscillator_psi: (n, x, o) => { const op = opts(o); const m = op.m === undefined ? 1 : op.m, w = op.omega === undefined ? 1 : op.omega, hb = op.hbar === undefined ? 1 : op.hbar; const xi = x * Math.sqrt((m * w) / hb); return Math.pow((m * w) / (Math.PI * hb), 0.25) / Math.sqrt(Math.pow(2, n) * fact(n)) * hermite(n, xi) * Math.exp(-xi * xi / 2); },
        hermite: (n, x) => hermite(n, x), laguerre: (n, a, x) => laguerre(n, a, x),
        // ----- tunneling through a rectangular barrier of height V0 and width a -----
        tunneling: (E, V0, a, m, hb) => { const mm = m === undefined ? m_e : m, hh = hb === undefined ? hbar : hb; if (E <= 0) return 0; if (Math.abs(E - V0) < 1e-12 * Math.abs(V0)) return 1 / (1 + (mm * V0 * a * a) / (2 * hh * hh)); if (E < V0) { const kappa = Math.sqrt(2 * mm * (V0 - E)) / hh; return 1 / (1 + (V0 * V0 * Math.sinh(kappa * a) ** 2) / (4 * E * (V0 - E))); } const k2 = Math.sqrt(2 * mm * (E - V0)) / hh; return 1 / (1 + (V0 * V0 * Math.sin(k2 * a) ** 2) / (4 * E * (E - V0))); },
        // ----- the Schrodinger equation in one dimension -----
        // solve_1d(|x| 0.5 * x * x, -6, 6, 400, k: 4): the k lowest energies and their wave functions (m = hbar = 1 unless you say otherwise)
        solve_1d: (V, xmin, xmax, n, o) => {
            const op = opts(o); const k = op.k === undefined ? 4 : op.k, m = op.m === undefined ? 1 : op.m, hb = op.hbar === undefined ? 1 : op.hbar;
            const N = n === undefined ? 400 : n; const dx = (xmax - xmin) / (N + 1);
            const xs = Array.from({ length: N }, (_, i) => xmin + (i + 1) * dx);
            const kin = (hb * hb) / (m * dx * dx);
            const d = xs.map((x) => kin + potentialFn(V, x));
            const off = new Array(N - 1).fill(-kin / 2);
            let lo = Infinity, hi = -Infinity;
            for (let i = 0; i < N; i++) { const r = (i > 0 ? Math.abs(off[i - 1]) : 0) + (i < N - 1 ? Math.abs(off[i]) : 0); lo = Math.min(lo, d[i] - r); hi = Math.max(hi, d[i] + r); }
            const energies = [], states = [];
            for (let j = 0; j < Math.min(k, N); j++) {
                const E = tridiagEigenvalue(d, off, j, lo, hi);
                const v = tridiagEigenvector(d, off, E);
                let nrm = 0; for (let i = 0; i < N; i++) nrm += v[i] * v[i]; nrm = Math.sqrt(nrm * dx);
                let sign = 1; for (let i = 0; i < N; i++) if (Math.abs(v[i]) > 1e-8 * Math.sqrt(1 / dx)) { sign = v[i] < 0 ? -1 : 1; break; }
                energies.push(E); states.push(Array.from(v, (t) => (sign * t) / nrm));
            }
            return map({ energies, states, x: xs, dx });
        },
        // ----- wave functions and time -----
        gaussian_packet: (xs, x0, sigma, k0) => { const g = A(xs).map((x) => { const env = Math.exp(-((x - x0) ** 2) / (4 * sigma * sigma)); const ph = (k0 || 0) * x; return C(env * Math.cos(ph), env * Math.sin(ph)); }); const dx = A(xs)[1] - A(xs)[0]; const nrm = norm(g, dx); return g.map((z) => C(z.re / nrm, z.im / nrm)); },
        probability_density: (psi) => A(psi).map((z) => CX.norm2(L(z))),
        norm: (psi, dx) => norm(vecL(psi), dx),
        // the chance of finding the particle between x = a and x = b
        probability: (psi, xs, a, b) => { const p = vecL(psi), x = A(xs); const dx = x[1] - x[0]; let s = 0; for (let i = 0; i < p.length; i++) if (x[i] >= a && x[i] <= b) s += CX.norm2(p[i]) * dx; return s; },
        expect_x: (psi, xs) => { const p = vecL(psi), x = A(xs); const dx = x[1] - x[0]; return p.reduce((s, z, i) => s + x[i] * CX.norm2(z) * dx, 0); },
        // the average of f(x): expect(psi, xs, |x| x * x)
        expect: (psi, xs, f) => { const p = vecL(psi), x = A(xs), g = cb(f); const dx = x[1] - x[0]; return p.reduce((s, z, i) => s + g(x[i]) * CX.norm2(z) * dx, 0); },
        expect_p: (psi, xs, hb) => { const p = vecL(psi), x = A(xs); const dx = x[1] - x[0]; let s = C(0, 0); for (let i = 1; i < p.length - 1; i++) { const d = C((p[i + 1].re - p[i - 1].re) / (2 * dx), (p[i + 1].im - p[i - 1].im) / (2 * dx)); s = CX.add(s, CX.mul(CX.conj(p[i]), d)); } const v = CX.mul(C(0, -(hb === undefined ? 1 : hb)), s); return v.re * dx; },
        spread_x: (psi, xs) => { const p = vecL(psi), x = A(xs); const dx = x[1] - x[0]; const m1 = p.reduce((s, z, i) => s + x[i] * CX.norm2(z) * dx, 0), m2 = p.reduce((s, z, i) => s + x[i] * x[i] * CX.norm2(z) * dx, 0); return Math.sqrt(Math.max(0, m2 - m1 * m1)); },
        // evolve(psi, V, xs, dt: 0.01, steps: 200, m: 1, hbar: 1): split-step Fourier time evolution (the number of points must be 64, 128, 256...)
        // V is a list of potentials or a function; frames: 10 also gives 10 snapshots of the probability density
        evolve: (psi, V, xs, o) => {
            const op = opts(o); const dt = op.dt === undefined ? 0.01 : op.dt, steps = op.steps === undefined ? 100 : op.steps, m = op.m === undefined ? 1 : op.m, hb = op.hbar === undefined ? 1 : op.hbar, frames = op.frames || 0;
            const p = vecL(psi), x = A(xs); const N = p.length, dx = x[1] - x[0];
            const re = Float64Array.from(p, (z) => z.re), im = Float64Array.from(p, (z) => z.im);
            const pot = Array.isArray(V) || (V && V.params === undefined && typeof V === 'object' && V.length !== undefined) ? A(V).map(Number) : x.map((xi) => potentialFn(V, xi));
            const kgrid = Float64Array.from({ length: N }, (_, i) => (2 * Math.PI * (i < N / 2 ? i : i - N)) / (N * dx));
            const half = pot.map((v) => [Math.cos((-v * dt) / (2 * hb)), Math.sin((-v * dt) / (2 * hb))]);
            const kin = Array.from(kgrid, (kk) => { const a = (-hb * kk * kk * dt) / (2 * m); return [Math.cos(a), Math.sin(a)]; });
            const snaps = [];
            const every = frames ? Math.max(1, Math.floor(steps / frames)) : 0;
            const mulv = (tab) => { for (let i = 0; i < N; i++) { const r = re[i], q = im[i]; re[i] = r * tab[i][0] - q * tab[i][1]; im[i] = r * tab[i][1] + q * tab[i][0]; } };
            for (let s = 0; s < steps; s++) {
                mulv(half); fftInPlace(re, im, false); mulv(kin); fftInPlace(re, im, true); mulv(half);
                if (every && (s + 1) % every === 0) snaps.push(Array.from(re, (r, i) => r * r + im[i] * im[i]));
            }
            const out = Array.from(re, (r, i) => C(r, im[i]));
            return frames ? map({ psi: out, frames: snaps }) : out;
        },
        // ----- spin and Pauli algebra -----
        pauli: () => map({ I: [[C(1, 0), C(0, 0)], [C(0, 0), C(1, 0)]], X: [[C(0, 0), C(1, 0)], [C(1, 0), C(0, 0)]], Y: [[C(0, 0), C(0, -1)], [C(0, 1), C(0, 0)]], Z: [[C(1, 0), C(0, 0)], [C(0, 0), C(-1, 0)]] }),
        spin_up: () => [C(1, 0), C(0, 0)], spin_down: () => [C(0, 0), C(1, 0)],
        // a spin pointing at polar angle theta and azimuth phi on the Bloch sphere
        spin_state: (theta, phi) => [C(Math.cos(theta / 2), 0), C(Math.cos(phi || 0) * Math.sin(theta / 2), Math.sin(phi || 0) * Math.sin(theta / 2))],
        spin_expect: (psi, axis) => { const v = vecL(psi); const P = { x: [[C(0, 0), C(1, 0)], [C(1, 0), C(0, 0)]], y: [[C(0, 0), C(0, -1)], [C(0, 1), C(0, 0)]], z: [[C(1, 0), C(0, 0)], [C(0, 0), C(-1, 0)]] }[String(axis).toLowerCase()]; if (!P) throw rtError('axis must be "x", "y" or "z"', 'QMError'); return inner(v, matvec(P, v)).re / Math.max(1e-300, inner(v, v).re); },
        // measure the spin along an axis: +1 or -1 (the state is not changed; use spin_collapse to get the new state)
        spin_measure: (psi, axis) => { const ex = (() => { const v = vecL(psi); const P = { x: [[C(0, 0), C(1, 0)], [C(1, 0), C(0, 0)]], y: [[C(0, 0), C(0, -1)], [C(0, 1), C(0, 0)]], z: [[C(1, 0), C(0, 0)], [C(0, 0), C(-1, 0)]] }[String(axis).toLowerCase()]; return inner(v, matvec(P, v)).re / Math.max(1e-300, inner(v, v).re); })(); return rt.rng.float() < (1 + ex) / 2 ? 1 : -1; },
        // ----- complex matrices: lists of lists of numbers or complex numbers -----
        matmul: (a, b) => mmul(toM(a), toM(b)), dagger: (a) => dagger(toM(a)), kron: (a, b) => kron(toM(a), toM(b)),
        add: (a, b) => madd(toM(a), toM(b), 1), sub: (a, b) => madd(toM(a), toM(b), -1),
        scale: (a, k) => toM(a).map((r) => r.map((x) => CX.mul(x, L(k)))),
        trace: (a) => toM(a).reduce((s, r, i) => CX.add(s, r[i]), C(0, 0)),
        commutator: (a, b) => { const x = toM(a), y = toM(b); return madd(mmul(x, y), mmul(y, x), -1); },
        anticommutator: (a, b) => { const x = toM(a), y = toM(b); return madd(mmul(x, y), mmul(y, x), 1); },
        apply: (a, psi) => matvec(toM(a), vecL(psi)),
        inner: (a, b) => inner(vecL(a), vecL(b)), outer: (a, b) => vecL(a).map((x) => vecL(b).map((y) => CX.mul(x, CX.conj(y)))),
        // <psi| A |psi> for a Hermitian A
        expect_op: (psi, a) => { const v = vecL(psi); const r = inner(v, matvec(toM(a), v)); return Math.abs(r.im) < 1e-12 ? r.re : r; },
        normalize: (psi) => { const v = vecL(psi); const n = Math.sqrt(v.reduce((s, z) => s + CX.norm2(z), 0)); return v.map((z) => C(z.re / n, z.im / n)); },
        born: (psi) => { const v = vecL(psi); const t = v.reduce((s, z) => s + CX.norm2(z), 0); return v.map((z) => CX.norm2(z) / t); },
        is_hermitian: (a) => isHermitian(toM(a)),
        is_unitary: (a) => { const m = toM(a); const p = mmul(m, dagger(m)); return p.every((r, i) => r.every((x, j) => CX.abs(CX.sub(x, C(i === j ? 1 : 0, 0))) < 1e-9)); },
        // eigh(H): {values (lowest first), vectors}
        eigh: (a) => { const r = eigh(toM(a)); return map({ values: r.values, vectors: r.vectors }); },
        // the state after time t under the Hamiltonian H (a Hermitian matrix): exp(-i H t / hbar) |psi>
        time_evolve: (H, psi, t, hb) => { const { values, vectors } = eigh(toM(H)); const v = vecL(psi); const hh = hb === undefined ? 1 : hb; const out = v.map(() => C(0, 0)); values.forEach((E, k) => { const coef = CX.mul(inner(vectors[k], v), CX.fromPolar(1, (-E * t) / hh)); for (let i = 0; i < out.length; i++) out[i] = CX.add(out[i], CX.mul(coef, vectors[k][i])); }); return out; },
        density: (psi) => { const v = vecL(psi); const t = v.reduce((s, z) => s + CX.norm2(z), 0); return v.map((x) => v.map((y) => { const z = CX.mul(x, CX.conj(y)); return C(z.re / t, z.im / t); })); },
        purity: (rho) => { const m = toM(rho); return mmul(m, m).reduce((s, r, i) => s + r[i].re, 0); },
        // the entropy of a density matrix in bits (0 = a pure state)
        von_neumann: (rho) => { const { values } = eigh(toM(rho)); return values.reduce((s, l) => (l > 1e-12 ? s - l * Math.log2(l) : s), 0); },
        ket_text: (psi) => vecL(psi).map((z, i, a) => { const n = Math.log2(a.length); return CX.abs(z) < 1e-9 ? null : (Math.abs(z.im) < 1e-9 ? String(+z.re.toPrecision(4)) : Math.abs(z.re) < 1e-9 ? (Math.abs(z.im) === 1 ? (z.im < 0 ? '-i' : 'i') : String(+z.im.toPrecision(4)) + 'i') : '(' + String(+z.re.toPrecision(4)) + (z.im < 0 ? ' - ' : ' + ') + String(+Math.abs(z.im).toPrecision(4)) + 'i)') + '|' + (Number.isInteger(n) && n > 0 ? i.toString(2).padStart(n, '0') : i) + '>'; }).filter(Boolean).join(' + '),
        ev_to_joule: (v) => v * e, joule_to_ev: (v) => v / e, nm_to_m: (v) => v * 1e-9,
    });
};
