/* std.pool: ready-made pools. A pool is a value that is decided when it is first used (see docs/POOLS.md). */
import { rt, SMap, SPool, opts, num, nums, list, cb, call, map, rtError, show, typeOf, toArray, str, tuple } from './_util.js';
import { makePool } from '../interp.js';
import { entangle } from '../methods.js';

const A = (x) => toArray(x);
const f = () => rt.rng.float();
export const poolModule = () => {
    const mk = (sampler) => new SPool(null, null, sampler);
    const normal = (mu, sigma) => () => (mu === undefined ? 0 : mu) + (sigma === undefined ? 1 : sigma) * Math.sqrt(-2 * Math.log(1 - f())) * Math.cos(2 * Math.PI * f());
    return {
        new: (options, w) => makePool(options, w instanceof rt.Named ? w.obj.weights : w),
        // pool.die(6) is pool 1..=6, pool.coin() is pool ["heads", "tails"]
        die: (n) => makePool(Array.from({ length: n === undefined ? 6 : n }, (_, i) => i + 1)),
        dice: (spec) => { const m = /^(\d*)d(\d+)([+-]\d+)?$/.exec(str(spec, 'pool.dice')); if (!m) throw rtError('dice needs text like "2d6+1"', 'ArgError'); return mk(() => { let t = Number(m[3] || 0); for (let i = 0; i < Number(m[1] || 1); i++) t += 1 + Math.floor(f() * Number(m[2])); return t; }); },
        coin: (p) => makePool(['heads', 'tails'], p === undefined ? undefined : [p, 1 - p]),
        bool: (p) => makePool([true, false], [p === undefined ? 0.5 : p, 1 - (p === undefined ? 0.5 : p)]),
        choice: (xs) => makePool(A(xs)),
        weighted: (m) => makePool(m),
        // pools that give a fresh number every time they are decided
        uniform: (a, b) => mk(() => a + f() * (b - a)),
        normal: (mu, sigma) => mk(normal(mu, sigma)),
        exponential: (rate) => mk(() => -Math.log(1 - f()) / (rate === undefined ? 1 : rate)),
        poisson: (lambda) => mk(() => { const L = Math.exp(-lambda); let k = 0, p = 1; do { k++; p *= f(); } while (p > L); return k - 1; }),
        int: (a, b) => mk(() => a + Math.floor(f() * (b - a + 1))),
        from_fn: (fn) => { const g = cb(fn); return mk(() => g()); },
        // a pool of orderings: pool.shuffle([1, 2, 3]) decides on one shuffled list
        shuffle: (xs) => { const a = A(xs); return mk(() => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(f() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; }); },
        // a hand of k different cards from a deck
        deal: (xs, k) => { const a = A(xs); return mk(() => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(f() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r.slice(0, k); }); },
        entangle: (...ps) => entangle(ps),
        // several separate pools made the same way, each decided on its own
        many: (n, fn) => Array.from({ length: n }, () => call(fn, [])),
        decide_all: (ps) => A(ps).map((p) => (p instanceof SPool ? p.decide() : p)),
        is_pool: (x) => x instanceof SPool, is_decided: (x) => x instanceof SPool && x.decided,
        seed: (n) => { rt.rng = rt.makeRng(n); return null; },
    };
};
