/* Number crunching: std.math, std.stats, std.linalg, std.random, std.bits, std.bigint, std.complex, std.rational. */
import * as CX from '../complexmath.js';
import { rt, SMap, SSet, SObj, SVariant, Tuple, tuple, SRange, SIter, Named, opts, num, nums, list, cb, call, map, nativeType, make, rtError, show, repr, eq, truthy, typeOf, ok, err, toArray, iterate, str } from './_util.js';

const A = (x) => toArray(x);

// ---------- std.math ----------
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a, b] = [b, a % b]; } return a; }
function isPrime(n) {
    if (n < 2 || !Number.isInteger(n)) return false;
    if (n < 4) return true;
    if (n % 2 === 0 || n % 3 === 0) return false;
    for (let i = 5; i * i <= n; i += 6) if (n % i === 0 || n % (i + 2) === 0) return false;
    return true;
}
export const mathModule = () => {
    const f1 = (fn, name, cfn) => (x) => (x instanceof rt.SComplex && cfn ? cfn(x) : fn(num(x, name)));
    const isC = (x) => x instanceof rt.SComplex;
    return {
        I: CX.C(0, 1), PI: Math.PI, E: Math.E, TAU: Math.PI * 2, INF: Infinity, NAN: NaN, pi: Math.PI, e: Math.E, tau: Math.PI * 2, inf: Infinity, nan: NaN, PHI: (1 + Math.sqrt(5)) / 2, SQRT2: Math.SQRT2, LN2: Math.LN2, LN10: Math.LN10,
        sin: f1(Math.sin, 'sin', CX.sin), cos: f1(Math.cos, 'cos', CX.cos), tan: f1(Math.tan, 'tan', CX.tan), asin: f1(Math.asin, 'asin'), acos: f1(Math.acos, 'acos'), atan: f1(Math.atan, 'atan'),
        atan2: (y, x) => Math.atan2(num(y), num(x)), sinh: f1(Math.sinh, 'sinh', CX.sinh), cosh: f1(Math.cosh, 'cosh', CX.cosh), tanh: f1(Math.tanh, 'tanh', CX.tanh),
        asinh: f1(Math.asinh), acosh: f1(Math.acosh), atanh: f1(Math.atanh),
        exp: f1(Math.exp, 'exp', CX.exp), ln: (x) => (isC(x) || num(x, 'ln') < 0 ? CX.ln(CX.lift(x)) : Math.log(x)), log: (x, b) => (b === undefined ? Math.log(num(x)) : Math.log(num(x)) / Math.log(num(b))), log2: f1(Math.log2), log10: f1(Math.log10),
        sqrt: (x) => (isC(x) || num(x, 'sqrt') < 0 ? CX.sqrt(CX.lift(x)) : Math.sqrt(x)), cbrt: f1(Math.cbrt), pow: (a, b) => (isC(a) || isC(b) || (num(a) < 0 && !Number.isInteger(num(b))) ? CX.pow(CX.lift(a), CX.lift(b)) : Math.pow(a, b)), hypot: (...a) => Math.hypot(...a.map((x) => num(x))),
        floor: f1(Math.floor), ceil: f1(Math.ceil), trunc: f1(Math.trunc), abs: f1(Math.abs, 'abs', CX.abs), sign: f1(Math.sign),
        round: (x, p) => { num(x); const f = Math.pow(10, p || 0); return Math.sign(x) * Math.round(Math.abs(x) * f + 1e-9) / f; },
        min: (...a) => Math.min(...(a.length === 1 ? nums(a[0]) : a)), max: (...a) => Math.max(...(a.length === 1 ? nums(a[0]) : a)),
        clamp: (x, lo, hi) => Math.min(Math.max(num(x), num(lo)), num(hi)),
        lerp: (a, b, t) => a + (b - a) * t,
        remap: (x, a, b, c, d) => c + ((x - a) / (b - a)) * (d - c),
        deg: (r) => (r * 180) / Math.PI, rad: (d) => (d * Math.PI) / 180,
        is_nan: (x) => Number.isNaN(x), is_finite: (x) => Number.isFinite(x), is_int: (x) => Number.isInteger(x),
        approx: (a, b, eps) => Math.abs(a - b) <= (eps === undefined ? 1e-9 : eps) * Math.max(1, Math.abs(a), Math.abs(b)),
        gcd: (...a) => a.reduce((x, y) => gcd(x, y)),
        lcm: (...a) => a.reduce((x, y) => (x === 0 || y === 0 ? 0 : Math.abs(x * y) / gcd(x, y))),
        factorial: (n) => { if (!Number.isInteger(n) || n < 0) throw rtError('factorial needs a whole number that is not negative', 'MathError'); let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; },
        choose: (n, k) => { if (k < 0 || k > n) return 0; k = Math.min(k, n - k); let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return Math.round(r); },
        permutations: (n, k) => { let r = 1; for (let i = 0; i < k; i++) r *= n - i; return r; },
        fib: (n) => { let a = 0, b = 1; for (let i = 0; i < n; i++) { [a, b] = [b, a + b]; } return a; },
        is_prime: isPrime,
        primes: (n) => { const s = new Uint8Array(n + 1).fill(1); s[0] = s[1] = 0; for (let i = 2; i * i <= n; i++) if (s[i]) for (let j = i * i; j <= n; j += i) s[j] = 0; const r = []; for (let i = 2; i <= n; i++) if (s[i]) r.push(i); return r; },
        next_prime: (n) => { let k = Math.floor(n) + 1; while (!isPrime(k)) k++; return k; },
        prime_factors: (n) => { const r = []; for (let p = 2; p * p <= n; p++) while (n % p === 0) { r.push(p); n /= p; } if (n > 1) r.push(n); return r; },
        divisors: (n) => { const r = []; for (let i = 1; i * i <= n; i++) if (n % i === 0) { r.push(i); if (i * i !== n) r.push(n / i); } return r.sort((a, b) => a - b); },
        mod_pow: (b, e, m) => { let r = 1n; let bb = BigInt(b) % BigInt(m), ee = BigInt(e); const mm = BigInt(m); while (ee > 0n) { if (ee & 1n) r = (r * bb) % mm; bb = (bb * bb) % mm; ee >>= 1n; } return Number(r); },
        isqrt: (n) => Math.floor(Math.sqrt(n)),
        sum: (xs) => nums(xs).reduce((a, b) => a + b, 0), product: (xs) => nums(xs).reduce((a, b) => a * b, 1),
        mean: (xs) => { const a = nums(xs); return a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN; },
        digits_sum: (n) => String(Math.abs(Math.trunc(n))).split('').reduce((a, d) => a + Number(d), 0),
        is_perfect_square: (n) => Number.isInteger(n) && n >= 0 && Number.isInteger(Math.sqrt(n)),
        collatz: (n) => { const r = [n]; while (n !== 1) { n = n % 2 ? 3 * n + 1 : n / 2; r.push(n); } return r; },
        // roots of a x^2 + b x + c: a list of 0, 1 or 2 numbers
        quadratic: (a, b, c) => { const d = b * b - 4 * a * c; if (d < 0) return []; if (d === 0) return [-b / (2 * a)]; const s = Math.sqrt(d); return [(-b - s) / (2 * a), (-b + s) / (2 * a)]; },
        // find a root of f between a and b by bisection
        solve: (f, a, b, tol) => { const g = cb(f); let lo = a, hi = b; const t = tol === undefined ? 1e-12 : tol; if (g(lo) * g(hi) > 0) throw rtError('solve needs f(a) and f(b) to have different signs', 'MathError'); for (let i = 0; i < 200 && hi - lo > t; i++) { const mid = (lo + hi) / 2; if (g(lo) * g(mid) <= 0) hi = mid; else lo = mid; } return (lo + hi) / 2; },
        // numeric integral by Simpson's rule
        integrate: (f, a, b, n) => { const g = cb(f); const N = (n || 1000) % 2 ? (n || 1000) + 1 : (n || 1000); const h = (b - a) / N; let s = g(a) + g(b); for (let i = 1; i < N; i++) s += g(a + i * h) * (i % 2 ? 4 : 2); return (s * h) / 3; },
        derivative: (f, x, h) => { const g = cb(f); const d = h || 1e-6; return (g(x + d) - g(x - d)) / (2 * d); },
    };
};

// ---------- std.stats ----------
const sum = (a) => a.reduce((x, y) => x + y, 0);
const mean = (a) => sum(a) / a.length;
function variance(a, sample) { if (a.length < (sample ? 2 : 1)) return NaN; const m = mean(a); return a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - (sample ? 1 : 0)); }
function percentile(sorted, p) {
    if (!sorted.length) return NaN;
    const k = (sorted.length - 1) * p;
    const lo = Math.floor(k), hi = Math.ceil(k);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (k - lo);
}
const sortedNums = (x, w) => nums(x, w).slice().sort((a, b) => a - b);
export const statsModule = () => {
    const corr = (x, y) => { const a = nums(x), b = nums(y); if (a.length !== b.length) throw rtError('corr needs two lists of the same length', 'ArgError'); const ma = mean(a), mb = mean(b); let n = 0, da = 0, db = 0; for (let i = 0; i < a.length; i++) { n += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2; } return n / Math.sqrt(da * db); };
    return {
        sum: (x) => sum(nums(x)), mean: (x) => mean(nums(x)),
        median: (x) => percentile(sortedNums(x), 0.5),
        mode: (x) => { const m = new SMap(); let best = null, bc = 0; for (const v of A(x)) { const c = (m.get(v) || 0) + 1; m.set(v, c); if (c > bc) { bc = c; best = v; } } return best; },
        modes: (x) => { const m = new SMap(); let bc = 0; for (const v of A(x)) { const c = (m.get(v) || 0) + 1; m.set(v, c); if (c > bc) bc = c; } return m.entries().filter(([, c]) => c === bc).map(([k]) => k); },
        variance: (x) => variance(nums(x), false), sample_variance: (x) => variance(nums(x), true),
        stddev: (x) => Math.sqrt(variance(nums(x), false)), sample_stddev: (x) => Math.sqrt(variance(nums(x), true)),
        min: (x) => Math.min(...nums(x)), max: (x) => Math.max(...nums(x)), range: (x) => { const a = nums(x); return Math.max(...a) - Math.min(...a); },
        percentile: (x, p) => percentile(sortedNums(x), p / 100), quantile: (x, q) => percentile(sortedNums(x), q),
        iqr: (x) => { const s = sortedNums(x); return percentile(s, 0.75) - percentile(s, 0.25); },
        cov: (x, y) => { const a = nums(x), b = nums(y); const ma = mean(a), mb = mean(b); let s = 0; for (let i = 0; i < a.length; i++) s += (a[i] - ma) * (b[i] - mb); return s / a.length; },
        corr,
        zscore: (x) => { const a = nums(x); const m = mean(a), s = Math.sqrt(variance(a, false)); return a.map((v) => (v - m) / s); },
        normalize: (x) => { const a = nums(x); const lo = Math.min(...a), hi = Math.max(...a); return a.map((v) => (hi === lo ? 0 : (v - lo) / (hi - lo))); },
        cumsum: (x) => { let t = 0; return nums(x).map((v) => (t += v)); }, cumprod: (x) => { let t = 1; return nums(x).map((v) => (t *= v)); },
        moving_avg: (x, k) => { const a = nums(x); const r = []; for (let i = 0; i + k <= a.length; i++) r.push(mean(a.slice(i, i + k))); return r; },
        geomean: (x) => Math.exp(mean(nums(x).map(Math.log))), harmean: (x) => { const a = nums(x); return a.length / sum(a.map((v) => 1 / v)); },
        weighted_mean: (x, w) => { const a = nums(x), b = nums(w); return sum(a.map((v, i) => v * b[i])) / sum(b); },
        skew: (x) => { const a = nums(x); const m = mean(a), s = Math.sqrt(variance(a, false)); return mean(a.map((v) => ((v - m) / s) ** 3)); },
        kurtosis: (x) => { const a = nums(x); const m = mean(a), s = Math.sqrt(variance(a, false)); return mean(a.map((v) => ((v - m) / s) ** 4)) - 3; },
        rank: (x) => { const a = nums(x); const idx = a.map((v, i) => [v, i]).sort((p, q) => p[0] - q[0]); const r = new Array(a.length); for (let i = 0; i < idx.length; i++) { let j = i; while (j + 1 < idx.length && idx[j + 1][0] === idx[i][0]) j++; for (let k = i; k <= j; k++) r[idx[k][1]] = (i + j) / 2 + 1; i = j; } return r; },
        entropy: (x) => { const a = nums(x); const t = sum(a); return -sum(a.filter((v) => v > 0).map((v) => (v / t) * Math.log2(v / t))); },
        // a least squares line: {slope, intercept, r2}
        linreg: (x, y) => { const a = nums(x), b = nums(y); const ma = mean(a), mb = mean(b); let n = 0, d = 0; for (let i = 0; i < a.length; i++) { n += (a[i] - ma) * (b[i] - mb); d += (a[i] - ma) ** 2; } const slope = n / d, intercept = mb - slope * ma; const r = corr(a, b); return map({ slope, intercept, r2: r * r }); },
        histogram: (x, bins) => { const a = nums(x); const lo = Math.min(...a), hi = Math.max(...a); const b = bins || 10; const w = (hi - lo) / b || 1; const counts = new Array(b).fill(0); for (const v of a) counts[Math.min(b - 1, Math.floor((v - lo) / w))]++; return counts.map((c, i) => map({ from: lo + i * w, to: lo + (i + 1) * w, count: c })); },
        describe: (x) => { const a = nums(x); const s = a.slice().sort((p, q) => p - q); return map({ count: a.length, mean: mean(a), std: Math.sqrt(variance(a, true)), min: s[0], q1: percentile(s, 0.25), median: percentile(s, 0.5), q3: percentile(s, 0.75), max: s[s.length - 1] }); },
        outliers: (x) => { const s = sortedNums(x); const q1 = percentile(s, 0.25), q3 = percentile(s, 0.75), k = 1.5 * (q3 - q1); return nums(x).filter((v) => v < q1 - k || v > q3 + k); },
    };
};

// ---------- std.linalg ----------
export const linalgModule = () => {
    const mat = (m, w) => { const a = list(m, w); if (!a.length || !a.every((r) => Array.isArray(r) && r.length === a[0].length)) throw rtError((w || 'This') + ' needs a matrix: a list of equal-length lists', 'TypeError'); return a; };
    const mul = (a, b) => { const A1 = mat(a, 'matmul'), B = mat(b, 'matmul'); if (A1[0].length !== B.length) throw rtError('matmul: ' + A1.length + 'x' + A1[0].length + ' cannot multiply ' + B.length + 'x' + B[0].length, 'MathError'); return A1.map((r) => B[0].map((_, j) => r.reduce((s, v, k) => s + v * B[k][j], 0))); };
    const eye = (n) => Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)));
    function gauss(a, b) {
        const n = a.length;
        const m = a.map((r, i) => r.slice().concat(b[i]));
        let det = 1;
        for (let c = 0; c < n; c++) {
            let p = c;
            for (let r = c + 1; r < n; r++) if (Math.abs(m[r][c]) > Math.abs(m[p][c])) p = r;
            if (Math.abs(m[p][c]) < 1e-12) return { det: 0, sol: null };
            if (p !== c) { [m[p], m[c]] = [m[c], m[p]]; det = -det; }
            det *= m[c][c];
            for (let r = 0; r < n; r++) { if (r === c) continue; const f = m[r][c] / m[c][c]; for (let k = c; k < m[r].length; k++) m[r][k] -= f * m[c][k]; }
        }
        return { det, sol: m.map((r, i) => r.slice(n).map((v) => v / m[i][i])) };
    }
    return {
        zeros: (r, c) => Array.from({ length: r }, () => new Array(c === undefined ? r : c).fill(0)),
        ones: (r, c) => Array.from({ length: r }, () => new Array(c === undefined ? r : c).fill(1)),
        eye, identity: eye,
        diag: (v) => { const a = nums(v); return a.map((x, i) => a.map((_, j) => (i === j ? x : 0))); },
        transpose: (m) => mat(m, 'transpose')[0].map((_, j) => m.map((r) => r[j])),
        matmul: mul,
        add: (a, b) => mat(a).map((r, i) => r.map((v, j) => v + b[i][j])), sub: (a, b) => mat(a).map((r, i) => r.map((v, j) => v - b[i][j])),
        scale: (m, k) => mat(m).map((r) => r.map((v) => v * k)),
        dot: (a, b) => { const x = nums(a), y = nums(b); if (x.length !== y.length) throw rtError('dot needs vectors of the same length', 'MathError'); return x.reduce((s, v, i) => s + v * y[i], 0); },
        cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
        outer: (a, b) => a.map((x) => b.map((y) => x * y)),
        norm: (v) => Math.sqrt(nums(v).reduce((s, x) => s + x * x, 0)),
        normalize: (v) => { const n = Math.sqrt(nums(v).reduce((s, x) => s + x * x, 0)); return v.map((x) => x / n); },
        trace: (m) => mat(m).reduce((s, r, i) => s + r[i], 0),
        det: (m) => { const a = mat(m, 'det'); if (a.length !== a[0].length) throw rtError('det needs a square matrix', 'MathError'); return gauss(a, a.map(() => [])).det; },
        inverse: (m) => { const a = mat(m, 'inverse'); const g = gauss(a, eye(a.length)); if (!g.sol) throw rtError('This matrix has no inverse (it is singular)', 'MathError'); return g.sol; },
        // solve A x = b for x (b is a list)
        solve: (a, b) => { const g = gauss(mat(a, 'solve'), nums(b).map((v) => [v])); if (!g.sol) throw rtError('No single solution (the matrix is singular)', 'MathError'); return g.sol.map((r) => r[0]); },
        power: (m, k) => { let r = eye(m.length), b = m; let e = k; while (e > 0) { if (e & 1) r = mul(r, b); b = mul(b, b); e >>= 1; } return r; },
        shape: (m) => tuple([m.length, Array.isArray(m[0]) ? m[0].length : 0]),
        rank: (m) => { const a = mat(m).map((r) => r.slice()); let rank = 0; const rows = a.length, cols = a[0].length; for (let c = 0; c < cols && rank < rows; c++) { let p = rank; for (let r = rank + 1; r < rows; r++) if (Math.abs(a[r][c]) > Math.abs(a[p][c])) p = r; if (Math.abs(a[p][c]) < 1e-10) continue; [a[p], a[rank]] = [a[rank], a[p]]; for (let r = rank + 1; r < rows; r++) { const f = a[r][c] / a[rank][c]; for (let k = c; k < cols; k++) a[r][k] -= f * a[rank][k]; } rank++; } return rank; },
        to_text: (m) => mat(m).map((r) => r.map((v) => String(+v.toFixed(6))).join('  ')).join('\n'),
        rotation: (deg) => { const r = (deg * Math.PI) / 180; return [[Math.cos(r), -Math.sin(r)], [Math.sin(r), Math.cos(r)]]; },
    };
};

// ---------- std.random ----------
// (the generator itself lives in the runtime: rt.rng, shared with pools and quantum measurements)
const makeRng = (seed) => rt.makeRng(seed);
export const randomModule = () => {
    const f = () => rt.rng.float();
    const normal = (mu, sigma) => { const u = 1 - f(), v = f(); return (mu === undefined ? 0 : mu) + (sigma === undefined ? 1 : sigma) * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
    const choice = (xs) => { const a = A(xs); if (!a.length) throw rtError('choice needs a list with something in it', 'ArgError'); return a[Math.floor(f() * a.length)]; };
    const shuffle = (xs) => { const r = A(xs).slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(f() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
    return {
        seed: (s) => { rt.rng = rt.makeRng(s); return null; },
        rand: f, float: f,
        uniform: (a, b) => a + f() * (b - a),
        randint: (a, b) => { if (b === undefined) { b = a; a = 0; } return a + Math.floor(f() * (b - a + 1)); },
        below: (n) => Math.floor(f() * n),
        bool: (p) => f() < (p === undefined ? 0.5 : p),
        normal, gauss: normal,
        exponential: (rate) => -Math.log(1 - f()) / (rate === undefined ? 1 : rate),
        poisson: (lambda) => { const L = Math.exp(-lambda); let k = 0, p = 1; do { k++; p *= f(); } while (p > L); return k - 1; },
        choice, shuffle,
        sample: (xs, k) => shuffle(xs).slice(0, k),
        weighted_choice: (xs, ws) => { const a = A(xs), w = nums(ws); const t = w.reduce((x, y) => x + y, 0); let r = f() * t; for (let i = 0; i < a.length; i++) { r -= w[i]; if (r <= 0) return a[i]; } return a[a.length - 1]; },
        string: (n, alphabet) => { const al = Array.from(alphabet === undefined ? 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789' : alphabet); let s = ''; for (let i = 0; i < n; i++) s += al[Math.floor(f() * al.length)]; return s; },
        dice: (spec) => { const m = /^(\d*)d(\d+)([+-]\d+)?$/.exec(str(spec, 'dice')); if (!m) throw rtError('dice needs text like "2d6+1"', 'ArgError'); let t = Number(m[3] || 0); for (let i = 0; i < Number(m[1] || 1); i++) t += 1 + Math.floor(f() * Number(m[2])); return t; },
        // a private generator that does not disturb the main one
        generator: (seed) => { const r = makeRng(seed); return map({ rand: () => r.float(), randint: (a, b) => a + Math.floor(r.float() * (b - a + 1)) }); },
    };
};

// ---------- std.bits ----------
export const bitsModule = () => {
    const i32 = (x) => { if (typeof x !== 'number' || !Number.isInteger(x)) throw rtError('This needs a whole number but got ' + repr(x), 'TypeError'); return x; };
    return {
        and: (a, b) => Number(BigInt(i32(a)) & BigInt(i32(b))), or: (a, b) => Number(BigInt(i32(a)) | BigInt(i32(b))), xor: (a, b) => Number(BigInt(i32(a)) ^ BigInt(i32(b))),
        not: (a) => Number(~BigInt(i32(a))), shl: (a, n) => Number(BigInt(i32(a)) << BigInt(n)), shr: (a, n) => Number(BigInt(i32(a)) >> BigInt(n)),
        popcount: (a) => { let c = 0; let x = BigInt(i32(a)); if (x < 0n) x = BigInt.asUintN(64, x); while (x) { c += Number(x & 1n); x >>= 1n; } return c; },
        bit: (a, i) => Number((BigInt(a) >> BigInt(i)) & 1n), set_bit: (a, i) => Number(BigInt(a) | (1n << BigInt(i))), clear_bit: (a, i) => Number(BigInt(a) & ~(1n << BigInt(i))), toggle_bit: (a, i) => Number(BigInt(a) ^ (1n << BigInt(i))),
        rotl32: (a, n) => ((a << n) | (a >>> (32 - n))) >>> 0, rotr32: (a, n) => ((a >>> n) | (a << (32 - n))) >>> 0,
        to_bin: (a, w) => { const s = (a < 0 ? BigInt.asUintN(w || 32, BigInt(a)) : BigInt(a)).toString(2); return w ? s.padStart(w, '0') : s; },
        from_bin: (s) => parseInt(s, 2), to_hex: (a) => (a < 0 ? BigInt.asUintN(32, BigInt(a)) : BigInt(a)).toString(16), from_hex: (s) => parseInt(s, 16),
        is_power_of_two: (a) => a > 0 && (a & (a - 1)) === 0, next_power_of_two: (a) => { let p = 1; while (p < a) p *= 2; return p; },
        lowest_set_bit: (a) => (a === 0 ? null : Math.log2(a & -a)), bit_length: (a) => (a === 0 ? 0 : BigInt(Math.abs(a)).toString(2).length),
        to_bytes: (a, n) => { const r = []; let x = BigInt(a); for (let i = 0; i < (n || 4); i++) { r.unshift(Number(x & 255n)); x >>= 8n; } return Uint8Array.from(r); },
        from_bytes: (b) => Array.from(b).reduce((acc, v) => acc * 256 + v, 0),
    };
};

// ---------- std.bigint ----------
export const bigintModule = () => {
    const B = (x) => { if (typeof x === 'bigint') return x; if (typeof x === 'number') return BigInt(Math.trunc(x)); if (typeof x === 'string') { try { return BigInt(x.trim()); } catch (e) { throw rtError('"' + x + '" is not a whole number', 'ValueError'); } } throw rtError('This needs a whole number', 'TypeError'); };
    const gcd = (a, b) => { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) { [a, b] = [b, a % b]; } return a; };
    const modpow = (b, e, m) => { let r = 1n; b %= m; while (e > 0n) { if (e & 1n) r = (r * b) % m; b = (b * b) % m; e >>= 1n; } return r; };
    return {
        from: B, parse: (s, base) => { if (!base || base === 10) return B(s); let r = 0n; for (const c of String(s).toLowerCase()) { const d = parseInt(c, base); if (Number.isNaN(d)) throw rtError('"' + c + '" is not a digit in base ' + base, 'ValueError'); r = r * BigInt(base) + BigInt(d); } return r; },
        to_str: (x, base) => B(x).toString(base || 10),
        factorial: (n) => { let r = 1n; for (let i = 2n; i <= B(n); i++) r *= i; return r; },
        fib: (n) => { let a = 0n, b = 1n; for (let i = 0; i < n; i++) { [a, b] = [b, a + b]; } return a; },
        pow: (a, b) => B(a) ** B(b), mod_pow: (b, e, m) => modpow(B(b), B(e), B(m)),
        gcd: (a, b) => gcd(B(a), B(b)), lcm: (a, b) => { const x = B(a), y = B(b); return x === 0n || y === 0n ? 0n : (x * y < 0n ? -(x * y) : x * y) / gcd(x, y); },
        sqrt: (n) => { n = B(n); if (n < 0n) throw rtError('No square root of a negative number', 'MathError'); if (n < 2n) return n; let x = BigInt(Math.floor(Math.sqrt(Number(n)))); while (x * x > n) x--; while ((x + 1n) * (x + 1n) <= n) x++; return x; },
        is_prime: (n) => { n = B(n); if (n < 2n) return false; for (const p of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) { if (n === p) return true; if (n % p === 0n) return false; } let d = n - 1n, r = 0; while (d % 2n === 0n) { d /= 2n; r++; } outer: for (const a of [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n]) { let x = modpow(a, d, n); if (x === 1n || x === n - 1n) continue; for (let i = 0; i < r - 1; i++) { x = (x * x) % n; if (x === n - 1n) continue outer; } return false; } return true; },
        digits: (n) => Array.from(B(n).toString().replace('-', ''), Number),
        bit_length: (n) => B(n).toString(2).replace('-', '').length,
        abs: (n) => (B(n) < 0n ? -B(n) : B(n)), sign: (n) => (B(n) > 0n ? 1 : B(n) < 0n ? -1 : 0),
        to_float: (n) => Number(B(n)), is_big: (x) => typeof x === 'bigint',
        // modular inverse of a mod m
        mod_inverse: (a, m) => { let [r0, r1] = [((B(a) % B(m)) + B(m)) % B(m), B(m)], [s0, s1] = [1n, 0n]; while (r1) { const q = r0 / r1; [r0, r1] = [r1, r0 - q * r1]; [s0, s1] = [s1, s0 - q * s1]; } if (r0 !== 1n) throw rtError('No inverse exists', 'MathError'); return ((s0 % B(m)) + B(m)) % B(m); },
    };
};

// ---------- std.complex ----------
// Complex numbers are part of the language itself: 3 + 4i, 2.5i, complex(3, 4). This module adds the maths around them.
export const complexModule = () => {
    const C = CX.C;
    const L = (x) => CX.lift(x);
    const cl = (xs) => A(xs).map(L);
    return {
        I: C(0, 1), new: (re, im) => C(num(re, 'complex'), im === undefined ? 0 : num(im, 'complex')), parse: (s) => CX.parse(str(s, 'complex.parse')),
        polar: (r, t) => CX.fromPolar(r, t), from_polar: (r, t) => CX.fromPolar(r, t), to_polar: (z) => tuple([CX.abs(L(z)), CX.arg(L(z))]),
        abs: (z) => CX.abs(L(z)), arg: (z) => CX.arg(L(z)), conj: (z) => CX.conj(L(z)), re: (z) => L(z).re, im: (z) => L(z).im, norm: (z) => CX.norm2(L(z)),
        sqrt: (z) => CX.sqrt(L(z)), exp: (z) => CX.exp(L(z)), ln: (z) => CX.ln(L(z)), pow: (z, w) => CX.pow(L(z), L(w)), sin: (z) => CX.sin(L(z)), cos: (z) => CX.cos(L(z)),
        // the n roots of z, and the n roots of 1
        roots: (z, n) => CX.roots(L(z), n), roots_of_unity: (n) => CX.roots(C(1, 0), n),
        // roots of a x^2 + b x + c: always two, real or complex
        quadratic: (a, b, c) => { const d = CX.sqrt(C(b * b - 4 * a * c, 0)); const two = 2 * a; return [CX.div(CX.sub(C(-b, 0), d), C(two, 0)), CX.div(CX.add(C(-b, 0), d), C(two, 0))]; },
        // every root of a polynomial given from the highest power down: polyroots([1, 0, 1]) finds the roots of x^2 + 1
        polyroots: (coeffs) => { const a = cl(coeffs); const n = a.length - 1; if (n < 1) return []; const lead = a[0]; const p = a.map((c) => CX.div(c, lead)); let z = Array.from({ length: n }, (_, k) => CX.fromPolar(1 + 0.5 * (CX.abs(p[n]) ** (1 / n)), (2 * Math.PI * k) / n + 0.4)); const evalp = (x) => p.reduce((acc, c) => CX.add(CX.mul(acc, x), c)); for (let it = 0; it < 500; it++) { let moved = 0; z = z.map((zk, k) => { let den = C(1, 0); for (let j = 0; j < n; j++) if (j !== k) den = CX.mul(den, CX.sub(zk, z[j])); const delta = CX.div(evalp(zk), den); moved = Math.max(moved, CX.abs(delta)); return CX.sub(zk, delta); }); if (moved < 1e-13) break; } return z.map((c) => C(Math.abs(c.re) < 1e-12 ? 0 : c.re, Math.abs(c.im) < 1e-12 ? 0 : c.im)); },
        // the Fourier transform of a list of numbers or complex numbers
        fft: (xs) => CX.fft(cl(xs), false), ifft: (xs) => CX.fft(cl(xs), true),
        magnitudes: (xs) => cl(xs).map(CX.abs), phases: (xs) => cl(xs).map(CX.arg),
        // how many steps z -> z^2 + c takes to run away (the Mandelbrot set)
        mandelbrot: (c, max) => { const cc = L(c); let z = C(0, 0); const m = max || 100; for (let i = 0; i < m; i++) { z = CX.add(CX.mul(z, z), cc); if (CX.norm2(z) > 4) return i; } return m; },
        is_complex: (z) => z instanceof rt.SComplex, sum: (xs) => cl(xs).reduce((a, b) => CX.add(a, b), C(0, 0)), product: (xs) => cl(xs).reduce((a, b) => CX.mul(a, b), C(1, 0)),
    };
};

// ---------- std.rational ----------
let RationalT = null;
export const rationalModule = () => {
    if (!RationalT) {
        const gcd = (a, b) => { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) { [a, b] = [b, a % b]; } return a; };
        const R = (n, d) => { if (d === 0n) throw rtError('A fraction cannot have 0 underneath', 'MathError'); if (d < 0n) { n = -n; d = -d; } const g = gcd(n, d) || 1n; n /= g; d /= g; const o = make(RationalT, { n, d }); o.f.num = Number(n); o.f.den = Number(d); return o; };
        const B = (x) => (typeof x === 'bigint' ? x : BigInt(x));
        const toR = (x) => (x instanceof SObj ? x : typeof x === 'number' && Number.isInteger(x) ? R(BigInt(x), 1n) : (() => { throw rtError('A fraction can only combine with fractions and whole numbers', 'TypeError'); })());
        const fmt = (r) => (r.state.d === 1n ? String(r.state.n) : r.state.n + '/' + r.state.d);
        RationalT = nativeType('Rational', {
            add: (s, a) => { const o = toR(a[0]); return R(s.state.n * o.state.d + o.state.n * s.state.d, s.state.d * o.state.d); },
            sub: (s, a) => { const o = toR(a[0]); return R(s.state.n * o.state.d - o.state.n * s.state.d, s.state.d * o.state.d); },
            mul: (s, a) => { const o = toR(a[0]); return R(s.state.n * o.state.n, s.state.d * o.state.d); },
            div: (s, a) => { const o = toR(a[0]); return R(s.state.n * o.state.d, s.state.d * o.state.n); },
            radd: (s, a) => R(s.state.n + B(a[0]) * s.state.d, s.state.d), rsub: (s, a) => R(B(a[0]) * s.state.d - s.state.n, s.state.d), rmul: (s, a) => R(s.state.n * B(a[0]), s.state.d),
            neg: (s) => R(-s.state.n, s.state.d), pow: (s, a) => (a[0] >= 0 ? R(s.state.n ** BigInt(a[0]), s.state.d ** BigInt(a[0])) : R(s.state.d ** BigInt(-a[0]), s.state.n ** BigInt(-a[0]))),
            cmp: (s, a) => { const o = toR(a[0]); const l = s.state.n * o.state.d, r = o.state.n * s.state.d; return l < r ? -1 : l > r ? 1 : 0; },
            eq: (s, a) => a[0] instanceof SObj && a[0].type === RationalT && s.state.n === a[0].state.n && s.state.d === a[0].state.d,
            to_float: (s) => Number(s.state.n) / Number(s.state.d), numerator: (s) => s.state.n, denominator: (s) => s.state.d,
            floor: (s) => { let q = s.state.n / s.state.d; if (s.state.n % s.state.d < 0n) q -= 1n; return q; },
            to_str: (s) => fmt(s), abs: (s) => R(s.state.n < 0n ? -s.state.n : s.state.n, s.state.d), recip: (s) => R(s.state.d, s.state.n),
        }, { reprFn: fmt, showFn: fmt });
        RationalT.mk = R;
    }
    const R = RationalT.mk;
    return {
        new: (n, d) => R(BigInt(n), BigInt(d === undefined ? 1 : d)),
        parse: (s) => { const m = /^\s*(-?\d+)\s*(?:\/\s*(\d+))?\s*$/.exec(str(s, 'rational.parse')); if (!m) throw rtError('"' + s + '" is not a fraction like 3/4', 'ValueError'); return R(BigInt(m[1]), BigInt(m[2] || 1)); },
        // the closest fraction to a decimal, with a denominator up to max
        from_float: (x, max) => { const lim = max || 1000000; let h1 = 1, h0 = 0, k1 = 0, k0 = 1, b = x; for (let i = 0; i < 40; i++) { const a = Math.floor(b); const h = a * h1 + h0, k = a * k1 + k0; if (k > lim) break; h0 = h1; h1 = h; k0 = k1; k1 = k; if (Math.abs(b - a) < 1e-12) break; b = 1 / (b - a); } return R(BigInt(h1), BigInt(k1 || 1)); },
    };
};
