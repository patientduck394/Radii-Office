/* std.quantum: a quantum computer you can run in the terminal.
   A Register holds the 2^n complex amplitudes of n qubits. Qubit 0 is the FIRST (leftmost) one, so |011> means qubit 0 is 0, qubits 1 and 2 are 1.
   Gates change the amplitudes, measuring picks an outcome at random (with the odds the amplitudes give) and collapses the state.
   Random choices come from the shared generator, so random.seed(n) makes a quantum run repeatable. */
import { rt, SMap, SPool, SComplex, Tuple, tuple, opts, num, list, cb, call, map, nativeType, make, rtError, show, typeOf, toArray, str } from './_util.js';
import * as CX from '../complexmath.js';

const A = (x) => toArray(x);
const MAX_QUBITS = 22;
const S2 = Math.SQRT1_2;
const c = (re, im) => [re, im || 0];
// gates as [m00, m01, m10, m11], each [re, im]
const GATES = {
    I: [c(1), c(0), c(0), c(1)],
    H: [c(S2), c(S2), c(S2), c(-S2)],
    X: [c(0), c(1), c(1), c(0)],
    Y: [c(0), c(0, -1), c(0, 1), c(0)],
    Z: [c(1), c(0), c(0), c(-1)],
    S: [c(1), c(0), c(0), c(0, 1)],
    SDG: [c(1), c(0), c(0), c(0, -1)],
    T: [c(1), c(0), c(0), c(S2, S2)],
    TDG: [c(1), c(0), c(0), c(S2, -S2)],
    SX: [c(0.5, 0.5), c(0.5, -0.5), c(0.5, -0.5), c(0.5, 0.5)],
};
const rx = (t) => [c(Math.cos(t / 2)), c(0, -Math.sin(t / 2)), c(0, -Math.sin(t / 2)), c(Math.cos(t / 2))];
const ry = (t) => [c(Math.cos(t / 2)), c(-Math.sin(t / 2)), c(Math.sin(t / 2)), c(Math.cos(t / 2))];
const rz = (t) => [c(Math.cos(t / 2), -Math.sin(t / 2)), c(0), c(0), c(Math.cos(t / 2), Math.sin(t / 2))];
const ph = (f) => [c(1), c(0), c(0), c(Math.cos(f), Math.sin(f))];
const ugate = (t, f, l) => [c(Math.cos(t / 2)), c(-Math.cos(l) * Math.sin(t / 2), -Math.sin(l) * Math.sin(t / 2)), c(Math.cos(f) * Math.sin(t / 2), Math.sin(f) * Math.sin(t / 2)), c(Math.cos(f + l) * Math.cos(t / 2), Math.sin(f + l) * Math.cos(t / 2))];
const toMat = (m) => [m[0], m[1], m[2], m[3]].map(([a, b]) => CX.C(a, b));

function fmtNum(x) { return String(+x.toPrecision(4)); }
function fmtAmp(re, im) {
    const e = 1e-9;
    if (Math.abs(im) < e) return fmtNum(re);
    if (Math.abs(re) < e) return fmtNum(im) + 'i';
    return '(' + fmtNum(re) + (im < 0 ? ' - ' : ' + ') + fmtNum(Math.abs(im)) + 'i)';
}
const bits = (i, n) => i.toString(2).padStart(n, '0');
// tidy away floating-point dust (0.5000000000000001 -> 0.5)
const cl = (x) => { const r = Math.round(x * 1e12) / 1e12; return Object.is(r, -0) ? 0 : r; };

class State {
    constructor(n) {
        if (!Number.isInteger(n) || n < 1) throw rtError('A register needs at least 1 qubit (got ' + n + ')', 'QuantumError');
        if (n > MAX_QUBITS) throw rtError('This simulator holds up to ' + MAX_QUBITS + ' qubits (the memory doubles with each one), not ' + n, 'QuantumError');
        this.n = n; this.N = 1 << n;
        this.re = new Float64Array(this.N); this.im = new Float64Array(this.N);
        this.re[0] = 1;
        this.ops = [];
    }
    mask(q) { return 1 << (this.n - 1 - q); }
    qb(q) { if (!Number.isInteger(q) || q < 0 || q >= this.n) throw rtError('Qubit ' + show(q) + ' does not exist: this register has qubits 0 to ' + (this.n - 1), 'QuantumError'); return q; }
    copy() { const s = new State(this.n); s.re.set(this.re); s.im.set(this.im); s.ops = this.ops.slice(); return s; }
    // apply a 2x2 gate to the target, only where every control qubit is 1
    gate(m, target, controls) {
        const t = this.mask(this.qb(target));
        let cm = 0;
        for (const q of controls || []) { const mk = this.mask(this.qb(q)); if (mk === t) throw rtError('A qubit cannot control itself', 'QuantumError'); cm |= mk; }
        const [[a, b], [cc, d], [e, f], [g, h]] = m;
        const re = this.re, im = this.im;
        for (let i = 0; i < this.N; i++) {
            if ((i & t) !== 0 || (i & cm) !== cm) continue;
            const j = i | t;
            const xr = re[i], xi = im[i], yr = re[j], yi = im[j];
            re[i] = a * xr - b * xi + cc * yr - d * yi; im[i] = a * xi + b * xr + cc * yi + d * yr;
            re[j] = e * xr - f * xi + g * yr - h * yi; im[j] = e * xi + f * xr + g * yi + h * yr;
        }
    }
    swap(a, b, controls) {
        const ma = this.mask(this.qb(a)), mb = this.mask(this.qb(b));
        let cm = 0;
        for (const q of controls || []) cm |= this.mask(this.qb(q));
        for (let i = 0; i < this.N; i++) {
            if ((i & ma) && !(i & mb) && (i & cm) === cm) { const j = (i ^ ma) | mb; [this.re[i], this.re[j]] = [this.re[j], this.re[i]]; [this.im[i], this.im[j]] = [this.im[j], this.im[i]]; }
        }
    }
    // multiply by e^(i phi) where all the given qubits are 1
    phase(qubits, phi) {
        let cm = 0;
        for (const q of qubits) cm |= this.mask(this.qb(q));
        const cr = Math.cos(phi), ci = Math.sin(phi);
        for (let i = 0; i < this.N; i++) if ((i & cm) === cm) { const r = this.re[i], m = this.im[i]; this.re[i] = r * cr - m * ci; this.im[i] = r * ci + m * cr; }
    }
    // move amplitude from basis state i to f(i) (f must be one-to-one)
    permute(f) {
        const re = new Float64Array(this.N), im = new Float64Array(this.N), seen = new Uint8Array(this.N);
        for (let i = 0; i < this.N; i++) {
            const j = f(i);
            if (!Number.isInteger(j) || j < 0 || j >= this.N) throw rtError('The permutation sent ' + i + ' to ' + show(j) + ', which is not a basis state (0 to ' + (this.N - 1) + ')', 'QuantumError');
            if (seen[j]) throw rtError('The permutation is not reversible: two states both go to ' + j, 'QuantumError');
            seen[j] = 1; re[j] = this.re[i]; im[j] = this.im[i];
        }
        this.re = re; this.im = im;
    }
    prob(i) { return this.re[i] * this.re[i] + this.im[i] * this.im[i]; }
    probs() { const p = new Float64Array(this.N); for (let i = 0; i < this.N; i++) p[i] = this.prob(i); return p; }
    p1(q) { const t = this.mask(q); let p = 0; for (let i = 0; i < this.N; i++) if (i & t) p += this.prob(i); return p; }
    normalize() { let s = 0; for (let i = 0; i < this.N; i++) s += this.prob(i); if (s === 0) throw rtError('The state has no amplitude at all', 'QuantumError'); const k = 1 / Math.sqrt(s); for (let i = 0; i < this.N; i++) { this.re[i] *= k; this.im[i] *= k; } }
    // measure one qubit: collapse and give 0 or 1
    measure(q) {
        const t = this.mask(this.qb(q));
        const p1 = this.p1(q);
        const out = rt.rng.float() < p1 ? 1 : 0;
        for (let i = 0; i < this.N; i++) if (((i & t) !== 0) !== (out === 1)) { this.re[i] = 0; this.im[i] = 0; }
        this.normalize();
        this.ops.push({ name: 'M', targets: [q], controls: [] });
        return out;
    }
    // measure several qubits at once (all of them by default): the outcome as a list of bits
    measureQubits(qs) {
        const q = qs || Array.from({ length: this.n }, (_, i) => i);
        return q.map((x) => this.measure(x));
    }
    sampleIndex() { let r = rt.rng.float(), acc = 0; for (let i = 0; i < this.N; i++) { acc += this.prob(i); if (r < acc) return i; } return this.N - 1; }
    // the qubit's own 3D direction (Bloch vector) and the entanglement entropy
    bloch(q) {
        const t = this.mask(this.qb(q));
        let r00 = 0, r11 = 0, r01r = 0, r01i = 0;
        for (let i = 0; i < this.N; i++) {
            if (i & t) { r11 += this.prob(i); continue; }
            r00 += this.prob(i);
            const j = i | t;
            // rho01 = sum psi(0,rest) * conj(psi(1,rest))
            r01r += this.re[i] * this.re[j] + this.im[i] * this.im[j];
            r01i += this.im[i] * this.re[j] - this.re[i] * this.im[j];
        }
        return { x: 2 * r01r, y: -2 * r01i, z: r00 - r11 };
    }
    record(name, targets, controls, label) { this.ops.push({ name, targets, controls: controls || [], label }); }
}

function entropyOf(r) { const l1 = (1 + r) / 2, l2 = (1 - r) / 2; const f = (l) => (l > 1e-12 ? -l * Math.log2(l) : 0); return f(l1) + f(l2); }
function ket(st, tol) {
    const parts = [];
    for (let i = 0; i < st.N; i++) {
        const a = Math.hypot(st.re[i], st.im[i]);
        if (a < (tol || 1e-9)) continue;
        parts.push(fmtAmp(st.re[i], st.im[i]) + '|' + bits(i, st.n) + '>');
    }
    return parts.length ? parts.join(' + ').replace(/\+ -/g, '- ') : '0';
}

// ---------- circuit drawing ----------
function draw(st) {
    const n = st.n;
    const cols = [];
    for (const op of st.ops) {
        const all = [...op.targets, ...op.controls];
        const lo = Math.min(...all), hi = Math.max(...all);
        const col = new Array(n).fill(null);
        const mid = new Array(n).fill(false);
        for (let q = lo; q <= hi; q++) mid[q] = true;
        for (const q of op.controls) col[q] = '●';
        if (op.name === 'SWAP') for (const q of op.targets) col[q] = '✕';
        else if (op.name === 'X' && op.controls.length) col[op.targets[0]] = '⊕';
        else if (op.name === 'M') col[op.targets[0]] = 'M';
        else for (const q of op.targets) col[q] = op.label ? op.label : op.name;
        cols.push({ col, mid, lo, hi });
    }
    const w = cols.map((x) => Math.max(1, ...x.col.map((s) => (s ? s.length : 0))) + 2);
    const rows = [];
    for (let q = 0; q < n; q++) {
        let wire = 'q' + q + ' |0>─', gap = '        ';
        cols.forEach((x, k) => {
            const s = x.col[q];
            const pad = (txt, fill) => { const total = w[k] - txt.length; const l = Math.floor(total / 2); return fill.repeat(l) + txt + fill.repeat(total - l); };
            wire += s ? pad(s.length > 1 ? '[' + s + ']' : s, '─') : (x.mid[q] ? pad('│', '─') : '─'.repeat(w[k]));
            gap += x.mid[q] && q < x.hi ? pad('│', ' ') : ' '.repeat(w[k]);
        });
        rows.push(wire + '─');
        if (q < n - 1) rows.push(gap);
    }
    return rows.join('\n');
}

export const quantumModule = () => {
    const stateOf = (r) => r.state;
    const qlist = (st, a) => (a.length === 0 ? Array.from({ length: st.n }, (_, i) => i) : (a.length === 1 && Array.isArray(a[0]) ? a[0] : a));
    const Reg = nativeType('Register', {}, {});
    const wrap = (st) => make(Reg, st);
    const def = (name, fn) => Reg.methods.set(name, (self, a, named) => { const r = fn(self.state, a, named, self); return r === undefined ? self : r; });
    // single-qubit gates: reg.h(0)
    for (const [name, key] of [['h', 'H'], ['x', 'X'], ['y', 'Y'], ['z', 'Z'], ['s', 'S'], ['t', 'T'], ['sdg', 'SDG'], ['tdg', 'TDG'], ['sx', 'SX'], ['id', 'I']]) {
        def(name, (st, a) => { st.gate(GATES[key], a[0]); st.record(key, [a[0]]); });
        def(name + '_all', (st, a) => { for (let q = 0; q < st.n; q++) { st.gate(GATES[key], q); st.record(key, [q]); } });
    }
    def('rx', (st, a) => { st.gate(rx(a[1]), a[0]); st.record('RX', [a[0]], [], 'RX(' + fmtNum(a[1]) + ')'); });
    def('ry', (st, a) => { st.gate(ry(a[1]), a[0]); st.record('RY', [a[0]], [], 'RY(' + fmtNum(a[1]) + ')'); });
    def('rz', (st, a) => { st.gate(rz(a[1]), a[0]); st.record('RZ', [a[0]], [], 'RZ(' + fmtNum(a[1]) + ')'); });
    def('p', (st, a) => { st.gate(ph(a[1]), a[0]); st.record('P', [a[0]], [], 'P(' + fmtNum(a[1]) + ')'); });
    def('u', (st, a) => { st.gate(ugate(a[1], a[2], a[3]), a[0]); st.record('U', [a[0]]); });
    // controlled gates: reg.cx(control, target)
    def('cx', (st, a) => { st.gate(GATES.X, a[1], [a[0]]); st.record('X', [a[1]], [a[0]]); });
    def('cy', (st, a) => { st.gate(GATES.Y, a[1], [a[0]]); st.record('Y', [a[1]], [a[0]]); });
    def('cz', (st, a) => { st.gate(GATES.Z, a[1], [a[0]]); st.record('Z', [a[1]], [a[0]]); });
    def('ch', (st, a) => { st.gate(GATES.H, a[1], [a[0]]); st.record('H', [a[1]], [a[0]]); });
    def('cp', (st, a) => { st.gate(ph(a[2]), a[1], [a[0]]); st.record('P', [a[1]], [a[0]], 'P(' + fmtNum(a[2]) + ')'); });
    def('crx', (st, a) => { st.gate(rx(a[2]), a[1], [a[0]]); st.record('RX', [a[1]], [a[0]], 'RX'); });
    def('cry', (st, a) => { st.gate(ry(a[2]), a[1], [a[0]]); st.record('RY', [a[1]], [a[0]], 'RY'); });
    def('crz', (st, a) => { st.gate(rz(a[2]), a[1], [a[0]]); st.record('RZ', [a[1]], [a[0]], 'RZ'); });
    def('ccx', (st, a) => { st.gate(GATES.X, a[2], [a[0], a[1]]); st.record('X', [a[2]], [a[0], a[1]]); });
    def('ccz', (st, a) => { st.gate(GATES.Z, a[2], [a[0], a[1]]); st.record('Z', [a[2]], [a[0], a[1]]); });
    def('mcx', (st, a) => { const cs = A(a[0]); st.gate(GATES.X, a[1], cs); st.record('X', [a[1]], cs); });
    def('mcz', (st, a) => { const cs = A(a[0]); st.gate(GATES.Z, a[1], cs); st.record('Z', [a[1]], cs); });
    def('swap', (st, a) => { st.swap(a[0], a[1]); st.record('SWAP', [a[0], a[1]]); });
    def('cswap', (st, a) => { st.swap(a[1], a[2], [a[0]]); st.record('SWAP', [a[1], a[2]], [a[0]]); });
    // your own 2x2 gate (a unitary): reg.gate([[a, b], [c, d]], qubit) with numbers or complex numbers
    def('gate', (st, a) => { const m = A(a[0]).map((r) => A(r).map((x) => CX.lift(x))); if (m.length !== 2 || m.some((r) => r.length !== 2)) throw rtError('gate needs a 2x2 matrix like [[0, 1], [1, 0]]', 'QuantumError'); const det = [m[0][0], m[0][1], m[1][0], m[1][1]]; const dag = (x) => CX.conj(x); const u = CX.add(CX.mul(det[0], dag(det[0])), CX.mul(det[1], dag(det[1]))); if (Math.abs(u.re - 1) > 1e-6 || Math.abs(u.im) > 1e-6) throw rtError('That matrix is not unitary (its rows are not unit length), so it is not a quantum gate', 'QuantumError'); st.gate([[det[0].re, det[0].im], [det[1].re, det[1].im], [det[2].re, det[2].im], [det[3].re, det[3].im]], a[1], a[2] === undefined ? [] : A(a[2])); st.record('U', [a[1]], a[2] === undefined ? [] : A(a[2]), a[3] === undefined ? 'U' : show(a[3])); });
    // the quantum Fourier transform on some qubits (all of them by default)
    const qft = (st, qs, inverse) => {
        const k = qs.length;
        if (!inverse) {
            for (let j = 0; j < k; j++) { st.gate(GATES.H, qs[j]); for (let m = j + 1; m < k; m++) st.phase([qs[m], qs[j]], Math.PI / (1 << (m - j))); }
            for (let j = 0; j < (k >> 1); j++) st.swap(qs[j], qs[k - 1 - j]);
        } else {
            for (let j = 0; j < (k >> 1); j++) st.swap(qs[j], qs[k - 1 - j]);
            for (let j = k - 1; j >= 0; j--) { for (let m = k - 1; m > j; m--) st.phase([qs[m], qs[j]], -Math.PI / (1 << (m - j))); st.gate(GATES.H, qs[j]); }
        }
    };
    def('qft', (st, a) => { const qs = qlist(st, a); qft(st, qs, false); st.record('QFT', qs, [], 'QFT'); });
    def('iqft', (st, a) => { const qs = qlist(st, a); qft(st, qs, true); st.record('IQFT', qs, [], 'QFT†'); });
    // flip the sign of every basis state where f(index) is true (a "phase oracle"), and reorder states with a reversible function
    def('phase_oracle', (st, a) => { const f = cb(a[0]); for (let i = 0; i < st.N; i++) if (rt.truthy(f(i))) { st.re[i] = -st.re[i]; st.im[i] = -st.im[i]; } st.record('ORACLE', Array.from({ length: st.n }, (_, i) => i), [], 'Of'); });
    def('permute', (st, a) => { const f = cb(a[0]); st.permute((i) => f(i)); st.record('PERM', Array.from({ length: st.n }, (_, i) => i), [], 'Uf'); });
    def('diffusion', (st) => { let mr = 0, mi = 0; for (let i = 0; i < st.N; i++) { mr += st.re[i]; mi += st.im[i]; } mr /= st.N; mi /= st.N; for (let i = 0; i < st.N; i++) { st.re[i] = 2 * mr - st.re[i]; st.im[i] = 2 * mi - st.im[i]; } st.record('DIFFUSE', Array.from({ length: st.n }, (_, i) => i), [], 'D'); });
    def('barrier', () => undefined);
    // ----- measuring -----
    def('measure', (st, a) => (a.length ? st.measure(a[0]) : st.measureQubits(null)), true);
    Reg.methods.set('measure', (self, a) => (a.length === 1 && !Array.isArray(a[0]) ? self.state.measure(a[0]) : self.state.measureQubits(a.length ? A(a[0]) : null)));
    Reg.methods.set('measure_int', (self) => { const b = self.state.measureQubits(null); return b.reduce((acc, x) => acc * 2 + x, 0); });
    Reg.methods.set('measure_text', (self) => self.state.measureQubits(null).join(''));
    // measure_later(0) / measure_later() gives a pool: the measurement really happens, and collapses the state, when you first use the value
    Reg.methods.set('measure_later', (self, a) => new SPool(null, null, () => (a.length === 1 && !Array.isArray(a[0]) ? self.state.measure(a[0]) : (() => { const b = self.state.measureQubits(a.length ? A(a[0]) : null); return b.join(''); })())));
    // pool(): a pool over the basis states, weighted by their probabilities (deciding it does NOT collapse the register)
    Reg.methods.set('pool', (self) => { const st = self.state; const opts = [], ws = []; for (let i = 0; i < st.N; i++) { const p = st.prob(i); if (p > 1e-12) { opts.push(bits(i, st.n)); ws.push(p); } } return new SPool(opts, ws); });
    // sample(1000) -> {"00": 503, "11": 497}: many measurements of copies, the register itself is left alone
    Reg.methods.set('sample', (self, a) => { const st = self.state; const shots = a.length ? a[0] : 1024; const p = st.probs(); const cum = new Float64Array(st.N); let acc = 0; for (let i = 0; i < st.N; i++) { acc += p[i]; cum[i] = acc; } const counts = new Map(); for (let s = 0; s < shots; s++) { const r = rt.rng.float() * acc; let lo = 0, hi = st.N - 1; while (lo < hi) { const mid = (lo + hi) >> 1; if (cum[mid] > r) hi = mid; else lo = mid + 1; } counts.set(lo, (counts.get(lo) || 0) + 1); } const m = new SMap(); for (const k of Array.from(counts.keys()).sort((x, y) => x - y)) m.set(bits(k, st.n), counts.get(k)); return m; });
    Reg.methods.set('probabilities', (self) => Array.from(self.state.probs(), cl));
    Reg.methods.set('probs', (self) => { const st = self.state; const m = new SMap(); for (let i = 0; i < st.N; i++) { const p = st.prob(i); if (p > 1e-12) m.set(bits(i, st.n), cl(p)); } return m; });
    Reg.methods.set('prob', (self, a) => cl(self.state.p1(self.state.qb(a[0]))));
    Reg.methods.set('prob_of', (self, a) => { const st = self.state; const i = typeof a[0] === 'string' ? parseInt(a[0], 2) : a[0]; if (!(i >= 0 && i < st.N)) throw rtError('That is not a state of ' + st.n + ' qubits', 'QuantumError'); return cl(st.prob(i)); });
    Reg.methods.set('amplitudes', (self) => Array.from({ length: self.state.N }, (_, i) => CX.C(self.state.re[i], self.state.im[i])));
    Reg.methods.set('amplitude', (self, a) => { const st = self.state; const i = typeof a[0] === 'string' ? parseInt(a[0], 2) : a[0]; return CX.C(st.re[i], st.im[i]); });
    Reg.methods.set('bloch', (self, a) => { const b = self.state.bloch(a[0]); return map({ x: cl(b.x), y: cl(b.y), z: cl(b.z) }); });
    // how entangled a qubit is with the rest: 0 (not at all) to 1 (as much as one qubit can be)
    Reg.methods.set('entanglement', (self, a) => { const b = self.state.bloch(a[0]); return cl(entropyOf(Math.min(1, Math.hypot(b.x, b.y, b.z)))); });
    Reg.methods.set('expect_z', (self, a) => { const b = self.state.bloch(a[0]); return cl(b.z); });
    // expect("ZZ") or expect("XIZ"): the average value of a product of Pauli operators
    Reg.methods.set('expect', (self, a) => { const st = self.state; const p = str(a[0], 'expect'); if (p.length !== st.n) throw rtError('expect needs one letter (I X Y Z) for each of the ' + st.n + ' qubits', 'QuantumError'); const w = st.copy(); for (let q = 0; q < st.n; q++) { const g = GATES[p[q].toUpperCase()]; if (!g) throw rtError('"' + p[q] + '" is not a Pauli letter (I X Y Z)', 'QuantumError'); w.gate(g, q); } let re = 0; for (let i = 0; i < st.N; i++) re += st.re[i] * w.re[i] + st.im[i] * w.im[i]; return cl(re); });
    Reg.methods.set('inner', (self, a) => { const x = self.state, y = a[0].state; if (x.n !== y.n) throw rtError('The registers have different sizes', 'QuantumError'); let re = 0, im = 0; for (let i = 0; i < x.N; i++) { re += x.re[i] * y.re[i] + x.im[i] * y.im[i]; im += x.re[i] * y.im[i] - x.im[i] * y.re[i]; } return CX.C(re, im); });
    Reg.methods.set('fidelity', (self, a) => { const x = self.state, y = a[0].state; if (x.n !== y.n) throw rtError('The registers have different sizes', 'QuantumError'); let re = 0, im = 0; for (let i = 0; i < x.N; i++) { re += x.re[i] * y.re[i] + x.im[i] * y.im[i]; im += x.re[i] * y.im[i] - x.im[i] * y.re[i]; } return cl(re * re + im * im); });
    Reg.methods.set('norm', (self) => { let s = 0; for (let i = 0; i < self.state.N; i++) s += self.state.prob(i); return cl(Math.sqrt(s)); });
    Reg.methods.set('n', (self) => self.state.n); Reg.methods.set('size', (self) => self.state.n); Reg.methods.set('len', (self) => self.state.N);
    Reg.methods.set('reset', (self) => { const st = self.state; st.re.fill(0); st.im.fill(0); st.re[0] = 1; st.ops = []; return self; });
    Reg.methods.set('copy', (self) => wrap(self.state.copy()));
    Reg.methods.set('ops', (self) => self.state.ops.map((o) => map({ gate: o.name, targets: o.targets.slice(), controls: o.controls.slice() })));
    Reg.methods.set('text', (self) => ket(self.state)); Reg.methods.set('to_str', (self) => ket(self.state));
    Reg.methods.set('draw', (self) => draw(self.state));
    Reg.methods.set('is_entangled', (self) => { const st = self.state; for (let q = 0; q < st.n; q++) { const b = st.bloch(q); if (Math.hypot(b.x, b.y, b.z) < 1 - 1e-6) return true; } return false; });
    Reg.reprFn = (o) => ket(o.state, 1e-9);
    Reg.showFn = (o) => ket(o.state, 1e-9);
    Reg.nativeIter = (o) => Array.from({ length: o.state.N }, (_, i) => CX.C(o.state.re[i], o.state.im[i]));

    const reg = (n) => wrap(new State(n));
    const fromBits = (text) => { const s = new State(text.length); s.re[0] = 0; s.re[parseInt(text, 2)] = 1; return wrap(s); };
    const bell = (kind) => { const r = reg(2); const k = kind === undefined ? 0 : kind; if (k & 2) r.state.gate(GATES.X, 0); if (k & 1) r.state.gate(GATES.X, 1); r.state.ops = []; r.state.gate(GATES.H, 0); r.state.record('H', [0]); r.state.gate(GATES.X, 1, [0]); r.state.record('X', [1], [0]); return r; };

    // ---------- algorithms ----------
    const grover = (n, marked, iterations) => {
        const N = 1 << n;
        const isMarked = typeof marked === 'function' || (marked && marked.params) ? (() => { const f = cb(marked); return (i) => rt.truthy(f(i)); })() : (() => { const set = new Set(A(marked).map((x) => (typeof x === 'string' ? parseInt(x, 2) : x))); return (i) => set.has(i); })();
        let M = 0; for (let i = 0; i < N; i++) if (isMarked(i)) M++;
        if (M === 0) throw rtError('Grover needs at least one marked answer', 'QuantumError');
        const iters = iterations === undefined ? Math.max(1, Math.floor((Math.PI / 4) * Math.sqrt(N / M))) : iterations;
        const r = reg(n); const st = r.state;
        for (let q = 0; q < n; q++) { st.gate(GATES.H, q); st.record('H', [q]); }
        for (let k = 0; k < iters; k++) {
            for (let i = 0; i < N; i++) if (isMarked(i)) { st.re[i] = -st.re[i]; st.im[i] = -st.im[i]; }
            st.record('ORACLE', Array.from({ length: n }, (_, i) => i), [], 'Of');
            let mr = 0, mi = 0; for (let i = 0; i < N; i++) { mr += st.re[i]; mi += st.im[i]; } mr /= N; mi /= N;
            for (let i = 0; i < N; i++) { st.re[i] = 2 * mr - st.re[i]; st.im[i] = 2 * mi - st.im[i]; }
            st.record('DIFFUSE', Array.from({ length: n }, (_, i) => i), [], 'D');
        }
        let pm = 0; for (let i = 0; i < N; i++) if (isMarked(i)) pm += st.prob(i);
        const m = st.copy(); const found = m.measureQubits(null).reduce((a, b) => a * 2 + b, 0);
        return map({ found, found_bits: bits(found, n), correct: isMarked(found), probability: pm, iterations: iters, searched: N, marked: M, register: r });
    };
    const modpow = (b, e, m) => { let r = 1n; let x = BigInt(b) % BigInt(m); let k = BigInt(e); const mm = BigInt(m); while (k > 0n) { if (k & 1n) r = (r * x) % mm; x = (x * x) % mm; k >>= 1n; } return Number(r); };
    const gcd = (a, b) => { while (b) [a, b] = [b, a % b]; return a; };
    function shor(N, tries) {
        if (!Number.isInteger(N) || N < 4) throw rtError('shor needs a whole number of at least 4', 'QuantumError');
        if (N % 2 === 0) return map({ number: N, factors: [2, N / 2], method: 'even number: no quantum needed' });
        const n = Math.ceil(Math.log2(N + 1)), t = 2 * n;
        if (t + n > MAX_QUBITS) throw rtError('shor(' + N + ') needs ' + (t + n) + ' qubits; this simulator holds ' + MAX_QUBITS + ' (try a number below ' + (1 << Math.floor(MAX_QUBITS / 3)) + ')', 'QuantumError');
        for (let attempt = 1; attempt <= (tries || 12); attempt++) {
            const a = 2 + Math.floor(rt.rng.float() * (N - 3));
            const g = gcd(a, N);
            if (g > 1) return map({ number: N, factors: [Math.min(g, N / g), Math.max(g, N / g)], a, method: 'lucky guess: gcd(a, N) > 1', attempts: attempt });
            const st = new State(t + n);
            const workMask = (1 << n) - 1;
            st.re[0] = 0; st.re[1] = 1;                      // the work register starts as |1>
            for (let q = 0; q < t; q++) st.gate(GATES.H, q);
            for (let k = 0; k < t; k++) {
                const e = modpow(a, 1 << (t - 1 - k), N), cm = st.mask(k);
                st.permute((i) => { if (!(i & cm)) return i; const y = i & workMask; if (y >= N) return i; return (i & ~workMask) | Number((BigInt(e) * BigInt(y)) % BigInt(N)); });
            }
            qft(st, Array.from({ length: t }, (_, i) => i), true);
            const outcome = st.measureQubits(Array.from({ length: t }, (_, i) => i)).reduce((x, y) => x * 2 + y, 0);
            if (outcome === 0) continue;
            // the measured number divided by 2^t is close to s/r: find r with continued fractions
            let r = 0;
            { let h0 = 0, h1 = 1, k0 = 1, k1 = 0, x = outcome, y = 1 << t; while (y !== 0) { const q = Math.floor(x / y); [x, y] = [y, x - q * y]; const h2 = q * h1 + h0, k2 = q * k1 + k0; h0 = h1; h1 = h2; k0 = k1; k1 = k2; if (k1 >= N) break; if (modpow(a, k1, N) === 1) { r = k1; break; } } }
            if (!r) continue;
            if (r % 2 !== 0) continue;
            const half = modpow(a, r / 2, N);
            if (half === N - 1) continue;
            const f1 = gcd(half - 1, N), f2 = gcd(half + 1, N);
            const p = f1 > 1 && f1 < N ? f1 : f2;
            if (p > 1 && p < N) return map({ number: N, factors: [Math.min(p, N / p), Math.max(p, N / p)], a, period: r, qubits: t + n, counting_qubits: t, measured: outcome, attempts: attempt, method: 'quantum period finding' });
        }
        throw rtError('Shor did not find a factor of ' + N + ' this time (it is random: try again)', 'QuantumError');
    }
    const deutschJozsa = (n, f) => {
        const g = cb(f); const N = 1 << n;
        let zeros = 0; for (let i = 0; i < N; i++) if (!rt.truthy(g(i)) || g(i) === 0) zeros++;
        const vals = Array.from({ length: N }, (_, i) => { const v = g(i); return v === 0 || v === false || v === null ? 0 : 1; });
        zeros = vals.filter((v) => v === 0).length;
        if (zeros !== 0 && zeros !== N && zeros !== N / 2) throw rtError('Deutsch-Jozsa needs f to be constant or balanced (half 0 and half 1)', 'QuantumError');
        const r = reg(n); const st = r.state;
        for (let q = 0; q < n; q++) { st.gate(GATES.H, q); st.record('H', [q]); }
        for (let i = 0; i < N; i++) if (vals[i]) { st.re[i] = -st.re[i]; st.im[i] = -st.im[i]; }
        st.record('ORACLE', Array.from({ length: n }, (_, i) => i), [], 'Of');
        for (let q = 0; q < n; q++) { st.gate(GATES.H, q); st.record('H', [q]); }
        const p0 = st.prob(0);
        return map({ verdict: p0 > 0.5 ? 'constant' : 'balanced', probability_all_zero: p0, queries: 1, classical_queries_needed: N / 2 + 1, register: r });
    };
    const bernsteinVazirani = (secret) => {
        const s = typeof secret === 'string' ? secret : bits(secret, 8);
        const n = s.length; const sv = parseInt(s, 2);
        const r = reg(n); const st = r.state;
        for (let q = 0; q < n; q++) { st.gate(GATES.H, q); st.record('H', [q]); }
        const par = (x) => { let c = 0; for (let v = x & sv; v; v >>= 1) c ^= v & 1; return c; };
        for (let i = 0; i < st.N; i++) if (par(i)) { st.re[i] = -st.re[i]; st.im[i] = -st.im[i]; }
        st.record('ORACLE', Array.from({ length: n }, (_, i) => i), [], 'Of');
        for (let q = 0; q < n; q++) { st.gate(GATES.H, q); st.record('H', [q]); }
        const found = st.measureQubits(null).join('');
        return map({ secret: found, correct: found === s, queries: 1, classical_queries_needed: n });
    };
    const teleport = (a, b) => {
        // send the qubit a|0> + b|1> from qubit 0 to qubit 2 using an entangled pair and two classical bits
        const nrm = Math.hypot(a, b); const alpha = a / nrm, beta = b / nrm;
        const r = reg(3); const st = r.state;
        st.re[0] = alpha; st.re[0b100] = beta;
        const sent = { x: 2 * alpha * beta, y: 0, z: alpha * alpha - beta * beta };
        st.gate(GATES.H, 1); st.record('H', [1]); st.gate(GATES.X, 2, [1]); st.record('X', [2], [1]);
        st.gate(GATES.X, 1, [0]); st.record('X', [1], [0]); st.gate(GATES.H, 0); st.record('H', [0]);
        const m0 = st.measure(0), m1 = st.measure(1);
        if (m1) { st.gate(GATES.X, 2); st.record('X', [2], [], 'X'); }
        if (m0) { st.gate(GATES.Z, 2); st.record('Z', [2], [], 'Z'); }
        const got = st.bloch(2);
        const fidelity = (1 + sent.x * got.x + sent.y * got.y + sent.z * got.z) / 2;
        return map({ bits_sent: [m0, m1], fidelity, received: map({ x: got.x, y: got.y, z: got.z }), register: r });
    };
    const entries = {
        register: (n) => reg(n), qubits: (n) => reg(n),
        // basis("101") starts in that state; ghz(3), w(3), plus(n)
        basis: (text) => { const t = str(text, 'quantum.basis'); if (!/^[01]+$/.test(t)) throw rtError('basis needs 0s and 1s, like "101"', 'QuantumError'); return fromBits(t); },
        bell, ghz: (n) => { const r = reg(n === undefined ? 3 : n); r.state.gate(GATES.H, 0); r.state.record('H', [0]); for (let q = 1; q < r.state.n; q++) { r.state.gate(GATES.X, q, [0]); r.state.record('X', [q], [0]); } return r; },
        w: (n) => { const k = n === undefined ? 3 : n; const r = reg(k); const st = r.state; st.re[0] = 0; for (let q = 0; q < k; q++) st.re[st.mask(q)] = 1 / Math.sqrt(k); return r; },
        plus: (n) => { const r = reg(n); for (let q = 0; q < r.state.n; q++) { r.state.gate(GATES.H, q); r.state.record('H', [q]); } return r; },
        // from_amplitudes([1, 1i]) builds a state from amplitudes (it is scaled to length 1)
        from_amplitudes: (xs) => { const a = A(xs).map((x) => CX.lift(x)); const n = Math.round(Math.log2(a.length)); if (a.length < 2 || (1 << n) !== a.length) throw rtError('from_amplitudes needs 2, 4, 8, ... amplitudes', 'QuantumError'); const s = new State(n); a.forEach((z, i) => { s.re[i] = z.re; s.im[i] = z.im; }); s.normalize(); return wrap(s); },
        gates: map(Object.fromEntries(Object.entries(GATES).map(([k, v]) => [k, [[CX.C(v[0][0], v[0][1]), CX.C(v[1][0], v[1][1])], [CX.C(v[2][0], v[2][1]), CX.C(v[3][0], v[3][1])]]]))),
        random_bits: (n) => { const r = reg(n); for (let q = 0; q < n; q++) r.state.gate(GATES.H, q); return r.state.measureQubits(null); },
        random_int: (n) => { const k = Math.max(1, Math.ceil(Math.log2(n))); for (;;) { const r = reg(k); for (let q = 0; q < k; q++) r.state.gate(GATES.H, q); const v = r.state.measureQubits(null).reduce((a, b) => a * 2 + b, 0); if (v < n) return v; } },
        coin: () => { const r = reg(1); r.state.gate(GATES.H, 0); return r.state.measure(0) === 0 ? 'heads' : 'tails'; },
        grover: (n, marked, o) => grover(n, marked, opts(o).iterations),
        deutsch_jozsa: deutschJozsa, bernstein_vazirani: bernsteinVazirani, shor, teleport,
        max_qubits: MAX_QUBITS,
    };
    return entries;
};
