import AVFoundation
import Foundation

// Reads sounds from standard input and plays each one at once on one running audio engine.
// Message: u8 command, u32 id, then
//   1 play numbers: u32 rate, u32 channels, u32 frames, f32 volume, then frames*channels f32 (channel after channel)
//   2 stop that sound
//   3 play a sound file: u32 length of the path, f32 volume, then the path (wav, mp3, m4a, aac, flac, aiff...)
// It answers  ready  once, then  done <id>  when a sound has finished, or  failed <id>  when a file could not be opened.
setvbuf(stdout, nil, _IOLBF, 0)
let engine = AVAudioEngine()
let stdin = FileHandle.standardInput
var players: [UInt32: AVAudioPlayerNode] = [:]
let lock = NSLock()

func readExact(_ n: Int) -> Data? {
    var out = Data()
    while out.count < n {
        let chunk = stdin.readData(ofLength: n - out.count)
        if chunk.isEmpty { return nil }
        out.append(chunk)
    }
    return out
}
func u32(_ d: Data, _ at: Int) -> UInt32 { d.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: at, as: UInt32.self) } }
func f32(_ d: Data, _ at: Int) -> Float { d.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: at, as: Float.self) } }

engine.mainMixerNode.outputVolume = 1
do { try engine.start() } catch { print("error engine \(error)"); exit(2) }
print("ready")

while let head = readExact(5) {
    let cmd = head[0], id = u32(head, 1)
    if cmd == 1 {
        guard let h = readExact(16) else { break }
        let rate = Double(u32(h, 0)), ch = Int(u32(h, 4)), frames = Int(u32(h, 8)), vol = f32(h, 12)
        guard let body = readExact(frames * ch * 4) else { break }
        guard let fmt = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: rate, channels: AVAudioChannelCount(ch), interleaved: false),
              let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: AVAudioFrameCount(frames)) else { print("done \(id)"); continue }
        buf.frameLength = AVAudioFrameCount(frames)
        for c in 0..<ch {
            body.withUnsafeBytes { raw in
                let src = raw.baseAddress!.advanced(by: c * frames * 4).assumingMemoryBound(to: Float.self)
                buf.floatChannelData![c].update(from: src, count: frames)
            }
        }
        let p = AVAudioPlayerNode()
        p.volume = vol
        engine.attach(p)
        engine.connect(p, to: engine.mainMixerNode, format: fmt)
        lock.lock(); players[id] = p; lock.unlock()
        p.scheduleBuffer(buf, at: nil, options: [], completionCallbackType: .dataConsumed) { _ in
            DispatchQueue.global().async {
                lock.lock(); let had = players.removeValue(forKey: id) != nil; lock.unlock()
                if had { engine.detach(p) }
                print("done \(id)")
            }
        }
        p.play()
    } else if cmd == 3 {
        guard let h = readExact(8) else { break }
        let plen = Int(u32(h, 0)), vol = f32(h, 4)
        guard let pb = readExact(plen), let path = String(data: pb, encoding: .utf8) else { break }
        do {
            let file = try AVAudioFile(forReading: URL(fileURLWithPath: path))
            let p = AVAudioPlayerNode()
            p.volume = vol
            engine.attach(p)
            engine.connect(p, to: engine.mainMixerNode, format: file.processingFormat)
            lock.lock(); players[id] = p; lock.unlock()
            p.scheduleFile(file, at: nil, completionCallbackType: .dataConsumed) { _ in
                DispatchQueue.global().async {
                    lock.lock(); let had = players.removeValue(forKey: id) != nil; lock.unlock()
                    if had { engine.detach(p) }
                    print("done \(id)")
                }
            }
            p.play()
        } catch { print("failed \(id)") }
    } else if cmd == 2 {
        lock.lock(); let p = players.removeValue(forKey: id); lock.unlock()
        if let p = p { p.stop(); engine.detach(p) }
        print("done \(id)")
    }
}
exit(0)
