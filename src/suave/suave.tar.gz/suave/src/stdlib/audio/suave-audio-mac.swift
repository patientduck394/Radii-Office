import AVFoundation
import Foundation

// Reads sounds from standard input and plays each one at once on one running audio engine.
// Message: u8 command, u32 id, then for play: u32 rate, u32 channels, u32 frames, f32 volume, then frames*channels f32 (channel after channel).
setvbuf(stdout, nil, _IOLBF, 0)
let engine = AVAudioEngine()
let stdin = FileHandle.standardInput
var players: [UInt32: AVAudioPlayerNode] = [:]
let lock = NSLock()

func readExact(_ n: Int) -> Data? {
    var out = Data()
    while out.count < n {
        let chunk = stdin.readData(ofLength: n - out.count)
        if chunk.isEmpty { return nil }
        out.append(chunk)
    }
    return out
}
func u32(_ d: Data, _ at: Int) -> UInt32 { d.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: at, as: UInt32.self) } }
func f32(_ d: Data, _ at: Int) -> Float { d.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: at, as: Float.self) } }

engine.mainMixerNode.outputVolume = 1
do { try engine.start() } catch { print("error engine \(error)"); exit(2) }
print("ready")

while let head = readExact(5) {
    let cmd = head[0], id = u32(head, 1)
    if cmd == 1 {
        guard let h = readExact(16) else { break }
        let rate = Double(u32(h, 0)), ch = Int(u32(h, 4)), frames = Int(u32(h, 8)), vol = f32(h, 12)
        guard let body = readExact(frames * ch * 4) else { break }
        guard let fmt = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: rate, channels: AVAudioChannelCount(ch), interleaved: false),
              let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: AVAudioFrameCount(frames)) else { print("done \(id)"); continue }
        buf.frameLength = AVAudioFrameCount(frames)
        for c in 0..<ch {
            body.withUnsafeBytes { raw in
                let src = raw.baseAddress!.advanced(by: c * frames * 4).assumingMemoryBound(to: Float.self)
                buf.floatChannelData![c].update(from: src, count: frames)
            }
        }
        let p = AVAudioPlayerNode()
        p.volume = vol
        engine.attach(p)
        engine.connect(p, to: engine.mainMixerNode, format: fmt)
        lock.lock(); players[id] = p; lock.unlock()
        p.scheduleBuffer(buf, at: nil, options: [], completionCallbackType: .dataConsumed) { _ in
            DispatchQueue.global().async {
                lock.lock(); let had = players.removeValue(forKey: id) != nil; lock.unlock()
                if had { engine.detach(p) }
                print("done \(id)")
            }
        }
        p.play()
    } else if cmd == 2 {
        lock.lock(); let p = players.removeValue(forKey: id); lock.unlock()
        if let p = p { p.stop(); engine.detach(p) }
        print("done \(id)")
    }
}
exit(0)
