/* std.web: the web made simple for people who are new to websites.
   Fetch things (await web.get(url)), make pages without writing tags (web.page, web.h1, web.list),
   start a website with one line (web.serve), and put things on a page with one word each (web.say, web.button). */
import { rt, SMap, Named, cb, call, map, guard, rtError, show, typeOf, str, toArray } from './_util.js';
import { callMethod } from '../interp.js';
import { httpModule, domModule } from './web.js';

const A = (x) => toArray(x);
const escapeHtml = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// ---- HTML that Suave made itself is remembered, so it is never escaped twice, and text from anywhere else always is ----
const made = new Set();
const mk = (html) => { if (made.size > 20000) made.clear(); made.add(html); return html; };
const esc = (x) => (typeof x === 'string' && made.has(x) ? x : escapeHtml(show(x === null || x === undefined ? '' : x)));
const flatten = (xs) => xs.reduce((a, x) => a.concat(Array.isArray(x) ? flatten(x) : [x]), []);
const join = (xs) => flatten(xs).map(esc).join('');
const tag = (name, xs, attrs) => mk('<' + name + (attrs || '') + '>' + join(xs) + '</' + name + '>');
const named = (rest) => { const n = rest.length && rest[rest.length - 1] instanceof Named ? rest[rest.length - 1].obj : null; return [n ? rest.slice(0, -1) : rest, n || {}]; };

const PAGE_CSS = 'body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;max-width:46rem;margin:2.5rem auto;padding:0 1rem;line-height:1.6;color:#1b2430;background:#fff}' +
    'h1,h2,h3{line-height:1.25}a{color:#0b6bcb}code,pre{background:#f1f4f8;border-radius:6px;padding:.1em .35em}pre{padding:.7em .9em;overflow:auto}' +
    'table{border-collapse:collapse}td,th{border:1px solid #d5dbe3;padding:.35em .7em;text-align:left}th{background:#f1f4f8}' +
    'button{font:inherit;padding:.4em .9em;border:0;border-radius:8px;background:#0b6bcb;color:#fff;cursor:pointer}input{font:inherit;padding:.4em .6em;border:1px solid #b9c3cf;border-radius:8px}' +
    '.box{border:1px solid #d5dbe3;border-radius:12px;padding:.8em 1.1em;margin:1em 0;background:#f8fafc}img{max-width:100%}';

// ---- asking a server (these give futures, so use await: let text = await web.get("https://...")) ----
function ask(method, url, body, o) {
    return new Promise((resolve, reject) => {
        if (typeof fetch === 'undefined') return reject(rtError('This computer cannot reach the web from here', 'NetworkError'));
        const headers = {};
        if (o.headers instanceof SMap) for (const [k, v] of o.headers.entries()) headers[show(k)] = show(v);
        if (o.bearer) headers.Authorization = 'Bearer ' + o.bearer;
        let payload;
        if (body !== undefined && body !== null) {
            if (typeof body === 'string') payload = body;
            else { payload = JSON.stringify(rt.toJS(body)); if (!Object.keys(headers).some((h) => h.toLowerCase() === 'content-type')) headers['Content-Type'] = 'application/json'; }
        }
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), (o.timeout || 30) * 1000);
        fetch(str(url, 'web'), { method, headers, body: payload, signal: ctl.signal })
            .then((res) => res.text().then((text) => { clearTimeout(timer); resolve({ res, text }); }))
            .catch((e) => { clearTimeout(timer); reject(rtError(e && e.name === 'AbortError' ? 'The page took too long to answer: ' + url : 'Could not reach ' + url + (e && e.message ? ' (' + e.message + ')' : ''), 'NetworkError')); });
    });
}
const needGood = ({ res, text }, url) => { if (!res.ok) throw rtError(url + ' answered "' + res.status + ' ' + (res.statusText || 'error') + '"', 'NetworkError'); return text; };
const tryJson = (text) => { try { return rt.fromJS(JSON.parse(text)); } catch (e) { return text; } };


// ---- Keydown text -> HTML ----
// In a browser page that has Keydown.js loaded (<script src="Keydown.js">), the real Keydown engine draws everything (every chip, badge, block and style).
// Anywhere else (the terminal, or a page without Keydown.js) this small built-in version handles the everyday parts of Keydown.
const CHIP_COLORS = { R: '#ef4444', O: '#f97316', Y: '#eab308', G: '#22c55e', C: '#06b6d4', B: '#3b82f6', P: '#a855f7', K: '#ec4899', W: '#94a3b8', D: '#334155' };
const BADGE_COLORS = { red: '#ef4444', orange: '#f97316', yellow: '#eab308', green: '#22c55e', cyan: '#06b6d4', blue: '#3b82f6', purple: '#a855f7', pink: '#ec4899', gray: '#64748b', grey: '#64748b' };
function inlineKd(raw) {
    let t = escapeHtml(raw);
    const hold = []; const keep = (h) => '\u0001' + (hold.push(h) - 1) + '\u0001';
    t = t.replace(/`([^`]+)`/g, (m, c) => keep('<code>' + c + '</code>'));
    t = t.replace(/\{badge\s+([^{}|]*?)\s*(?:\|\s*([A-Za-z]+)[^{}]*)?\}/g, (m, w, c) => { const col = BADGE_COLORS[(c || '').toLowerCase()] || '#06b6d4'; return keep('<span style="display:inline-block;padding:0 .55em;border-radius:999px;font-size:.85em;font-weight:600;color:#fff;background:' + col + '">' + w + '</span>'); });
    t = t.replace(/#([RGBYOCPKWD])#(.+?)#/g, (m, c, w) => keep('<span style="padding:0 .4em;border-radius:6px;font-weight:600;background:' + CHIP_COLORS[c] + '33;box-shadow:inset 0 0 0 1px ' + CHIP_COLORS[c] + '">' + w + '</span>'));
    t = t.replace(/=([RGBYOCPKWD])=(.+?)=/g, (m, c, w) => keep('<mark style="background:' + CHIP_COLORS[c] + '55;border-radius:4px;padding:0 .2em">' + w + '</mark>'));
    t = t.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*])\*([^*\s][^*]*?)\*(?!\*)/g, '$1<em>$2</em>');
    t = t.replace(/__(.+?)__/g, '<u>$1</u>').replace(/-_(.+?)_-/g, '<s>$1</s>').replace(/~~(.+?)~~/g, '<s>$1</s>');
    t = t.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (m, l, u) => (/^(javascript|data):/i.test(u) ? l : '<a href="' + u + '">' + l + '</a>'));
    return t.replace(/\u0001(\d+)\u0001/g, (m, i) => hold[Number(i)]);
}
export function keydownToHtml(src) {
    const kd = typeof globalThis !== 'undefined' && globalThis.Keydown && typeof globalThis.Keydown.render === 'function' ? globalThis.Keydown : null;
    if (kd) { try { return String(kd.render(String(src))); } catch (e) { /* use the small built-in version */ } }
    const lines = String(src).replace(/\r/g, '').split('\n');
    const out = []; let list = null, para = [], i = 0;
    const endPara = () => { if (para.length) { out.push('<p>' + para.map(inlineKd).join('<br>') + '</p>'); para = []; } };
    const endList = () => { if (list) { out.push('<' + list.t + '>' + list.items.map((x) => '<li>' + inlineKd(x) + '</li>').join('') + '</' + list.t + '>'); list = null; } };
    for (; i < lines.length; i++) {
        const l = lines[i]; let m;
        if ((m = /^```(\w*)/.exec(l))) { endPara(); endList(); const code = []; for (i++; i < lines.length && !/^```/.test(lines[i]); i++) code.push(lines[i]); out.push('<pre><code>' + escapeHtml(code.join('\n')) + '</code></pre>'); continue; }
        if (/^\s*$/.test(l)) { endPara(); endList(); continue; }
        if ((m = /^(#{1,6})\s+(.*)$/.exec(l))) { endPara(); endList(); out.push('<h' + m[1].length + '>' + inlineKd(m[2]) + '</h' + m[1].length + '>'); continue; }
        if (/^(---+|\*\*\*+)\s*$/.test(l)) { endPara(); endList(); out.push('<hr>'); continue; }
        if ((m = /^\s*[-*+]\s+\[([ xX])\]\s+(.*)$/.exec(l))) { endPara(); if (!list || list.t !== 'ul') { endList(); list = { t: 'ul', items: [] }; } list.items.push((m[1] === ' ' ? '☐ ' : '☑ ') + m[2]); continue; }
        if ((m = /^\s*[-*+]\s+(.*)$/.exec(l))) { endPara(); if (!list || list.t !== 'ul') { endList(); list = { t: 'ul', items: [] }; } list.items.push(m[1]); continue; }
        if ((m = /^\s*\d+[.)]\s+(.*)$/.exec(l))) { endPara(); if (!list || list.t !== 'ol') { endList(); list = { t: 'ol', items: [] }; } list.items.push(m[1]); continue; }
        if ((m = /^>\s?(.*)$/.exec(l))) { endPara(); endList(); out.push('<blockquote>' + inlineKd(m[1]) + '</blockquote>'); continue; }
        endList(); para.push(l);
    }
    endPara(); endList();
    return out.join('\n');
}

export const webModule = () => {
    const http = httpModule();
    const dom = domModule();
    const needPage = (what) => { if (typeof document === 'undefined') throw rtError('web.' + what + ' puts something on a web page, so it works in a browser. In the terminal, use web.serve(...) to make a site you can open in your browser', 'EnvError'); };
    const home = () => (typeof document !== 'undefined' ? document.getElementById('app') || document.getElementById('suave-output') || document.body : null);
    const put = (el) => { home().appendChild(el); return el; };
    const mkEl = (t, text, cls) => { const e = document.createElement(t); if (text !== undefined) e.textContent = show(text); if (cls) e.className = cls; return e; };

    // serve(what, port): a folder, a page, a map of addresses, or a function
    function serve(what, ...rest) {
        const [pos, o] = named(rest);
        const port = pos[0] !== undefined ? pos[0] : (o.port !== undefined ? o.port : 8000);
        rt.needSys('web.serve');
        const app = http.app();
        const isFn = (v) => typeof v === 'function' || (v !== null && typeof v === 'object' && v.params !== undefined && v.body !== undefined);
        const add = (path, v) => callMethod(app, 'get', [path, isFn(v) ? v : () => v]);
        if (what instanceof SMap) {
            for (const [k, v] of what.entries()) {
                // "POST /save" answers only that kind of request; a plain "/page" answers visits
                const mm = /^(GET|POST|PUT|DELETE|PATCH)\s+(\S.*)$/i.exec(String(k));
                if (mm) { callMethod(app, mm[1].toLowerCase(), [mm[2].startsWith('/') ? mm[2] : '/' + mm[2], isFn(v) ? v : () => v]); continue; }
                const path = String(k).startsWith('/') ? String(k) : '/' + k;
                if (typeof v === 'string' && !/^\s*</.test(v) && rt.sys.stat(v) && v.length < 300) { const st = rt.sys.stat(v); if (st.isDir) callMethod(app, 'static', [path === '/' ? '' : path, v]); else add(path, map({ file: v })); }
                else add(path, v);
            }
        } else if (isFn(what)) { callMethod(app, 'any', ['*', what]); }
        else if (typeof what === 'string') {
            const st = what.length < 300 && !/^\s*</.test(what) ? rt.sys.stat(what) : null;
            if (st && st.isDir) callMethod(app, 'static', ['', what]);
            else if (st) add('/', map({ file: what }));
            else add('/', /^\s*</.test(what) ? what : page('My page', what));
        } else if (what === undefined || what === null) callMethod(app, 'static', ['', '.']);
        else add('/', what);
        const url = 'http://localhost:' + port;
        callMethod(app, 'listen', [port, () => { rt.write('Your website is running! Open ' + url + ' in your browser (press Ctrl+C to stop)\n'); if (o.open === true) openIt(url); }]);
        return null;
    }
    function openIt(url) {
        if (typeof window !== 'undefined' && typeof document !== 'undefined') { window.open(str(url, 'web.open'), '_blank'); return null; }
        const s = rt.needSys('web.open');
        const os = s.os();
        const [cmd, args] = os === 'darwin' ? ['open', [url]] : os === 'windows' ? ['cmd', ['/c', 'start', '', url]] : ['xdg-open', [url]];
        try { s.runSync(cmd, args, {}); } catch (e) { rt.write('Open this address in your browser: ' + url + '\n'); }
        return null;
    }

    // page("Title", parts..., css: ".card { color: red }") (the css: text goes after Suave's own style, so yours wins)
    const page = (title, ...rest) => {
        const [parts, o] = named(rest);
        const css = o.css === undefined ? '' : show(o.css);
        const lang = o.lang === undefined ? 'en' : show(o.lang);
        return mk('<!doctype html><html lang="' + escapeHtml(lang) + '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + esc(title) + '</title><style>' + PAGE_CSS + '</style>' + (css ? '<style>' + css.replace(/<\/style/gi, '') + '</style>' : '') + '</head><body>' + join(parts) + '</body></html>');
    };
    const classOf = (c) => String(c === undefined || c === null ? '' : c).replace(/[^\w\- ]/g, '');
    const cleanStyle = (c) => escapeHtml(show(c));

    return {
        // ----- asking the web (use await) -----
        get: async (url, ...r) => needGood(await ask('GET', url, undefined, named(r)[1]), url),
        json: async (url, ...r) => { const t = needGood(await ask('GET', url, undefined, named(r)[1]), url); try { return rt.fromJS(JSON.parse(t)); } catch (e) { throw rtError(url + ' did not answer with JSON data', 'NetworkError'); } },
        post: async (url, data, ...r) => { const x = await ask('POST', url, data, named(r)[1]); return tryJson(needGood(x, url)); },
        put: async (url, data, ...r) => { const x = await ask('PUT', url, data, named(r)[1]); return tryJson(needGood(x, url)); },
        delete: async (url, ...r) => { const x = await ask('DELETE', url, undefined, named(r)[1]); return tryJson(needGood(x, url)); },
        // is_up(url) says yes or no and never fails; status(url) is the number (200, 404...), or 0 when nothing answers
        is_up: async (url) => { try { return (await ask('GET', url, undefined, { timeout: 10 })).res.ok; } catch (e) { return false; } },
        status: async (url) => { try { return (await ask('GET', url, undefined, { timeout: 10 })).res.status; } catch (e) { return 0; } },

        // ----- addresses -----
        encode: (s) => encodeURIComponent(show(s)), decode: (s) => { try { return decodeURIComponent(show(s)); } catch (e) { return show(s); } },
        // query({q: "cats", page: 2}) -> "q=cats&page=2";   link_to("https://x.com/search", {q: "cats"}) -> "https://x.com/search?q=cats"
        query: (m) => (m instanceof SMap ? m.entries() : []).map(([k, v]) => encodeURIComponent(show(k)) + '=' + encodeURIComponent(show(v))).join('&'),
        link_to: (base, m) => { const q = m instanceof SMap && m.size ? m.entries().map(([k, v]) => encodeURIComponent(show(k)) + '=' + encodeURIComponent(show(v))).join('&') : ''; return str(base, 'web.link_to') + (q ? (base.includes('?') ? '&' : '?') + q : ''); },
        // parts("https://a.com:8080/x/y?q=1#top") -> {host, port, path, query, hash, scheme}
        parts: (u) => { try { const x = new URL(str(u, 'web.parts')); const q = new SMap(); for (const [k, v] of x.searchParams) q.set(k, v); return map({ scheme: x.protocol.replace(':', ''), host: x.hostname, port: x.port === '' ? null : Number(x.port), path: x.pathname, query: q, hash: x.hash.replace('#', '') }); } catch (e) { throw rtError('"' + u + '" is not a web address (it should look like https://example.com)', 'ValueError'); } },
        escape: (s) => escapeHtml(show(s)),

        // ----- making pages without writing any tags (text you give is made safe for you) -----
        page, safe: (html) => mk(show(html)),
        // ----- Keydown: web.ktext("# Hello\n**bold** and #C#a chip#") gives formatted HTML you can put in a page -----
        ktext: (text) => mk(keydownToHtml(show(text))), keydown: (text) => mk(keydownToHtml(show(text))),
        // ----- your own CSS (see docs/WEB.md): classes, inline styles, and style sheets -----
        // div("card", ...)  <div class="card">;   span("hot", ...)  <span class="hot">;   styled("color: red; font-size: 2rem", ...)  an element with its own style
        // style(".card { padding: 1rem }")  a style sheet you can put in a page;   page("T", ..., css: "...")  does the same
        div: (cls, ...x) => tag('div', x, cls ? ' class="' + classOf(cls) + '"' : ''), span: (cls, ...x) => tag('span', x, cls ? ' class="' + classOf(cls) + '"' : ''),
        styled: (css, ...x) => tag('div', x, ' style="' + cleanStyle(css) + '"'),
        // css({".card": {border: "2px solid teal", font_size: "1.2rem"}, "h2": {color: "purple"}}) writes the style sheet text for you (no braces to type inside a string)
        css: (rules) => {
            if (!(rules instanceof SMap)) throw rtError('web.css needs a map like {".card": {color: "red"}} but got ' + typeOf(rules), 'TypeError');
            const kebab = (k) => String(k).replace(/_/g, '-').replace(/[A-Z]/g, (c) => '-' + c.toLowerCase());
            const block = (sel, decl) => {
                if (!(decl instanceof SMap)) throw rtError('web.css: the rules for ' + show(sel) + ' should be a map like {color: "red"}', 'TypeError');
                return String(sel).replace(/[{}<]/g, '') + ' { ' + decl.entries().map(([k, v]) => kebab(k) + ': ' + show(v).replace(/[{};<]/g, '') + ';').join(' ') + ' }';
            };
            return rules.entries().map(([sel, decl]) => block(sel, decl)).join('\n');
        },
        style: (css) => mk('<style>' + show(css).replace(/<\/style/gi, '') + '</style>'),
        h1: (...x) => tag('h1', x), h2: (...x) => tag('h2', x), h3: (...x) => tag('h3', x), p: (...x) => tag('p', x),
        bold: (...x) => tag('strong', x), italic: (...x) => tag('em', x), code: (...x) => tag('code', x), quote: (...x) => tag('blockquote', x), box: (...x) => tag('div', x, ' class="box"'),
        text: (...x) => mk(join(x)), line: () => mk('<hr>'), br: () => mk('<br>'),
        link: (label, url) => mk('<a href="' + escapeHtml(show(url)) + '">' + esc(label) + '</a>'),
        image: (url, alt) => mk('<img src="' + escapeHtml(show(url)) + '" alt="' + escapeHtml(alt === undefined ? '' : show(alt)) + '">'),
        list: (items) => mk('<ul>' + A(items).map((i) => '<li>' + esc(i) + '</li>').join('') + '</ul>'),
        numbered: (items) => mk('<ol>' + A(items).map((i) => '<li>' + esc(i) + '</li>').join('') + '</ol>'),
        // table([["Ann", 31], ["Bo", 28]], ["Name", "Age"])
        table: (rows, head) => mk('<table>' + (head ? '<thead><tr>' + A(head).map((h) => '<th>' + esc(h) + '</th>').join('') + '</tr></thead>' : '') + '<tbody>' + A(rows).map((r) => '<tr>' + (Array.isArray(r) ? r : [r]).map((c) => '<td>' + esc(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table>'),
        // form_value(req, "name") reads a value a visitor sent (from the address or a JSON body)
        form_value: (req, name, fallback) => { const q = req.get('query'); if (q && q.has(name)) return q.get(name); const j = req.get('json'); if (j instanceof SMap && j.has(name)) return j.get(name); return fallback === undefined ? null : fallback; },

        // ----- starting a website -----
        // serve("public")              share a folder        serve(web.page("Hi", web.h1("Hello!")))     one page
        // serve({"/": "<h1>Hi</h1>", "/time": || time.now()})     several addresses            serve(|req| "Hello")      answer everything
        serve, open: openIt, serve_here: (port) => serve('.', port === undefined ? 8000 : port),

        // ----- putting things on a page, one word each (browser only) -----
        say: (...x) => { needPage('say'); return put(mkEl('p', x.map(show).join(' '))); },
        heading: (t, level) => { needPage('heading'); return put(mkEl('h' + Math.min(6, Math.max(1, level || 1)), t)); },
        // button("Click me", || web.say("Hi!"))
        button: (label, f) => { needPage('button'); const b = mkEl('button', label); const g = guard(cb(f)); b.addEventListener('click', () => g()); return put(b); },
        // input("Your name", |name| web.say("Hello " + name))   asks for text; the function runs when the visitor presses Enter or the button
        input: (label, f, start) => {
            needPage('input');
            const wrap = mkEl('p'); const i = mkEl('input'); i.placeholder = show(label); if (start !== undefined) i.value = show(start); const b = mkEl('button', 'OK'); b.style.marginLeft = '.4rem';
            const g = guard(cb(f)); const go = () => { g(i.value); }; b.addEventListener('click', go); i.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
            wrap.append(i, b); return put(wrap);
        },
        // say_ktext("# Hi **there**") puts formatted Keydown on the page;   add_css(".card { color: red }") adds your own style sheet to the page
        say_ktext: (text) => { needPage('say_ktext'); const d = mkEl('div'); d.innerHTML = keydownToHtml(show(text)); return put(d); },
        add_css: (css) => { needPage('add_css'); const st = document.createElement('style'); st.textContent = show(css); document.head.appendChild(st); return st; },
        picture: (url, alt) => { needPage('picture'); const i = mkEl('img'); i.src = show(url); i.alt = alt === undefined ? '' : show(alt); i.style.maxWidth = '100%'; return put(i); },
        add_link: (label, url) => { needPage('add_link'); const a = mkEl('a', label); a.href = show(url); const p = mkEl('p'); p.appendChild(a); put(p); return a; },
        clear: () => { needPage('clear'); const h = home(); h.textContent = ''; return null; },
        title: (t) => { needPage('title'); return dom.title(t); },
        // after(2, || ...) does something later;  every(1, || ...) repeats (it gives back a function that stops it)
        after: (seconds, f) => { const g = guard(cb(f)); setTimeout(() => g(), Math.max(0, Number(seconds) || 0) * 1000); return null; },
        every: (seconds, f) => { const g = guard(cb(f)); const id = setInterval(() => g(), Math.max(0.05, Number(seconds) || 1) * 1000); return () => { clearInterval(id); return null; }; },
    };
};
void call; void typeOf;
