/* Suave parser: tokens -> syntax tree. Newlines end statements, except inside ( ) and [ ] and before .method / |> continuations. */
import { lex, SuaveSyntaxError } from './lexer.js';

const COMPOUND = { '+=': '+', '-=': '-', '*=': '*', '/=': '/', '%=': '%', '**=': '**', '??=': '??' };
const BLOCKISH = new Set(['if', 'match', 'for', 'while', 'loop', 'try']);

class Parser {
    constructor(toks, file) { this.toks = toks; this.p = 0; this.file = file || '<main>'; this.ign = 0; this.asyncCtx = [true]; this.pendingAsync = false; }
    // ----- token helpers -----
    get tok() { return this.toks[this.p]; }
    peek(k) { return this.toks[Math.min(this.p + (k || 0), this.toks.length - 1)]; }
    next() { return this.toks[this.p++]; }
    err(msg, tok) { tok = tok || this.tok; throw new SuaveSyntaxError(msg, tok.line, tok.col, this.file); }
    describe(t) { return t.t === 'eof' ? 'the end of the file' : t.t === 'str' ? 'a string' : t.t === 'num' ? 'the number ' + t.v : '"' + t.v + '"'; }
    isOp(v, k) { const t = this.peek(k); return t.t === 'op' && t.v === v; }
    isKw(v, k) { const t = this.peek(k); return t.t === 'kw' && t.v === v; }
    // a token that starts a new line ends the statement (unless we are inside ( ) or [ ])
    newline() { return this.tok.nl && this.ign === 0; }
    eatOp(v) { if (this.isOp(v)) { this.p++; return true; } return false; }
    eatKw(v) { if (this.isKw(v)) { this.p++; return true; } return false; }
    expectOp(v, why) { if (!this.isOp(v)) this.err('Expected "' + v + '"' + (why ? ' ' + why : '') + ' but found ' + this.describe(this.tok)); return this.next(); }
    expectKw(v) { if (!this.isKw(v)) this.err('Expected "' + v + '" but found ' + this.describe(this.tok)); return this.next(); }
    ident(why) { const t = this.tok; if (t.t !== 'id') this.err('Expected a name' + (why ? ' ' + why : '') + ' but found ' + this.describe(t)); this.p++; return t.v; }
    node(t, tok, props) { return Object.assign({ t, line: tok.line, col: tok.col }, props); }
    withIgn(n, fn) { const s = this.ign; this.ign = n; try { return fn(); } finally { this.ign = s; } }

    // ----- program and statements -----
    program() {
        const stmts = [];
        this.skipSemis();
        while (this.tok.t !== 'eof') { stmts.push(this.statement()); this.endStatement(); }
        return { t: 'Program', stmts, line: 1 };
    }
    skipSemis() { while (this.isOp(';')) this.p++; }
    endStatement() {
        if (this.isOp(';')) { this.skipSemis(); return; }
        if (this.tok.t === 'eof' || this.isOp('}') || this.tok.nl) return;
        this.err('I expected the end of the line here but found ' + this.describe(this.tok) + '. Put it on a new line, or separate with ;');
    }
    block() {
        if (!this.isOp('{') && this.tok.nl) this.err('I expected the lines of a block here. End the line above with a colon (:) and indent the lines below it, like  if x > 3:  then the indented lines', this.tok);
        const open = this.expectOp('{');
        return this.withIgn(0, () => {
            const stmts = [];
            this.skipSemis();
            while (!this.isOp('}')) {
                if (this.tok.t === 'eof') this.err('This { was never closed', open);
                stmts.push(this.statement());
                this.endStatement();
                this.skipSemis();
            }
            this.p++;
            return this.node('Block', open, { stmts });
        });
    }
    statement() {
        const t = this.tok;
        if (t.t === 'kw') {
            switch (t.v) {
                case 'let': case 'var': return this.letStmt();
                case 'const': return this.letStmt();
                case 'pub': this.p++; return this.statement();
                case 'fn': if (this.peek(1).t === 'id') return this.fnDecl(); break;
                case 'async': if (this.isKw('fn', 1) && this.peek(2).t === 'id') { this.p++; this.pendingAsync = true; return this.fnDecl(); } break;
                case 'struct': return this.structDecl();
                case 'enum': return this.enumDecl();
                case 'impl': return this.implDecl();
                case 'trait': return this.traitDecl();
                case 'use': return this.useStmt();
                case 'return': { this.p++; const v = this.canStartExpr() ? this.expr() : null; return this.node('Return', t, { e: v }); }
                case 'break': { this.p++; const v = this.canStartExpr() ? this.expr() : null; return this.node('Break', t, { e: v }); }
                case 'continue': this.p++; return this.node('Continue', t, {});
                case 'throw': { this.p++; return this.node('Throw', t, { e: this.expr() }); }
            }
        }
        if (t.t === 'id' && t.v === 'from' && this.peek(1).t === 'id') {                  // Python style: from math import sqrt, pi as p   (or: from math import *)
            let k = 1; while (this.peek(k).t === 'id' && this.isOp('.', k + 1) && this.peek(k + 2).t === 'id') k += 2;
            if (this.peek(k).t === 'id' && this.isKw('use', k + 1)) {
                this.p++;
                const parts = [this.ident()];
                while (this.eatOp('.')) parts.push(this.ident());
                this.p++;                                                                   // the import word
                if (this.eatOp('*')) return this.node('Use', t, { path: null, parts, names: null, star: true, alias: null });
                const names = [];
                do { const n = this.ident(); let as = n; if (this.eatKw('as')) as = this.ident(); names.push([n, as]); } while (this.eatOp(','));
                return this.node('Use', t, { path: null, parts, names, star: false, alias: null });
            }
        }
        if (t.t === 'id' && t.v === 'class' && this.peek(1).t === 'id' && (this.isOp('{', 2) || this.isOp('(', 2))) return this.classDecl();
        if (t.t === 'id' && t.v === 'test' && this.peek(1).t === 'str' && this.isOp('{', 2)) {
            this.p++;
            const name = this.stringLit();
            return this.node('Test', t, { name, body: this.block() });
        }
        return this.exprStatement();
    }
    // at a "{": is it a map like {a: 1} or {*other, b: 2}, rather than a block of statements?
    looksLikeMap() {
        if (this.tok.gen) return false;                                              // a block that came from a Python-style colon
        const a = this.peek(1), b = this.peek(2);
        if (a.t === 'op' && a.v === '}') return true;
        if (a.t === 'op' && a.v === '*') return true;
        return (a.t === 'id' || a.t === 'str' || a.t === 'kw' || a.t === 'num') && b.t === 'op' && b.v === ':' && !(this.peek(3).t === 'op' && this.peek(3).v === ':');
    }
    canStartExpr() {
        const t = this.tok;
        if (t.nl && this.ign === 0) return false;
        if (t.t === 'eof') return false;
        if (t.t === 'op') return ['(', '[', '{', '-', '|', '||', '!', '#{', '..', '..=', '+'].includes(t.v);
        if (t.t === 'kw') return !['else', 'in', 'as', 'catch', 'finally', 'and', 'or', 'is'].includes(t.v);
        return true;
    }
    stringLit() { const t = this.next(); if (t.t !== 'str' || t.parts.some((x) => typeof x !== 'string')) this.err('Expected a plain string here', t); return t.parts.join(''); }
    letStmt() {
        const kw = this.next();
        const pat = this.pattern(true);
        let type = null;
        if (this.eatOp(':')) type = this.parseType();
        let init = null;
        if (this.eatOp('=')) init = this.expr();
        else if (kw.v !== 'var') this.err('"' + kw.v + '" needs a value: ' + kw.v + ' name = value');
        return this.node('Let', kw, { pat, type, init, mut: kw.v === 'var', isConst: kw.v === 'const' });
    }
    params(closer, lambda) {
        const out = [];
        let seenRest = false;
        while (!this.isOp(closer)) {
            if (this.eatOp('*')) { out.push({ rest: true, name: this.ident(), pat: null, type: null, def: null }); seenRest = true; }
            else {
                const pat = this.pattern(true);
                let type = null, def = null;
                if (this.isOp(':')) { this.p++; type = this.parseType(lambda); }
                if (this.eatOp('=')) def = lambda ? this.coalesce() : this.expr();
                out.push({ pat, name: pat.t === 'PBind' ? pat.name : null, type, def });
            }
            if (!this.eatOp(',')) break;
        }
        if (seenRest && !out[out.length - 1].rest) this.err('A *rest parameter has to be the last one');
        return out;
    }
    fnDecl() {
        const kw = this.next();
        const name = this.ident();
        if (this.isOp('<')) this.skipGenerics();
        const fn = this.fnRest(kw, name);
        return this.node('FnDecl', kw, { name, fn });
    }
    skipGenerics() { let d = 0; do { if (this.isOp('<')) d++; else if (this.isOp('>')) d--; this.p++; } while (d > 0 && this.tok.t !== 'eof'); }
    fnRest(kw, name) {
        const isAsync = this.pendingAsync; this.pendingAsync = false;
        this.asyncCtx.push(isAsync);
        try { return this.fnRest2(kw, name, isAsync); } finally { this.asyncCtx.pop(); }
    }
    fnRest2(kw, name, isAsync) {
        this.expectOp('(', 'after the function name');
        const params = this.withIgn(1, () => { const ps = this.params(')'); this.expectOp(')'); return ps; });
        let ret = null;
        if (this.eatOp('->')) ret = this.parseType();
        let body, bodyless = false;
        if (this.isOp('{')) body = this.block();
        else if (this.eatOp('=')) body = this.expr();
        else if (this.newline() || this.isOp('}') || this.tok.t === 'eof' || this.isOp(';')) bodyless = true;
        else this.err('A function needs a body: { ... } or = expression');
        return this.node('Fn', kw, { name, params, body, ret, bodyless, lambda: false, async: isAsync });
    }
    structDecl() {
        const kw = this.next();
        const name = this.ident();
        const fields = [];
        if (this.isOp('{')) {
            this.p++;
            this.withIgn(1, () => {
                while (!this.isOp('}')) {
                    const f = this.ident('for a field');
                    let type = null, def = null;
                    if (this.eatOp(':')) type = this.parseType();
                    if (this.eatOp('=')) def = this.expr();
                    fields.push({ name: f, type, def });
                    if (!this.eatOp(',') && !this.tok.nl) break;
                }
                this.expectOp('}');
            });
        } else if (this.isOp('(')) {
            this.p++;
            this.withIgn(1, () => {
                while (!this.isOp(')')) { fields.push({ name: this.ident('for a field'), type: null, def: null }); if (!this.eatOp(',')) break; }
                this.expectOp(')');
            });
        }
        return this.node('Struct', kw, { name, fields });
    }
    // class Dog: fields (name: str, age: num = 1) and def methods together. It is a struct plus its methods, with no __init__ needed:  Dog("Rex")  or  Dog(name="Rex")
    classDecl() {
        const kw = this.next();
        const name = this.ident();
        if (this.eatOp('(')) { this.err('Suave classes do not inherit. Use a trait for shared behavior', kw); }
        this.expectOp('{');
        const fields = [], methods = [];
        this.withIgn(0, () => {
            this.skipSemis();
            while (!this.isOp('}')) {
                if (this.tok.t === 'eof') this.err('This class was never closed', kw);
                this.eatKw('pub');
                if (this.isKw('fn')) {
                    const fk = this.next(); const mname = this.ident();
                    if (this.isOp('<')) this.skipGenerics();
                    methods.push(this.fnRest(fk, mname));
                } else if (this.isKw('const')) { methods.push({ konst: this.letStmt() }); }
                else {
                    const f = this.ident('for a field or a def');
                    let type = null, def = null;
                    if (this.eatOp(':')) type = this.parseType();
                    if (this.eatOp('=')) def = this.expr();
                    fields.push({ name: f, type, def });
                }
                this.endStatement();
                this.skipSemis();
            }
            this.p++;
        });
        return this.node('Multi', kw, { stmts: [this.node('Struct', kw, { name, fields }), this.node('Impl', kw, { name, trait: null, methods })] });
    }
    enumDecl() {
        const kw = this.next();
        const name = this.ident();
        this.expectOp('{');
        const variants = [];
        this.withIgn(1, () => {
            while (!this.isOp('}')) {
                const v = this.ident('for a variant');
                const fields = [];
                if (this.eatOp('(')) { while (!this.isOp(')')) { fields.push(this.ident('for a field')); if (this.eatOp(':')) this.parseType(); if (!this.eatOp(',')) break; } this.expectOp(')'); }
                let value = null;
                if (this.eatOp('=')) value = this.expr();
                variants.push({ name: v, fields, value });
                if (!this.eatOp(',') && !this.tok.nl) break;
            }
            this.expectOp('}');
        });
        return this.node('Enum', kw, { name, variants });
    }
    methods() {
        this.expectOp('{');
        const ms = [];
        this.withIgn(0, () => {
            this.skipSemis();
            while (!this.isOp('}')) {
                this.eatKw('pub');
                if (this.isKw('const')) { const s = this.letStmt(); ms.push({ konst: s }); }
                else {
                    const kw = this.expectKw('fn');
                    const name = this.ident();
                    if (this.isOp('<')) this.skipGenerics();
                    ms.push(this.fnRest(kw, name));
                }
                this.skipSemis();
            }
            this.p++;
        });
        return ms;
    }
    implDecl() {
        const kw = this.next();
        let a = this.ident();
        while (this.eatOp('.')) a += '.' + this.ident();
        let trait = null, name = a;
        if (this.eatKw('for')) { trait = a; name = this.ident(); }
        return this.node('Impl', kw, { name, trait, methods: this.methods() });
    }
    traitDecl() {
        const kw = this.next();
        const name = this.ident();
        return this.node('Trait', kw, { name, methods: this.methods() });
    }
    useStmt() {
        const kw = this.next();
        let path = null, parts = [];
        if (this.tok.t === 'str') { path = this.stringLit(); }
        else {
            parts.push(this.ident());
            while (this.isOp('.') && (this.peek(1).t === 'id')) { this.p++; parts.push(this.ident()); }
        }
        let names = null, star = false, alias = null;
        if (this.isOp('.')) {
            this.p++;
            if (this.eatOp('*')) star = true;
            else if (this.eatOp('{')) {
                names = [];
                this.withIgn(1, () => {
                    while (!this.isOp('}')) { const n = this.ident(); let as = n; if (this.eatKw('as')) as = this.ident(); names.push([n, as]); if (!this.eatOp(',')) break; }
                    this.expectOp('}');
                });
            } else this.err('After "use a.b." I expected * or { names }');
        }
        if (this.eatKw('as')) alias = this.ident();
        return this.node('Use', kw, { path, parts, names, star, alias });
    }

    // ----- types (kept for checks and documentation) -----
    parseType(noUnion) {
        let t = this.parseTypeBase();
        while (!noUnion && this.isOp('|') && this.ign === 0 && !this.tok.nl) { this.p++; const r = this.parseTypeBase(); t = { t: 'union', items: t.t === 'union' ? t.items.concat([r]) : [t, r] }; }
        return t;
    }
    parseTypeBase() {
        let t;
        if (this.eatOp('[')) { const e = this.parseType(); this.expectOp(']'); t = { t: 'name', name: 'list', args: [e] }; }
        else if (this.eatOp('(')) { const items = []; while (!this.isOp(')')) { items.push(this.parseType()); if (!this.eatOp(',')) break; } this.expectOp(')'); t = { t: 'name', name: 'tuple', args: items }; }
        else if (this.isKw('fn')) { this.p++; this.expectOp('('); while (!this.isOp(')')) { this.parseType(); if (!this.eatOp(',')) break; } this.expectOp(')'); if (this.eatOp('->')) this.parseType(); t = { t: 'name', name: 'fn', args: [] }; }
        else if (this.isKw('none')) { this.p++; t = { t: 'name', name: 'none', args: [] }; }
        else {
            let name = this.ident('for a type');
            while (this.isOp('.') && this.peek(1).t === 'id') { this.p++; name += '.' + this.ident(); }
            const args = [];
            if (this.isOp('<')) { this.p++; while (!this.isOp('>')) { args.push(this.parseType()); if (!this.eatOp(',')) break; } this.expectOp('>'); }
            t = { t: 'name', name, args };
        }
        while (this.isOp('?') && !this.tok.nl) { this.p++; t = { t: 'union', items: [t, { t: 'name', name: 'none', args: [] }] }; }
        return t;
    }

    // ----- patterns -----
    pattern(simple) {
        const first = this.patternAtom(simple);
        if (!simple && this.isOp('|') && this.ign === 0 || (!simple && this.isOp('|') && this.ign > 0)) {
            const alts = [first];
            while (this.isOp('|')) { this.p++; alts.push(this.patternAtom(simple)); }
            return { t: 'POr', alts, line: first.line };
        }
        return first;
    }
    patternAtom(simple) {
        const t = this.tok;
        if (t.t === 'id') {
            this.p++;
            if (t.v === '_') return this.node('PWild', t, {});
            // Name(...) or Name { ... }  or Module.Name(...)
            const isType = /^[A-Z]/.test(t.v);
            let name = t.v;
            while (isType && this.isOp('.') && this.peek(1).t === 'id' && /^[A-Z]/.test(this.peek(1).v)) { this.p++; name = this.ident(); }
            if (this.isOp('(') && isType) {
                this.p++;
                const args = this.withIgn(1, () => { const a = []; while (!this.isOp(')')) { a.push(this.pattern()); if (!this.eatOp(',')) break; } this.expectOp(')'); return a; });
                return this.node('PVariant', t, { name, args });
            }
            if (this.isOp('{') && isType && !simple) {
                const m = this.mapPattern();
                return this.node('PStruct', t, { name, entries: m.entries, rest: m.rest });
            }
            if (isType && !simple) return this.node('PVariant', t, { name, args: null });
            if (this.isOp(':') && !simple && this.peek(1).t === 'id' && /^(int|num|float|str|bool|list|map|set|tuple|fn|sym|bigint|range|none)$/.test(this.peek(1).v) && false) { /* typed patterns: n: int */ }
            return this.node('PBind', t, { name: t.v });
        }
        if (t.t === 'num' || t.t === 'str' || (t.t === 'op' && t.v === '-' && this.peek(1).t === 'num') || t.t === 'sym' || t.t === 'big' ||
            (t.t === 'kw' && ['true', 'false', 'none'].includes(t.v))) {
            if (simple) this.err('A pattern like this is only allowed in match: ' + this.describe(t));
            const lit = this.literalValue();
            if (this.isOp('..') || this.isOp('..=')) {
                const incl = this.next().v === '..=';
                const hi = (this.tok.t === 'num' || this.isOp('-')) ? this.literalValue() : null;
                return this.node('PRange', t, { a: lit, b: hi, incl });
            }
            return this.node('PLit', t, { v: lit });
        }
        if (t.t === 'op' && (t.v === '..' || t.v === '..=')) {
            this.p++; const incl = t.v === '..=';
            return this.node('PRange', t, { a: null, b: this.literalValue(), incl });
        }
        if (t.t === 'op' && t.v === '[') {
            this.p++;
            const r = this.withIgn(1, () => this.seqPattern(']', simple));
            return this.node('PList', t, r);
        }
        if (t.t === 'op' && t.v === '(') {
            this.p++;
            const r = this.withIgn(1, () => this.seqPattern(')', simple));
            return this.node('PList', t, r);
        }
        if (t.t === 'op' && t.v === '{') {
            const m = this.mapPattern();
            return this.node('PMap', t, { entries: m.entries, rest: m.rest });
        }
        this.err('Expected a pattern here but found ' + this.describe(t));
    }
    literalValue() {
        const t = this.next();
        if (t.t === 'op' && t.v === '-') { const n = this.next(); return { t: 'Num', v: -n.v, line: t.line }; }
        if (t.t === 'num') return { t: 'Num', v: t.v, line: t.line };
        if (t.t === 'big') return { t: 'Big', v: t.v, line: t.line };
        if (t.t === 'str') return this.strNode(t);
        if (t.t === 'sym') return { t: 'Sym', name: t.v, line: t.line };
        if (t.t === 'kw') return { t: t.v === 'none' ? 'None' : 'Bool', v: t.v === 'true', line: t.line };
        this.err('Expected a value', t);
    }
    seqPattern(closer, simple) {
        const items = [];
        let rest = null, restAt = -1;
        while (!this.isOp(closer)) {
            if (this.isOp('..') || this.isOp('*')) {
                this.p++;
                rest = this.tok.t === 'id' ? this.ident() : '_';
                restAt = items.length;
            } else items.push(this.pattern(simple));
            if (!this.eatOp(',')) break;
        }
        this.expectOp(closer);
        return { items, rest, restAt, tuple: closer === ')' };
    }
    mapPattern() {
        this.expectOp('{');
        return this.withIgn(1, () => {
            const entries = [];
            let rest = null;
            while (!this.isOp('}')) {
                if (this.isOp('..') || this.isOp('*')) { this.p++; rest = this.tok.t === 'id' ? this.ident() : '_'; }
                else {
                    const kt = this.tok;
                    let key;
                    if (kt.t === 'str') key = this.stringLit(); else key = this.ident('for a field name');
                    let pat;
                    if (this.eatOp(':')) pat = this.pattern(); else pat = this.node('PBind', kt, { name: key });
                    entries.push({ key, pat });
                }
                if (!this.eatOp(',')) break;
            }
            this.expectOp('}');
            return { entries, rest };
        });
    }

    // ----- expressions -----
    exprStatement() {
        const start = this.tok;
        let e = this.expr();
        // Python style, without brackets:  a, b = 1, 2   and   first, *rest = items
        if (this.isOp(',') && !this.tok.nl && this.ign === 0) {
            const items = [e];
            while (this.eatOp(',')) { if (this.isOp('=')) break; items.push(this.itemOrSpread()); }
            if (!this.isOp('=')) this.err('A list of values with commas needs brackets here, or an = after the names', start);
            e = this.node('Tuple', start, { items });
            this.p++;
            let value = this.expr();
            if (this.isOp(',') && !this.tok.nl) { const vs = [value]; while (this.eatOp(',')) { if (this.tok.nl || this.tok.t === 'eof') break; vs.push(this.itemOrSpread()); } value = this.node('Tuple', start, { items: vs }); }
            return this.node('Assign', start, { target: this.toTarget(e, start), op: null, value });
        }
        const t = this.tok;
        if (t.t === 'op' && !(t.nl && this.ign === 0)) {
            if (t.v === '=') {
                this.p++;
                return this.node('Assign', start, { target: this.toTarget(e, start), op: null, value: this.expr() });
            }
            if (COMPOUND[t.v]) {
                this.p++;
                return this.node('Assign', start, { target: this.toTarget(e, start), op: COMPOUND[t.v], value: this.expr() });
            }
        }
        return e;
    }
    toTarget(e, tok) {
        if (e.t === 'Id' || e.t === 'Member' || e.t === 'Index') return e;
        if (e.t === 'Tuple' || e.t === 'List') return { t: 'Destructure', pat: this.toPattern(e), line: e.line };
        this.err('You cannot assign to this', tok);
    }
    toPattern(e) {
        if (e.t === 'Id') return { t: e.name === '_' ? 'PWild' : 'PBind', name: e.name, line: e.line };
        if (e.t === 'Tuple' || e.t === 'List') {
            const items = []; let rest = null, restAt = -1;
            for (const x of e.items) { if (x.spread) { rest = x.e && x.e.t === 'Id' ? x.e.name : '_'; restAt = items.length; } else items.push(this.toPattern(x)); }
            return { t: 'PList', items, rest, restAt, tuple: e.t === 'Tuple', line: e.line };
        }
        this.err('You can only assign into names and (a, b) pairs here');
    }
    expr() {
        const e = this.pipe();
        // Python style:  value if condition else other
        if (this.isKw('if') && !(this.tok.nl && this.ign === 0) && this.isTernary()) {
            const t = this.next();
            const c = this.pipe();
            this.expectKw('else');
            const other = this.expr();
            return this.node('If', t, { c, th: { t: 'Block', stmts: [e], line: e.line || t.line }, el: { t: 'Block', stmts: [other], line: other.line || t.line } });
        }
        return e;
    }
    // at an "if" that follows a value: is there a matching "else" on this line (so it is a ternary, not a comprehension filter)?
    isTernary() {
        let d = 0, ifs = 0;
        for (let k = this.p + 1; k < this.toks.length; k++) {
            const u = this.toks[k];
            if (u.t === 'eof') return false;
            if (u.nl && d === 0 && this.ign === 0) return false;
            if (u.t === 'op') {
                if (u.v === '(' || u.v === '[' || u.v === '{' || u.v === '#{') d++;
                else if (u.v === ')' || u.v === ']' || u.v === '}') { d--; if (d < 0) return false; }
                else if (u.v === ';' && d === 0) return false;
            } else if (u.t === 'kw' && d === 0) {
                if (u.v === 'if') ifs++;
                else if (u.v === 'else') { if (ifs === 0) return true; ifs--; }
                else if (u.v === 'for') return false;
            }
        }
        return false;
    }
    pipe() {
        let l = this.coalesce();
        while (this.isOp('|>')) {
            const t = this.next();
            const r = this.coalesce();
            l = this.node('Pipe', t, { l, r });
        }
        return l;
    }
    coalesce() {
        let l = this.or();
        while (this.isOp('??')) { const t = this.next(); const r = this.or(); l = this.node('Coalesce', t, { l, r }); }
        return l;
    }
    or() {
        let l = this.and();
        while (this.isKw('or')) { const t = this.next(); l = this.node('Or', t, { l, r: this.and() }); }
        return l;
    }
    and() {
        let l = this.not();
        while (this.isKw('and')) { const t = this.next(); l = this.node('And', t, { l, r: this.not() }); }
        return l;
    }
    not() {
        if (this.isKw('not') || this.isOp('!')) { const t = this.next(); return this.node('Not', t, { e: this.not() }); }
        return this.cmp();
    }
    cmp() {
        let l = this.range();
        for (;;) {
            const t = this.tok;
            if (t.t === 'op' && ['==', '!=', '<', '<=', '>', '>='].includes(t.v)) { this.p++; l = this.node('Bin', t, { op: t.v, l, r: this.range() }); }
            else if (this.isKw('in')) { this.p++; l = this.node('In', t, { l, r: this.range(), neg: false }); }
            else if (this.isKw('not') && this.isKw('in', 1)) { this.p += 2; l = this.node('In', t, { l, r: this.range(), neg: true }); }
            else if (this.isKw('is')) {
                this.p++;
                const neg = this.eatKw('not');
                const pat = this.isTypeStart() ? { type: this.parseType() } : { value: this.range() };
                l = this.node('Is', t, Object.assign({ e: l, neg }, pat));
            } else break;
        }
        return l;
    }
    isTypeStart() {
        const t = this.tok;
        if (t.t === 'kw' && t.v === 'none') return true;
        if (t.t === 'id' && !(this.peek(1).t === 'op' && this.peek(1).v === '(')) return true;
        return false;
    }
    endsRange() {
        const t = this.tok;
        if (t.t === 'eof' || (t.nl && this.ign === 0)) return true;
        return t.t === 'op' && [']', ')', ',', '}', ':', ';', '{', '=>'].includes(t.v) || (t.t === 'kw' && ['by', 'in', 'if'].includes(t.v));
    }
    range() {
        const t = this.tok;
        if (t.t === 'op' && (t.v === '..' || t.v === '..=')) {
            this.p++;
            return this.node('Range', t, { a: null, b: this.endsRange() ? null : this.add(), incl: t.v === '..=' });
        }
        let l = this.add();
        if (this.isOp('..') || this.isOp('..=')) {
            const o = this.next();
            const r = this.endsRange() ? null : this.add();
            l = this.node('Range', o, { a: l, b: r, incl: o.v === '..=' });
        }
        return l;
    }
    add() {
        let l = this.mul();
        while ((this.isOp('+') || this.isOp('-')) && !(this.tok.nl && this.ign === 0)) { const t = this.next(); l = this.node('Bin', t, { op: t.v, l, r: this.mul() }); }
        return l;
    }
    mul() {
        let l = this.unary();
        while ((this.isOp('*') || this.isOp('/') || this.isOp('%')) && !(this.tok.nl && this.ign === 0)) { const t = this.next(); l = this.node('Bin', t, { op: t.v, l, r: this.unary() }); }
        return l;
    }
    unary() {
        if (this.isKw('await')) return this.keywordExpr(this.tok);
        if (this.isOp('-')) { const t = this.next(); return this.node('Neg', t, { e: this.unary() }); }
        if (this.isOp('+')) { this.p++; return this.unary(); }
        return this.pow();
    }
    pow() {
        const b = this.postfix();
        if (this.isOp('**') && !(this.tok.nl && this.ign === 0)) { const t = this.next(); return this.node('Bin', t, { op: '**', l: b, r: this.unary() }); }
        return b;
    }
    args() {
        const args = [];
        while (!this.isOp(')')) {
            const t = this.tok;
            if (this.eatOp('*')) args.push({ spread: true, v: this.expr() });
            else if (t.t === 'id' && this.isOp(':', 1) && !(this.peek(2).t === 'op' && this.peek(2).v === ':')) { this.p += 2; args.push({ name: t.v, v: this.expr() }); }
            else if (t.t === 'id' && this.isOp('=', 1)) { this.p += 2; args.push({ name: t.v, v: this.expr() }); }          // Python style: f(size=3)
            else {
                const v = this.expr();
                if (this.isKw('for') && !args.length) { const clauses = this.compClauses(); args.push({ v: this.node('Comp', t, { kind: 'list', elt: v, clauses }) }); }   // sum(x * x for x in xs)
                else args.push({ v });
            }
            if (!this.eatOp(',')) break;
        }
        return args;
    }
    postfix() {
        let e = this.primary();
        let inOpt = false;   // after a ?. the rest of the chain gives none instead of failing
        for (;;) {
            const t = this.tok;
            if (t.t !== 'op') break;
            const nlBreak = t.nl && this.ign === 0;
            if (t.v === '(' && !nlBreak) {
                this.p++;
                const args = this.withIgn(1, () => { const a = this.args(); this.expectOp(')', 'to close the call'); return a; });
                // a call followed by a colon block:  task("build"):  ...lines...   passes the block as a function called run
                if (!this.stopBlock && this.isOp('{') && this.tok.gen) {
                    const bt = this.tok; this.asyncCtx.push(false);
                    let body; try { body = this.block(); } finally { this.asyncCtx.pop(); }
                    args.push({ name: 'run', v: this.node('Fn', bt, { name: null, params: [], body, ret: null, lambda: true, bodyless: false, async: false }) });
                }
                e = this.node('Call', t, { f: e, args, opt: inOpt });
            } else if (t.v === '[' && !nlBreak) {
                this.p++;
                const i = this.withIgn(1, () => {
                    // Python style slices: xs[1:3], xs[:2], xs[2:]  (the same as xs[1..3], xs[..2], xs[2..])
                    if (this.isOp(':')) { const c = this.next(); const b = this.isOp(']') ? null : this.expr(); this.expectOp(']'); return this.node('Range', c, { a: null, b, incl: false }); }
                    const x = this.expr();
                    if (this.isOp(':')) { const c = this.next(); const b = this.isOp(']') ? null : this.expr(); this.expectOp(']'); return this.node('Range', c, { a: x, b, incl: false }); }
                    this.expectOp(']'); return x;
                });
                e = this.node('Index', t, { o: e, i, opt: inOpt });
            } else if (t.v === '.' || t.v === '?.') {
                this.p++;
                const nt = this.next();
                if (t.v === '?.') inOpt = true;
                if (nt.t === 'num') e = this.node('Member', t, { o: e, name: String(nt.v), opt: inOpt, index: true });
                else if (nt.t === 'id' || nt.t === 'kw') e = this.node('Member', t, { o: e, name: nt.v, opt: inOpt });
                else if (nt.t === 'op' && nt.v === '(' && false) { /* unused */ }
                else this.err('Expected a name after the dot but found ' + this.describe(nt), nt);
                if (t.v === '?.' && this.isOp('[')) { /* x?.[i] not supported */ }
            } else if (t.v === '?' && !nlBreak) {
                // postfix try: value? returns early on Err or none
                const nx = this.peek(1);
                if (nx.t === 'op' && (nx.v === '.' || nx.v === '?')) { this.p++; e = this.node('Try', t, { e }); continue; }
                this.p++; e = this.node('Try', t, { e });
            } else break;
        }
        return e;
    }
    strNode(t) {
        if (t.parts.every((p) => typeof p === 'string')) return { t: 'Str', v: t.parts.join(''), line: t.line };
        const parts = t.parts.map((p) => {
            if (typeof p === 'string') return p;
            const sub = new Parser(lex(p.src, this.file, p.line - 1), this.file);
            sub.asyncCtx = this.asyncCtx.slice();
            const e = sub.withIgn(1, () => sub.expr());
            if (sub.tok.t !== 'eof') sub.err('Something extra inside { } of a string: ' + sub.describe(sub.tok));
            return { e, spec: p.spec };
        });
        return { t: 'Interp', parts, line: t.line };
    }
    primary() {
        const t = this.tok;
        switch (t.t) {
            case 'num': this.p++; return this.node('Num', t, { v: t.v });
            case 'big': this.p++; return this.node('Big', t, { v: t.v });
            case 'imag': this.p++; return this.node('Imag', t, { v: t.v });
            case 'str': this.p++; return this.strNode(t);
            case 'sym': this.p++; return this.node('Sym', t, { name: t.v });
            case 'id': this.p++; return this.node('Id', t, { name: t.v });
            case 'kw': return this.keywordExpr(t);
            case 'op': return this.opExpr(t);
        }
        this.err('I did not expect ' + this.describe(t) + ' here');
    }
    keywordExpr(t) {
        switch (t.v) {
            case 'true': this.p++; return this.node('Bool', t, { v: true });
            case 'false': this.p++; return this.node('Bool', t, { v: false });
            case 'none': this.p++; return this.node('None', t, {});
            case 'async': {
                { const nx = this.peek(1); if (!((nx.t === 'kw' && nx.v === 'fn') || (nx.t === 'op' && ['|', '||', '{'].includes(nx.v)))) { this.p++; return this.node('Id', t, { name: 'async' }); } }   // the module name: async.all(...)
                this.p++;
                if (this.isKw('fn')) { const kw = this.next(); if (this.tok.t === 'id') this.err('A named function is a statement. Write async fn name(...) on its own line'); this.pendingAsync = true; const f = this.fnRest(kw, null); f.lambda = true; return f; }
                if (this.isOp('|') || this.isOp('||')) { this.pendingAsync = true; return this.lambda(); }
                if (this.isOp('{')) {
                    // async { ... } runs the block as an async function and gives back its future
                    this.asyncCtx.push(true);
                    let body;
                    try { body = this.block(); } finally { this.asyncCtx.pop(); }
                    const fn = this.node('Fn', t, { name: null, params: [], body, ret: null, lambda: true, bodyless: false, async: true });
                    return this.node('Call', t, { f: fn, args: [] });
                }
                this.err('After async I expected fn, a lambda like |x| ..., or a { block }');
            }
            case 'await': {
                if (!this.asyncCtx[this.asyncCtx.length - 1]) this.err('await can only be used inside an async function (or at the top of a program). Write async fn name() { ... }');
                this.p++;
                return this.node('Await', t, { e: this.unary() });
            }
            case 'pool': {
                // pool [1, 2, 3] / pool 1..=6 / pool {heads: 1, tails: 1}: a value decided when it is first used.
                // Used as a plain name (pool.new(...), pool(...)) it is the pool module or function.
                const nx = this.peek(1);
                const startsOperand = !nx.nl && ((nx.t === 'op' && ['[', '{', '|', '||', '..', '..=', '#{'].includes(nx.v)) || nx.t === 'num' || nx.t === 'str' || nx.t === 'id' || (nx.t === 'op' && nx.v === '(' && nx.col > t.col + 4) || (nx.t === 'kw' && ['true', 'false', 'none', 'if', 'match'].includes(nx.v)));
                this.p++;
                if (!startsOperand) return this.node('Id', t, { name: 'pool' });
                // pool [1, 2, 3] / pool 1..=6 / pool xs: the pool takes just the next value, so pool [1, 2].where(...) asks the pool
                let e;
                if (this.isOp('-')) { const m = this.next(); e = this.node('Neg', m, { e: this.primary() }); } else e = this.primary();
                if (this.isOp('..') || this.isOp('..=')) { const o = this.next(); const r = this.endsRange() ? null : this.add(); e = this.node('Range', o, { a: e, b: r, incl: o.v === '..=' }); }
                return this.node('Pool', t, { e });
            }
            case 'if': return this.ifExpr();
            case 'match': return this.matchExpr();
            case 'fn': {
                this.p++;
                if (this.tok.t === 'id') this.err('A named function is a statement. Use fn name(...) on its own line, or a lambda like |x| x');
                const f = this.fnRest(t, null);
                f.lambda = true;
                return f;
            }
            case 'lambda': {
                this.p++;
                const params = this.withIgn(1, () => {
                    const ps = [];
                    while (!this.isOp(':')) {
                        const pat = this.pattern(true);
                        const def = this.eatOp('=') ? this.coalesce() : null;
                        ps.push({ pat, name: pat.t === 'PBind' ? pat.name : null, type: null, def });
                        if (!this.eatOp(',')) break;
                    }
                    return ps;
                });
                this.expectOp(':', 'after the lambda parameters');
                const body = this.expr();
                return this.node('Fn', t, { name: null, params, body, ret: null, lambda: true, bodyless: false, async: false });
            }
            case 'for': return this.forExpr();
            case 'while': { this.p++; const c = this.noBlock(() => this.expr()); return this.node('While', t, { c, body: this.block() }); }
            case 'loop': { this.p++; return this.node('Loop', t, { body: this.block() }); }
            case 'try': return this.tryExpr();
            case 'return': case 'break': case 'continue': case 'throw': return this.statement();
            case 'let': case 'var': this.err('A "' + t.v + '" cannot be used inside an expression. Put it on its own line');
        }
        this.err('I did not expect "' + t.v + '" here');
    }
    noBlock(fn) { this.stopBlock = (this.stopBlock || 0) + 1; try { return fn(); } finally { this.stopBlock--; } }
    ifExpr() {
        const t = this.next();
        const c = this.noBlock(() => this.expr());
        const th = this.block();
        let el = null;
        if (this.isKw('else')) {
            this.p++;
            el = this.isKw('if') ? this.ifExpr() : this.block();
        } else if (this.tok.nl && this.ign === 0 && this.isKw('else')) { /* unreachable */ }
        return this.node('If', t, { c, th, el });
    }
    matchExpr() {
        const t = this.next();
        const e = this.noBlock(() => this.expr());
        this.expectOp('{');
        const arms = this.withIgn(0, () => {
            const out = [];
            this.skipSemis();
            while (!this.isOp('}')) {
                const at = this.tok;
                if (this.tok.t === 'id' && this.tok.v === 'case' && !this.isOp('=>', 1) && !this.isKw('if', 1)) this.p++;   // Python style: case pattern:
                const pat = this.pattern();
                let guard = null;
                if (this.eatKw('if')) guard = this.noBlock(() => this.expr());
                let body;
                if (this.isOp('{') && this.tok.gen) body = this.block();
                else { this.expectOp('=>', 'after the pattern'); body = this.isOp('{') && !this.looksLikeMap() ? this.block() : this.expr(); }
                out.push({ pat, guard, body, line: at.line });
                if (!this.eatOp(',')) { if (!this.tok.nl && !this.isOp('}')) this.err('Put a comma or a new line between match arms'); }
                this.skipSemis();
            }
            this.p++;
            return out;
        });
        return this.node('Match', t, { e, arms });
    }
    forExpr() {
        const t = this.next();
        let pat = this.pattern(true);
        if (this.isOp(',')) {                                   // Python style: for key, value in pairs:
            const items = [pat];
            while (this.eatOp(',')) items.push(this.pattern(true));
            pat = this.node('PList', t, { items, rest: null, restAt: -1, tuple: true });
        }
        this.expectKw('in');
        const iter = this.noBlock(() => this.expr());
        return this.node('For', t, { pat, iter, body: this.block() });
    }
    tryExpr() {
        const t = this.next();
        const body = this.block();
        let param = null, handler = null, fin = null;
        if (this.eatKw('catch')) {
            if (this.tok.t === 'id' && this.isKw('as', 1)) this.p += 2;          // except SomeError as e:  (the error type is not needed)
            // catch e { }, catch [a, b] { }, or catch {code} { } (a map pattern is told from the block by the { that follows it)
            let isPat = !this.isOp('{');
            if (!isPat) { let d = 0, k = this.p; do { if (this.toks[k].t === 'op' && this.toks[k].v === '{') d++; else if (this.toks[k].t === 'op' && this.toks[k].v === '}') d--; k++; } while (d > 0 && this.toks[k] && this.toks[k].t !== 'eof'); isPat = this.toks[k] && this.toks[k].t === 'op' && this.toks[k].v === '{'; }
            if (isPat) param = this.pattern(true);
            handler = this.block();
        }
        if (this.eatKw('finally')) fin = this.block();
        if (!handler && !fin) this.err('A try needs a catch { } or a finally { }', t);
        return this.node('TryCatch', t, { body, param, handler, fin });
    }
    lambda() {
        const isAsync = this.pendingAsync; this.pendingAsync = false;
        this.asyncCtx.push(isAsync);
        try { return this.lambda2(isAsync); } finally { this.asyncCtx.pop(); }
    }
    lambda2(isAsync) {
        const t = this.tok;
        let params = [];
        if (this.isOp('||')) this.p++;
        else {
            this.p++;
            params = this.withIgn(1, () => { const ps = this.params('|', true); this.expectOp('|', 'to close the lambda parameters'); return ps; });
        }
        let body;
        if (this.isOp('{') && !this.looksLikeMap()) body = this.block(); else body = this.expr();
        return this.node('Fn', t, { name: null, params, body, ret: null, lambda: true, bodyless: false, async: isAsync });
    }
    opExpr(t) {
        switch (t.v) {
            case '(': {
                this.p++;
                return this.withIgn(1, () => {
                    if (this.eatOp(')')) return this.node('Tuple', t, { items: [] });
                    const first = this.itemOrSpread();
                    if (this.isOp(')')) { this.p++; if (first.spread) return this.node('Tuple', t, { items: [first] }); return this.node('Group', t, { e: first }); }
                    const items = [first];
                    while (this.eatOp(',')) { if (this.isOp(')')) break; items.push(this.itemOrSpread()); }
                    this.expectOp(')', 'to close the group');
                    return this.node('Tuple', t, { items });
                });
            }
            case '[': {
                this.p++;
                return this.withIgn(1, () => {
                    if (this.eatOp(']')) return this.node('List', t, { items: [] });
                    const first = this.itemOrSpread();
                    if (this.isKw('for')) {
                        const clauses = this.compClauses();
                        this.expectOp(']');
                        return this.node('Comp', t, { kind: 'list', elt: first, clauses });
                    }
                    const items = [first];
                    while (this.eatOp(',')) { if (this.isOp(']')) break; items.push(this.itemOrSpread()); }
                    this.expectOp(']', 'to close the list');
                    return this.node('List', t, { items });
                });
            }
            case '#{': {
                this.p++;
                return this.withIgn(1, () => {
                    if (this.eatOp('}')) return this.node('Set', t, { items: [] });
                    const first = this.itemOrSpread();
                    if (this.isKw('for')) { const clauses = this.compClauses(); this.expectOp('}'); return this.node('Comp', t, { kind: 'set', elt: first, clauses }); }
                    const items = [first];
                    while (this.eatOp(',')) { if (this.isOp('}')) break; items.push(this.itemOrSpread()); }
                    this.expectOp('}', 'to close the set');
                    return this.node('Set', t, { items });
                });
            }
            case '{': return this.mapLiteral();
            case '|': case '||': return this.lambda();
        }
        this.err('I did not expect ' + this.describe(t) + ' here');
    }
    itemOrSpread() {
        if (this.isOp('*')) { const t = this.next(); return { spread: true, e: this.expr(), line: t.line }; }
        return this.expr();
    }
    compClauses() {
        const clauses = [];
        for (;;) {
            if (this.eatKw('for')) { const pat = this.pattern(true); this.expectKw('in'); clauses.push({ pat, iter: this.or() }); }
            else if (this.eatKw('if')) clauses.push({ cond: this.or() });
            else break;
        }
        return clauses;
    }
    mapLiteral() {
        const t = this.next();
        return this.withIgn(1, () => {
            const entries = [];
            if (this.eatOp('}')) return this.node('Map', t, { entries });
            let first = true;
            while (!this.isOp('}')) {
                const kt = this.tok;
                let entry;
                if (this.isOp('*')) { this.p++; entry = { spread: this.expr() }; }
                else {
                    let key;
                    if (kt.t === 'kw' && this.isOp(':', 1) && !(this.peek(2).t === 'op' && this.peek(2).v === ':')) { this.p += 2; entry = { k: { t: 'Str', v: kt.v, line: kt.line }, v: this.expr() }; }
                    else if (kt.t === 'id' && (this.isOp(':', 1) || this.isOp(',', 1) || this.isOp('}', 1)) && !(this.isOp(':', 1) && this.peek(2).t === 'op' && this.peek(2).v === ':')) {
                        this.p++;
                        key = { t: 'Str', v: kt.v, line: kt.line, bare: kt.v };
                        if (!this.isOp(':')) { entry = { k: key, v: { t: 'Id', name: kt.v, line: kt.line } }; }
                    } else if (this.isOp('[') ) { this.p++; key = this.expr(); this.expectOp(']'); }
                    else key = this.expr();
                    if (!entry) { this.expectOp(':', 'after the map key'); entry = { k: key, v: this.expr() }; }
                }
                if (first && this.isKw('for')) {
                    const clauses = this.compClauses();
                    this.expectOp('}');
                    if (entry.k && entry.k.bare) entry = { k: { t: 'Id', name: entry.k.bare, line: entry.k.line }, v: entry.v };
                    return this.node('Comp', t, { kind: 'map', elt: entry, clauses });
                }
                first = false;
                entries.push(entry);
                if (!this.eatOp(',')) break;
            }
            this.expectOp('}', 'to close the map');
            return this.node('Map', t, { entries });
        });
    }
}

export function parse(src, file) {
    const toks = lex(src, file);
    return new Parser(toks, file).program();
}
export function parseExpression(src, file) {
    const p = new Parser(lex(src, file), file);
    const e = p.expr();
    if (p.tok.t !== 'eof') p.err('Something extra after the expression: ' + p.describe(p.tok));
    return e;
}
export { Parser, SuaveSyntaxError };
