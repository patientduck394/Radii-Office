/* Suave interpreter: compiles the syntax tree into JavaScript closures and runs them. */
import rt from './runtime.js';
import { parse } from './parser.js';
import * as CX from './complexmath.js';

const { Sym, sym, Tuple, tuple, SRange, SIter, SMap, SSet, SType, SObj, SVariant, VariantCtor, SFn, Bound, SModule, Named, ResultT, ok, err, Brk, Cont, Ret,
    SuaveError, rtError, errValue, Env, typeOf, eq, cmp, truthy, repr, show, formatSpec, iterate, toArray, state, SComplex, SPool } = rt;

// the standard pieces plug in here (set by index.js)
export const hooks = { methodsFor: null, stdlib: null, builtins: null, findPackage: null };
const userExt = new Map();   // impl str { ... }  -> methods added to built-in types

const line = (n) => { state.line = n.line; };

// ---------- calling ----------
function settleArgs(args) { for (let i = 0; i < args.length; i++) if (args[i] instanceof SPool) args[i] = args[i].decide(); return args; }
// ---------- partial functions: f with some values filled in now and the rest later ----------
// partial(add, 1)   add(1, _)   add(_, 2)   partial_right(sub, 1)   -- "_" marks a hole that a later value fills!
export const HOLE = Object.freeze({ suaveHole: true });
export const isHole = (x) => x === HOLE;
export function makePartial(f, slots, preNamed, right) {
    if (!(typeof f === 'function' || f instanceof SFn || f instanceof Bound || f instanceof VariantCtor || f instanceof SType)) throw rtError('partial needs a function but got a ' + typeOf(f), 'TypeError');
    const holes = slots.filter(isHole).length;
    const fn = (...later) => {
        let named = preNamed ? Object.assign({}, preNamed) : null;
        if (later.length && later[later.length - 1] instanceof Named) { named = Object.assign(named || {}, later.pop().obj); }
        if (later.length < holes) throw rtError('This partial function still needs ' + (holes - later.length) + ' more value' + (holes - later.length === 1 ? '' : 's') + ' (it was given ' + later.length + ')', 'ArgError');
        let k = 0;
        const filled = slots.map((x) => (isHole(x) ? later[k++] : x));
        const rest = later.slice(k);
        return call(f, right ? rest.concat(filled) : filled.concat(rest), named);
    };
    fn.partialOf = f; fn.partialSlots = slots; fn.partialNamed = preNamed || null; fn.partialRight = !!right;
    return fn;
}
export function call(f, args, named) {
    if (f instanceof SFn) return callFn(f, args, named, null);
    if (typeof f === 'function') { if (!f.keepPools) settleArgs(args); if (named) args.push(new Named(named)); return f.apply(null, args); }
    if (f instanceof SPool) return call(f.decide(), args, named);
    if (f instanceof Bound) return f.fn instanceof SFn ? callFn(f.fn, args, named, f.self) : (typeof f.fn === 'function' ? f.fn(f.self, args, named) : call(f.fn, [f.self].concat(args), named));
    if (f instanceof SType) return construct(f, args, named);
    if (f instanceof VariantCtor) return makeVariant(f, args, named);
    throw rtError('A ' + typeOf(f) + ' cannot be called like a function', 'TypeError');
}
function makeVariant(c, args, named) {
    const fs = c.v.fields;
    if (named) { args = args.slice(); for (const k of Object.keys(named)) { const i = fs.indexOf(k); if (i < 0) throw rtError(c.v.name + ' has no field "' + k + '"'); args[i] = named[k]; } }
    if (args.length !== fs.length) throw rtError(c.type.name + '.' + c.v.name + ' needs ' + fs.length + ' value' + (fs.length === 1 ? '' : 's') + ' but got ' + args.length, 'ArgError');
    return new SVariant(c.type, c.v, args);
}
function construct(T, args, named) {
    if (T.kind === 'enum') throw rtError('Pick a variant of ' + T.name + ' like ' + T.name + '.' + (T.variants.keys().next().value || 'Variant'));
    const f = Object.create(null);
    const fields = T.fields;
    if (args.length > fields.length) throw rtError(T.name + ' has ' + fields.length + ' field' + (fields.length === 1 ? '' : 's') + ' but got ' + args.length + ' values', 'ArgError');
    for (let i = 0; i < fields.length; i++) {
        const fd = fields[i];
        let v;
        if (i < args.length) v = args[i];
        else if (named && Object.prototype.hasOwnProperty.call(named, fd.name)) v = named[fd.name];
        else if (fd.def) v = fd.def(T.env);
        else throw rtError(T.name + ' needs a value for "' + fd.name + '"', 'ArgError');
        if (fd.type && !typeMatches(fd.type, v, T.env)) throw rtError(T.name + '.' + fd.name + ' should be ' + typeName(fd.type) + ' but got ' + typeOf(v), 'TypeError');
        f[fd.name] = v;
    }
    if (named) for (const k of Object.keys(named)) if (!fields.some((fd) => fd.name === k)) throw rtError(T.name + ' has no field "' + k + '"', 'ArgError');
    return new SObj(T, f);
}
function callFn(f, args, named, self) {
    const env = new Env(f.env);
    const ps = f.params;
    let ai = 0;
    if (self !== null) { env.vars.set('self', self); }
    for (let i = 0; i < ps.length; i++) {
        const p = ps[i];
        if (p.self) continue;
        if (p.rest) { env.def(p.name, args.slice(ai), true); ai = args.length; continue; }
        let v;
        if (ai < args.length) v = args[ai++];
        else if (named && p.name !== null && Object.prototype.hasOwnProperty.call(named, p.name)) v = named[p.name];
        else if (p.def) v = p.def(env);
        else throw rtError((f.name || 'This function') + ' needs a value for "' + (p.name || 'argument ' + (i + 1)) + '"', 'ArgError');
        if (p.type && !typeMatches(p.type, v, f.env)) throw rtError((f.name || 'lambda') + ': "' + p.name + '" should be ' + typeName(p.type) + ' but got ' + typeOf(v) + ' (' + repr(v) + ')', 'TypeError');
        if (p.pat) p.pat(v, env, false); else env.vars.set(p.name, v === undefined ? null : v);
    }
    if (ai < args.length && !f.isLambda) throw rtError((f.name || 'This function') + ' takes ' + ps.filter((p) => !p.self).length + ' value' + (ps.length === 1 ? '' : 's') + ' but got ' + args.length, 'ArgError');
    if (named) for (const k of Object.keys(named)) if (!ps.some((p) => p.name === k)) throw rtError((f.name || 'This function') + ' has no parameter "' + k + '"', 'ArgError');
    if (f.isAsync) return runAsync(f.bodyG(env));
    if (++state.depth > state.maxDepth) { state.depth = 0; throw rtError('The program called itself too deeply (stack overflow)', 'StackOverflow'); }
    state.stack.push(f); state.lines.push(state.line);
    let r;
    try { r = f.body(env); }
    catch (e) { if (e instanceof Ret) r = e.v; else throw e; }
    finally { state.depth--; state.stack.pop(); state.lines.pop(); }
    if (f.ret && !typeMatches(f.ret, r, f.env)) throw rtError((f.name || 'lambda') + ' should give back ' + typeName(f.ret) + ' but gave ' + typeOf(r), 'TypeError');
    return r === undefined ? null : r;
}

// ---------- types ----------
function typeName(t) {
    if (t.t === 'union') return t.items.map(typeName).join(' or ');
    return t.name + (t.args && t.args.length ? '<' + t.args.map(typeName).join(', ') + '>' : '');
}
export function typeMatches(t, v, env) {
    if (v instanceof SPool && !(t.t === 'name' && (t.name === 'pool' || t.name === 'any'))) v = v.decide();
    if (t.t === 'union') return t.items.some((x) => typeMatches(x, v, env));
    const nm = t.name.includes('.') ? t.name.split('.').pop() : t.name;
    switch (nm) {
        case 'any': return true;
        case 'int': return typeof v === 'number' && Number.isInteger(v);
        case 'float': case 'num': case 'number': return typeof v === 'number';
        case 'str': case 'string': return typeof v === 'string';
        case 'bool': return typeof v === 'boolean';
        case 'bigint': return typeof v === 'bigint';
        case 'none': case 'null': return v === null || v === undefined;
        case 'list': return Array.isArray(v) && !(v instanceof Tuple) && (!t.args.length || v.every((x) => typeMatches(t.args[0], x, env)));
        case 'tuple': return v instanceof Tuple;
        case 'map': return v instanceof SMap && (!t.args.length || v.values().every((x) => typeMatches(t.args[t.args.length - 1], x, env)));
        case 'set': return v instanceof SSet;
        case 'sym': return v instanceof Sym;
        case 'range': return v instanceof SRange;
        case 'fn': return typeof v === 'function' || v instanceof SFn || v instanceof Bound || v instanceof VariantCtor || v instanceof SType;
        case 'Result': return v instanceof SVariant && v.type === ResultT;
        case 'iter': return v instanceof SIter;
        case 'complex': return v instanceof SComplex;
        case 'pool': return v instanceof SPool;
    }
    const T = env && env.lookup(nm);
    if (T instanceof SType) {
        if (T.kind === 'trait') return (v instanceof SObj || v instanceof SVariant) && v.type.traits.has(T.name);
        return (v instanceof SObj || v instanceof SVariant) && v.type === T;
    }
    return true;   // an unknown name is not checked
}

// a method can be a Suave function or a native one (self, args, named)
export function invoke(m, self, args, named) {
    if (m instanceof SFn) return callFn(m, args, named || null, self);
    return m(self, settleArgs(args), named || null);
}

// ---------- members and methods ----------
function didYouMean(name, options) {
    let best = null, bd = 3;
    for (const o of options) { const d = lev(name, o); if (d < bd) { bd = d; best = o; } }
    return best ? '. Did you mean "' + best + '"?' : '';
}
function lev(a, b) {
    if (Math.abs(a.length - b.length) > 3) return 9;
    const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) dp[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return dp[a.length][b.length];
}
const KIND_OF = (o) => {
    switch (typeof o) { case 'string': return 'str'; case 'number': return 'num'; case 'boolean': return 'bool'; case 'bigint': return 'bigint'; case 'function': return 'fn'; }
    if (o instanceof Tuple) return 'tuple';
    if (Array.isArray(o)) return 'list';
    if (o instanceof SMap) return 'map';
    if (o instanceof SSet) return 'set';
    if (o instanceof SRange) return 'range';
    if (o instanceof SIter) return 'iter';
    if (o instanceof Sym) return 'sym';
    if (o instanceof SFn || o instanceof Bound) return 'fn';
    if (o instanceof Date) return 'datetime';
    if (o instanceof Uint8Array) return 'bytes';
    if (o instanceof SComplex) return 'complex';
    if (o instanceof Promise) return 'future';
    if (o instanceof SVariant && o.type === ResultT) return 'result';
    return null;
};
function builtinMethod(o, name) {
    const k = KIND_OF(o);
    if (!k) return null;
    const table = hooks.methodsFor(k);
    let m = table && table[name];
    if (!m) { const u = userExt.get(k); if (u && u.has(name)) m = u.get(name); }
    if (!m && userExt.has('any') && userExt.get('any').has(name)) m = userExt.get('any').get(name);
    return m || null;
}
function getMember(o, name, n) {
    if (o instanceof SPool) {
        const pm = hooks.methodsFor('pool')[name];
        if (pm) return new Bound(o, pm, name);
        o = o.decide();
    }
    if (o === null || o === undefined) throw rtError('Cannot read ".' + name + '" of none. Use ?. if it may be missing', 'TypeError');
    if (o instanceof SObj) {
        const v = o.f[name];
        if (v !== undefined) return v;
        const m = o.type.methods.get(name);
        if (m) return new Bound(o, m, name);
        throw rtError(o.type.name + ' has no "' + name + '"' + didYouMean(name, Object.keys(o.f).concat(Array.from(o.type.methods.keys()))), 'NameError');
    }
    if (o instanceof SMap) {
        const v = o.get(name);
        if (v !== undefined) return v;
        const bm = builtinMethod(o, name);
        if (bm) return new Bound(o, bm, name);
        return null;
    }
    if (o instanceof SModule) {
        const v = o.exports[name];
        if (v === undefined) throw rtError('Module ' + o.name + ' has no "' + name + '"' + didYouMean(name, Object.keys(o.exports)), 'NameError');
        return v;
    }
    if (o instanceof SType) {
        if (o.variants.size && o.variants.has(name)) { const v = o.variants.get(name); return v.fields.length ? new VariantCtor(o, v) : (v.unit || (v.unit = new SVariant(o, v, []))); }
        if (o.statics.has(name)) return o.statics.get(name);
        if (o.consts.has(name)) return o.consts.get(name);
        if (name === 'name') return o.name;
        if (o.methods.has(name)) return o.methods.get(name);
        throw rtError(o.name + ' has no "' + name + '"' + didYouMean(name, Array.from(o.statics.keys()).concat(Array.from(o.variants.keys()))), 'NameError');
    }
    if (o instanceof SVariant) {
        if (name === 'name') return o.v.name;
        if (name === 'value' && o.v.val !== undefined) return o.v.val;
        const fi = o.v.fields.indexOf(name);
        if (fi >= 0) return o.vals[fi];
        const m = o.type.methods.get(name);
        if (m) return new Bound(o, m, name);
        const bm = o.type === ResultT && builtinMethod(o, name);
        if (bm) return new Bound(o, bm, name);
        throw rtError(o.type.name + '.' + o.v.name + ' has no "' + name + '"', 'NameError');
    }
    if (o instanceof SComplex && (name === 're' || name === 'im')) return o[name];
    if (Array.isArray(o) && /^\d+$/.test(name)) { const v = o[+name]; if (v === undefined) throw rtError('Index ' + name + ' is out of range (size ' + o.length + ')', 'IndexError'); return v; }
    const bm = builtinMethod(o, name);
    if (bm) return new Bound(o, bm, name);
    if (o instanceof Sym && name === 'name') return o.name;
    if (typeof o === 'number' || typeof o === 'string') throw rtError('A ' + typeOf(o) + ' has no "' + name + '"' + didYouMean(name, Object.keys(hooks.methodsFor(KIND_OF(o)) || {})), 'NameError');
    throw rtError('A ' + typeOf(o) + ' has no "' + name + '"', 'NameError');
}
export function callMethod(o, name, args, named, opt) {
    if (o instanceof SPool) {
        const pm = hooks.methodsFor('pool')[name];
        if (pm) return pm(o, args, named || null);
        o = o.decide();
    }
    if (o === null || o === undefined) {
        if (opt) return null;
        throw rtError('Cannot call .' + name + '() on none. Use ?. if it may be missing', 'TypeError');
    }
    if (o instanceof SObj) {
        const m = o.type.methods.get(name);
        if (m) return invoke(m, o, args, named);
        const fv = o.f[name];
        if (fv !== undefined) return call(fv, args, named);
        const bm = builtinObjMethod(o, name);
        if (bm) return bm(o, args, named);
        throw rtError(o.type.name + ' has no method "' + name + '"' + didYouMean(name, Array.from(o.type.methods.keys())), 'NameError');
    }
    if (o instanceof SModule || o instanceof SType) return call(getMember(o, name), args, named);
    if (o instanceof SVariant) {
        const m = o.type.methods.get(name);
        if (m) return invoke(m, o, args, named);
        const bm = builtinMethod(o, name);
        if (bm) return bm(o, args, named);
        const fv = getMember(o, name);
        return call(fv, args, named);
    }
    const bm = builtinMethod(o, name);
    if (bm) return bm(o, settleArgs(args), named);
    if (o instanceof SMap) { const v = o.get(name); if (v !== undefined) return call(v, args, named); }
    getMember(o, name);   // raises the helpful error (or returns a value that cannot be called)
    throw rtError('"' + name + '" cannot be called', 'TypeError');
}
function builtinObjMethod(o, name) {
    const t = hooks.methodsFor('object');
    return t && t[name] || null;
}

// ---------- operators ----------
function numOnly(op, a, b) {
    throw rtError('Cannot do ' + typeOf(a) + ' ' + op + ' ' + typeOf(b) + (op === '+' && (typeof a === 'string' || typeof b === 'string') ? '. Put values inside a string with {}, like "total: {x}"' : ''), 'TypeError');
}
const OPNAME = { '+': 'add', '-': 'sub', '*': 'mul', '/': 'div', '%': 'rem', '**': 'pow' };
function userOp(op, a, b) {
    const nm = OPNAME[op];
    if (a instanceof SObj || a instanceof SVariant) { const m = a.type.methods.get(nm); if (m) return [true, invoke(m, a, [b])]; }
    if (b instanceof SObj || b instanceof SVariant) { const m = b.type.methods.get('r' + nm); if (m) return [true, invoke(m, b, [a])]; }
    return [false];
}
export function binop(op, a, b) {
    if (a instanceof SPool) a = a.decide();
    if (b instanceof SPool) b = b.decide();
    if (a instanceof SComplex || b instanceof SComplex) {
        if (op === '==' ) return eq(a, b);
        if (op === '!=') return !eq(a, b);
        if ((a instanceof SComplex || typeof a === 'number' || typeof a === 'bigint') && (b instanceof SComplex || typeof b === 'number' || typeof b === 'bigint')) return CX.binop(op, a, b);
    }
    switch (op) {
        case '+':
            if (typeof a === 'number' && typeof b === 'number') return a + b;
            if (typeof a === 'string' && typeof b === 'string') return a + b;
            if (typeof a === 'bigint' && typeof b === 'bigint') return a + b;
            if (Array.isArray(a) && Array.isArray(b)) { const r = a.concat(b); return a instanceof Tuple ? tuple(r) : r; }
            if (a instanceof SMap && b instanceof SMap) { const r = new SMap(a.entries()); for (const [k, v] of b.entries()) r.set(k, v); return r; }
            if (a instanceof SSet && b instanceof SSet) return new SSet(a.values().concat(b.values()));
            { const u = userOp(op, a, b); if (u[0]) return u[1]; }
            return numOnly(op, a, b);
        case '-':
            if (typeof a === 'number' && typeof b === 'number') return a - b;
            if (typeof a === 'bigint' && typeof b === 'bigint') return a - b;
            if (a instanceof SSet && b instanceof SSet) return new SSet(a.values().filter((x) => !b.has(x)));
            { const u = userOp(op, a, b); if (u[0]) return u[1]; }
            return numOnly(op, a, b);
        case '*':
            if (typeof a === 'number' && typeof b === 'number') return a * b;
            if (typeof a === 'bigint' && typeof b === 'bigint') return a * b;
            if (typeof a === 'string' && typeof b === 'number') return a.repeat(Math.max(0, b));
            if (Array.isArray(a) && typeof b === 'number') { let r = []; for (let i = 0; i < b; i++) r = r.concat(a); return r; }
            { const u = userOp(op, a, b); if (u[0]) return u[1]; }
            return numOnly(op, a, b);
        case '/':
            if (typeof a === 'number' && typeof b === 'number') { if (b === 0) throw rtError('Cannot divide by zero', 'MathError'); return a / b; }
            if (typeof a === 'bigint' && typeof b === 'bigint') { if (b === 0n) throw rtError('Cannot divide by zero', 'MathError'); return a / b; }
            { const u = userOp(op, a, b); if (u[0]) return u[1]; }
            return numOnly(op, a, b);
        case '%':
            if (typeof a === 'number' && typeof b === 'number') { if (b === 0) throw rtError('Cannot take a remainder with zero', 'MathError'); const r = a % b; return r !== 0 && (r < 0) !== (b < 0) ? r + b : r; }
            if (typeof a === 'bigint' && typeof b === 'bigint') { if (b === 0n) throw rtError('Cannot take a remainder with zero', 'MathError'); const r = a % b; return r !== 0n && (r < 0n) !== (b < 0n) ? r + b : r; }
            { const u = userOp(op, a, b); if (u[0]) return u[1]; }
            return numOnly(op, a, b);
        case '**':
            if (typeof a === 'number' && typeof b === 'number') return Math.pow(a, b);
            if (typeof a === 'bigint' && typeof b === 'bigint') return a ** b;
            { const u = userOp(op, a, b); if (u[0]) return u[1]; }
            return numOnly(op, a, b);
        case '==': {
            if ((a instanceof SObj) && a.type.methods.has('eq')) return truthy(invoke(a.type.methods.get('eq'), a, [b]));
            return eq(a, b);
        }
        case '!=': return !binop('==', a, b);
        case '<': return ordered(a, b) < 0;
        case '<=': return ordered(a, b) <= 0;
        case '>': return ordered(a, b) > 0;
        case '>=': return ordered(a, b) >= 0;
    }
    throw rtError('Unknown operator ' + op);
}
function ordered(a, b) {
    if (a instanceof SPool) a = a.decide();
    if (b instanceof SPool) b = b.decide();
    if (typeof a === 'number' && typeof b === 'number') return a < b ? -1 : a > b ? 1 : 0;
    if (a instanceof SObj && a.type.methods.has('cmp')) return invoke(a.type.methods.get('cmp'), a, [b]);
    return cmp(a, b);
}
rt.cmp = function (a, b) { return ordered(a, b); };
function contains(coll, x) {
    if (coll instanceof SPool) coll = coll.decide();
    if (x instanceof SPool) x = x.decide();
    if (typeof coll === 'string') { if (typeof x !== 'string') throw rtError('Only text can be searched for inside text', 'TypeError'); return coll.includes(x); }
    if (Array.isArray(coll)) { for (const y of coll) if (eq(y, x)) return true; return false; }
    if (coll instanceof SMap) return coll.has(x);
    if (coll instanceof SSet) return coll.has(x);
    if (coll instanceof SRange) { if (typeof x !== 'number') return false; const { start, end, incl, step } = coll; if (step > 0) return x >= start && (end === null || (incl ? x <= end : x < end)) && (x - start) % step === 0; return x <= start && (incl ? x >= end : x > end) && (start - x) % -step === 0; }
    if (coll instanceof SObj && coll.type.methods.has('contains')) return truthy(invoke(coll.type.methods.get('contains'), coll, [x]));
    throw rtError('"in" does not work on a ' + typeOf(coll), 'TypeError');
}

// ---------- indexing ----------
function getIndex(o, i, n) {
    if (o instanceof SPool) o = o.decide();
    if (i instanceof SPool) i = i.decide();
    if (o === null || o === undefined) throw rtError('Cannot look inside none. Use ?? or an if first', 'TypeError');
    if (i instanceof SRange) return slice(o, i);
    if (Array.isArray(o) || typeof o === 'string') {
        if (typeof i !== 'number' || !Number.isInteger(i)) throw rtError('A list or text is indexed with a whole number, not ' + repr(i), 'TypeError');
        const len = o.length;
        const k = i < 0 ? len + i : i;
        if (k < 0 || k >= len) throw rtError('Index ' + i + ' is out of range (size ' + len + ')', 'IndexError');
        return o[k];
    }
    if (o instanceof SMap) { const v = o.get(i); return v === undefined ? null : v; }
    if (o instanceof SObj && o.type.methods.has('get')) return invoke(o.type.methods.get('get'), o, [i]);
    if (o instanceof SObj && typeof i === 'string' && o.f[i] !== undefined) return o.f[i];
    if (o instanceof Uint8Array) { const k = i < 0 ? o.length + i : i; if (k < 0 || k >= o.length) throw rtError('Index ' + i + ' is out of range', 'IndexError'); return o[k]; }
    if (o instanceof SRange) return toArray(o)[i < 0 ? o.size + i : i];
    throw rtError('A ' + typeOf(o) + ' cannot be indexed with []', 'TypeError');
}
export function slice(o, r) {
    const len = typeof o === 'string' || Array.isArray(o) || o instanceof Uint8Array ? o.length : null;
    if (len === null) throw rtError('Only lists, text and tuples can be cut with a range', 'TypeError');
    let a = r.start === null || r.start === undefined ? 0 : r.start, b = r.end === null ? len : (r.incl ? r.end + 1 : r.end);
    if (a < 0) a += len; if (b < 0) b += len;
    a = Math.max(0, Math.min(len, a)); b = Math.max(a, Math.min(len, b));
    const out = o.slice(a, b);
    return o instanceof Tuple ? tuple(out) : out;
}
function setIndex(o, i, v) {
    if (o instanceof SPool) o = o.decide();
    if (i instanceof SPool) i = i.decide();
    if (Array.isArray(o)) {
        if (o instanceof Tuple) throw rtError('A tuple cannot be changed. Make a new one or use a list', 'TypeError');
        if (typeof i !== 'number' || !Number.isInteger(i)) throw rtError('A list is indexed with a whole number', 'TypeError');
        const k = i < 0 ? o.length + i : i;
        if (k < 0 || k >= o.length) throw rtError('Index ' + i + ' is out of range (size ' + o.length + '). Use push to add', 'IndexError');
        o[k] = v; return;
    }
    if (o instanceof SMap) { o.set(i, v); return; }
    if (o instanceof SObj && o.type.methods.has('set')) { invoke(o.type.methods.get('set'), o, [i, v]); return; }
    if (o instanceof Uint8Array) { o[i] = v; return; }
    throw rtError('A ' + typeOf(o) + ' cannot be changed with []', 'TypeError');
}
function setMember(o, name, v) {
    if (o instanceof SPool) o = o.decide();
    if (o instanceof SObj) {
        if (!(name in o.f)) throw rtError(o.type.name + ' has no field "' + name + '"' + didYouMean(name, Object.keys(o.f)), 'NameError');
        const fd = o.type.fields.find((f) => f.name === name);
        if (fd && fd.type && !typeMatches(fd.type, v, o.type.env)) throw rtError(o.type.name + '.' + name + ' should be ' + typeName(fd.type) + ' but got ' + typeOf(v), 'TypeError');
        o.f[name] = v; return;
    }
    if (o instanceof SMap) { o.set(name, v); return; }
    throw rtError('Cannot set ".' + name + '" on a ' + typeOf(o), 'TypeError');
}

// pool [a, b, c]  (all equally likely)   pool {a: 3, b: 1}  (weighted)   pool || sampler()  (a function that gives a fresh value)
export function makePool(v, weights) {
    if (v instanceof SPool) return v;
    if (typeof v === 'function' || v instanceof SFn || v instanceof Bound) return new SPool(null, null, () => call(v, []));
    if (v instanceof SMap) {
        const ws = v.values();
        if (!ws.every((w) => typeof w === 'number' && w >= 0)) throw rtError('In pool {option: weight}, every weight must be a number that is not negative', 'PoolError');
        return new SPool(v.keys(), ws);
    }
    let options;
    if (v instanceof SRange) { if (v.end === null) throw rtError('A pool needs a range that ends, like pool 1..=6', 'PoolError'); options = v.toArray(); }
    else if (Array.isArray(v) || v instanceof SSet) options = Array.from(v instanceof SSet ? v.values() : v);
    else throw rtError('A pool is made from a list, a range, a set or a map of weights, not a ' + typeOf(v), 'PoolError');
    if (weights !== undefined && weights !== null) {
        const ws = Array.from(weights);
        if (ws.length !== options.length || !ws.every((w) => typeof w === 'number' && w >= 0)) throw rtError('There must be one weight (not negative) for each option of the pool', 'PoolError');
        return new SPool(options, ws);
    }
    return new SPool(options, null);
}
// ---------- compile ----------
const DECL = new Set(['Let', 'FnDecl', 'Struct', 'Enum', 'Impl', 'Trait', 'Use']);
function compileBlockBody(stmts, scoped) {
    const hoistT = [], hoistF = [], hoistI = [], rest = [];
    for (const s of stmts) {
        if (s.t === 'Struct' || s.t === 'Enum' || s.t === 'Trait') hoistT.push(s);
        else if (s.t === 'FnDecl') hoistF.push(s);
        else if (s.t === 'Impl') hoistI.push(s);
        else rest.push(s);
    }
    const pre = hoistT.concat(hoistF, hoistI).map(compile);
    const body = rest.map(compile);
    const nb = body.length, np = pre.length;
    const needsScope = scoped && stmts.some((s) => DECL.has(s.t));
    return (env) => {
        const e = needsScope ? new Env(env) : env;
        for (let i = 0; i < np; i++) pre[i](e);
        let r = null;
        for (let i = 0; i < nb; i++) r = body[i](e);
        return r === undefined ? null : r;
    };
}

let strictSeq = false;   // in match arms, [a, b] only fits a list and (a, b) only a tuple
function compilePat(p, mut) {
    switch (p.t) {
        case 'PWild': return () => true;
        case 'PBind': { const name = p.name; return (v, env, assign) => { if (assign) env.assign(name, v); else env.def(name, v, mut); return true; }; }
        case 'PLit': { const c = compile(p.v); return (v, env) => eq(v, c(env)); }
        case 'PRange': {
            const a = p.a && compile(p.a), b = p.b && compile(p.b), incl = p.incl;
            return (v, env) => {
                const lo = a ? a(env) : null, hi = b ? b(env) : null;
                const ref = a ? lo : hi;
                if (typeof v !== typeof ref || (typeof v !== 'number' && typeof v !== 'string')) return false;
                if (a && cmp(v, lo) < 0) return false;
                if (b) { const c = cmp(v, hi); if (incl ? c > 0 : c >= 0) return false; }
                return true;
            };
        }
        case 'PList': {
            const items = p.items.map((x) => compilePat(x, mut));
            const restAt = p.restAt, hasRest = p.rest !== null, rname = p.rest;
            const nBefore = hasRest ? restAt : items.length, nAfter = hasRest ? items.length - restAt : 0;
            const strict = strictSeq, wantTuple = !!p.tuple;
            return (v, env, assign) => {
                if (!Array.isArray(v)) { if (v instanceof SRange && Number.isFinite(v.size)) v = v.toArray(); else return false; }
                if (strict && (v instanceof Tuple) !== wantTuple) return false;
                if (hasRest ? v.length < items.length : v.length !== items.length) return false;
                for (let i = 0; i < nBefore; i++) if (!items[i](v[i], env, assign)) return false;
                for (let i = 0; i < nAfter; i++) if (!items[nBefore + i](v[v.length - nAfter + i], env, assign)) return false;
                if (hasRest && rname !== '_') { const r = v.slice(nBefore, v.length - nAfter); const rv = v instanceof Tuple ? tuple(r) : r; if (assign) env.assign(rname, rv); else env.def(rname, rv, mut); }
                return true;
            };
        }
        case 'PMap': case 'PStruct': {
            const entries = p.entries.map((e) => ({ key: e.key, pat: compilePat(e.pat, mut) }));
            const rname = p.rest, tname = p.t === 'PStruct' ? p.name : null;
            return (v, env, assign) => {
                const isMap = v instanceof SMap, isObj = v instanceof SObj;
                if (!isMap && !isObj) return false;
                if (tname && !(isObj && v.type.name === tname)) return false;
                if (tname === null && isObj && false) return false;
                for (const e of entries) {
                    const x = isMap ? v.get(e.key) : v.f[e.key];
                    if (x === undefined) return false;
                    if (!e.pat(x, env, assign)) return false;
                }
                if (rname && rname !== '_') {
                    const used = new Set(entries.map((e) => e.key));
                    const r = new SMap();
                    if (isMap) for (const [k, x] of v.entries()) { if (!used.has(k)) r.set(k, x); } else for (const k of Object.keys(v.f)) if (!used.has(k)) r.set(k, v.f[k]);
                    if (assign) env.assign(rname, r); else env.def(rname, r, mut);
                }
                return true;
            };
        }
        case 'PVariant': {
            const name = p.name, args = p.args && p.args.map((x) => compilePat(x, mut));
            return (v, env, assign) => {
                if (v instanceof SVariant) {
                    if (v.v.name !== name) return false;
                    if (!args) return true;
                    if (args.length !== v.vals.length) return false;
                    for (let i = 0; i < args.length; i++) if (!args[i](v.vals[i], env, assign)) return false;
                    return true;
                }
                if (v instanceof SObj && v.type.name === name) {
                    if (!args) return true;
                    const keys = Object.keys(v.f);
                    if (args.length !== keys.length) return false;
                    for (let i = 0; i < args.length; i++) if (!args[i](v.f[keys[i]], env, assign)) return false;
                    return true;
                }
                return false;
            };
        }
        case 'POr': { const alts = p.alts.map((x) => compilePat(x, mut)); return (v, env, assign) => alts.some((a) => a(v, env, assign)); }
    }
    throw rtError('Unknown pattern ' + p.t);
}

function compileParams(params) {
    return params.map((p) => ({
        name: p.rest ? p.name : p.name, rest: !!p.rest, type: p.type, self: p.name === 'self',
        def: p.def ? compile(p.def) : null,
        pat: p.pat && p.pat.t !== 'PBind' ? compilePat(p.pat, true) : null,
    }));
}
function compileFn(n) {
    const params = compileParams(n.params);
    const name = n.name, lambda = n.lambda, ret = n.ret;
    if (n.async) {
        const c = n.bodyless ? { s: () => { throw rtError((n.name || 'This function') + ' has no body yet'); } } : (n.body.t === 'Block' ? compileBlockBodyG(n.body.stmts, false) : cg(n.body));
        const bodyG = asGen(c);
        return (env) => { const f = new SFn(name, params, null, env, lambda, ret); f.isAsync = true; f.bodyG = bodyG; return f; };
    }
    const body = n.bodyless ? () => { throw rtError((n.name || 'This function') + ' has no body yet'); } : (n.body.t === 'Block' ? compileBlockBody(n.body.stmts, false) : compile(n.body));
    return (env) => new SFn(name, params, body, env, lambda, ret);
}

function compile(n) {
    switch (n.t) {
        case 'Num': case 'Big': case 'Str': { const v = n.v; return () => v; }
        case 'Pool': {
            const e = compile(n.e);
            return (env) => { const v = e(env); state.line = n.line; return makePool(v); };
        }
        case 'Slot': { const name = n.name; return (env) => env.vars.get(name); }
        case 'Await': throw rtError('await can only be used inside an async function (line ' + n.line + ')', 'SyntaxError');
        case 'Imag': { const z = new SComplex(0, n.v); return () => z; }
        case 'Bool': { const v = n.v; return () => v; }
        case 'None': return () => null;
        case 'Sym': { const s = sym(n.name); return () => s; }
        case 'Group': return compile(n.e);
        case 'Interp': {
            const parts = n.parts.map((p) => typeof p === 'string' ? p : { f: compile(p.e), spec: p.spec });
            return (env) => {
                let out = '';
                for (let i = 0; i < parts.length; i++) {
                    const p = parts[i];
                    if (typeof p === 'string') out += p;
                    else { const v = p.f(env); out += p.spec ? formatSpec(v, p.spec) : show(v); }
                }
                return out;
            };
        }
        case 'Id': {
            const name = n.name;
            return (env) => {
                for (let e = env; e; e = e.parent) { const v = e.vars.get(name); if (v !== undefined) return v; }
                state.line = n.line;
                throw rtError('Nothing is named "' + name + '" here' + didYouMean(name, visibleNames(env)), 'NameError');
            };
        }
        case 'List': {
            const items = n.items.map((x) => x.spread ? { s: true, f: compile(x.e) } : { f: compile(x) });
            if (!items.some((x) => x.s)) { const fs = items.map((x) => x.f); return (env) => { const r = new Array(fs.length); for (let i = 0; i < fs.length; i++) r[i] = fs[i](env); return r; }; }
            return (env) => { const r = []; for (const x of items) { if (x.s) for (const y of iterate(x.f(env))) r.push(y); else r.push(x.f(env)); } return r; };
        }
        case 'Tuple': {
            const items = n.items.map((x) => x.spread ? { s: true, f: compile(x.e) } : { f: compile(x) });
            return (env) => { const r = []; for (const x of items) { if (x.s) for (const y of iterate(x.f(env))) r.push(y); else r.push(x.f(env)); } return tuple(r); };
        }
        case 'Set': {
            const items = n.items.map((x) => x.spread ? { s: true, f: compile(x.e) } : { f: compile(x) });
            return (env) => { const r = new SSet(); for (const x of items) { if (x.s) for (const y of iterate(x.f(env))) r.add(y); else r.add(x.f(env)); } return r; };
        }
        case 'Map': {
            const es = n.entries.map((e) => e.spread ? { s: compile(e.spread) } : { k: compile(e.k), v: compile(e.v) });
            return (env) => {
                const m = new SMap();
                for (const e of es) {
                    if (e.s) { const o = e.s(env); if (o instanceof SMap) for (const [k, v] of o.entries()) m.set(k, v); else if (o instanceof SObj) for (const k of Object.keys(o.f)) m.set(k, o.f[k]); else if (o !== null) throw rtError('Only a map can be spread into a map'); }
                    else m.set(e.k(env), e.v(env));
                }
                return m;
            };
        }
        case 'Comp': {
            const clauses = n.clauses.map((c) => c.cond ? { cond: compile(c.cond) } : { pat: compilePat(c.pat, true), iter: compile(c.iter) });
            const kind = n.kind;
            const elt = kind === 'map' ? { k: compile(n.elt.k), v: compile(n.elt.v) } : (n.elt.spread ? { s: compile(n.elt.e) } : compile(n.elt));
            return (env) => {
                const out = kind === 'list' ? [] : kind === 'set' ? new SSet() : new SMap();
                const emit = (e) => {
                    if (kind === 'map') out.set(elt.k(e), elt.v(e));
                    else { const v = elt.s ? elt.s(e) : elt(e); if (kind === 'list') { if (elt.s) { for (const y of iterate(v)) out.push(y); } else out.push(v); } else out.add(v); }
                };
                const run = (e, i) => {
                    if (i === clauses.length) { emit(e); return; }
                    const c = clauses[i];
                    if (c.cond) { if (truthy(c.cond(e))) run(e, i + 1); return; }
                    for (const x of iterate(c.iter(e))) { const e2 = new Env(e); c.pat(x, e2, false); run(e2, i + 1); }
                };
                run(env, 0);
                return out;
            };
        }
        case 'Range': {
            const a = n.a && compile(n.a), b = n.b && compile(n.b), incl = n.incl;
            return (env) => {
                const x = a ? rt.settle(a(env)) : 0, y = b ? rt.settle(b(env)) : null;
                if (typeof x !== 'number' || (y !== null && typeof y !== 'number')) { state.line = n.line; throw rtError('A range needs numbers, like 1..5', 'TypeError'); }
                return new SRange(a ? x : null, y, incl, 1);
            };
        }
        case 'Neg': {
            const e = compile(n.e);
            return (env) => { let v = e(env); if (v instanceof SPool) v = v.decide(); if (typeof v === 'number') return -v; if (typeof v === 'bigint') return -v; if (v instanceof SComplex) return CX.neg(v); if (v instanceof SObj && v.type.methods.has('neg')) return invoke(v.type.methods.get('neg'), v, []); state.line = n.line; throw rtError('Cannot negate a ' + typeOf(v), 'TypeError'); };
        }
        case 'Not': { const e = compile(n.e); return (env) => !truthy(e(env)); }
        case 'And': { const l = compile(n.l), r = compile(n.r); return (env) => { const a = l(env); return truthy(a) ? r(env) : a; }; }
        case 'Or': { const l = compile(n.l), r = compile(n.r); return (env) => { const a = l(env); return truthy(a) ? a : r(env); }; }
        case 'Coalesce': { const l = compile(n.l), r = compile(n.r); return (env) => { const a = rt.settle(l(env)); return a === null ? r(env) : a; }; }
        case 'Bin': {
            const l = compile(n.l), r = compile(n.r), op = n.op;
            if (op === '+') return (env) => { const a = l(env), b = r(env); if (typeof a === 'number' && typeof b === 'number') return a + b; state.line = n.line; return binop('+', a, b); };
            if (op === '-') return (env) => { const a = l(env), b = r(env); if (typeof a === 'number' && typeof b === 'number') return a - b; state.line = n.line; return binop('-', a, b); };
            if (op === '<') return (env) => { const a = l(env), b = r(env); if (typeof a === 'number' && typeof b === 'number') return a < b; state.line = n.line; return binop('<', a, b); };
            if (op === '==') return (env) => { const a = l(env), b = r(env); if (a === b && typeof a !== 'object') return true; return binop('==', a, b); };
            return (env) => { const a = l(env), b = r(env); state.line = n.line; return binop(op, a, b); };
        }
        case 'In': { const l = compile(n.l), r = compile(n.r), neg = n.neg; return (env) => { const x = l(env), c = r(env); state.line = n.line; return contains(c, x) !== neg; }; }
        case 'Is': {
            const e = compile(n.e), neg = n.neg;
            if (n.type) { const t = n.type; return (env) => typeMatches(t, e(env), env) !== neg; }
            const v = compile(n.value);
            return (env) => eq(e(env), v(env)) !== neg;
        }
        case 'Pipe': {
            const l = compile(n.l);
            const r = n.r;
            if (r.t === 'Call' && r.args.some(isHoleArg) && !makesPartial(r.f)) {
                // x |> f(_, 2)  puts x where the _ is (and the call happens right away)
                const pf = compile({ t: 'Call', f: r.f, args: r.args, line: n.line });
                return (env) => { const x = l(env); state.line = n.line; return call(pf(env), [x], null); };
            }
            if (r.t === 'Call') return compile({ t: 'Call', f: r.f, args: [{ v: n.l, __c: l }].concat(r.args), line: n.line });
            const rf = compile(r);
            return (env) => { const x = l(env), f = rf(env); state.line = n.line; return call(f, [x], null); };
        }
        case 'Member': {
            const o = compile(n.o), name = n.name, opt = n.opt;
            return (env) => { const x = o(env); if (x === null && opt) return null; state.line = n.line; return getMember(x, name, n); };
        }
        case 'Index': {
            const o = compile(n.o), i = compile(n.i), opt = n.opt;
            return (env) => { const x = o(env); if (x === null && opt) return null; const k = i(env); state.line = n.line; return getIndex(x, k, n); };
        }
        case 'Try': {
            const e = compile(n.e);
            return (env) => {
                const v = rt.settle(e(env));
                if (v === null) throw new Ret(null);
                if (v instanceof SVariant && v.type === ResultT) { if (v.v.name === 'Err') throw new Ret(v); return v.vals[0]; }
                return v;
            };
        }
        case 'Call': return compileCall(n);
        case 'Fn': return compileFn(n);
        case 'If': {
            const c = compile(n.c), t = compileBlockBody(n.th.stmts, true), e = n.el ? (n.el.t === 'If' ? compile(n.el) : compileBlockBody(n.el.stmts, true)) : null;
            return (env) => truthy(c(env)) ? t(env) : (e ? e(env) : null);
        }
        case 'Block': return compileBlockBody(n.stmts, true);
        case 'Match': {
            const e = compile(n.e);
            strictSeq = true;
            let arms;
            try { arms = n.arms.map((a) => ({ pat: compilePat(a.pat, false), guard: a.guard && compile(a.guard), body: a.body.t === 'Block' ? compileBlockBody(a.body.stmts, false) : compile(a.body) })); } finally { strictSeq = false; }
            return (env) => {
                const v = rt.settle(e(env));
                for (let i = 0; i < arms.length; i++) {
                    const a = arms[i];
                    const e2 = new Env(env);
                    if (a.pat(v, e2, false) && (!a.guard || truthy(a.guard(e2)))) return a.body(e2);
                }
                state.line = n.line;
                throw rtError('No match arm fits ' + repr(v) + '. Add a _ arm to catch everything else', 'MatchError');
            };
        }
        case 'For': {
            const iter = compile(n.iter), pat = compilePat(n.pat, true), body = compileBlockBody(n.body.stmts, false);
            return (env) => {
                const src = iter(env);
                state.line = n.line;
                for (const x of iterate(src)) {
                    const e2 = new Env(env);
                    pat(x, e2, false);
                    try { body(e2); } catch (e) { if (e instanceof Brk) return e.v; if (e instanceof Cont) continue; throw e; }
                }
                return null;
            };
        }
        case 'While': {
            const c = compile(n.c), body = compileBlockBody(n.body.stmts, true);
            return (env) => {
                while (truthy(c(env))) { try { body(env); } catch (e) { if (e instanceof Brk) return e.v; if (e instanceof Cont) continue; throw e; } }
                return null;
            };
        }
        case 'Loop': {
            const body = compileBlockBody(n.body.stmts, true);
            return (env) => { for (;;) { try { body(env); } catch (e) { if (e instanceof Brk) return e.v; if (e instanceof Cont) continue; throw e; } } };
        }
        case 'TryCatch': {
            const body = compileBlockBody(n.body.stmts, true), handler = n.handler && compileBlockBody(n.handler.stmts, false), fin = n.fin && compileBlockBody(n.fin.stmts, true);
            const param = n.param && compilePat(n.param, true);
            return (env) => {
                const depth = state.depth, sl = state.stack.length;
                try { return body(env); }
                catch (e) {
                    if (e instanceof Brk || e instanceof Cont || e instanceof Ret || !handler) throw e;
                    state.depth = depth; state.stack.length = sl; state.lines.length = sl;
                    const v = errValue(e);
                    const e2 = new Env(env);
                    if (param) param(v, e2, false);
                    return handler(e2);
                } finally { if (fin) fin(env); }
            };
        }
        case 'Throw': { const e = compile(n.e); return (env) => { const v = rt.settle(e(env)); state.line = n.line; throw new SuaveError(v, 'Thrown'); }; }
        case 'Return': { const e = n.e && compile(n.e); return (env) => { throw new Ret(e ? e(env) : null); }; }
        case 'Break': { const e = n.e && compile(n.e); return (env) => { throw new Brk(e ? e(env) : null); }; }
        case 'Continue': return () => { throw new Cont(); };
        case 'Let': {
            const init = n.init ? compile(n.init) : () => null, mut = n.mut, type = n.type;
            if (n.pat.t === 'PBind') {
                const name = n.pat.name;
                return (env) => {
                    const v = init(env);
                    if (type && !typeMatches(type, v, env)) { state.line = n.line; throw rtError('"' + name + '" should be ' + typeName(type) + ' but got ' + typeOf(v) + ' (' + repr(v) + ')', 'TypeError'); }
                    if (v instanceof SFn && !v.name) v.name = name;
                    env.def(name, v, mut);
                    return null;
                };
            }
            const pat = compilePat(n.pat, mut);
            return (env) => { const v = init(env); state.line = n.line; if (!pat(v, env, false)) throw rtError('The value ' + repr(v) + ' does not fit the pattern on the left of =', 'MatchError'); return null; };
        }
        case 'Assign': return compileAssign(n);
        case 'Multi': { const cs = n.stmts.map((x) => compile(x)); return (env) => { for (const c of cs) c(env); return null; }; }
        case 'FnDecl': { const f = compileFn(n.fn), name = n.name; return (env) => { env.def(name, f(env), false); return null; }; }
        case 'Struct': {
            const fields = n.fields.map((f) => ({ name: f.name, type: f.type, def: f.def ? compile(f.def) : null }));
            const name = n.name;
            return (env) => { const T = new SType(name, 'struct'); T.fields = fields; T.env = env; env.def(name, T, false); return null; };
        }
        case 'Enum': {
            const vs = n.variants.map((v, i) => ({ name: v.name, fields: v.fields, idx: i, valC: v.value && compile(v.value) }));
            const name = n.name;
            return (env) => {
                const T = new SType(name, 'enum'); T.env = env;
                for (const v of vs) { const def = { name: v.name, fields: v.fields, idx: v.idx }; if (v.valC) def.val = v.valC(env); T.variants.set(v.name, def); }
                env.def(name, T, false);
                return null;
            };
        }
        case 'Trait': {
            const ms = n.methods.map((m) => m.konst ? null : { name: m.name, fn: compileFn(m), required: m.bodyless });
            const name = n.name;
            return (env) => { const T = new SType(name, 'trait'); T.env = env; for (const m of ms) if (m) { if (m.required) T.statics.set(m.name, null); else T.methods.set(m.name, m.fn(env)); } env.def(name, T, false); return null; };
        }
        case 'Impl': {
            const ms = n.methods.map((m) => m.konst ? { konst: compile(m.konst.init), name: m.konst.pat.name } : { name: m.name, fn: compileFn(m), isStatic: !m.params.some((p) => p.name === 'self') });
            const name = n.name, traitName = n.trait;
            return (env) => {
                state.line = n.line;
                const T = env.lookup(name);
                if (!(T instanceof SType)) {
                    // impl str { ... } adds methods to a built-in type
                    if (['str', 'num', 'list', 'map', 'set', 'tuple', 'bool', 'fn', 'range', 'any', 'iter', 'sym', 'bytes'].includes(name)) {
                        let table = userExt.get(name); if (!table) { table = new Map(); userExt.set(name, table); }
                        for (const m of ms) if (m.fn) { const f = m.fn(env); table.set(m.name, (self, args, named) => callFn(f, args, named, self)); }
                        return null;
                    }
                    throw rtError('Nothing called "' + name + '" to implement methods for', 'NameError');
                }
                for (const m of ms) {
                    if (m.konst) { T.consts.set(m.name, m.konst(env)); continue; }
                    const f = m.fn(env);
                    if (m.isStatic) T.statics.set(m.name, f); else T.methods.set(m.name, f);
                    if (m.name === 'to_str' && !m.isStatic) T.showFn = (o) => callFn(f, [], null, o);
                }
                if (traitName) {
                    const tr = env.lookup(traitName);
                    if (!(tr instanceof SType) || tr.kind !== 'trait') throw rtError('"' + traitName + '" is not a trait', 'NameError');
                    for (const [k, v] of tr.methods) if (!T.methods.has(k)) T.methods.set(k, v);
                    for (const [k, v] of tr.statics) if (v === null && !T.methods.has(k) && !T.statics.has(k)) throw rtError(T.name + ' must define "' + k + '" to implement ' + traitName, 'TraitError');
                    T.traits.add(traitName);
                }
                return null;
            };
        }
        case 'Use': return compileUse(n);
        case 'Test': {
            const body = compileBlockBodyG(n.body.stmts, true), name = n.name;
            return (env) => {
                const file = state.file;
                interp.tests.push({ name, file, line: n.line, run: () => {
                    const prev = state.file; state.file = file;
                    try { return body.s ? body.s(new Env(env)) : runAsync(body.g(new Env(env))); } finally { state.file = prev; }
                } });
                return null;
            };
        }
        case 'Destructure': return () => null;
    }
    throw rtError('The interpreter does not know the node "' + n.t + '"');
}

function visibleNames(env) {
    const names = [];
    for (let e = env, k = 0; e && k < 6; e = e.parent, k++) for (const key of e.vars.keys()) names.push(key);
    return names;
}

// partial(f, _, 1) and f.partial(_, 1) already build the partial function, so their _ is just the hole value
const makesPartial = (f) => (f.t === 'Id' || f.t === 'Member') && /^partial(_right)?$/.test(f.name);
const isHoleArg = (a) => !a.name && !a.spread && a.v && a.v.t === 'Id' && a.v.name === '_';
// f(_, 2) gives back a new function that waits for the value in the hole!
function compilePlaceholderCall(n) {
    const target = n.f.t === 'Member' ? compile({ t: 'Member', o: n.f.o, name: n.f.name, opt: n.f.opt, line: n.line }) : compile(n.f);
    const args = n.args.map((a) => (isHoleArg(a) ? { hole: true } : { name: a.name || null, spread: !!a.spread, f: a.__c || compile(a.v) }));
    return (env) => {
        const f = target(env);
        const slots = []; let named = null;
        for (const a of args) {
            if (a.hole) slots.push(HOLE);
            else if (a.spread) { for (const y of iterate(a.f(env))) slots.push(y); }
            else if (a.name) { (named || (named = {}))[a.name] = a.f(env); }
            else slots.push(a.f(env));
        }
        state.line = n.line;
        return makePartial(f, slots, named, false);
    };
}
function compileCall(n) {
    if (n.args.some(isHoleArg) && !makesPartial(n.f)) return compilePlaceholderCall(n);
    const args = n.args.map((a) => ({ name: a.name || null, spread: !!a.spread, f: a.__c || compile(a.v) }));
    const simple = args.every((a) => !a.name && !a.spread);
    const len = args.length;
    const fns = args.map((a) => a.f);
    // the general case: named arguments (name: value) and spreads (*list)
    const buildFull = (env) => {
        const r = []; let named = null;
        for (const a of args) {
            if (a.spread) { for (const y of iterate(a.f(env))) r.push(y); }
            else if (a.name) { (named || (named = {}))[a.name] = a.f(env); }
            else r.push(a.f(env));
        }
        return [r, named];
    };
    if (n.f.t === 'Member') {
        const o = compile(n.f.o), name = n.f.name, opt = n.f.opt;
        if (simple) return (env) => {
            const x = o(env);
            if (x === null && opt) return null;
            const a = new Array(len);
            for (let i = 0; i < len; i++) a[i] = fns[i](env);
            state.line = n.line;
            return callMethod(x, name, a, null, opt);
        };
        return (env) => {
            const x = o(env);
            if (x === null && opt) return null;
            const [a, named] = buildFull(env);
            state.line = n.line;
            return callMethod(x, name, a, named, opt);
        };
    }
    const fc = compile(n.f), optCall = n.opt;
    if (simple) return (env) => {
        const f = fc(env);
        if (f === null && optCall) return null;
        const a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = fns[i](env);
        state.line = n.line;
        if (f instanceof SFn) return callFn(f, a, null, null);
        return call(f, a, null);
    };
    return (env) => {
        const f = fc(env);
        if (f === null && optCall) return null;
        const [a, named] = buildFull(env);
        state.line = n.line;
        return call(f, a, named);
    };
}

function compileAssign(n) {
    const val = compile(n.value), op = n.op, t = n.target;
    const combine = (cur, v, env) => op === '??' ? (cur === null ? v : cur) : binop(op, cur, v);
    if (t.t === 'Id') {
        const name = t.name;
        return (env) => {
            let v;
            if (op) { const cur = env.get(name); if (op === '??' && cur !== null) return null; v = combine(cur, val(env), env); } else v = val(env);
            state.line = n.line;
            if (op) env.set(name, v); else env.assign(name, v);
            return null;
        };
    }
    if (t.t === 'Member') {
        const o = compile(t.o), name = t.name;
        return (env) => { const x = o(env); let v = val(env); state.line = n.line; if (op) v = combine(getMember(x, name), v, env); setMember(x, name, v); return null; };
    }
    if (t.t === 'Index') {
        const o = compile(t.o), i = compile(t.i);
        return (env) => { const x = o(env), k = i(env); let v = val(env); state.line = n.line; if (op) v = combine(getIndex(x, k), v, env); setIndex(x, k, v); return null; };
    }
    if (t.t === 'Destructure') {
        const pat = compilePat(t.pat, true);
        return (env) => { const v = val(env); state.line = n.line; if (!pat(v, env, true)) throw rtError('The value ' + repr(v) + ' does not fit the pattern on the left of =', 'MatchError'); return null; };
    }
    throw rtError('Cannot assign here');
}


// ---------- async / await ----------
// A function marked async runs as a generator: each `await` hands a future back to the driver (runAsync), which comes back
// when the future is done. Only code that really contains an await is compiled this way; everything else stays on the fast path.
const awaitCache = new WeakMap();
function hasAwait(x) {
    if (x === null || typeof x !== 'object') return false;
    const hit = awaitCache.get(x);
    if (hit !== undefined) return hit;
    let r = false;
    if (Array.isArray(x)) { for (let i = 0; i < x.length; i++) if (hasAwait(x[i])) { r = true; break; } }
    else if (x.t === 'Await') r = true;
    else if (x.t === 'Fn' || x.t === 'Test') r = false;
    else { for (const k in x) { const y = x[k]; if (y !== null && typeof y === 'object' && hasAwait(y)) { r = true; break; } } }
    awaitCache.set(x, r);
    return r;
}
const isThenable = (x) => x !== null && x !== undefined && typeof x.then === 'function';
function* awaitValue(v) {
    v = rt.settle(v);
    if (isThenable(v)) return yield v;
    return v;
}
export function runAsync(gen) {
    return new Promise((resolve, reject) => {
        const step = (method, arg) => {
            let r;
            try { r = gen[method](arg); }
            catch (e) { if (e instanceof Ret) resolve(e.v === undefined ? null : e.v); else reject(e); return; }
            if (r.done) { resolve(r.value === undefined ? null : r.value); return; }
            Promise.resolve(r.value).then((v) => step('next', v), (e) => step('throw', e));
        };
        step('next', undefined);
    });
}
let slotCounter = 0;
const cg = (n) => (hasAwait(n) ? compileG(n) : { s: compile(n) });
const asGen = (c) => c.g || function* (env) { return c.s(env); };

// replaces each child expression of a node by a "slot" that reads an already computed value (evaluated left to right)
function substitute(n, mk) {
    const opt = (x) => (x === null || x === undefined ? x : mk(x));
    switch (n.t) {
        case 'Bin': case 'In': return { ...n, l: mk(n.l), r: mk(n.r) };
        case 'Neg': case 'Not': case 'Try': case 'Pool': case 'Throw': return { ...n, e: mk(n.e) };
        case 'Return': case 'Break': return { ...n, e: opt(n.e) };
        case 'Member': return { ...n, o: mk(n.o) };
        case 'Index': return { ...n, o: mk(n.o), i: mk(n.i) };
        case 'Is': return n.type ? { ...n, e: mk(n.e) } : { ...n, e: mk(n.e), value: mk(n.value) };
        case 'Range': return { ...n, a: opt(n.a), b: opt(n.b) };
        case 'List': case 'Tuple': case 'Set': return { ...n, items: n.items.map((x) => (x.spread ? { ...x, e: mk(x.e) } : mk(x))) };
        case 'Map': return { ...n, entries: n.entries.map((e) => (e.spread ? { spread: mk(e.spread) } : { k: mk(e.k), v: mk(e.v) })) };
        case 'Interp': return { ...n, parts: n.parts.map((p) => (typeof p === 'string' ? p : { ...p, e: mk(p.e) })) };
        case 'Call': {
            const f = n.f.t === 'Member' ? { ...n.f, o: mk(n.f.o) } : mk(n.f);
            return { ...n, f, args: n.args.map((a) => ({ ...a, v: mk(a.v) })) };
        }
        case 'Pipe': return n.r.t === 'Call' ? substitute({ t: 'Call', f: n.r.f, args: [{ v: n.l }].concat(n.r.args), line: n.line }, mk) : { ...n, l: mk(n.l), r: mk(n.r) };
        case 'Let': return n.init ? { ...n, init: mk(n.init) } : n;
        case 'Assign': return { ...n, value: mk(n.value) };
        case 'Group': return mk(n.e);
    }
    return null;
}
function strictG(n) {
    const kids = [], names = [];
    const mk = (child) => { const name = '\u0000a' + (slotCounter++); kids.push(cg(child)); names.push(name); return { t: 'Slot', name, line: child.line }; };
    const n2 = substitute(n, mk);
    if (!n2) throw rtError('await cannot be used inside this kind of expression (' + n.t + ' at line ' + n.line + '). Put the await on its own line first', 'SyntaxError');
    const sync = compile(n2);
    const len = kids.length;
    return {
        g: function* (env) {
            const vals = new Array(len);
            for (let i = 0; i < len; i++) { const c = kids[i]; vals[i] = c.s ? c.s(env) : yield* c.g(env); }
            for (let i = 0; i < len; i++) env.vars.set(names[i], vals[i] === undefined ? null : vals[i]);
            try { state.line = n.line; return sync(env); }
            finally { for (let i = 0; i < len; i++) env.vars.delete(names[i]); }
        },
    };
}
function compileBlockBodyG(stmts, scoped) {
    if (!hasAwait(stmts)) return { s: compileBlockBody(stmts, scoped) };
    const hoistT = [], hoistF = [], hoistI = [], rest = [];
    for (const st of stmts) {
        if (st.t === 'Struct' || st.t === 'Enum' || st.t === 'Trait') hoistT.push(st);
        else if (st.t === 'FnDecl') hoistF.push(st);
        else if (st.t === 'Impl') hoistI.push(st);
        else rest.push(st);
    }
    const pre = hoistT.concat(hoistF, hoistI).map(compile);
    const body = rest.map(cg);
    const needsScope = scoped && stmts.some((x) => DECL.has(x.t));
    return {
        g: function* (env) {
            const e = needsScope ? new Env(env) : env;
            for (let i = 0; i < pre.length; i++) pre[i](e);
            let r = null;
            for (let i = 0; i < body.length; i++) { const c = body[i]; r = c.s ? c.s(e) : yield* c.g(e); }
            return r === undefined ? null : r;
        },
    };
}
function compileG(n) {
    switch (n.t) {
        case 'Await': {
            const c = cg(n.e);
            return { g: function* (env) { const v = c.s ? c.s(env) : yield* c.g(env); state.line = n.line; return yield* awaitValue(v); } };
        }
        case 'Block': return compileBlockBodyG(n.stmts, true);
        case 'And': { const l = cg(n.l), r = cg(n.r); return { g: function* (env) { const a = l.s ? l.s(env) : yield* l.g(env); return truthy(a) ? (r.s ? r.s(env) : yield* r.g(env)) : a; } }; }
        case 'Or': { const l = cg(n.l), r = cg(n.r); return { g: function* (env) { const a = l.s ? l.s(env) : yield* l.g(env); return truthy(a) ? a : (r.s ? r.s(env) : yield* r.g(env)); } }; }
        case 'Coalesce': { const l = cg(n.l), r = cg(n.r); return { g: function* (env) { const a = rt.settle(l.s ? l.s(env) : yield* l.g(env)); return a === null ? (r.s ? r.s(env) : yield* r.g(env)) : a; } }; }
        case 'If': {
            const c = cg(n.c), t = compileBlockBodyG(n.th.stmts, true), e = n.el ? (n.el.t === 'If' ? cg(n.el) : compileBlockBodyG(n.el.stmts, true)) : null;
            return { g: function* (env) { const v = c.s ? c.s(env) : yield* c.g(env); if (truthy(v)) return t.s ? t.s(env) : yield* t.g(env); if (e) return e.s ? e.s(env) : yield* e.g(env); return null; } };
        }
        case 'While': {
            const c = cg(n.c), body = compileBlockBodyG(n.body.stmts, true);
            return { g: function* (env) {
                for (;;) {
                    const v = c.s ? c.s(env) : yield* c.g(env);
                    if (!truthy(v)) return null;
                    try { if (body.s) body.s(env); else yield* body.g(env); } catch (e) { if (e instanceof Brk) return e.v; if (e instanceof Cont) continue; throw e; }
                }
            } };
        }
        case 'Loop': {
            const body = compileBlockBodyG(n.body.stmts, true);
            return { g: function* (env) { for (;;) { try { if (body.s) body.s(env); else yield* body.g(env); } catch (e) { if (e instanceof Brk) return e.v; if (e instanceof Cont) continue; throw e; } } } };
        }
        case 'For': {
            const iter = cg(n.iter), pat = compilePat(n.pat, true), body = compileBlockBodyG(n.body.stmts, false);
            return { g: function* (env) {
                const src = iter.s ? iter.s(env) : yield* iter.g(env);
                state.line = n.line;
                for (const x of iterate(src)) {
                    const e2 = new Env(env);
                    pat(x, e2, false);
                    try { if (body.s) body.s(e2); else yield* body.g(e2); } catch (e) { if (e instanceof Brk) return e.v; if (e instanceof Cont) continue; throw e; }
                }
                return null;
            } };
        }
        case 'Match': {
            const e = cg(n.e);
            strictSeq = true;
            let arms;
            try { arms = n.arms.map((a) => ({ pat: compilePat(a.pat, false), guard: a.guard && cg(a.guard), body: a.body.t === 'Block' ? compileBlockBodyG(a.body.stmts, false) : cg(a.body) })); } finally { strictSeq = false; }
            return { g: function* (env) {
                const v = rt.settle(e.s ? e.s(env) : yield* e.g(env));
                for (let i = 0; i < arms.length; i++) {
                    const a = arms[i];
                    const e2 = new Env(env);
                    if (!a.pat(v, e2, false)) continue;
                    if (a.guard) { const gv = a.guard.s ? a.guard.s(e2) : yield* a.guard.g(e2); if (!truthy(gv)) continue; }
                    return a.body.s ? a.body.s(e2) : yield* a.body.g(e2);
                }
                state.line = n.line;
                throw rtError('No match arm fits ' + repr(v) + '. Add a _ arm to catch everything else', 'MatchError');
            } };
        }
        case 'TryCatch': {
            const body = compileBlockBodyG(n.body.stmts, true), handler = n.handler && compileBlockBodyG(n.handler.stmts, false), fin = n.fin && compileBlockBodyG(n.fin.stmts, true);
            const param = n.param && compilePat(n.param, true);
            return { g: function* (env) {
                const depth = state.depth, sl = state.stack.length;
                try { return body.s ? body.s(env) : yield* body.g(env); }
                catch (e) {
                    if (e instanceof Brk || e instanceof Cont || e instanceof Ret || !handler) throw e;
                    state.depth = depth; state.stack.length = sl; state.lines.length = sl;
                    const v = errValue(e);
                    const e2 = new Env(env);
                    if (param) param(v, e2, false);
                    return handler.s ? handler.s(e2) : yield* handler.g(e2);
                } finally { if (fin) { if (fin.s) fin.s(env); else yield* fin.g(env); } }
            } };
        }
    }
    return strictG(n);
}

// ---------- modules ----------
const moduleCache = new Map();
function dirOf(p) { const i = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')); return i < 0 ? '.' : p.slice(0, i); }
function joinPath(base, rel) {
    if (rel.startsWith('/')) return rel;
    const out = base.split('/').filter((x, i) => x !== '' || i === 0);
    for (const seg of rel.split('/')) { if (seg === '.' || seg === '') continue; if (seg === '..') { if (out.length > 1 || (out.length === 1 && out[0] !== '')) out.pop(); } else out.push(seg); }
    return out.join('/') || '/';
}
export function loadModule(parts, path) {
    if (path) {
        let full = path;
        if (!/^(\/|[A-Za-z]+:)/.test(path)) full = joinPath(dirOf(state.file) === '.' ? (rt.sys ? rt.sys.cwd() : '.') : dirOf(state.file), path);
        if (!/\.[a-z]+$/i.test(full)) full += '.sv';
        if (moduleCache.has(full)) return moduleCache.get(full);
        let src;
        const base = path.split('/').pop();
        const hit = rt.files && [full, path, path + '.sv', base, base + '.sv'].find((k) => rt.files[k] !== undefined);
        if (hit) src = rt.files[hit];
        else if (rt.sys) { try { src = rt.sys.readText(full); } catch (e) { throw rtError('I could not read the module file ' + full, 'ModuleError'); } }
        else throw rtError('No module file ' + path + ' is available here', 'ModuleError');
        if (/\.(xsv|wsv)$/i.test(full)) {                    // a web component or page file
            if (!hooks.loadWeb) throw rtError('Web files (.xsv, .wsv) are not available here', 'ModuleError');
            const comp = hooks.loadWeb(src, full);
            const wm = new SModule(full, { component: comp, default: comp, [comp.name]: comp });
            wm.web = comp;
            moduleCache.set(full, wm);
            return wm;
        }
        const mod = new SModule(full, {});
        moduleCache.set(full, mod);
        const prevFile = state.file;
        state.file = full;
        try {
            const env = new Env(interp.globals);
            const mr = runProgram(src, full, env);
            if (mr instanceof Promise) throw rtError('The module ' + full + ' uses await at its top level. Wrap it in an async function', 'ModuleError');
            for (const [k, v] of env.vars) if (!k.startsWith('_')) mod.exports[k] = v;
        } finally { state.file = prevFile; }
        return mod;
    }
    const name = parts.join('.');
    if (moduleCache.has(name)) return moduleCache.get(name);
    // use mylib / use mylib.part: a package installed with the package manager (suave_modules/)
    if (parts[0] !== 'std') {
        const file = hooks.findPackage ? hooks.findPackage(parts, state.file) : null;
        const virt = rt.files && [parts.join('/') + '.sv', parts.join('/') + '/main.sv', parts[parts.length - 1] + '.sv'].find((k) => rt.files[k] !== undefined);
        if (file || virt) return loadModule(null, file || virt);
        if (!hooks.stdlib[name] && hooks.stdlib['std.' + name]) return loadModule(['std'].concat(parts));      // import math works like use std.math
        if (!hooks.stdlib[name]) throw rtError('I do not know a module or package called ' + name + '. The standard library starts with std. (suave modules); packages are installed with: suave add ' + parts[0] + '. If you expected a built-in module, your Suave may be old: run  suave upgrade', 'ModuleError');
    }
    const factory = hooks.stdlib[name];
    if (!factory) {
        const near = Object.keys(hooks.stdlib).filter((k) => lev(name, k) <= 3).slice(0, 3);
        throw rtError('I do not know a module called ' + name + (near.length ? '. Did you mean ' + near.join(' or ') + '?' : '. Run "suave modules" to see them all') + '. If it should exist, your Suave may be old: run  suave upgrade', 'ModuleError');
    }
    const exports = factory(rt);
    const mod = new SModule(name, exports);
    moduleCache.set(name, mod);
    return mod;
}
function compileUse(n) {
    return (env) => {
        state.line = n.line;
        const mod = loadModule(n.parts, n.path);
        if (mod.web && !n.names && !n.star) { env.def(n.alias || mod.web.name, mod.web, false); return null; }   // use "./counter.xsv" makes Counter
        if (n.star) { for (const k of Object.keys(mod.exports)) env.def(k, mod.exports[k], false); return null; }
        if (n.names) {
            for (const [k, as] of n.names) {
                const v = mod.exports[k];
                if (v === undefined) throw rtError('Module ' + mod.name + ' has no "' + k + '"' + didYouMean(k, Object.keys(mod.exports)), 'ModuleError');
                env.def(as, v, false);
            }
            return null;
        }
        const alias = n.alias || (n.path ? n.path.replace(/\\/g, '/').split('/').pop().replace(/\.[a-z]+$/i, '') : n.parts[n.parts.length - 1]);
        env.def(alias, mod, false);
        return null;
    };
}

// ---------- running ----------
export function runProgram(src, file, env) {
    const ast = parse(src, file);
    const prev = state.file;
    state.file = file;
    try {
        const c = compileBlockBodyG(ast.stmts, false);
        // a program that awaits at its top level gives back a future (a Promise)
        if (c.g) return runAsync(c.g(env));
        try { return c.s(env); }
        catch (e) { if (e instanceof Ret) return e.v; throw e; }
    } finally { state.file = prev; }
}

// compiles a bit of Suave (an expression, or a few statements) once, so a web template can run it again and again
export function compileSnippet(src, file, line) {
    const ast = parse('\n'.repeat(Math.max(0, (line || 1) - 1)) + src, file);
    const c = compileBlockBodyG(ast.stmts, false);
    if (!c.s) throw rtError('await cannot be used inside a template. Do the waiting in the script', 'SyntaxError');
    return (env) => { try { return c.s(env); } catch (e) { if (e instanceof Ret) return e.v; throw e; } };
}

export const interp = {
    globals: null, tests: [],
    reset() { this.tests = []; moduleCache.clear(); },
    newScope() { return new Env(this.globals); },
    run(src, file, env) { return runProgram(src, file || '<main>', env || this.newScope()); },
};
rt.call = call;
rt.callMethod = callMethod;
rt.binop = binop;
rt.slice = slice;
rt.typeMatches = typeMatches;
export { userExt, getMember, didYouMean, lev, contains, callFn };
