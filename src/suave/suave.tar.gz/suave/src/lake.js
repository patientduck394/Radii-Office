/* Lake: Suave's task runner and build tool, like Make, Rake or Cargo's scripts. Tasks live in a file called Lakefile (plain Suave):

       default_task("build")

       task("build", desc="Bundle the web app"):
           suave("build", "app.wsv", "-o", "dist")

       task("test", needs=["build"], desc="Run the tests"):
           suave("test")

       file("dist/app.zip", needs=["dist/index.html"]):
           sh("zip -r dist/app.zip dist")

   Run it with:  lake            (the default task)
                 lake test       (one task; its needs run first, each only once)
                 lake -l         (list the tasks)                                   */
import rt from './runtime.js';
import { interp, runProgram } from './interp.js';

const sys = () => rt.sys;
const NAMES = ['Lakefile', 'Lakefile.sv', 'lakefile.sv', 'lake.sv'];

export function findLakefile(from) {
    let dir = from || sys().cwd();
    for (;;) {
        for (const n of NAMES) { const p = dir + '/' + n; if (sys().exists(p) && sys().stat(p).isFile) return p; }
        const up = dir.replace(/\/[^/]*$/, '');
        if (!up || up === dir) return null;
        dir = up;
    }
}

const SAMPLE = `# Lakefile: the tasks for this project. Run one with  lake <name>,  list them with  lake -l
default_task("build")

task("build", desc="Build the project"):
    echo("Building...")
    # suave("build", "app.wsv", "-o", "dist")

task("test", desc="Run the tests"):
    suave("test")

task("clean", desc="Remove what the build made"):
    rm("dist")

task("all", needs=["clean", "build", "test"], desc="Everything, in order")
`;

export function newLakefile(path) {
    path = path || 'Lakefile';
    if (sys().exists(path)) throw rt.rtError(path + ' already exists', 'IOError');
    sys().writeText(path, SAMPLE);
    return path;
}

// the little language of a Lakefile: the functions it can call
function makeDsl(ctx) {
    const split = (args) => { const a = args.slice(); const named = a.length && a[a.length - 1] instanceof rt.Named ? a.pop().obj : {}; return [a, named]; };
    const quote = (p) => (/^[\w@%+=:,./-]+$/.test(p) ? p : "'" + String(p).replace(/'/g, "'\\''") + "'");
    const run = (cmd, args, opts) => {
        const code = sys().runInherit(cmd, args, opts);
        return code;
    };
    const flat = (xs) => xs.reduce((a, x) => a.concat(Array.isArray(x) ? flat(x) : [x]), []);
    const walk = (dir, out) => { for (const e of sys().readDir(dir)) { const p = (dir === '.' ? '' : dir + '/') + e.name; if (e.isDir) walk(p, out); else out.push(p); } return out; };
    const globRe = (pat) => new RegExp('^' + pat.replace(/[.+^${}()|\\]/g, '\\$&').replace(/\*\*\//g, '(?:.*/)?').replace(/\*\*/g, '.*').replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]') + '$');
    const dsl = {
        // task("name", needs=["a", "b"], desc="what it does"):  ...lines...
        task: (...args) => {
            const [pos, o] = split(args);
            const name = String(pos[0]);
            const t = { name, needs: [], desc: o.desc || '', run: o.run || null, file: false };
            for (const x of pos.slice(1)) { if (Array.isArray(x)) t.needs = t.needs.concat(x.map(String)); else if (typeof x === 'string') t.desc = x; }
            if (o.needs) t.needs = t.needs.concat(flat([o.needs]).map(String));
            if (ctx.tasks.has(name) && ctx.tasks.get(name).run && t.run) { const old = ctx.tasks.get(name); const first = old.run; t.run = (...a) => { rt.call(first, []); return rt.call(o.run, []); }; t.needs = old.needs.concat(t.needs); }   // a second task with the same name adds to the first
            ctx.tasks.set(name, t);
            return null;
        },
        // file("dist/app.js", needs=["src/app.js"]):  ...runs only when the file is missing or older than something it needs
        file: (...args) => {
            const [pos, o] = split(args);
            const name = String(pos[0]);
            ctx.tasks.set(name, { name, needs: flat([o.needs || pos[1] || []]).map(String), desc: o.desc || '', run: o.run || null, file: true });
            return null;
        },
        default_task: (name) => { ctx.def = String(name); return null; },
        sh: (...args) => {
            const [pos, o] = split(args);
            const cmd = pos.map(String).join(' ');
            if (!o.quiet) sys().out('  $ ' + cmd + '\n');
            const code = sys().os() === 'windows' ? run('cmd', ['/c', cmd], { cwd: ctx.cwd }) : run('sh', ['-c', cmd], { cwd: ctx.cwd });
            if (code !== 0 && o.check !== false) throw rt.rtError('The command failed (exit ' + code + '): ' + cmd, 'LakeError');
            return code;
        },
        // suave("test") runs this same Suave; laker("build") runs Laker
        suave: (...args) => dsl.sh(...flat(args.filter((a) => !(a instanceof rt.Named))).map(quote), ...args.filter((a) => a instanceof rt.Named), new rt.Named({ prefix: true })),
        echo: (...a) => { sys().out(a.map((x) => rt.show(x)).join(' ') + '\n'); return null; },
        rm: (...paths) => { for (const p of flat(paths)) { try { if (sys().exists(p)) sys().remove(p, true); } catch (e) { throw rt.rtError('Could not remove ' + p, 'LakeError'); } } return null; },
        mkdir: (p) => { sys().mkdir(String(p), true); return null; },
        cp: (a, b) => {
            const copy = (x, y) => { const st = sys().stat(x); if (st.isDir) { sys().mkdir(y, true); for (const e of sys().readDir(x)) copy(x + '/' + e.name, y + '/' + e.name); } else { const parent = y.replace(/\/[^/]*$/, ''); if (parent && parent !== y) sys().mkdir(parent, true); sys().copy(x, y); } };
            copy(String(a), String(b)); return null;
        },
        exists: (p) => sys().exists(String(p)),
        read: (p) => sys().readText(String(p)),
        write: (p, text) => { sys().writeText(String(p), String(text)); return null; },
        glob: (pattern) => { const re = globRe(String(pattern)); const base = String(pattern).split(/[*?]/)[0].replace(/\/[^/]*$/, '') || '.'; try { return walk(base, []).filter((f) => re.test(f)); } catch (e) { return []; } },
        env: (name, dflt) => { const v = sys().env(String(name)); return v === undefined ? (dflt === undefined ? null : dflt) : v; },
        os: () => sys().os(),
        cd: (p) => { ctx.cwd = String(p); return null; },
        newer: (a, b) => { const x = sys().mtime(String(a)), y = sys().mtime(String(b)); return x !== null && (y === null || x > y); },
        invoke: (name) => { runTask(ctx, String(name)); return null; },
    };
    // suave(...) is sh("suave", ...), run with this same Deno and Suave
    dsl.suave = (...args) => {
        const [pos, o] = split(args);
        const main = sys().env('SUAVE_MAIN');
        const flatArgs = flat(pos).map(String);
        const cmdText = 'suave ' + flatArgs.map(quote).join(' ');
        if (!o.quiet) sys().out('  $ ' + cmdText + '\n');
        const code = run(Deno.execPath(), ['run', '-A', '--quiet', '--v8-flags=--stack-size=7000', main].concat(flatArgs), { cwd: ctx.cwd });
        if (code !== 0 && o.check !== false) throw rt.rtError('suave ' + flatArgs.join(' ') + ' failed (exit ' + code + ')', 'LakeError');
        return code;
    };
    dsl.laker = (...args) => {
        const [pos, o] = split(args);
        const main = sys().env('SUAVE_MAIN');
        const flatArgs = ['laker'].concat(flat(pos).map(String));
        if (!o.quiet) sys().out('  $ laker ' + flat(pos).map(String).map(quote).join(' ') + '\n');
        const code = run(Deno.execPath(), ['run', '-A', '--quiet', '--v8-flags=--stack-size=7000', main].concat(flatArgs), { cwd: ctx.cwd });
        if (code !== 0 && o.check !== false) throw rt.rtError('laker ' + flat(pos).join(' ') + ' failed (exit ' + code + ')', 'LakeError');
        return code;
    };
    return dsl;
}

export function loadLakefile(path, args, vars) {
    const ctx = { tasks: new Map(), def: null, cwd: undefined, done: new Set(), stack: [], file: path };
    const scope = interp.newScope();
    const dsl = makeDsl(ctx);
    for (const k of Object.keys(dsl)) scope.def(k, dsl[k], false);
    scope.def('args', args || [], false);
    const m = new rt.SMap(); for (const k of Object.keys(vars || {})) m.set(k, vars[k]);
    scope.def('vars', m, false);
    scope.def('lake_dir', path.replace(/\/[^/]*$/, '') || '.', false);
    const src = sys().readText(path);
    const prevCwd = sys().cwd();
    runProgram(src, path, scope);
    ctx.dir = prevCwd;
    return ctx;
}

function runTask(ctx, name, io) {
    const t = ctx.tasks.get(name);
    if (!t) {
        // a name that is an existing file with no task is fine as a need
        if (sys().exists(name)) return;
        const near = Array.from(ctx.tasks.keys()).filter((k) => k.startsWith(name.slice(0, 2))).slice(0, 3);
        throw rt.rtError('There is no task called "' + name + '"' + (near.length ? '. Did you mean ' + near.join(' or ') + '?' : '. Run lake -l to see them'), 'LakeError');
    }
    if (ctx.done.has(name)) return;
    if (ctx.stack.includes(name)) throw rt.rtError('Tasks that need each other in a circle: ' + ctx.stack.concat([name]).join(' -> '), 'LakeError');
    ctx.stack.push(name);
    for (const n of t.needs) runTask(ctx, n, io);
    ctx.stack.pop();
    // a file task is skipped when the file is newer than everything it needs
    if (t.file && sys().exists(name)) {
        const mine = sys().mtime(name);
        const stale = t.needs.some((n) => { const x = sys().mtime(n); return x !== null && x > mine; });
        if (!stale) { ctx.done.add(name); if (!ctx.quiet) sys().out('==> ' + name + ' (up to date)\n'); return; }
    }
    ctx.done.add(name);
    if (!ctx.quiet) sys().out('==> ' + name + (t.desc ? '   ' + t.desc : '') + '\n');
    if (ctx.dry) return;
    const t0 = Date.now();
    if (t.run) rt.call(t.run, []);
    if (!ctx.quiet && t.run) sys().out('    done in ' + ((Date.now() - t0) / 1000).toFixed(2) + 's\n');
}

export function lakeMain(argv) {
    const out = (s) => sys().out(s + '\n'), eout = (s) => sys().errOut(s + '\n');
    let file = null, list = false, dry = false, quiet = false, init = false;
    const names = [], vars = {}, extra = [];
    let rest = false;
    for (let i = 0; i < argv.length; i++) {
        const a = argv[i];
        if (rest) { extra.push(a); continue; }
        if (a === '--') rest = true;
        else if (a === '-f' || a === '--file') file = argv[++i];
        else if (a === '-l' || a === '--list' || a === '-T') list = true;
        else if (a === '-n' || a === '--dry-run') dry = true;
        else if (a === '-q' || a === '--quiet') quiet = true;
        else if (a === 'init' && !names.length) init = true;
        else if (/^[A-Za-z_]\w*=/.test(a)) { const k = a.slice(0, a.indexOf('=')); vars[k] = a.slice(a.indexOf('=') + 1); }
        else names.push(a);
    }
    if (init) { try { out('Created ' + newLakefile('Lakefile') + '. List its tasks with:  lake -l'); } catch (e) { eout(e.message); sys().exit(1); } return;  }
    const path = file || findLakefile();
    if (!path) { eout('I could not find a Lakefile here or in any folder above. Make one with:  lake init'); sys().exit(1); return; }
    let ctx;
    try { ctx = loadLakefile(path, extra, vars); } catch (e) { eout(rt.formatError ? rt.formatError(e) : (e.message || String(e))); sys().exit(1); return; }
    ctx.dry = dry; ctx.quiet = quiet;
    const dir = path.replace(/\/[^/]*$/, '');
    if (list) {
        const ts = Array.from(ctx.tasks.values()).filter((t) => !t.file || t.desc);
        const w = Math.max(4, ...ts.map((t) => t.name.length)) + 2;
        out('Tasks in ' + path + ':');
        for (const t of ts) out('  ' + (t.name === ctx.def ? '*' : ' ') + ' ' + t.name.padEnd(w) + (t.desc || '') + (t.needs.length ? '   (needs ' + t.needs.join(', ') + ')' : ''));
        if (ctx.def) out('\n  * runs when you type just  lake');
        return;
    }
    if (!names.length) { if (ctx.def) names.push(ctx.def); else { eout('Which task? Run  lake -l  to see them' + (ctx.tasks.size ? '' : ' (this Lakefile has none yet)')); sys().exit(1); return; } }
    const here = sys().cwd();
    try {
        if (dir && dir !== path) sys().chdir(dir || '.');
        for (const n of names) runTask(ctx, n);
    } catch (e) {
        eout('\nLake stopped: ' + (e && e.message ? e.message : String(e)));
        if (e && e.line) eout('  (Lakefile line ' + e.line + ')');
        sys().exit(1);
    } finally { try { sys().chdir(here); } catch (e) { /* ignore */ } }
}
