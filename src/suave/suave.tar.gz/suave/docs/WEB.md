# Suave on the web

## In a page

```html
<div id="root"></div>
<script src="suave.js"></script>
<script type="text/suave">
    use std.dom
    dom.text(dom.query("#root"), "Hello from Suave!")
</script>
```

`suave.js` is the whole language and standard library in one file (about 280 KB). Build it with `deno task bundle` (it lands in `dist/suave.js`), or let `suave build` do it.

- **Opening a page from disk (file://)** works too: browsers will not let such a page read other files, so write a *twin* beside each Suave file it loads with `suave twin app.wsv components/counter.xsv` (it makes `app.wsv.js`, which a plain `<script>` can load). Suave finds the twins by itself, including the files a page brings in with `use "./counter.xsv"`. `suave build app.wsv` already puts everything inside `index.html`, so it needs no twins.
- Several `<script type="text/suave">` tags share one scope, in order. `src="app.sv"` loads a file.
- A tag with `data-module="util.sv"` is not run; it is a module for `use "./util.sv"`.
- `print` writes to the browser console, and also into an element with `id="suave-output"` if the page has one.
- A program error shows in a red box at the bottom of the page, with the line and source.
- From JavaScript: `Suave.run(code)` and `Suave.eval(code)`.

## The easy web (`std.web`): start here if websites are new to you

You do not need to know HTML, callbacks or promises. `use std.web` gives plain words for the common jobs:

```suave
use std.web

# 1. Start a website with one line (a page, a folder, or several addresses)
web.serve(web.page("Hello", web.h1("Welcome!"), web.p("This is my first site.")))
web.serve("public")                                  # share a folder
web.serve({"/": "<h1>Home</h1>", "/time": || time.now(), "POST /save": |req| {got: req.json}})
web.serve(|req| "Hello from " + req.path)            # answer every address
```

```suave
# 2. Read things from the web (put `await` in front)
let text = await web.get("https://example.com")
let data = await web.json("https://api.example.com/items")
let reply = await web.post("https://api.example.com/save", {name: "Sam"})
if await web.is_up("https://example.com"): print("it works!")
```

```suave
# 3. Build pages with words instead of tags (your text is made safe for you)
web.page("Shop",
    web.h1("Today's fruit"),
    web.list(["apple", "pear"]),
    web.table([["apple", 3], ["pear", 5]], ["Fruit", "Price"]),
    web.p("See ", web.link("our map", "https://example.com/map")))
```

```suave
# 4. In a browser page: put things on screen, one word each
web.heading("Greeter")
web.input("Your name", |name| web.say("Hello " + name + "!"))
web.button("Click me", || web.say("Clicked!"))
```

- `web.get` `web.json` `web.post` `web.put` `web.delete` give back the answer, and a failure says what went wrong (`404 Not Found`). `web.is_up(url)` and `web.status(url)` never fail.
- `web.page` `h1` `h2` `h3` `p` `bold` `italic` `code` `quote` `box` `link` `image` `list` `numbered` `table` `line` `br` build HTML for you. Text you give is always made safe, and the helpers can be nested. `web.safe("<b>x</b>")` lets in HTML you wrote yourself.
- `web.serve` takes a folder name, a page, a map of addresses (`"/about"`, or `"POST /save"` for a form or data), or a function. Add `open: true` to open your browser. `web.open(url)` opens one.
- `web.form_value(req, "name", "friend")` reads what a visitor sent. `web.query`, `web.link_to`, `web.parts`, `web.encode` and `web.decode` handle addresses.
- **Keydown:** `web.ktext("# Hello\n**bold** and #C#a chip#")` (also `web.keydown`) turns Keydown text into HTML you can put anywhere in a page. If the page loads `Keydown.js` the whole Keydown language works (every chip, badge, block and style); otherwise a small built-in version handles headings, lists, tasks, quotes, code blocks, bold, italic, underline, strike, code, links, chips and badges. In a browser, `web.say_ktext(text)` puts it on the page.
- Browser only: `say say_ktext heading button input picture add_link clear title add_css`. `web.after(2, f)` runs something later and `web.every(1, f)` repeats it.
- Outside a browser, a page function tells you so and points you to `web.serve`.

### Styling with CSS

`web.page` comes with a clean built-in look (readable text, tidy tables, round buttons, a `.box` class). To change it you add CSS, and there are four ways, from easiest to most flexible:

```suave
use std.web

# 1. Write the CSS as a map (no braces or semicolons to get wrong). Use _ for dashes: font_size is font-size.
let look = web.css({
    ".card": {border: "2px solid teal", padding: "1rem", border_radius: "12px"},
    "h1": {color: "teal"}
})

# 2. Give things a class with web.div / web.span, then style the class
let card = web.div("card", web.h2("Today"), web.p("Sunny!"))

# 3. Or style one thing right where it is
let note = web.styled("color: crimson; font-size: 1.4rem", "Careful!")

# 4. Hand the sheet to the page (it comes after the built-in look, so yours wins)
web.serve(web.page("My site", web.h1("Hello"), card, note, css: look))
```

- You can also write the sheet as plain text, `css: 'h1 { color: teal }'`, and `web.style(sheet)` makes a `<style>` you can put inside any part of a page.
- **Use single quotes (or `r"..."`) around CSS text.** Inside normal double quotes Suave treats `{ }` as a value to fill in, so `"h1 { color: red }"` is an error. `web.css({...})` avoids the problem completely.
- In a browser, `web.add_css(sheet)` adds a style sheet to the live page, and `web.div` / `web.styled` pieces can be placed on it with `web.say_ktext` or `dom.html`.
- Class names are cleaned (letters, numbers, `-` and `_` only) and text inside `web.styled` is escaped, so nothing can break out of its tag.
- In `.xsv` and `.wsv` files, CSS goes in the `style:` block and is scoped to that component, so you do not need `web.css` there.

When you want more control, `std.http` (servers, routes, callbacks) and `std.dom` (the whole page) are still there!

## File types: .sv, .xsv and .wsv

| File | What it is | How you use it |
| --- | --- | --- |
| `.sv` | a Suave program or module | `suave run app.sv`, or `use "./util.sv"` |
| `.xsv` | a **web component**: props, script, template and style in one file | `use "./counter.xsv"` makes `Counter`, then `<Counter/>` in a template |
| `.wsv` | a **web page or app**: the same parts plus a `<head>` | `suave serve app.wsv`, `suave build app.wsv -o dist` |

Suave is also a small web framework, and it is made so that someone new to websites can use it. The **easy style** has no tags to close: plain Suave at the left edge, and indented blocks named `page:`, `style:`, `props:` and `head:`.

```
# counter.xsv
props:
    start = 0

count = start

def inc():
    count += 1

page:
    div.counter:
        h2: Clicks: {count}
        button @click=inc: Click me
        if count > 5:
            p: That is a lot of clicking!

style:
    .counter { padding: 1rem }
```

- A markup line is `tag.class#id attribute=value ...: text`. Leave out the tag and you get a `div`. Indented lines are its children.
- `"quoted text"` (or `| text`) is a plain text line. `{name}` puts a value in.
- `if cond:`, `elif cond:`, `else:` and `for item in items:` hold the lines under them.
- `@click=handler` runs a function, `@click="count += 1"` runs a bit of code, `bind:value={name}` links a box to a variable, and `class:done={cond}` switches a class.
- A capital letter makes a component: `Counter start=5`. `slot` shows what was written between a component's tags.
- `title "My site"` at the top sets the browser tab title, and a `.wsv` is a whole page (`suave build`, `suave serve`).

If you already know HTML you can write the same thing with tags (below), and the two styles can even mix: the `page:` block of an easy file takes the same lines, and a `<template>` that has no `<` in it is read as easy markup.

### The HTML style

```xml
<props>
  start = 0                     <!-- values a parent can pass in, with defaults -->
</props>

<script>
count = start                   # ordinary Suave, in the component's own scope
def inc():
    count += 1
</script>

<template>
  <button class="big" on:click={inc}>Clicked {count} times</button>
</template>

<style>
  .big { padding: 8px 14px }    /* scoped to this component */
</style>
```

**Template syntax** (HTML plus `{expressions}`):

- `{expr}` in text, and `value={expr}` or `class="btn {kind}"` in attributes.
- Events: `on:click={handler}` or `@click={handler}` (a function; it gets the event if it has a parameter), or `@click="count += 1"` for a bit of code. The page redraws after every handler, and when you call `update()`.
- Two-way binding: `bind:value={name}` and `bind:checked={item.done}`.
- `class:done={item.done}` turns a class on and off.
- `if="count > 3"`, `else-if="..."`, `else`, and `for="item in items"` or `for="i, item in items"` on any element. `<block>` groups without adding an element.
- Child components: `<Counter start={5} on_change={handler}/>`, with `<slot/>` in the child for what is written between the tags. Names starting with a capital letter are components.
- A function called `on_mount()` in the script runs after the first draw, and `on_unmount()` when the component goes away.
- Styles are scoped to the component (they only touch its own elements). Write `:global(body)` to reach outside.
- A `.wsv` page also takes a `<head>` (title, meta, links) and mounts into `#app`.

```sh
suave new my-app --web        # a project with app.wsv and a counter component
suave serve app.wsv           # build it and serve it at http://localhost:8000
suave build app.wsv -o dist   # dist/index.html (the page and every component it uses are inside) + dist/suave.js
suave check app.wsv           # look for mistakes in the script, the expressions and the handlers
```

By hand, in any page: `<script type="text/suave" src="app.wsv"></script>` mounts a page into `#app`, and `<script type="text/suave" src="counter.xsv" data-mount="#box"></script>` mounts one component. From Suave code: `dom.mount(Counter, "#box", {start: 5})`. `dom.render_html(Counter, {start: 5})` gives a component's HTML as text, with no browser needed (handy in tests).

Limits: no `await` inside a template (do the waiting in the script and call `update()`), no named slots, and a component redraws as a whole tree (fine for ordinary pages, not for thousands of rows).

## The app framework (`std.dom`)

An app is three things: a **state**, a **view** that draws it, and an **update** that changes it.

```suave
use std.dom

fn view(state, dispatch) {
    dom.h("div", {}, [
        dom.h("h1", {}, ["Count: {state}"]),
        dom.h("button", {on_click: |e| dispatch("up")}, ["+1"]),
    ])
}
fn update(state, msg) = match msg { "up" => state + 1, _ => state }

dom.app("#root", 0, view, update)
```

- `dom.h(tag, props, children)` makes a virtual node. Props: `class`, `style` (a map like `{fontFamily: "serif"}`), `value`, `checked`, `text`, any attribute, and `on_click`, `on_input`, `on_change`, `on_submit`... for events. An event is a map with `value`, `checked`, `key`, `x`, `y`, `target` and the functions `prevent()` and `stop()`.
- After every `dispatch(msg)` the page is patched, not rebuilt, so inputs keep focus.
- `dom.query`, `dom.query_all`, `dom.create`, `dom.on`, `dom.text`, `dom.attr`, `dom.add_class`, `dom.value`, `dom.delegate`, `dom.download` and more work on real elements if you prefer.

## Using JavaScript libraries (`std.js`)

`use std.js` lets Suave call any JavaScript on the page: `js.global("Math")`, `js.get(obj, "a.b")`, `js.set(obj, "x", 5)`, `js.call(obj, "method", args...)`, `js.new("Uint8Array", data)`, `js.import(url)` (a module from a URL) and `js.load_script(url)`. Objects stay opaque (you hold them and pass them back), maps and lists become plain JavaScript on the way in, functions become JavaScript functions, and promises are futures, so `await` works. `examples/pdf-annotator/` uses it to drive pdf.js and pdf-lib.

## Drawing (`std.canvas`)

```suave
use std.canvas
let c = canvas.new(400, 300)
c.fill_style("tomato").fill_circle(200, 150, 60)
c.loop(|dt| c.clear("#111").fill_style("white").text("{(1 / dt).round()} fps", 10, 20))
```

## Talking to servers (`std.http`)

Requests use callbacks that receive a `Result`:

```suave
use std.http
http.get_json("https://example.com/api/items", |result| {
    match result {
        Ok(items) => print(items.len()),
        Err(message) => print("failed: {message}")
    }
})
```

## Saving data (`std.storage`)

`storage.set("key", value)` and `storage.get("key", default)` keep any value in the browser's localStorage (in the terminal they use a `.suave-storage.json` file).

## Servers

```suave
use std.http
let app = http.app()
app.get("/hi/:name", |req| "Hello, {req.params.name}!")
app.get("/api/items", |req| [1, 2, 3])               // data becomes JSON
app.post("/api/echo", |req| {got: req.json})
app.static("/files", "./public")
app.listen(8080)
```

A handler gives back text (HTML if it starts with `<`), data (sent as JSON), or `http.json(x, 201)`, `http.redirect("/")`, `http.file("a.png")`, `http.status(404, "no")`.

## Building and serving a project

```sh
suave new todo --web          # index.html + app.sv + suave.suvl
cd todo
suave build app.sv -o dist
suave serve dist              # http://localhost:8000
```
