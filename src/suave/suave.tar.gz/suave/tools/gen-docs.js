// Writes docs/STDLIB.md from the real modules, so the list can never go out of date:  deno run -A tools/gen-docs.js
import rt from '../src/runtime.js';
import '../src/index.js';
import { stdlib } from '../src/stdlib/index.js';

const DESC = {
    json: 'Read and write JSON, with exact line and column errors, a lenient mode (comments, trailing commas), JSON Lines and big integers.',
    yaml: 'YAML 1.2: block and flow collections, quoted, plain and block text, anchors, merge keys and several documents.',
    toml: 'TOML 1.0: tables, arrays of tables, dotted keys, inline tables, every string kind and dates.',
    suvl: "Suave's own data format: friendly like YAML, exact like JSON, typed like TOML (durations, sizes, dates). See docs/SUVL.md.",
    csv: 'CSV and TSV with quoted fields, headers into maps and optional type guessing.',
    data: 'Change between formats (json, yaml, toml, suvl, csv), load and save files by their extension, guess a format.',
    xml: 'Parse and write XML, find tags, follow paths, turn a tree into a map.', ini: 'INI and config files.',
    table: 'Data frames: filter, sort, group, join, summarize and print tables of rows. Reads CSV.',
    math: 'Functions and constants, primes, factors, combinatorics, root finding, integration. Works with complex numbers too (sqrt(-4) is 2i).', stats: 'Mean, median, spread, correlation, regression, percentiles, histograms.',
    linalg: 'Matrices and vectors: multiply, invert, solve, determinant, rank.', random: 'Seedable random numbers, choices, shuffles, distributions, dice.',
    bits: 'Bit operations and conversions.', bigint: 'Huge whole numbers: factorials, powers, primes, modular maths.', complex: 'More for complex and imaginary numbers (3 + 4i is part of the language): roots, polynomial roots, the Fourier transform, the Mandelbrot test.', rational: 'Exact fractions with + - * /.',
    unit: 'Convert between length, mass, time, data, volume, area, speed, energy, pressure, angle and temperature.', geometry: 'Distances, polygons, convex hulls, intersections, map distances.',
    text: 'Wrap, slug, case changes, edit distance, word counts, human-friendly numbers and sizes.', fmt: 'printf-style formatting, money, Roman numerals, number words, text tables and boxes.',
    regex: 'Regular expressions with named groups, global replace and split.', markdown: 'Turn Markdown into HTML; headings, links and table of contents.',
    template: 'Mustache-style templates: {{name}}, {{#each}}, {{#if}}, {{else}}.', diff: 'Line, word and character differences and unified patches.',
    encoding: 'Base64, hex, URL and HTML escaping, UTF-8 bytes, Base32, Morse.', url: 'Parse, build and join URLs and query strings.', color: 'Parse and mix colors, lighten, contrast, gradients, palettes.',
    semver: 'Parse, compare, bump and match semantic versions.', hash: 'SHA-256, SHA-1, MD5, HMAC, CRC32 and friends (pure JavaScript, also in browsers).', crypto: 'Random bytes, tokens, passwords, key stretching.', uuid: 'UUID v4 and v7.',
    ds: 'Stacks, queues, deques, heaps, LRU caches, counters, tries, union-find, ring buffers, sorted lists.', graph: 'Graphs: search, shortest paths, topological order, cycles, spanning trees.',
    iter: 'Lazy and combinatorial sequences: count, cycle, permutations, combinations, product, run lengths.', func: 'compose, curry, partial, memoize, juxt, trampoline and more.',
    algo: 'Classic algorithms: LIS, LCS, knapsack, n-queens, search, intervals, Luhn.', events: 'Event emitters.', plot: 'Charts in the terminal (bars, lines, histograms, sparklines) and SVG output.',
    fs: 'Files and folders: read, write, list, walk, glob, copy, remove, temp folders.', path: 'Work with file paths as text.', os: 'Which system you are on.', env: 'Environment variables and .env files.',
    process: 'Run other programs, read arguments, exit.', io: 'Ask the user questions, read standard input.', term: 'Colors, cursor control, progress bars, terminal size.',
    time: 'Clock, sleep, timers (after, every), stopwatch, benchmarks, retry, durations.', date: 'Dates and times: parse, format, add, difference, calendars, "3 days ago".',
    log: 'Leveled logging with fields, colors, files and JSON lines.', cli: 'Command-line option parsing with help text.', test: 'Extra assertions for test blocks.', storage: "A tiny key-value store (a file in the terminal, localStorage in a browser).",
    pool: 'Ready-made pools: dice, coins, weighted choices, random numbers, shuffles, deals. A pool is decided when it is first used (docs/POOLS.md).',
    async: 'Futures: wait for many (all, race, settle), time out, retry, limit how many run at once, channels and locks.',
    quantum: 'A quantum computer you can run: qubit registers, gates, entanglement, measurement, circuit diagrams, Grover, Deutsch-Jozsa, Bernstein-Vazirani, teleportation and Shor (docs/QUANTUM.md).',
    qm: 'Quantum mechanics: hydrogen, particles in boxes, oscillators, tunneling, the Schrodinger equation, wave packets, spin, complex matrices and Hermitian eigenvalues.',
    sound: 'Play sounds: sine, square, triangle and mole waves from numbers, and sound files from GitHub (sound.git), Mintcode (sound.mint) or your own folders (sound.file, relative to the program). await waits until the sound ends.',
    web: 'The web made simple for beginners: fetch with await web.get(url), build pages with no tags (web.page, web.h1, web.list), start a site with web.serve(...), and web.say / web.button / web.input in a browser.',
    http: 'Web requests and a web server with routes (callbacks for requests; a router for servers).', dom: 'Web pages: find elements, events, and a small app framework (state, view, update).', canvas: 'Drawing on a canvas, animation loops.',
};
const GROUPS = [
    ['Data formats', ['json', 'yaml', 'toml', 'suvl', 'csv', 'data', 'xml', 'ini', 'table']],
    ['Numbers and science', ['math', 'stats', 'linalg', 'random', 'bits', 'bigint', 'complex', 'rational', 'unit', 'geometry']],
    ['Quantum', ['quantum', 'qm']],
    ['Pools and futures', ['pool', 'async']],
    ['Text', ['text', 'fmt', 'regex', 'markdown', 'template', 'diff', 'encoding', 'url', 'color', 'semver']],
    ['Codes and keys', ['hash', 'crypto', 'uuid']],
    ['Collections and flow', ['ds', 'graph', 'iter', 'func', 'algo', 'events', 'plot']],
    ['The machine', ['fs', 'path', 'os', 'env', 'process', 'io', 'term', 'time', 'date', 'log', 'cli', 'test', 'storage', 'sound']],
    ['The web', ['web', 'http', 'dom', 'canvas']],
];
let total = 0, fnTotal = 0;
const lines = ['# The Suave standard library', '', 'This page is written by `tools/gen-docs.js` from the real modules. Run `suave doc std.json` for any module, and use one with `use std.json`.', ''];
for (const [group, names] of GROUPS) {
    lines.push('## ' + group, '');
    for (const n of names) {
        const mod = stdlib['std.' + n](rt);
        const keys = Object.keys(mod);
        const fns = keys.filter((k) => typeof mod[k] === 'function').sort();
        const vals = keys.filter((k) => typeof mod[k] !== 'function').sort();
        total++; fnTotal += fns.length;
        lines.push('### std.' + n, '', DESC[n] || '', '', '`use std.' + n + '`  (' + keys.length + ' things)', '');
        if (vals.length) lines.push('Values: ' + vals.map((v) => '`' + v + '`').join(', '), '');
        if (fns.length) lines.push('Functions: ' + fns.map((f) => '`' + f + '`').join(', '), '');
    }
}
lines.splice(3, 0, '**' + total + ' modules, ' + fnTotal + ' functions.**', '');
Deno.writeTextFileSync(import.meta.dirname + '/../docs/STDLIB.md', lines.join('\n'));
console.log(total + ' modules, ' + fnTotal + ' functions written to docs/STDLIB.md');
