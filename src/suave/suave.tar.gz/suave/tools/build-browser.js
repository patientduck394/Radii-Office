// Builds dist/suave.js, the whole language in one file for web pages:  deno task bundle
const root = import.meta.dirname + '/../';
const r = new Deno.Command(Deno.execPath(), { args: ['bundle', '--platform=browser', '--format=iife', '--minify', '-o', root + 'dist/suave.js', root + 'src/browser.js'], stdout: 'inherit', stderr: 'inherit' }).outputSync();
if (!r.success) Deno.exit(1);
// plain ASCII only, so the file works on any page whatever its character set
const code = Deno.readTextFileSync(root + 'dist/suave.js').replace(/[\u0080-\uffff]/g, (c) => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
Deno.writeTextFileSync(root + 'dist/suave.js', code);
const size = Deno.statSync(root + 'dist/suave.js').size;
console.log('Built dist/suave.js (' + Math.round(size / 1024) + ' KB)');
