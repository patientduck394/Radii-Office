#!/bin/sh
# Rebuilds src/stdlib/audio/suave-audio-mac (the small program that keeps the Mac sound card open so Suave sounds start at once).
# Needs the Swift compiler (Xcode or its command line tools).   Run:  sh tools/build-audio-mac.sh
set -e
cd "$(dirname "$0")/../src/stdlib/audio"
swiftc -O -target arm64-apple-macos11 suave-audio-mac.swift -o /tmp/suave-audio-arm
swiftc -O -target x86_64-apple-macos11 suave-audio-mac.swift -o /tmp/suave-audio-x86
lipo -create /tmp/suave-audio-arm /tmp/suave-audio-x86 -output suave-audio-mac
chmod +x suave-audio-mac
rm -f /tmp/suave-audio-arm /tmp/suave-audio-x86
echo "Built $(pwd)/suave-audio-mac"
