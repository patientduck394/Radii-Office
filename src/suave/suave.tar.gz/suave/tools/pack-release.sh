#!/bin/sh
# Builds release/suave.tar.gz (+ its checksum): the file install.sh downloads.   Run:  sh tools/pack-release.sh [publish-folder]
#   With a folder (like ../radii-office\ deployment/suave) it also copies install.sh, the tarball and the checksum there.
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
OUT="$ROOT/release"
rm -rf "$OUT" && mkdir -p "$OUT/stage"
# the whole program, docs and small examples (not the 70 MB of Keydown.js / app builds)
tar -c --exclude='.laker-dev' --exclude='build' --exclude='.DS_Store' --exclude='node_modules' --exclude='release' \
    --exclude='examples/keydown-editor/Keydown.js' --exclude='examples/keydown-editor/suave.js' --exclude='examples/pdf-annotator/suave.js' \
    --exclude='examples/keydown-editor/icon.png' \
    bin src dist docs examples tests tools playground deno.json LICENSE README.md install.sh "Install Suave.command" | (cd "$OUT/stage" && mkdir suave && cd suave && tar -x)
(cd "$OUT/stage" && tar -czf "$OUT/suave.tar.gz" suave)
rm -rf "$OUT/stage"
if command -v shasum >/dev/null 2>&1; then (cd "$OUT" && shasum -a 256 suave.tar.gz > suave.tar.gz.sha256); else (cd "$OUT" && sha256sum suave.tar.gz > suave.tar.gz.sha256); fi
cp install.sh "$OUT/install.sh"
echo "Built $OUT/suave.tar.gz ($(du -h "$OUT/suave.tar.gz" | cut -f1))"
if [ -n "$1" ]; then mkdir -p "$1" && cp "$OUT/suave.tar.gz" "$OUT/suave.tar.gz.sha256" "$OUT/install.sh" "$1/" && echo "Copied to $1"; fi
