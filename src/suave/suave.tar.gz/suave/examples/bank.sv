// Structs, traits, errors and Results working together.
struct Account { owner, balance = 0 }

impl Account {
    fn deposit(self, amount) {
        if amount <= 0 { return Err("deposit must be positive") }
        self.balance += amount
        Ok(self.balance)
    }
    fn withdraw(self, amount) {
        if amount > self.balance { return Err("insufficient funds: have {self.balance}, need {amount}") }
        self.balance -= amount
        Ok(self.balance)
    }
    fn to_str(self) = "{self.owner}: ${self.balance:.2f}"
}

fn transfer(from, to, amount) {
    from.withdraw(amount)?
    to.deposit(amount)?
    Ok("moved {amount}")
}

let a = Account("Ada", 100)
let b = Account("Bob")
print(transfer(a, b, 30))
print(transfer(a, b, 500))
print(a, b)
