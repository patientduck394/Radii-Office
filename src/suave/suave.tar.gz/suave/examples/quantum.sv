// A tour of the quantum computer: run it with  suave run examples/quantum.sv
use std.quantum as q
use std.random

random.seed(7)

print("=== Entanglement: a Bell pair ===")
let bell = q.bell()
print(bell.draw())
print("state:", bell)
print("counts over 1000 measurements:", bell.sample(1000))
print("qubit 0 is entangled with qubit 1:", bell.entanglement(0), "bit")

print("\n=== Grover's search: find 11 among 16 ===")
let g = q.grover(4, [11])
print("found {g.found} (bits {g.found_bits}) with probability {g.probability:.4f} after {g.iterations} rounds")
print(g.register.draw())

print("\n=== Deutsch-Jozsa: constant or balanced, in ONE question ===")
print(q.deutsch_jozsa(4, |x| 1).verdict, "and", q.deutsch_jozsa(4, |x| x % 2).verdict)

print("\n=== Teleporting a qubit ===")
let t = q.teleport(0.6, 0.8)
print("sent bits {t.bits_sent}, fidelity {t.fidelity:.6f}")

print("\n=== Shor: factoring with a quantum computer ===")
for n in [15, 21, 35] {
    let r = q.shor(n)
    print("{n} = {r.factors[0]} x {r.factors[1]}   ({r.method})")
}

print("\n=== A measurement that happens only when you look ===")
let r = q.register(1).h(0)
let outcome = r.measure_later(0)       // a pool: nothing is measured yet
print("before looking:", r.probs())
print("you look:", outcome)            // now it is measured, for real
print("after looking:", r.probs())
