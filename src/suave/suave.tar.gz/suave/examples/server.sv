// A tiny web server:  suave run examples/server.sv   then open http://localhost:8080
use std.http

let app = http.app()
var visits = 0

app.get("/", |req| {
    visits += 1
    "<h1>Hello from Suave!</h1><p>You are visitor number {visits}.</p><p><a href='/api/time'>time</a> · <a href='/hi/Ada'>greeting</a></p>"
})
app.get("/hi/:name", |req| "Hello, {req.params.name}!")
app.get("/api/time", |req| {now: time.now(), visits})
app.post("/api/echo", |req| {you_sent: req.json})

use std.time
app.listen(8080)
