// async and await.
use std.async
use std.time

async fn fetch_price(item, secs) {
    await async.delay(secs)             // pretend this is a slow network call
    {item, price: secs * 100}
}

let start = time.clock()
// one after another: slow
let a = await fetch_price("apple", 0.2)
let b = await fetch_price("pear", 0.2)
print("sequential:", a.price + b.price, "in", ((time.clock() - start) / 1000).round(1), "s")

// all at once: fast
let t2 = time.clock()
let all = await async.all([fetch_price("apple", 0.2), fetch_price("pear", 0.2), fetch_price("plum", 0.2)])
print("together:", all.map(|r| r.item), "in", ((time.clock() - t2) / 1000).round(1), "s")

// a timeout, and a retry
try { await async.timeout(fetch_price("slow", 2), 0.1) } catch e { print("gave up:", e.message) }
var tries = 0
async fn flaky() { tries += 1; if tries < 3 { throw "not yet" }; "ok after {tries} tries" }
print(await async.retry(flaky, times: 5))

// two tasks talking through a channel
let ch = async.channel()
async fn producer() { for i in 1..=3 { await async.delay(0.05); ch.send("message {i}") }; ch.close() }
let p = producer()
loop {
    let msg = await ch.recv()
    if msg == none { break }
    print("got", msg)
}
await p
