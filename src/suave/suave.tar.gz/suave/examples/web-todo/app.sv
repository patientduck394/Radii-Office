// A to-do list web app. Build it:  suave build examples/web-todo/app.sv -o dist  and  suave serve dist
use std.dom
use std.storage

let saved = storage.get("todos", [])

fn view(state, dispatch) {
    let left = state.items.filter(|t| not t.done).len()
    dom.h("div", {style: {maxWidth: "26rem", margin: "2rem auto", fontFamily: "system-ui"}}, [
        dom.h("h1", {}, ["To do ({left} left)"]),
        dom.h("form", {on_submit: |e| { e.prevent(); dispatch(("add", state.draft)) }}, [
            dom.h("input", {value: state.draft, placeholder: "What needs doing?", on_input: |e| dispatch(("draft", e.value)), style: {width: "70%"}}),
            dom.h("button", {}, ["Add"]),
        ]),
        dom.h("ul", {style: {listStyle: "none", padding: "0"}}, state.items.enumerate().map(|(i, t)|
            dom.h("li", {}, [
                dom.h("label", {style: {textDecoration: if t.done { "line-through" } else { "none" }}}, [
                    dom.h("input", {type: "checkbox", checked: t.done, on_change: |e| dispatch(("toggle", i))}),
                    " {t.text} ",
                ]),
                dom.h("button", {on_click: |e| dispatch(("remove", i))}, ["×"]),
            ])
        )),
    ])
}

fn update(state, msg) {
    let next = match msg {
        ("draft", text) => {*state, draft: text},
        ("add", text) => if text.trim() == "" { state } else { {items: state.items + [{text: text.trim(), done: false}], draft: ""} },
        ("toggle", i) => {*state, items: state.items.enumerate().map(|(k, t)| if k == i { {*t, done: not t.done} } else { t })},
        ("remove", i) => {*state, items: state.items.enumerate().filter(|(k, t)| k != i).map(|(k, t)| t)},
        _ => state
    }
    storage.set("todos", next.items)
    next
}

dom.app("#root", {items: saved, draft: ""}, view, update)
