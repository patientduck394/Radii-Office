// One value, five formats: JSON, YAML, TOML, SUVL and CSV.
use std.json
use std.yaml
use std.toml
use std.suvl
use std.csv

let people = [
    {name: "Ada", age: 36, langs: ["en", "fr"]},
    {name: "Bob", age: 25, langs: ["en"]},
]

print("JSON:\n" + json.stringify(people, indent: 2))
print("\nYAML:\n" + yaml.stringify(people))
print("TOML:\n" + toml.stringify({people: people}))
print("SUVL:\n" + suvl.stringify({people: people}))
print("CSV:\n" + csv.stringify(people.map(|p| p.omit(["langs"]))))

// and back again: every format round-trips
assert_eq(json.parse(json.stringify(people)), people)
assert_eq(yaml.parse(yaml.stringify(people)), people)
assert_eq(suvl.parse(suvl.stringify({people: people})).people, people)
print("All formats read back the same data!")
