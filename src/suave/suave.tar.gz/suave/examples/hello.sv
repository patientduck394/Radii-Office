# Hello, Suave! Run it with:  suave run examples/hello.sv
name = "world"
print("Hello, {name}!")

def fizzbuzz(n):
    if n % 15 == 0:
        return "FizzBuzz"
    elif n % 3 == 0:
        return "Fizz"
    elif n % 5 == 0:
        return "Buzz"
    else:
        return str(n)

print(" ".join(fizzbuzz(n) for n in range(1, 16)))

class Dog:
    name: str
    age: num = 1

    def speak(self):
        return f"{self.name} (age {self.age}) says woof!"

print(Dog("Rex").speak())
