# Keydown Editor, written in Suave

`index.html` loads Keydown.js (which turns Keydown text into formatted pages), Suave and the app. The editor is one easy-style Suave file, `editor.wsv`.

- **Four views:** Split (Keydown text on the left, the formatted page on the right), Source, Visual (edit the formatted page itself) and View.
- **Syntax highlighting in the Source box:** headings, bold, italic, underline, strike, code, color chips, badges, links, math, quotes, list marks, tables, `::` blocks and code fences each get a color (cyan, blue and orange, with a night version). The highlighter is written in Suave too (`highlight_text` in `editor.wsv`), drawn in a layer behind a transparent text box so typing, selecting and scrolling stay exact.
- **Toolbar:** bold, italic, underline, strike, code, color chips, badges, headings, quotes, lists, tasks, code blocks, tables, dividers, note boxes, math and a table of contents. It works in Source and in Visual.
- **Files:** New, Open a `.kd` or text file, Save `.kd`, Export HTML, Print. Your work also autosaves in this browser.
- **Extras:** word count, a Keydown guide panel and a dark theme.

Double-click `index.html`: it works straight from disk (file://) because `editor.wsv.js` is a copy of the Suave file that a page opened from disk can load (`suave twin editor.wsv` refreshes it). `Keydown.js` is copied from `Web Projects/Keydown.js` (rebuild it with the Radii Office `scripts/build_keydown_js.mjs`, then copy it here again).

Suave talks to Keydown.js with `std.js`: `js.call(KD, "render", text)` draws the page and `js.call(KD, "editor", box, {...})` makes the Visual editor.
