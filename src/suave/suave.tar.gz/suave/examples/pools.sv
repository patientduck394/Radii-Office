// Pools: values that are decided when they are first used.
use std.random
random.seed(2026)

let weather = pool ["rain", "sun", "snow"]
print(inspect(weather))                    // nothing decided yet

fn advice(w) = if w == "rain" { "take an umbrella" } else { "no umbrella needed" }
let plans = [weather, weather]             // storing it decides nothing
print(len(plans), inspect(weather))

print("Today:", advice(weather))           // using it decides, once
print(inspect(weather), "- and it stays:", weather, weather)

weather.forget()                           // undecided again
let die = pool 1..=6
fn roll() { die.forget(); die + 0 }      // forget, then use: a fresh decision each time
print("rolls:", [roll() for _ in 1..10])

let loaded = pool {"heads": 9, "tails": 1}
print(loaded.chances(), "most likely:", loaded.most_likely())
print(loaded.simulate(1000))

// entangled pools always agree
let shirt = pool ["red", "green", "blue"]
let shoes = pool ["white", "black", "grey"]
entangle(shirt, shoes)
print("{shirt} with {shoes}")
