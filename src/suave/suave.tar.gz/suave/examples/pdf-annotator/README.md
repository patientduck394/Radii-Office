# Suave PDF Annotator

A PDF annotator written in Suave. `index.html` is just a page that loads Suave (`suave.js`) and the app (`annotator.wsv`), and the whole app is that one Suave file, written in the easy `.wsv` style.

- Open a PDF, flip pages, zoom and fit.
- Pen, highlighter, box, oval, arrow, text notes and an eraser, in 8 colors and 5 sizes, with undo and redo.
- Save your marks as a `.json` file and load them again, save one page as a PNG, or save a flattened annotated PDF.

pdf.js (drawing the pages) and pdf-lib (writing the PDF) load from a CDN, so it needs an internet connection. Suave talks to them with `std.js`.

**Double-click `index.html` and it works**, even straight from disk (file://): `annotator.wsv.js` is a copy of the Suave file that a page opened from disk can load, because browsers do not let such pages read other files. After editing `annotator.wsv` run `suave twin annotator.wsv` (or `lake build`) to refresh it. Through a web server none of this is needed.

Run it: `lake` in this folder (builds `suave.js`, then serves it at http://localhost:8000), or copy `suave.js` from the Suave `dist/` folder next to `index.html` and open the folder with any web server.
