// Count the words in a text and chart the top ones.
use std.text
use std.plot

let story = """
    the quick brown fox jumps over the lazy dog while the dog sleeps
    and the fox runs far away from the quick dog
    """

let freq = text.word_freq(story)
let top = freq.items().sort_by(|p| -p[1]).take(5)
print("Top words:")
print(plot.bar(top, width: 20))
print("{freq.len()} different words, {text.count_words(story)} in all")
