// Complex and imaginary numbers.
use std.complex as cx
use std.math

let z = 3 + 4i
print(z, "has size", abs(z), "and angle", z.arg().round(4))
print("z * z =", z * z, "  z / (1 - 2i) =", z / (1 - 2i))
print("sqrt(-4) =", sqrt(-4), "  i squared =", 1i ** 2)
print("Euler: e^(i pi) + 1 =", (math.exp(1i * math.PI) + 1).round(12))
print("4th roots of unity:", cx.roots_of_unity(4).map(|r| r.round(6)))
print("x^2 + 2x + 5 = 0 has roots", cx.quadratic(1, 2, 5))

// the Mandelbrot set in text
for y in -10..=10 {
    var line = ""
    for x in -30..=10 {
        let n = cx.mandelbrot(x / 15 + (y / 8) * 1i, 30)
        line += if n >= 30 { "#" } else if n > 5 { "+" } else if n > 2 { "." } else { " " }
    }
    print(line)
}
