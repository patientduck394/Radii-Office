// async and await.
use std.async
use std.time

async fn double_later(x, secs = 0.01) {
    await async.delay(secs)
    x * 2
}

test "await gives the value of a future" {
    assert_eq(await double_later(21), 42)
    let f = double_later(1)
    assert_eq(type(f), "future")
    assert_eq(await f, 2)
    assert_eq(await 5, 5)                       // awaiting a plain value gives it back
    assert_eq(await none, none)
    assert_eq(await async { 1 + 1 }, 2)
    assert_eq(await (async |x| x + 1)(1), 2)
}

test "await works inside every kind of statement" {
    var log = []
    for i in 1..=3 { log.push(await double_later(i)) }
    assert_eq(log, [2, 4, 6])
    var n = 0
    while n < 4 { n += await double_later(1) }
    assert_eq(n, 4)
    let got = if await double_later(2) > 3 { "big" } else { "small" }
    assert_eq(got, "big")
    let m = match await double_later(3) { 6 => "six", _ => "other" }
    assert_eq(m, "six")
    assert_eq("{await double_later(4)}!", "8!")
    assert_eq([await double_later(1), await double_later(2)], [2, 4])
    assert_eq({a: await double_later(5)}, {a: 10})
    assert_eq(await double_later(1) + await double_later(2) * 2, 10)
    assert_eq((await double_later(1)).to_str(), "2")
    var total = 0
    for x in [1, 2, 3] { if x == 2 { continue }; total += await double_later(x) }
    assert_eq(total, 8)
    assert_eq(await double_later(0) or "falsy", 0)      // 0 is true in Suave: only false and none are false
    let lazy = false and await double_later(1)
    assert_eq(lazy, false)
}

test "errors travel through futures" {
    async fn bad() { await async.delay(0.01); throw "bad" }
    var caught = none
    try { await bad() } catch e { caught = e }
    assert_eq(caught, "bad")
    async fn bad_map() { throw {code: 7} }
    try { await bad_map() } catch {code} { assert_eq(code, 7) }
    async fn nested() { await bad() }
    try { await nested() } catch e { assert_eq(e, "bad") }
    var after = 0
    try { await bad() } catch e { after = 1 } finally { after += 10 }
    assert_eq(after, 11)
    async fn rt_error() { [1, 2][9] }
    try { await rt_error() } catch e { assert_eq(e.kind, "IndexError") }
}

test "doing many things at once" {
    let t0 = time.clock()
    let rs = await async.all([double_later(1, 0.15), double_later(2, 0.15), double_later(3, 0.15)])
    assert_eq(rs, [2, 4, 6])
    assert((time.clock() - t0) < 400)           // together, not one after another
    assert_eq(await async.race([double_later(1, 0.3), double_later(2, 0.02)]), 4)
    assert_eq((await async.settle([double_later(1), async.rejected("no")])).map(|r| r.is_ok()), [true, false])
    var tried = 0
    async fn flaky() { tried += 1; if tried < 3 { throw "again" }; tried }
    assert_eq(await async.retry(flaky, times: 5), 3)
    assert_eq(await async.map_limit([1, 2, 3, 4], 2, async |x| { await async.delay(0.01); x * x }), [1, 4, 9, 16])
    try { await async.timeout(double_later(1, 1), 0.05); fail("should have timed out") } catch e { assert_eq(e.kind, "TimeoutError") }
    assert_eq(await async.all([]), [])
}

test "channels, locks, deferred and futures with then" {
    let ch = async.channel()
    async fn produce() { for i in 1..=3 { await async.delay(0.005); ch.send(i) }; ch.close() }
    let _ = produce()
    var got = []
    loop { let v = await ch.recv(); if v == none { break }; got.push(v) }
    assert_eq(got, [1, 2, 3])
    let lock = async.lock()
    var order = []
    async fn critical(n) { await lock.acquire(); order.push("in{n}"); await async.delay(0.01); order.push("out{n}"); lock.release() }
    await async.all([critical(1), critical(2)])
    assert_eq(order, ["in1", "out1", "in2", "out2"])
    let d = async.deferred()
    d.resolve(7)
    assert_eq(await d.promise, 7)
    assert_eq(await double_later(2).then(|x| x + 1), 5)
    assert_eq(await async.spawn(|a, b| a + b, 1, 2), 3)
    var seen = none
    let failing = async.rejected("oops").catch(|e| { seen = e; "handled" })
    assert_eq(await failing, "handled")
    assert_eq(seen.message, "oops")
}

test "pools and await work together" {
    let p = pool [10, 10]
    assert_eq(await async.spawn(|| p + 1), 11)
    async fn use_pool(x) { await async.delay(0.001); x * 2 }
    let q = pool [4, 4]
    assert_eq(await use_pool(q), 8)
    assert_eq(await q, 4)
}
