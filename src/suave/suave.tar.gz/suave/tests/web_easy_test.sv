# std.web: the easy web functions (pages without tags, safe text, addresses, a site in one line)
use std.web

test "pages are built without tags and text is made safe":
    let html = web.page("Hi", web.h1("Hello <world>"), web.p("Go ", web.link("home", "/?a=1&b=2")))
    assert(html.contains("<title>Hi</title>"))
    assert(html.contains("<h1>Hello &lt;world&gt;</h1>"))
    assert(html.contains('href="/?a=1&amp;b=2"'))
    assert_eq(web.list(["a", "<b>"]), "<ul><li>a</li><li>&lt;b&gt;</li></ul>")
    assert(web.table([["Ann", 31]], ["Name", "Age"]).contains("<td>31</td>"))
    # HTML made by web helpers is never escaped twice, but plain text always is
    assert(web.box(web.bold("x")).contains("<strong>x</strong>"))
    assert_eq(web.p("<b>no</b>"), "<p>&lt;b&gt;no&lt;/b&gt;</p>")
    assert_eq(web.p(web.safe("<b>yes</b>")), "<p><b>yes</b></p>")

test "addresses":
    assert_eq(web.query({q: "cats & dogs", page: 2}), "q=cats%20%26%20dogs&page=2")
    assert_eq(web.link_to("https://x.com/s", {q: "a b"}), "https://x.com/s?q=a%20b")
    assert_eq(web.link_to("https://x.com/s?a=1", {q: "z"}), "https://x.com/s?a=1&q=z")
    let u = web.parts("https://a.com:8080/x/y?q=1#top")
    assert_eq(u.host, "a.com")
    assert_eq(u.port, 8080)
    assert_eq(u.query.q, "1")
    assert_eq(u.hash, "top")
    assert_eq(web.decode(web.encode("a b/c")), "a b/c")
    assert_throws(|| web.parts("not a web address"))

test "one line starts a site and await reads it":
    web.serve({"/": web.page("Home", web.h1("Welcome!")), "/time": || "now", "/api": || {ok: true}, "POST /api": |req| {got: req.json}, "/hi": |req| "Hi " + web.form_value(req, "name", "friend")}, 8791)
    assert((await web.get("http://localhost:8791/")).contains("Welcome!"))
    assert_eq(await web.get("http://localhost:8791/time"), "now")
    assert_eq(await web.json("http://localhost:8791/api"), {ok: true})
    assert_eq(await web.get("http://localhost:8791/hi?name=Sam"), "Hi Sam")
    assert_eq(await web.post("http://localhost:8791/api", {a: 1}), {got: {a: 1}})
    assert_eq(await web.is_up("http://localhost:8791/"), true)
    assert_eq(await web.status("http://localhost:8791/nope"), 404)
    try:
        await web.get("http://localhost:8791/nope")
        assert(false)
    catch e:
        assert(e.message.contains("404"))

test "page functions say what to do outside a browser":
    try:
        web.say("hi")
        assert(false)
    catch e:
        assert(e.message.contains("browser"))

test "Keydown text becomes HTML":
    let k = web.ktext('# Hi <b>\n\n**bold**, *it*, `code` and #C#a chip#\n\n- one\n- two\n\n> quoted', static: true)
    assert(k.contains("<h1>Hi &lt;b&gt;</h1>"))
    assert(k.contains("<strong>bold</strong>"))
    assert(k.contains("<em>it</em>"))
    assert(k.contains("<code>code</code>"))
    assert(k.contains("a chip</span>"))
    assert(k.contains("<ul><li>one</li><li>two</li></ul>"))
    assert(k.contains("<blockquote>quoted</blockquote>"))
    assert_eq(web.keydown("**x**", static: true), web.ktext("**x**", static: true))
    # it can sit inside a page next to other helpers without being escaped
    assert(web.page("T", web.ktext("**yes**", static: true)).contains("<p><strong>yes</strong></p>"))

test "ktext hands the text to the full Keydown engine, which the page loads by itself":
    let k = web.ktext("# Hi <b>\n**bold** #C#chip#")
    assert(k.contains("data-keydown>"))
    assert(k.contains("&lt;b&gt;"))
    let p = web.page("T", k)
    assert(p.contains('<script src="https://radii-office.com/Keydown.js" data-keydown-engine defer></script></body>'))
    # no Keydown text, no engine download
    assert(not web.page("T", web.p("hi")).contains("Keydown.js"))
    # your own copy
    web.engine("http://localhost:1/K.js")
    assert(web.page("T", web.ktext("x")).contains('src="http://localhost:1/K.js"'))
    assert(web.page("T", web.ktext("x"), engine: false).contains("<script") == false)
    web.engine("https://radii-office.com/Keydown.js")

test "your own CSS":
    let sheet = web.css({".card": {border: "2px solid teal", font_size: "1.2rem"}, "h2": {color: "purple"}})
    assert(sheet.contains('.card { border: 2px solid teal; font-size: 1.2rem; }'))
    assert(sheet.contains('h2 { color: purple; }'))
    let p = web.page("Cards", web.style(sheet), web.div("card", web.h2("Hi")), web.styled("color: red", "x"), css: 'body { margin: 0 }')
    assert(p.contains('<div class="card"><h2>Hi</h2></div>'))
    assert(p.contains('<div style="color: red">x</div>'))
    assert(p.contains('body { margin: 0 }'))
    assert(p.contains('.card { border'))
    # a class name cannot break out of its tag
    assert_eq(web.div('x"><script>', "t"), '<div class="xscript">t</div>')
