# std.sound: the waves as numbers, and where sound files are looked up (nothing here needs a speaker)
use std.sound

test "the four waves have the right shape":
    # 441 Hz makes one cycle every 100 samples; the middle of a long wave has no fade
    let sine = sound.samples("sine", 441, 0.1, 1)
    assert_eq(sine.len(), 4410)
    assert((sine[2225] - 1).abs() < 0.0001)       # a quarter of the way: the top
    assert(sine[2250].abs() < 0.0001)             # half way: zero
    let sq = sound.samples("square", 441, 0.1, 0.5)
    assert_eq(sq[2210], 0.5)
    assert_eq(sq[2260], -0.5)
    let tri = sound.samples("triangle", 441, 0.1, 1)
    assert((tri[2225] - 1).abs() < 0.0001)
    assert(tri[2250].abs() < 0.0001)
    assert((tri[2275] + 1).abs() < 0.0001)
    # mole is |sin(x)| (twice as many humps), lifted to sit around zero
    let mole = sound.samples("mole", 441, 0.1, 1)
    assert((mole[2225] - mole[2275]).abs() < 0.0001)   # the same hump top at a quarter and three quarters
    assert((mole[2250] + 1).abs() < 0.0001)            # the bottom between humps
    assert(mole.all(|x| x >= -1.0001 and x <= 1.0001))

test "waves fade in and out so speakers do not click":
    let w = sound.samples("square", 441, 0.1, 1)
    assert(w[0].abs() < 0.01)
    assert(w[4409].abs() < 0.01)

test "wav bytes are a real wave file":
    let b = sound.wav("sine", 440, 0.1, 0.5)
    assert_eq(b.len(), 44 + 4410 * 2)
    assert_eq(b[0:4].to_str(), "RIFF")
    assert_eq(b[8:12].to_str(), "WAVE")

test "bad values say what is wrong":
    assert_throws(|| sound.samples("sine", 0))
    assert_throws(|| sound.samples("sine", 440, 0))
    assert_throws(|| sound.samples("sine", 440, 1, 2))
    assert_throws(|| sound.samples("saw", 440))

test "GitHub addresses":
    assert_eq(sound.git_url("user/repo/sounds/ding.wav"), "https://raw.githubusercontent.com/user/repo/HEAD/sounds/ding.wav")
    assert_eq(sound.git_url("user/repo@dev/a b/c.wav"), "https://raw.githubusercontent.com/user/repo/dev/a%20b/c.wav")
    assert_eq(sound.git_url("https://github.com/user/repo/blob/main/x/y.wav"), "https://raw.githubusercontent.com/user/repo/main/x/y.wav")
    assert_throws(|| sound.git_url("user/repo"))
    assert_throws(|| sound.git_url("user/repo/../secret.wav"))

test "file paths start beside this file":
    assert(sound.file_path("./ding.wav").ends_with("/tests/ding.wav"))
    assert(sound.file_path("ding.wav").ends_with("/tests/ding.wav"))
    assert(sound.file_path("../up.wav").ends_with("/up.wav"))
    assert(not sound.file_path("../up.wav").ends_with("/tests/up.wav"))
    assert_eq(sound.file_path("/abs/x.wav"), "/abs/x.wav")

test "short options: a d s r and v":
    # 441 Hz, 1 second: attack 0.5 s means the middle of the attack is about half as loud
    let plain = sound.samples("sine", 441, 1, 1)
    let slow = sound.samples("sine", 441, 1, 1, a=0.5)
    assert((slow[11025] / plain[11025] - 0.5).abs() < 0.01)
    assert((slow[44025] / plain[44025] - 1).abs() < 0.01)
    # v is the volume
    let quiet = sound.samples("sine", 441, 0.1, v=0.25)
    assert((quiet[2225] - 0.25).abs() < 0.0001)
    # release fades to nothing at the end, decay settles at the sustain level
    let note = sound.samples("square", 441, 1, 1, d=0.2, s=0.5, r=0.4)
    assert((note[22000].abs() - 0.5).abs() < 0.001)
    assert(note[44099].abs() < 0.01)

test "ADSR as a list or a map gives the same sound":
    let a = sound.samples("sine", 330, 0.2, 1, adsr=[0.02, 0.05, 0.6, 0.1])
    let b = sound.samples("sine", 330, 0.2, 1, adsr={attack: 0.02, decay: 0.05, sustain: 0.6, release: 0.1})
    let c = sound.samples("sine", 330, 0.2, 1, a=0.02, d=0.05, s=0.6, r=0.1)
    assert_eq(a, b)
    assert_eq(a, c)
    assert_throws(|| sound.samples("sine", 330, 0.2, 1, adsr=[1, 2]))
    assert_throws(|| sound.samples("sine", 330, 0.2, 1, s=2))

test "filters keep or remove pitches":
    # a 200 Hz wave is kept by a low pass at 2000 and removed by a high pass at 2000 (measured in the middle)
    let loud = |xs| xs.slice(5000, 9000).map(|x| x.abs()).max()
    let low = sound.samples("sine", 200, 0.3, 1, lowpass=2000)
    let high = sound.samples("sine", 200, 0.3, 1, highpass=2000)
    assert(loud(low) > 0.9)
    assert(loud(high) < 0.05)
    # and the other way round for 5000 Hz
    assert(loud(sound.samples("sine", 5000, 0.3, 1, lowpass=300)) < 0.05)
    assert(loud(sound.samples("sine", 5000, 0.3, 1, highpass=300)) > 0.9)
    # a band pass lets its own pitch through
    assert(loud(sound.samples("sine", 1000, 0.3, 1, bandpass=1000)) > 0.9)
    assert(loud(sound.samples("sine", 100, 0.3, 1, bandpass=1000)) < 0.2)

test "EQ boosts and cuts":
    let loud = |xs| xs.slice(5000, 9000).map(|x| x.abs()).max()
    let flat = loud(sound.samples("sine", 100, 0.3, 0.2))
    let boosted = loud(sound.samples("sine", 100, 0.3, 0.2, eq={bass: 12}))
    let cut = loud(sound.samples("sine", 100, 0.3, 0.2, eq={bass: -12}))
    assert(boosted > flat * 3)
    assert(cut < flat / 3)
    # treble does not touch a low pitch
    assert((loud(sound.samples("sine", 100, 0.3, 0.2, eq={treble: 12})) / flat - 1).abs() < 0.1)
    # your own band: [pitch, dB]
    assert(loud(sound.samples("sine", 1000, 0.3, 0.2, eq=[[1000, 12]])) > flat * 3)
    assert_throws(|| sound.samples("sine", 100, 0.3, 0.2, eq={loud: 3}))

test "a sound can be built, changed step by step and saved":
    let s = sound.make("sine", 441, 0.1, 1).volume(0.5).fade_out(0.02)
    assert_eq(s.seconds(), 0.1)
    assert_eq(s.samples().len(), 4410)
    assert((s.samples()[2225] - 0.5).abs() < 0.0001)
    assert(s.samples()[4409].abs() < 0.01)
    assert_eq(s.wav()[0:4].to_str(), "RIFF")
    let t = sound.make("square", 220, 0.5).adsr(0.1, 0.1, 0.5, 0.1).lowpass(1000).eq(bass=3)
    assert_eq(t.channels(), 1)
    assert(t.samples().all(|x| x.abs() < 1.5))
