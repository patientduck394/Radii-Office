# std.sound: the waves as numbers, and where sound files are looked up (nothing here needs a speaker)
use std.sound

test "the four waves have the right shape":
    # 441 Hz makes one cycle every 100 samples; the middle of a long wave has no fade
    let sine = sound.samples("sine", 441, 0.1, 1)
    assert_eq(sine.len(), 4410)
    assert((sine[2225] - 1).abs() < 0.0001)       # a quarter of the way: the top
    assert(sine[2250].abs() < 0.0001)             # half way: zero
    let sq = sound.samples("square", 441, 0.1, 0.5)
    assert_eq(sq[2210], 0.5)
    assert_eq(sq[2260], -0.5)
    let tri = sound.samples("triangle", 441, 0.1, 1)
    assert((tri[2225] - 1).abs() < 0.0001)
    assert(tri[2250].abs() < 0.0001)
    assert((tri[2275] + 1).abs() < 0.0001)
    # mole is |sin(x)| (twice as many humps), lifted to sit around zero
    let mole = sound.samples("mole", 441, 0.1, 1)
    assert((mole[2225] - mole[2275]).abs() < 0.0001)   # the same hump top at a quarter and three quarters
    assert((mole[2250] + 1).abs() < 0.0001)            # the bottom between humps
    assert(mole.all(|x| x >= -1.0001 and x <= 1.0001))

test "waves fade in and out so speakers do not click":
    let w = sound.samples("square", 441, 0.1, 1)
    assert(w[0].abs() < 0.01)
    assert(w[4409].abs() < 0.01)

test "wav bytes are a real wave file":
    let b = sound.wav("sine", 440, 0.1, 0.5)
    assert_eq(b.len(), 44 + 4410 * 2)
    assert_eq(b[0:4].to_str(), "RIFF")
    assert_eq(b[8:12].to_str(), "WAVE")

test "bad values say what is wrong":
    assert_throws(|| sound.samples("sine", 0))
    assert_throws(|| sound.samples("sine", 440, 0))
    assert_throws(|| sound.samples("sine", 440, 1, 2))
    assert_throws(|| sound.samples("saw", 440))

test "GitHub addresses":
    assert_eq(sound.git_url("user/repo/sounds/ding.wav"), "https://raw.githubusercontent.com/user/repo/HEAD/sounds/ding.wav")
    assert_eq(sound.git_url("user/repo@dev/a b/c.wav"), "https://raw.githubusercontent.com/user/repo/dev/a%20b/c.wav")
    assert_eq(sound.git_url("https://github.com/user/repo/blob/main/x/y.wav"), "https://raw.githubusercontent.com/user/repo/main/x/y.wav")
    assert_throws(|| sound.git_url("user/repo"))
    assert_throws(|| sound.git_url("user/repo/../secret.wav"))

test "file paths start beside this file":
    assert(sound.file_path("./ding.wav").ends_with("/tests/ding.wav"))
    assert(sound.file_path("ding.wav").ends_with("/tests/ding.wav"))
    assert(sound.file_path("../up.wav").ends_with("/up.wav"))
    assert(not sound.file_path("../up.wav").ends_with("/tests/up.wav"))
    assert_eq(sound.file_path("/abs/x.wav"), "/abs/x.wav")

test "short options: a d s r and v":
    # 441 Hz, 1 second: attack 0.5 s means the middle of the attack is about half as loud
    let plain = sound.samples("sine", 441, 1, 1)
    let slow = sound.samples("sine", 441, 1, 1, a=0.5)
    assert((slow[11025] / plain[11025] - 0.5).abs() < 0.01)
    assert((slow[44025] / plain[44025] - 1).abs() < 0.01)
    # v is the volume
    let quiet = sound.samples("sine", 441, 0.1, v=0.25)
    assert((quiet[2225] - 0.25).abs() < 0.0001)
    # release fades to nothing at the end, decay settles at the sustain level
    let note = sound.samples("square", 441, 1, 1, d=0.2, s=0.5, r=0.4)
    assert((note[22000].abs() - 0.5).abs() < 0.001)
    assert(note[44099].abs() < 0.01)

test "ADSR as a list or a map gives the same sound":
    let a = sound.samples("sine", 330, 0.2, 1, adsr=[0.02, 0.05, 0.6, 0.1])
    let b = sound.samples("sine", 330, 0.2, 1, adsr={attack: 0.02, decay: 0.05, sustain: 0.6, release: 0.1})
    let c = sound.samples("sine", 330, 0.2, 1, a=0.02, d=0.05, s=0.6, r=0.1)
    assert_eq(a, b)
    assert_eq(a, c)
    assert_throws(|| sound.samples("sine", 330, 0.2, 1, adsr=[1, 2]))
    assert_throws(|| sound.samples("sine", 330, 0.2, 1, s=2))

test "filters keep or remove pitches":
    # a 200 Hz wave is kept by a low pass at 2000 and removed by a high pass at 2000 (measured in the middle)
    let loud = |xs| xs.slice(5000, 9000).map(|x| x.abs()).max()
    let low = sound.samples("sine", 200, 0.3, 1, lowpass=2000)
    let high = sound.samples("sine", 200, 0.3, 1, highpass=2000)
    assert(loud(low) > 0.9)
    assert(loud(high) < 0.05)
    # and the other way round for 5000 Hz
    assert(loud(sound.samples("sine", 5000, 0.3, 1, lowpass=300)) < 0.05)
    assert(loud(sound.samples("sine", 5000, 0.3, 1, highpass=300)) > 0.9)
    # a band pass lets its own pitch through
    assert(loud(sound.samples("sine", 1000, 0.3, 1, bandpass=1000)) > 0.9)
    assert(loud(sound.samples("sine", 100, 0.3, 1, bandpass=1000)) < 0.2)

test "EQ boosts and cuts":
    let loud = |xs| xs.slice(5000, 9000).map(|x| x.abs()).max()
    let flat = loud(sound.samples("sine", 100, 0.3, 0.2))
    let boosted = loud(sound.samples("sine", 100, 0.3, 0.2, eq={bass: 12}))
    let cut = loud(sound.samples("sine", 100, 0.3, 0.2, eq={bass: -12}))
    assert(boosted > flat * 3)
    assert(cut < flat / 3)
    # treble does not touch a low pitch
    assert((loud(sound.samples("sine", 100, 0.3, 0.2, eq={treble: 12})) / flat - 1).abs() < 0.1)
    # your own band: [pitch, dB]
    assert(loud(sound.samples("sine", 1000, 0.3, 0.2, eq=[[1000, 12]])) > flat * 3)
    assert_throws(|| sound.samples("sine", 100, 0.3, 0.2, eq={loud: 3}))

test "a sound can be built, changed step by step and saved":
    let s = sound.make("sine", 441, 0.1, 1).volume(0.5).fade_out(0.02)
    assert_eq(s.seconds(), 0.1)
    assert_eq(s.samples().len(), 4410)
    assert((s.samples()[2225] - 0.5).abs() < 0.0001)
    assert(s.samples()[4409].abs() < 0.01)
    assert_eq(s.wav()[0:4].to_str(), "RIFF")
    let t = sound.make("square", 220, 0.5).adsr(0.1, 0.1, 0.5, 0.1).lowpass(1000).eq(bass=3)
    assert_eq(t.channels(), 1)
    assert(t.samples().all(|x| x.abs() < 1.5))

test "white, pink and brown noise":
    let a = sound.samples("noise", 0.2, 0.5, seed=1)
    assert_eq(a, sound.samples("noise", 0.2, 0.5, seed=1))
    assert(a != sound.samples("noise", 0.2, 0.5, seed=2))
    assert_eq(a, sound.samples("white", 0.2, 0.5, seed=1))
    assert(a.max() > 0.45 and a.min() < -0.45)
    assert(a.all(|x| x.abs() <= 0.5001))
    # roughly zero on average, and not a tone: neighbouring samples are unrelated
    assert((a.sum() / a.len()).abs() < 0.02)
    for color in ["pink", "brown"]:
        let c = sound.samples("noise", 0.2, 0.5, seed=3, color=color)
        assert_eq(c.len(), 8820)
        assert(c.all(|x| x.abs() <= 1.01))
    assert_throws(|| sound.samples("noise", 0.2, 0.5, color="blue"))

test "chip noise is a shift register":
    # one step per sample: the long register repeats every 32767 steps, the short one every 93
    let r = sound.samples("chipnoise", 44100, 2, 1, type="retro")
    assert_eq(r[10000], r[10000 + 32767])
    assert_eq(r[40000], r[40000 + 32767])
    assert(r[10000:10200] != r[10001:10201])
    let b = sound.samples("chipnoise", 44100, 0.5, 1, type="buzz")
    assert((3000..6000).all(|i| b[i] == b[i + 93]))
    assert(b[3000:3093].any(|x| x > 0) and b[3000:3093].any(|x| x < 0))
    # the first number is how fast it steps: a lower number holds each value longer
    let slow = sound.samples("chipnoise", 2205, 0.2, 1, type="retro")
    assert_eq(slow[1000], slow[1005])
    for kind in ["white", "bit", "crackle"]:
        assert_eq(sound.samples("chipnoise", 8000, 0.1, 0.5, type=kind, seed=7).len(), 4410)
    assert_throws(|| sound.samples("chipnoise", 8000, 0.1, 0.5, type="loud"))

test "harmonics add sines on top of each other":
    # one harmonic is a plain sine, a second one adds the octave
    let one = sound.samples("harmonics", 441, 0.1, 1, h=[1])
    let sine = sound.samples("sine", 441, 0.1, 1)
    assert((one[2300] - sine[2300]).abs() < 0.02)
    let two = sound.samples("harmonics", 441, 0.1, 1, h=[1, 1])
    assert(two.max() <= 1.0001 and two.max() > 0.9)
    # a saw has all the harmonics, a square only the odd ones, so they sound different
    assert(sound.samples("harmonics", 441, 0.1, 1, h="saw") != sound.samples("harmonics", 441, 0.1, 1, h="square"))
    assert_throws(|| sound.samples("harmonics", 441, 0.1, 1, h="loud"))
    assert_throws(|| sound.samples("harmonics", 441, 0.1, 1, h=[2]))
    # harmonics too high to be heard are left out instead of making noise (a 15000 Hz note is only its first harmonic)
    let high = sound.samples("harmonics", 15000, 0.05, 1, h=[1, 1, 1, 1])
    let pure = sound.samples("harmonics", 15000, 0.05, 1, h=[1])
    assert((high[1000] - pure[1000]).abs() < 0.001)

test "FM bends the phase of one sine with another":
    # with the modulator turned all the way down it is a plain sine
    let plain = sound.samples("fm", 441, 0.1, 1, levels=[15, 0, 0, 0])
    let sine = sound.samples("sine", 441, 0.1, 1)
    assert((plain[2225] - sine[2225]).abs() < 0.02)
    # turning it up changes the sound, and so does the wiring
    let a = sound.samples("fm", 441, 0.1, 1, levels=[15, 10, 0, 0])
    assert(a != plain)
    assert(sound.samples("fm", 441, 0.1, 1, algorithm=6, levels=[15, 10, 5, 5]) != sound.samples("fm", 441, 0.1, 1, algorithm=7, levels=[15, 10, 5, 5]))
    assert(sound.samples("fm", 441, 0.1, 1, levels=[15, 10, 0, 0], feedback=8) != a)
    assert(a.all(|x| x.abs() <= 1.0001))
    # all 15 wirings work
    for n in 1..16:
        assert_eq(sound.samples("fm", 220, 0.05, 0.5, algorithm=n, levels=[15, 8, 6, 4]).len(), 2205)
    assert_throws(|| sound.samples("fm", 220, 0.05, 0.5, algorithm=16))
    assert_throws(|| sound.samples("fm", 220, 0.05, 0.5, levels=[16]))

test "superchip":
    let s = sound.samples("superchip", 440, 0.5, 0.8)
    assert_eq(s.len(), 22050)
    assert((s.map(|x| x.abs()).max() - 0.8).abs() < 0.01)
    # it fades out at the end
    assert(s[22049].abs() < 0.02)
    # the options change it
    assert(sound.samples("superchip", 440, 0.5, 0.8, voices=1) != s)
    assert(sound.samples("superchip", 440, 0.5, 0.8, wave="sine") != s)
    assert(sound.samples("superchip", 440, 0.5, 0.8, chorus=0) != s)
    assert(sound.samples("superchip", 440, 0.5, 0.8, twang=0) != s)
    # the twang closes the filter after the start, so later parts have less high pitch than the same note with it off
    assert_throws(|| sound.samples("superchip", 440, 0.5, 0.8, wave="loud"))
    assert_throws(|| sound.samples("superchip", 440, 0.5, 0.8, voices=20))

test "chorus is a general option":
    let flat = sound.samples("sine", 440, 0.3, 0.5)
    assert(sound.samples("sine", 440, 0.3, 0.5, chorus=1) != flat)
    assert_throws(|| sound.samples("sine", 440, 0.3, 0.5, chorus=2))

test "every kind can be made by name":
    for kind in sound.waves():
        # noise has no pitch, so its first number is the length
        let s = sound.make(kind, 0.05, 0.3) if kind == "noise" or kind == "white" else sound.make(kind, 220, 0.05, 0.3)
        assert(s.seconds() > 0.049)
    assert_throws(|| sound.make("organ", 220, 0.05))

test "instruments from the Look at instruments song":
    assert_eq(sound.instruments(), ["high_superchip", "flute", "electric_piano", "scoot", "tweet", "high_scoot"])
    for name in sound.instruments():
        let s = sound.samples(name, 261.63, 0.5, 0.4)
        assert_eq(s.len(), 22050)
        assert((s.map(|x| x.abs()).max() - 0.4).abs() < 0.01)
    assert_eq(sound.samples("epiano", 261.63, 0.2, 0.4), sound.samples("electric_piano", 261.63, 0.2, 0.4))
    # a scoot is over in a flash: almost nothing is left after a third of a second
    let loud = |xs| xs.map(|x| x.abs()).max()
    for name in ["scoot", "high_scoot"]:
        let s = sound.samples(name, 261.63, 1, 0.4)
        assert(loud(s[0:4410]) > 0.3)
        assert(loud(s[17640:44100]) < 0.02)
    # the flute holds steady, the tweet dies away
    let flute = sound.samples("flute", 261.63, 1, 0.4)
    assert(loud(flute[30000:40000]) > 0.3)
    let tweet = sound.samples("tweet", 261.63, 1, 0.4)
    assert(loud(tweet[30000:40000]) < loud(tweet[4000:14000]) / 4)
    # options still work on an instrument, and the pitch limit for the tweet (it plays four times the pitch)
    assert(sound.samples("scoot", 261.63, 0.5, 0.4, flare=0) != sound.samples("scoot", 261.63, 0.5, 0.4))
    assert_throws(|| sound.samples("tweet", 6000, 0.1))
    assert((sound.samples("flute", 261.63, 0.3, 0.4, lowpass=300).map(|x| x.abs()).max()) <= 0.41)

test "new chip waves and FM extras":
    for w in ["spiky", "1/8 pulse", "1/4 pulse", "double saw", "saw", "sine", "square", "triangle", "mole"]:
        assert_eq(sound.samples("superchip", 220, 0.1, 0.3, wave=w).len(), 4410)
    # the vibrato can be put on harmonics and FM sounds too
    assert(sound.samples("harmonics", 220, 0.5, 0.3, h="organ", vibrato=0.5, vibrato_delay=0) != sound.samples("harmonics", 220, 0.5, 0.3, h="organ"))
    assert(sound.samples("fm", 220, 0.5, 0.3, vibrato=0.5) != sound.samples("fm", 220, 0.5, 0.3))
    # an operator that fades away changes the sound over time
    assert(sound.samples("fm", 220, 1, 0.3, op_decay=[0, 3, 0, 0]) != sound.samples("fm", 220, 1, 0.3))

test "every filter and envelope is on by default and zero switches it off":
    let plain = sound.samples("sine", 440, 0.3, 0.5)
    # the general options: zero means off, so these give the plain sound back
    assert_eq(sound.samples("sine", 440, 0.3, 0.5, adsr=0), plain)
    assert_eq(sound.samples("sine", 440, 0.3, 0.5, lowpass=0, highpass=0, bandpass=0, eq=0, fade_in=0, fade_out=0, chorus=0), plain)
    assert(sound.samples("sine", 440, 0.3, 0.5, adsr=[0.05, 0.05, 0.5, 0.1]) != plain)
    # superchip: its filter, twang, chorus, vibrato and unison are on by default
    let sc = sound.samples("superchip", 440, 0.5, 0.5)
    assert(sound.samples("superchip", 440, 0.5, 0.5, cutoff=0) != sc)
    assert(sound.samples("superchip", 440, 0.5, 0.5, twang=0) != sc)
    assert(sound.samples("superchip", 440, 0.5, 0.5, chorus=0) != sc)
    assert(sound.samples("superchip", 440, 0.5, 0.5, vibrato=0) != sc)
    assert(sound.samples("superchip", 440, 0.5, 0.5, voices=1) != sc)
    assert(sound.samples("superchip", 440, 0.5, 0.5, fade_out=0) != sc)
    # with the filter off, twang and flare have nothing to move
    assert_eq(sound.samples("superchip", 440, 0.5, 0.5, cutoff=0), sound.samples("superchip", 440, 0.5, 0.5, cutoff=0, twang=0))
    # the instruments keep their own filters and envelopes until you zero them
    for name in ["scoot", "high_scoot"]:
        assert(sound.samples(name, 261.63, 0.5, 0.4, flare=0) != sound.samples(name, 261.63, 0.5, 0.4))
        assert(sound.samples(name, 261.63, 0.5, 0.4, cutoff=0) != sound.samples(name, 261.63, 0.5, 0.4))
        # with no filter a scoot no longer dies away
        assert(sound.samples(name, 261.63, 1, 0.4, cutoff=0)[30000:40000].map(|x| x.abs()).max() > 0.2)
    let tweet = sound.samples("tweet", 261.63, 1, 0.4)
    assert(sound.samples("tweet", 261.63, 1, 0.4, decay=0)[30000:40000].map(|x| x.abs()).max() > 0.3)
    assert(sound.samples("tweet", 261.63, 1, 0.4, vibrato=0) != tweet)
    let piano = sound.samples("electric_piano", 261.63, 0.5, 0.4)
    assert(sound.samples("electric_piano", 261.63, 0.5, 0.4, cutoff=0) != piano)
    assert(sound.samples("electric_piano", 261.63, 0.5, 0.4, op_decay=0) != piano)
    assert(sound.samples("flute", 261.63, 0.5, 0.4, vibrato=0) != sound.samples("flute", 261.63, 0.5, 0.4))
