# std.sound: the waves as numbers, and where sound files are looked up (nothing here needs a speaker)
use std.sound

test "the four waves have the right shape":
    # 441 Hz makes one cycle every 100 samples; the middle of a long wave has no fade
    let sine = sound.samples("sine", 441, 0.1, 1)
    assert_eq(sine.len(), 4410)
    assert((sine[2225] - 1).abs() < 0.0001)       # a quarter of the way: the top
    assert(sine[2250].abs() < 0.0001)             # half way: zero
    let sq = sound.samples("square", 441, 0.1, 0.5)
    assert_eq(sq[2210], 0.5)
    assert_eq(sq[2260], -0.5)
    let tri = sound.samples("triangle", 441, 0.1, 1)
    assert((tri[2225] - 1).abs() < 0.0001)
    assert(tri[2250].abs() < 0.0001)
    assert((tri[2275] + 1).abs() < 0.0001)
    # mole is |sin(x)| (twice as many humps), lifted to sit around zero
    let mole = sound.samples("mole", 441, 0.1, 1)
    assert((mole[2225] - mole[2275]).abs() < 0.0001)   # the same hump top at a quarter and three quarters
    assert((mole[2250] + 1).abs() < 0.0001)            # the bottom between humps
    assert(mole.all(|x| x >= -1.0001 and x <= 1.0001))

test "waves fade in and out so speakers do not click":
    let w = sound.samples("square", 441, 0.1, 1)
    assert(w[0].abs() < 0.01)
    assert(w[4409].abs() < 0.01)

test "wav bytes are a real wave file":
    let b = sound.wav("sine", 440, 0.1, 0.5)
    assert_eq(b.len(), 44 + 4410 * 2)
    assert_eq(b[0:4].to_str(), "RIFF")
    assert_eq(b[8:12].to_str(), "WAVE")

test "bad values say what is wrong":
    assert_throws(|| sound.samples("sine", 0))
    assert_throws(|| sound.samples("sine", 440, 0))
    assert_throws(|| sound.samples("sine", 440, 1, 2))
    assert_throws(|| sound.samples("saw", 440))

test "GitHub addresses":
    assert_eq(sound.git_url("user/repo/sounds/ding.wav"), "https://raw.githubusercontent.com/user/repo/HEAD/sounds/ding.wav")
    assert_eq(sound.git_url("user/repo@dev/a b/c.wav"), "https://raw.githubusercontent.com/user/repo/dev/a%20b/c.wav")
    assert_eq(sound.git_url("https://github.com/user/repo/blob/main/x/y.wav"), "https://raw.githubusercontent.com/user/repo/main/x/y.wav")
    assert_throws(|| sound.git_url("user/repo"))
    assert_throws(|| sound.git_url("user/repo/../secret.wav"))

test "file paths start beside this file":
    assert(sound.file_path("./ding.wav").ends_with("/tests/ding.wav"))
    assert(sound.file_path("ding.wav").ends_with("/tests/ding.wav"))
    assert(sound.file_path("../up.wav").ends_with("/up.wav"))
    assert(not sound.file_path("../up.wav").ends_with("/tests/up.wav"))
    assert_eq(sound.file_path("/abs/x.wav"), "/abs/x.wav")
