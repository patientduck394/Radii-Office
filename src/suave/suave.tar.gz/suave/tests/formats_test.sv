// Tests for JSON, YAML, TOML, SUVL and CSV.
use std.json
use std.yaml
use std.toml
use std.suvl
use std.csv
use std.data

test "json parses every kind of value" {
    let v = json.parse('{"a": [1, 2.5, -3e2, true, false, null, "x\\ny\\u00e9"], "b": {"c": {}}, "": 0}')
    assert_eq(v.a, [1, 2.5, -300, true, false, none, "x\ny\u{e9}"])
    assert_eq(v.b, {c: {}})
    assert_eq(v[""], 0)
    assert_eq(json.parse("[]"), [])
    assert_eq(json.parse("  42  "), 42)
    assert_eq(json.parse('"just text"'), "just text")
    assert_eq(json.parse("null"), none)
}

test "json errors say where" {
    let r = json.try_parse('{"a": }')
    assert(r.is_err())
    assert(r.unwrap_err().contains("line 1, column 7"))
    assert_eq(json.valid("[1, 2,]"), false)
    assert_eq(json.valid('{"a": 1, "a": 2}'), false)
    assert_eq(json.valid("[01]"), false)
    assert_eq(json.valid('{"a": 1}'), true)
    assert_eq(json.parse("[1, 2, ]", lenient: true), [1, 2])
    assert_eq(json.parse('// note\n{a: "x", /* c */ b: 2,}', lenient: true), {a: "x", b: 2})
    assert_eq(json.parse("[12345678901234567890]", bigints: true), [12345678901234567890n])
}

test "json writes" {
    assert_eq(json.stringify({a: 1, b: [true, none, "x"]}), '{"a":1,"b":[true,null,"x"]}')
    assert_eq(json.stringify([1, [2]], indent: 2), "[\n  1,\n  [\n    2\n  ]\n]")
    assert_eq(json.stringify({b: 1, a: 2}, sort_keys: true), '{"a":2,"b":1}')
    assert_eq(json.stringify("quote\" and \\ and \n"), '"quote\\" and \\\\ and \\n"')
    assert_eq(json.stringify({1: "a"}), '{"1":"a"}')
    assert_eq(json.stringify(:sym), '"sym"')
    let round = json.parse(json.stringify({x: [1, {y: none}], "k k": 3.5}))
    assert_eq(round, {x: [1, {y: none}], "k k": 3.5})
    assert_eq(json.parse_lines('{"a": 1}\n{"a": 2}\n'), [{a: 1}, {a: 2}])
    assert_eq(json.stringify_lines([{a: 1}, {a: 2}]), '{"a":1}\n{"a":2}\n')
}

test "yaml block collections and scalars" {
    let y = yaml.parse(r"""
        name: Ada
        age: 36
        pi: 3.14
        ok: true
        nothing: null
        tilde: ~
        hex: 0x1F
        quoted: "tab\there"
        single: 'it''s'
        list:
          - one
          - 2
          - [a, b]
          - {k: v}
        nested:
          deep:
            deeper: yes
        empty_list: []
        empty_map: {}
        """)
    assert_eq(y.name, "Ada")
    assert_eq(y.age, 36)
    assert_eq(y.pi, 3.14)
    assert_eq(y.ok, true)
    assert_eq(y.nothing, none)
    assert_eq(y.tilde, none)
    assert_eq(y.hex, 31)
    assert_eq(y.quoted, "tab\there")
    assert_eq(y.single, "it's")
    assert_eq(y.list, ["one", 2, ["a", "b"], {k: "v"}])
    assert_eq(y.nested.deep.deeper, "yes")
    assert_eq(y.empty_list, [])
    assert_eq(y.empty_map, {})
}

test "yaml multi-line text, anchors and documents" {
    let y = yaml.parse(r"""
        literal: |
          line one
          line two
        folded: >
          folded
          text
        strip: |-
          no newline
        base: &b
          x: 1
          y: 2
        derived:
          <<: *b
          y: 3
        alias: *b
        seq_of_maps:
          - id: 1
            tags: [a]
          - id: 2
            tags: []
        """)
    assert_eq(y.literal, "line one\nline two\n")
    assert_eq(y.folded, "folded text\n")
    assert_eq(y.strip, "no newline")
    assert_eq(y.derived, {x: 1, y: 3})
    assert_eq(y.alias, {x: 1, y: 2})
    assert_eq(y.seq_of_maps[1].id, 2)
    let docs = yaml.parse_all("a: 1\n---\nb: 2\n---\n- c\n")
    assert_eq(docs, [{a: 1}, {b: 2}, ["c"]])
    assert_throws(|| yaml.parse("a: 1\n---\nb: 2"))
    assert_throws(|| yaml.parse("a: [1, 2"))
    assert_throws(|| yaml.parse("a: 1\na: 2"))
    assert_eq(yaml.parse("- a\n- b\n"), ["a", "b"])
    assert_eq(yaml.parse("just text"), "just text")
    assert_eq(yaml.parse("# only a comment\n"), none)
}

test "yaml writes and round-trips" {
    let v = {name: "Ada", tags: ["a", "b"], deep: {list: [{id: 1}, {id: 2, x: [1, 2]}]}, text: "two\nlines\n", empty: [], none: none, flag: true, n: 1.5, odd: "yes", numstr: "123", colon: "a: b"}
    let text = yaml.stringify(v)
    assert_eq(yaml.parse(text), v)
    assert(text.contains("name: Ada"))
    assert(text.contains("odd: \"yes\""))
    assert(text.contains("numstr: \"123\""))
}

test "toml" {
    let t = toml.parse(r"""
        title = "TOML"
        count = 1_000
        ratio = 0.5
        on = true
        hex = 0xFF
        when = 1979-05-27T07:32:00Z
        list = [1, 2, 3]
        mixed = [ "a", "b" ]
        inline = { x = 1, y = { z = 2 } }
        dotted.key = "v"
        multi = '''
        raw \n text'''
        [owner]
        name = "Tom"
        [[servers]]
        name = "a"
        [[servers]]
        name = "b"
        [servers.meta]
        k = 1
        """)
    assert_eq(t.title, "TOML")
    assert_eq(t.count, 1000)
    assert_eq(t.ratio, 0.5)
    assert_eq(t.hex, 255)
    assert_eq(t.when.year(), 1979)
    assert_eq(t.list, [1, 2, 3])
    assert_eq(t.inline, {x: 1, y: {z: 2}})
    assert_eq(t.dotted.key, "v")
    assert_eq(t.multi, "raw \\n text")
    assert_eq(t.owner.name, "Tom")
    assert_eq(t.servers.len(), 2)
    assert_eq(t.servers[1].meta.k, 1)
    assert_throws(|| toml.parse("a = 1\na = 2"))
    assert_throws(|| toml.parse("[t]\nx = 1\n[t]\ny = 2"))
    assert_throws(|| toml.parse("a = "))
    assert_eq(toml.parse(toml.stringify({a: 1, b: {c: [1, 2], d: "x"}, e: [{f: 1}, {f: 2}]})), {a: 1, b: {c: [1, 2], d: "x"}, e: [{f: 1}, {f: 2}]})
}

test "suvl" {
    let s = suvl.parse(r'''
        # SUVL
        name: "Ada"
        tags: [math, 3.5, true, none]
        server {
          host: localhost
          timeout: 90s
          cache: 64mb
          ratio: 50%
        }
        born: 1815-12-10
        color: #ff8800
        point: {x: 1, y: 2}
        a = 1, b = 2
        bio: """
          Several
            lines
        """
    ''')
    assert_eq(s.name, "Ada")
    assert_eq(s.tags, ["math", 3.5, true, none])
    assert_eq(s.server, {host: "localhost", timeout: 90, cache: 67108864, ratio: 0.5})
    assert_eq(s.born.year(), 1815)
    assert_eq(s.color, "#ff8800")
    assert_eq(s.point, {x: 1, y: 2})
    assert_eq((s.a, s.b), (1, 2))
    assert_eq(s.bio, "Several\n  lines")
    assert_eq(suvl.parse_raw("t: 90s").t, "90s")
    assert_eq(suvl.parse("[1, 2, three]"), [1, 2, "three"])
    assert_eq(suvl.parse("42"), 42)
    assert_eq(suvl.parse(""), {})
    assert_eq(suvl.parse("a: 5m\nb: 2h\nc: 1d\nd: 250ms\ne: 1kb"), {a: 300, b: 7200, c: 86400, d: 0.25, e: 1024})
    assert_throws(|| suvl.parse("a: 1\na: 2"))
    assert_throws(|| suvl.parse("a: [1, 2"))
    assert_throws(|| suvl.parse("a 1"))
    let doc = {name: "x y", list: [1, [2, 3]], nested: {deep: {k: "v"}}, none: none, t: true, text: "two\nlines", word: "hello", num: 12.5, empty: [], emap: {}}
    assert_eq(suvl.parse(suvl.stringify(doc)), doc)
    assert_eq(suvl.stringify({a: 1, b: "x"}), "a: 1\nb: x\n")
}

test "csv" {
    let rows = csv.parse("name,score\nAda,99\n\"Smith, J\",\"say \"\"hi\"\"\"\n", infer: true)
    assert_eq(rows, [{name: "Ada", score: 99}, {name: "Smith, J", score: "say \"hi\""}])
    assert_eq(csv.parse("a;b\n1;2", sep: ";"), [{a: "1", b: "2"}])
    assert_eq(csv.parse_rows("1,2\n3,4"), [["1", "2"], ["3", "4"]])
    assert_eq(csv.parse("a,b\n1,\n", infer: true), [{a: 1, b: none}])
    assert_eq(csv.stringify([{a: 1, b: "x,y"}, {a: 2, b: "z"}]), "a,b\n1,\"x,y\"\n2,z\n")
    assert_eq(csv.stringify([[1, 2], [3, "q\"r"]]), "1,2\n3,\"q\"\"r\"\n")
    assert_eq(csv.parse("a,b\n1,2\n3,4").len(), 2)
    assert_throws(|| csv.parse("a,b\n\"never closed"))
    assert_eq(csv.parse("a\n\"multi\nline\"\n"), [{a: "multi\nline"}])
}

test "converting between formats" {
    assert_eq(json.parse(data.convert("a: 1\nb: [x, y]", "yaml", "json")), {a: 1, b: ["x", "y"]})
    assert_eq(toml.parse(data.convert('{"a": {"b": 2}}', "json", "toml")), {a: {b: 2}})
    assert_eq(yaml.parse(data.convert("x = 1\n[t]\ny = 2", "toml", "yaml")), {x: 1, t: {y: 2}})
    assert_eq(suvl.parse(data.convert('{"k": [1, 2]}', "json", "suvl")), {k: [1, 2]})
    assert_eq(data.detect('{"a": 1}'), "json")
    assert_eq(data.detect("[server]\nport = 1"), "toml")
}
