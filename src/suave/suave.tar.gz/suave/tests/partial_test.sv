# Partial functions: partial(f, ...), partial_right, f(_, 2), x |> f(_, 2), and .partial.

fn add(a, b): a + b
fn sub(a, b): a - b
fn greet(hello, name, punct="."): hello + ", " + name + punct

test "partial fills the first values":
    assert_eq(partial(add, 1)(2), 3)
    assert_eq(partial(sub, 10)(3), 7)
    assert_eq(partial(add)(1, 2), 3)
    assert(is_partial(partial(add, 1)))
    assert(not is_partial(add))

test "partial_right fills the last values":
    assert_eq(partial_right(sub, 1)(10), 9)

test "underscore holes":
    assert_eq(sub(_, 1)(10), 9)
    assert_eq(sub(10, _)(3), 7)
    assert_eq(sub(_, _)(9, 4), 5)
    assert_eq([5, 6].map(sub(_, 1)), [4, 5])
    assert_eq(partial(sub, _, 1)(10), 9)

test "pipes put the value in the hole":
    assert_eq(5 |> sub(_, 2), 3)
    assert_eq(5 |> sub(100, _), 95)

test "named values and methods":
    let hi = partial(greet, "Hello", punct="!")
    assert_eq(hi("Sam"), "Hello, Sam!")
    assert_eq(hi("Al", punct="?"), "Hello, Al?")
    assert_eq(greet("Yo", _, punct="?")("Al"), "Yo, Al?")
    assert_eq(add.partial(7)(1), 8)
    assert_eq(sub.partial_right(1)(10), 9)

test "too few values is an error":
    assert_throws(|| sub(_, _)(1))
