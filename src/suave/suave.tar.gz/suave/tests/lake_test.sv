# Lake (Lakefile tasks), trailing blocks, easy web syntax and the std.js bridge
use std.fs
use std.path
use std.process
use std.env
use std.js

suave = env.get("SUAVE_MAIN")

def lake(dir, args):
    return process.run("deno", ["run", "-A", suave, "lake"] + args, cwd=dir)

def write(file, text):
    fs.mkdir(path.dirname(file))
    fs.write(file, text)

test "a Lakefile runs tasks with needs, once each":
    root = fs.temp_dir()
    write(path.join(root, "Lakefile"), 'default_task("all")\ntask("a", desc="first"):\n    write("log.txt", "a")\ntask("b", needs=["a"]):\n    write("log.txt", read("log.txt") + "b")\ntask("all", ["b", "a"]):\n    write("log.txt", read("log.txt") + "!")\n')
    r = lake(root, [])
    assert_eq(r.ok, true)
    assert_eq(fs.read(path.join(root, "log.txt")), "ab!")

test "lake -l lists the tasks and lake runs from a subfolder":
    root = fs.temp_dir()
    write(path.join(root, "Lakefile"), 'default_task("go")\ntask("go", desc="Go go go"):\n    echo("running")\n')
    fs.mkdir(path.join(root, "sub"))
    listing = lake(path.join(root, "sub"), ["-l"])
    assert_eq(listing.stdout.contains("Go go go"), true)
    assert_eq(lake(path.join(root, "sub"), ["go"]).stdout.contains("running"), true)

test "a failing command stops lake with an error":
    root = fs.temp_dir()
    write(path.join(root, "Lakefile"), 'task("bad"):\n    sh("exit 4", quiet=true)\n')
    r = lake(root, ["bad"])
    assert_eq(r.ok, false)
    assert_eq(r.stderr.contains("failed"), true)

test "tasks that need each other in a circle are caught":
    root = fs.temp_dir()
    write(path.join(root, "Lakefile"), 'task("x", needs=["y"]):\n    echo("x")\ntask("y", needs=["x"]):\n    echo("y")\n')
    assert_eq(lake(root, ["x"]).stderr.contains("circle"), true)

test "a call with a colon block gets the block as run":
    def twice(name, run=none):
        run()
        run()
    count = 0
    twice("hi"):
        count += 1
    assert_eq(count, 2)

test "std.js reaches JavaScript":
    assert_eq(js.call(js.global("Math"), "max", 3, 9), 9)
    arr = js.new("Uint8Array", [1, 2, 3])
    assert_eq(js.get(arr, "length"), 3)
