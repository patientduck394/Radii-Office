# .xsv components and .wsv pages: parsing and rendering to HTML (no browser needed)
use std.dom
use "../examples/components/counter.xsv"
use "../examples/components/todo-list.xsv"

test "a component renders its template with props":
    html = dom.render_html(Counter, {start: 5, step: 2})
    assert_eq(html.contains("Clicked 5 times"), true)
    assert_eq(html.contains("Reset"), false)

test "defaults, if and else-if":
    assert_eq(dom.render_html(Counter).contains("Clicked 0 times"), true)
    assert_eq(dom.render_html(Counter, {label: "Taps:", start: 1}).contains("Taps: 1 time<"), true)

test "styles are scoped with an attribute":
    html = dom.render_html(Counter)
    assert_eq(html.contains('data-x'), true)

test "for, if/else and child components":
    html = dom.render_html(TodoList)
    assert_eq(html.contains("Learn Suave"), true)
    assert_eq(html.contains("1 left"), true)
    assert_eq(html.contains("Points: 10 times"), true)
    assert_eq(html.contains('class="done"'), true)
