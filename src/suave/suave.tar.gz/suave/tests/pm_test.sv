// The package manager, tested end to end with real packages in a temporary folder.
use std.fs
use std.path
use std.process
use std.env
use std.suvl
use std.hash

let suave = env.get("SUAVE_MAIN")
fn sv(dir, args) {
    let r = process.run("deno", ["run", "-A", suave] + args, cwd: dir, env: {HOME: path.join(dir, "home")})
    r
}
fn write(file, text) { fs.mkdir(path.dirname(file)); fs.write(file, text) }

test "publish to a registry, install with a dependency, use it, lock it" {
    let root = fs.temp_dir()
    fs.mkdir(path.join(root, "home"))
    write(path.join(root, "mathx/suave.suvl"), "name: mathx\nversion: 1.2.0\ndescription: Maths\nentry: lib.sv\n")
    write(path.join(root, "mathx/lib.sv"), "fn double(x) = x * 2\nfn _hidden() = 1\nconst K = 7\n")
    write(path.join(root, "mathx/extra.sv"), "fn cube(x) = x ** 3\n")
    write(path.join(root, "textx/suave.suvl"), 'name: textx\nversion: 0.3.0\nentry: main.sv\ndeps { mathx: "mathx@^1.0.0" }\n')
    write(path.join(root, "textx/main.sv"), "use mathx\nfn shout(s) = s.upper() + \"!\" * mathx.double(1)\n")
    let reg = path.join(root, "reg")
    assert_eq(sv(path.join(root, "mathx"), ["publish", "--to", reg]).ok, true)
    assert_eq(sv(path.join(root, "textx"), ["publish", "--to", reg]).ok, true)
    let again = sv(path.join(root, "mathx"), ["publish", "--to", reg])
    assert_eq(again.ok, false)                              // a published version cannot change
    assert(again.stderr.contains("already published"))
    let index = suvl.parse(fs.read(path.join(reg, "index.suvl")))
    assert_eq(index.packages.mathx.versions.keys(), ["1.2.0"])
    assert_eq(index.packages.mathx.versions["1.2.0"].sha256.len(), 64)

    let app = path.join(root, "app")
    fs.mkdir(app)
    assert_eq(sv(app, ["init", "demo"]).ok, true)
    assert_eq(sv(app, ["registry", "set", reg]).ok, true)
    let add = sv(app, ["add", "textx"])
    assert_eq((add.ok, add.stderr), (true, ""))
    assert(add.stdout.contains("Added textx 0.3.0"))
    assert_eq(fs.exists(path.join(app, "suave_modules/mathx/lib.sv")), true)   // the dependency came along
    let man = suvl.parse(fs.read(path.join(app, "suave.suvl")))
    assert_eq(man.deps.textx, "textx@^0.3.0")
    let lock = suvl.parse(fs.read(path.join(app, "suave.lock.suvl")))
    assert_eq(lock.packages.mathx.version, "1.2.0")
    assert_eq(lock.packages.mathx.integrity, "sha256:" + index.packages.mathx.versions["1.2.0"].sha256)
    assert_eq(lock.packages.textx.deps.mathx, "mathx@^1.0.0")

    write(path.join(app, "main.sv"), "use textx\nuse mathx\nuse mathx.extra as ex\nprint(textx.shout(\"hi\"), mathx.double(4), mathx.K, ex.cube(3))\n")
    let run = sv(app, ["run"])
    assert_eq(run.stdout, "HI!! 8 7 27\n")
    write(path.join(app, "private.sv"), "use mathx\nprint(mathx._hidden)\n")
    assert_eq(sv(app, ["run", "private.sv"]).ok, false)     // names starting with _ stay private

    let ls = sv(app, ["list"]).stdout
    assert(ls.contains("mathx 1.2.0") and ls.contains("textx 0.3.0"))
    assert(sv(app, ["search", "maths"]).stdout.contains("mathx"))

    // install again from the lock (frozen) after deleting suave_modules
    fs.remove(path.join(app, "suave_modules"), true)
    assert_eq(sv(app, ["install", "--frozen"]).ok, true)
    assert_eq(sv(app, ["run"]).stdout, "HI!! 8 7 27\n")

    // remove takes the dependency that nothing needs any more
    assert_eq(sv(app, ["remove", "textx"]).ok, true)
    assert_eq(fs.exists(path.join(app, "suave_modules/textx")), false)
    assert_eq(fs.exists(path.join(app, "suave_modules/mathx")), false)
    fs.remove(root, true)
}

test "a tampered download is refused" {
    let root = fs.temp_dir()
    fs.mkdir(path.join(root, "home"))
    write(path.join(root, "lib/suave.suvl"), "name: lib\nversion: 1.0.0\nentry: lib.sv\n")
    write(path.join(root, "lib/lib.sv"), "fn one() = 1\n")
    let reg = path.join(root, "reg")
    assert_eq(sv(path.join(root, "lib"), ["publish", "--to", reg]).ok, true)
    let file = path.join(reg, "packages/lib-1.0.0.tar.gz")
    let bytes = fs.read_bytes(file)
    fs.write_bytes(file, bytes.to_list() + [0, 0, 0])        // change the bytes after publishing
    let app = path.join(root, "app")
    fs.mkdir(app)
    sv(app, ["init", "demo"])
    sv(app, ["registry", "set", reg])
    let r = sv(app, ["add", "lib"])
    assert_eq(r.ok, false)
    assert(r.stderr.contains("checksum"))
    assert_eq(fs.exists(path.join(app, "suave_modules/lib")), false)
    fs.remove(root, true)
}

test "path packages and packing" {
    let root = fs.temp_dir()
    fs.mkdir(path.join(root, "home"))
    write(path.join(root, "helper/suave.suvl"), "name: helper\nversion: 2.0.0\nentry: main.sv\n")
    write(path.join(root, "helper/main.sv"), 'fn hi(n) = "hi " + str(n)\n')
    let app = path.join(root, "app")
    fs.mkdir(app)
    sv(app, ["init", "demo"])
    let add = sv(app, ["add", "path:../helper"])
    assert_eq(add.ok, true)
    write(path.join(app, "main.sv"), "use helper\nprint(helper.hi(1))\n")
    assert_eq(sv(app, ["run"]).stdout, "hi 1\n")
    let packed = sv(path.join(root, "helper"), ["pack"])
    assert_eq(packed.ok, true)
    assert_eq(fs.exists(path.join(root, "helper/dist/helper-2.0.0.tar.gz")), true)
    let digest = hash.sha256(fs.read_bytes(path.join(root, "helper/dist/helper-2.0.0.tar.gz")))
    assert(packed.stdout.contains(digest))
    assert_eq(sv(app, ["add", "nothing-here"]).ok, false)           // no registry set: a clear error, not a crash
    assert(sv(app, ["add", "bad name!"]).stderr.contains("do not understand"))
    fs.remove(root, true)
}
