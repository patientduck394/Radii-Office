// Tests for the Suave language itself.

test "numbers and arithmetic" {
    assert_eq(1 + 2 * 3, 7)
    assert_eq(2 ** 10, 1024)
    assert_eq(2 ** 3 ** 2, 512)
    assert_eq(-2 ** 2, -4)
    assert_eq(7 % 3, 1)
    assert_eq(-7 % 3, 2)
    assert_eq(10 / 4, 2.5)
    assert_eq(div(7, 2), 3)
    assert_eq(0xFF + 0b101 + 0o10, 268)
    assert_eq(1_000_000, 1000000)
    assert_eq(1e3, 1000)
    assert_eq(0.1 + 0.2 == 0.3, false)
    assert_throws(|| 1 / 0)
    assert_eq(2n ** 70n, 1180591620717411303424n)
}

test "strings and interpolation" {
    let name = "Ada"
    let n = 3
    assert_eq("Hello, {name}!", "Hello, Ada!")
    assert_eq("{n * 2} items", "6 items")
    assert_eq("{3.14159:.2f}", "3.14")
    assert_eq("[{n:>5}]", "[    3]")
    assert_eq("[{name:<6}]", "[Ada   ]")
    assert_eq("[{name:^7}]", "[  Ada  ]")
    assert_eq("{255:x} {255:#X} {5:08.3f}", "ff 0XFF 0005.000")
    assert_eq("{1234567:,}", "1,234,567")
    assert_eq("{0.256:.1%}", "25.6%")
    assert_eq('no {interpolation} here', "no \{interpolation\} here")
    assert_eq("a\tb\n".len(), 4)
    assert_eq(r"raw \n text", "raw \\n text")
    assert_eq("{ {a: 1}.a }", "1")
    assert_eq("{[1, 2].map(|x| x * 2)}", "[2, 4]")
    let multi = """
        first
          second
        """
    assert_eq(multi, "first\n  second")
    assert_eq("ab" * 3, "ababab")
    assert_eq("héllo".len(), 5)
    assert_eq("😀".len(), 1)
}

test "string methods" {
    assert_eq("  hi  ".trim(), "hi")
    assert_eq("a,b,c".split(","), ["a", "b", "c"])
    assert_eq("one two  three".split(), ["one", "two", "three"])
    assert_eq("Hello".upper(), "HELLO")
    assert_eq("hello world".title(), "Hello World")
    assert_eq("abc".reverse(), "cba")
    assert_eq("banana".replace("a", "o"), "bonono")
    assert_eq("a-b".pad_left(5, "*"), "**a-b")
    assert_eq("abc".starts_with("ab"), true)
    assert_eq("hello"[1], "e")
    assert_eq("hello"[-1], "o")
    assert_eq("hello"[1..3], "el")
    assert_eq("hello"[..2], "he")
    assert_eq("hello"[3..], "lo")
    assert_eq("42".to_int(), 42)
    assert_eq("x".to_int(), none)
    assert_eq(int("12"), 12)
    assert_eq("a1b22".find_all("\\d+"), ["1", "22"])
    assert_eq("snake_case_word".camel(), "snakeCaseWord")
    assert_eq("line1\nline2".lines(), ["line1", "line2"])
}

test "lists" {
    let xs = [3, 1, 2]
    assert_eq(sorted(xs), [1, 2, 3])
    assert_eq(xs, [3, 1, 2])                    // sorted() makes a copy
    let ys = [3, 1, 2]
    ys.sort()                                   // .sort() sorts in place, like Python
    assert_eq(ys, [1, 2, 3])
    assert_eq(xs.map(|x| x * 2), [6, 2, 4])
    assert_eq(xs.filter(|x| x > 1), [3, 2])
    assert_eq(xs.reduce(|a, b| a + b), 6)
    assert_eq(xs.fold(10, |a, b| a + b), 16)
    assert_eq(xs.sum(), 6)
    assert_eq(xs.max(), 3)
    assert_eq(xs.reverse(), [2, 1, 3])
    assert_eq(xs[-1], 2)
    assert_eq(xs[0..2], [3, 1])
    assert_eq([1, 2, 3, 4].chunk(2), [[1, 2], [3, 4]])
    assert_eq([1, 2, 3].zip(["a", "b", "c"]), [(1, "a"), (2, "b"), (3, "c")])
    assert_eq(["a", "b"].enumerate(), [(0, "a"), (1, "b")])
    assert_eq([[1, 2], [3]].flatten(), [1, 2, 3])
    assert_eq([1, 1, 2, 3, 3].unique(), [1, 2, 3])
    assert_eq([1, 2, 3, 4].group_by(|x| x % 2), {1: [1, 3], 0: [2, 4]})
    assert_eq([1, 2, 3, 4].partition(|x| x > 2), ([3, 4], [1, 2]))
    assert_eq(["bb", "a", "ccc"].sort_by(|s| s.len()), ["a", "bb", "ccc"])
    assert_eq([1, 2, 3].contains(2), true)
    assert_eq(2 in [1, 2, 3], true)
    assert_eq(5 not in [1, 2, 3], true)
    assert_eq([1, 2] + [3], [1, 2, 3])
    assert_eq([0] * 3, [0, 0, 0])
    assert_eq([1, 2, 3].take(2), [1, 2])
    assert_eq([1, 2, 3].drop(1), [2, 3])
    assert_eq([].max(), none)
    var ys = [1, 2]
    ys.push(3)
    ys[0] = 10
    assert_eq(ys, [10, 2, 3])
    assert_eq(ys.pop(), 3)
    assert_throws(|| [1, 2][5])
    assert_eq([1, 2, 3].get(9, "none"), "none")
    assert_eq([3, 1, 2].sort_desc(), [3, 2, 1])
    assert_eq([1, 2, 3, 4].window(2).len(), 3)
}

test "maps and sets" {
    let m = {a: 1, "b c": 2, 3: "three"}
    assert_eq(m.a, 1)
    assert_eq(m["b c"], 2)
    assert_eq(m[3], "three")
    assert_eq(m.missing, none)
    assert_eq(m.keys(), ["a", "b c", 3])
    assert_eq(m.len(), 3)
    assert_eq(m.has("a"), true)
    let k = "x"
    let dyn = {[k]: 1, k}
    assert_eq(dyn, {x: 1, k: "x"})
    assert_eq({a: 1}.merge({b: 2}), {a: 1, b: 2})
    assert_eq({a: 1, b: 2}.map_values(|v| v * 10), {a: 10, b: 20})
    assert_eq({a: 1, b: 2}.filter(|k, v| v > 1), {b: 2})
    assert_eq({a: 1, b: 2}.items(), [("a", 1), ("b", 2)])
    assert_eq({a: {b: {c: 5}}}.get_in(["a", "b", "c"]), 5)
    assert_eq({a: 1} == {a: 1}, true)
    assert_eq({a: 1, b: 2} == {b: 2, a: 1}, true)
    var mm = {}
    mm["x"] = 1
    mm.y = 2
    assert_eq(mm, {x: 1, y: 2})
    assert_eq({(1, 2): "pair"}[(1, 2)], "pair")
    let s = #{1, 2, 3}
    assert_eq(s.union(#{3, 4}), #{1, 2, 3, 4})
    assert_eq(s.intersect(#{2, 3, 9}), #{2, 3})
    assert_eq(s.diff(#{1}), #{2, 3})
    assert_eq(2 in s, true)
    assert_eq(s.len(), 3)
    assert_eq(#{1, 1, 2}.len(), 2)
    assert_eq(set([1, 2, 2]).to_list().sort(), [1, 2])
}

test "tuples" {
    let t = (1, "two", 3.0)
    assert_eq(t.0, 1)
    assert_eq(t.1, "two")
    assert_eq(t.len(), 3)
    let (a, b) = (10, 20)
    assert_eq(a + b, 30)
    var x = 1
    var y = 2
    (x, y) = (y, x)
    assert_eq((x, y), (2, 1))
    assert_eq((1,), (1,))
    assert_eq(type((1, 2)), "tuple")
}

test "functions" {
    fn add(a, b = 10) = a + b
    assert_eq(add(1), 11)
    assert_eq(add(1, 2), 3)
    assert_eq(add(b: 5, a: 1), 6)
    fn many(first, *rest) { [first, rest.len()] }
    assert_eq(many(1, 2, 3, 4), [1, 3])
    assert_eq(many(*[9, 8, 7]), [9, 2])
    let inc = |x| x + 1
    assert_eq(inc(1), 2)
    assert_eq((|| 42)(), 42)
    let compose = |f, g| |x| f(g(x))
    assert_eq(compose(inc, inc)(0), 2)
    fn counter() {
        var n = 0
        || { n += 1; n }
    }
    let c = counter()
    c()
    c()
    assert_eq(c(), 3)
    fn fact(n) = if n <= 1 { 1 } else { n * fact(n - 1) }
    assert_eq(fact(10), 3628800)
    assert_throws(|| add())
    assert_throws(|| add(1, 2, 3))
    fn early(x) {
        if x > 5 { return "big" }
        "small"
    }
    assert_eq(early(9), "big")
    assert_eq(early(1), "small")
    // functions can be used before they are written
    assert_eq(later_fn(2), 4)
    fn later_fn(x) = x * x
}

test "control flow" {
    var total = 0
    for i in 1..=5 { total += i }
    assert_eq(total, 15)
    var n = 0
    while n < 10 { n += 3 }
    assert_eq(n, 12)
    let found = loop {
        n += 1
        if n > 20 { break n }
    }
    assert_eq(found, 21)
    var odd = []
    for i in 0..10 {
        if i % 2 == 0 { continue }
        if i > 7 { break }
        odd.push(i)
    }
    assert_eq(odd, [1, 3, 5, 7])
    let label = if total > 10 { "big" } else if total > 5 { "mid" } else { "small" }
    assert_eq(label, "big")
    let none_if = if false { 1 }
    assert_eq(none_if, none)
    var pairs = []
    for (i, ch) in "ab".chars().enumerate() { pairs.push("{i}{ch}") }
    assert_eq(pairs, ["0a", "1b"])
    var kv = []
    for (k, v) in {a: 1, b: 2} { kv.push("{k}={v}") }
    assert_eq(kv, ["a=1", "b=2"])
    for x in [] { fail_here() }
    assert_eq((0..5).sum(), 10)
    assert_eq((0..10).step(3).to_list(), [0, 3, 6, 9])
    assert_eq((1..=3).to_list(), [1, 2, 3])
    assert_eq(len(1..4), 3)
    assert_eq(5 in 1..10, true)
    assert_eq(10 in 1..10, false)
    assert_eq(10 in 1..=10, true)
}

test "pattern matching" {
    fn describe(v) {
        match v {
            0 => "zero",
            1 | 2 | 3 => "small",
            4..10 => "medium",
            n if type(n) == "num" and n > 100 => "huge {n}",
            "hi" => "greeting",
            true => "yes",
            none => "nothing",
            [] => "empty list",
            [x] => "one {x}",
            [first, ..rest] => "list {first} then {rest.len()}",
            {kind: "circle", r} => "circle {r}",
            {name, age: a} => "{name} is {a}",
            (p, q) => "pair {p} {q}",
            _ => "other"
        }
    }
    assert_eq(describe(0), "zero")
    assert_eq(describe(2), "small")
    assert_eq(describe(7), "medium")
    assert_eq(describe(500), "huge 500")
    assert_eq(describe("hi"), "greeting")
    assert_eq(describe(true), "yes")
    assert_eq(describe(none), "nothing")
    assert_eq(describe([]), "empty list")
    assert_eq(describe([5]), "one 5")
    assert_eq(describe([1, 2, 3]), "list 1 then 2")
    assert_eq(describe({kind: "circle", r: 3}), "circle 3")
    assert_eq(describe({name: "Ada", age: 36}), "Ada is 36")
    assert_eq(describe((1, 2)), "pair 1 2")
    assert_eq(describe(:sym), "other")
    assert_eq(describe(-5), "other")
    let [a, b, ..c] = [1, 2, 3, 4]
    assert_eq((a, b, c), (1, 2, [3, 4]))
    let [.., last] = [1, 2, 3]
    assert_eq(last, 3)
    let {x, y: why, ..others} = {x: 1, y: 2, z: 3, w: 4}
    assert_eq((x, why, others), (1, 2, {z: 3, w: 4}))
    assert_throws(|| match 5 { 1 => "one" })
}

test "structs, enums, impl and traits" {
    struct Point { x, y = 0 }
    impl Point {
        fn new(x, y) = Point(x, y)
        fn len(self) = (self.x ** 2 + self.y ** 2) ** 0.5
        fn add(self, o) = Point(self.x + o.x, self.y + o.y)
        fn to_str(self) = "({self.x}, {self.y})"
        fn eq(self, o) = self.x == o.x and self.y == o.y
        const ORIGIN = Point(0, 0)
    }
    let p = Point(3, 4)
    assert_eq(p.len(), 5)
    assert_eq(Point(x: 1).y, 0)
    assert_eq((p + Point(1, 1)).x, 4)
    assert_eq("{p}", "(3, 4)")
    assert_eq(Point.new(1, 2).y, 2)
    assert_eq(Point.ORIGIN.x, 0)
    assert_eq(p == Point(3, 4), true)
    p.x = 10
    assert_eq(p.x, 10)
    assert_eq(p.with(y: 7).y, 7)
    assert_throws(|| Point(1, 2, 3))
    assert_throws(|| p.nope)
    assert_throws(|| Point())

    enum Shape { Circle(r), Rect(w, h), Dot }
    fn area(s) {
        match s {
            Shape.Circle(r) => 3 * r * r,
            Rect(w, h) => w * h,
            Dot => 0
        }
    }
    assert_eq(area(Shape.Circle(2)), 12)
    assert_eq(area(Shape.Rect(2, 5)), 10)
    assert_eq(area(Shape.Dot), 0)
    assert_eq(Shape.Circle(1) == Shape.Circle(1), true)
    assert_eq(Shape.Circle(1) == Shape.Circle(2), false)
    assert_eq(Shape.Rect(1, 2).h, 2)
    enum Color { Red = 1, Green = 2 }
    assert_eq(Color.Green.value, 2)
    assert_eq(Color.Red.name, "Red")

    trait Speak {
        fn name(self)
        fn greet(self) = "I am {self.name()}"
    }
    struct Dog { n }
    impl Speak for Dog { fn name(self) = self.n }
    assert_eq(Dog("Rex").greet(), "I am Rex")
    fn needs_speak(x: Speak) = x.greet()
    assert_eq(needs_speak(Dog("Fido")), "I am Fido")
    assert_throws(|| needs_speak(5))

    struct V2 { x, y }
    impl V2 {
        fn add(self, o) = V2(self.x + o.x, self.y + o.y)
        fn mul(self, k) = V2(self.x * k, self.y * k)
        fn rmul(self, k) = V2(self.x * k, self.y * k)
        fn neg(self) = V2(-self.x, -self.y)
        fn cmp(self, o) = self.x - o.x
    }
    assert_eq((V2(1, 2) + V2(3, 4)).y, 6)
    assert_eq((V2(1, 2) * 3).x, 3)
    assert_eq((3 * V2(1, 2)).y, 6)
    assert_eq((-V2(1, 2)).x, -1)
    assert_eq(V2(1, 0) < V2(2, 0), true)
    assert_eq([V2(3, 0), V2(1, 0)].sort()[0].x, 1)

    impl str { fn shout(self) = self.upper() + "!" }
    assert_eq("hey".shout(), "HEY!")
}

test "errors" {
    var log = []
    try { throw "boom" } catch e { log.push(e) }
    assert_eq(log, ["boom"])
    try { [1][9] } catch e { log.push(e.kind) }
    assert_eq(log[1], "IndexError")
    try { 1 + "a" } catch e { log.push(e.message.starts_with("Cannot do")) }
    assert_eq(log[2], true)
    try { throw {code: 7} } catch {code} { log.push(code) }
    assert_eq(log[3], 7)
    fn f() {
        try { return "from try" } finally { log.push("finally") }
    }
    assert_eq(f(), "from try")
    assert_eq(log[4], "finally")
    let r = try { 5 } catch e { 0 }
    assert_eq(r, 5)
    struct MyErr { msg }
    try { throw MyErr("custom") } catch e { assert_eq(e.msg, "custom") }
    assert_throws(|| panic("no"))
    fn deep(n) = if n == 0 { throw "bottom" } else { deep(n - 1) }
    try { deep(50) } catch e { assert_eq(e, "bottom") }
}

test "results and the ? operator" {
    fn parse(s) = if s.to_int() == none { Err("bad: {s}") } else { Ok(s.to_int()) }
    fn double(s) {
        let n = parse(s)?
        Ok(n * 2)
    }
    assert_eq(double("21"), Ok(42))
    assert_eq(double("x"), Err("bad: x"))
    assert_eq(parse("5").unwrap(), 5)
    assert_eq(parse("x").unwrap_or(0), 0)
    assert_eq(parse("5").map(|n| n + 1), Ok(6))
    assert_eq(parse("x").map_err(|e| e.upper()), Err("BAD: X"))
    assert_eq(parse("5").and_then(|n| Ok(n * 3)), Ok(15))
    assert_eq(parse("5").is_ok(), true)
    assert_throws(|| parse("x").unwrap())
    match parse("7") { Ok(n) => assert_eq(n, 7), Err(e) => fail_test() }
    match parse("q") { Ok(n) => fail_test(), Err(e) => assert_eq(e, "bad: q") }
    fn first_even(xs) {
        let x = xs.find(|n| n % 2 == 0)?
        x * 10
    }
    assert_eq(first_even([1, 4]), 40)
    assert_eq(first_even([1, 3]), none)
}

test "optional chaining and coalescing" {
    let user = {name: "Ada", address: {city: "London"}}
    assert_eq(user.address.city, "London")
    assert_eq(user.phone ?? "none", "none")
    assert_eq(user.address?.city, "London")
    let nobody = none
    assert_eq(nobody?.name, none)
    assert_eq(nobody?.name ?? "anon", "anon")
    assert_eq(nobody?.items.len(), none)
    var cfg = {}
    cfg.port ??= 8080
    cfg.port ??= 1
    assert_eq(cfg.port, 8080)
    assert_eq(0 ?? 5, 0)
    assert_eq(false ?? 5, false)
}

test "pipes, comprehensions and truthiness" {
    assert_eq([1, 2, 3] |> map(|x| x * 2) |> sum(), 12)
    assert_eq(5 |> |x| x + 1, 6)
    assert_eq([x * x for x in 1..5], [1, 4, 9, 16])
    assert_eq([x for x in 1..10 if x % 3 == 0], [3, 6, 9])
    assert_eq([(a, b) for a in 1..3 for b in "xy".chars()], [(1, "x"), (1, "y"), (2, "x"), (2, "y")])
    assert_eq({k: k.len() for k in ["a", "bb"]}, {a: 1, bb: 2})
    assert_eq(#{x % 3 for x in 0..10}, #{0, 1, 2})
    // only false and none are false: 0 and "" count as true
    assert_eq(if 0 { "t" } else { "f" }, "t")
    assert_eq(if "" { "t" } else { "f" }, "t")
    assert_eq(if [] { "t" } else { "f" }, "t")
    assert_eq(if none { "t" } else { "f" }, "f")
    assert_eq(not 0, false)
    assert_eq(1 and 2, 2)
    assert_eq(none or "x", "x")
}
