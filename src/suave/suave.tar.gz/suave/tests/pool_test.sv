// Pools: values that are decided when they are used.
use std.random
use std.pool as pools

test "a pool stays undecided until it is used" {
    random.seed(1)
    let p = pool [1, 2, 3]
    assert_eq(is_pool(p), true)
    assert_eq(p.is_decided(), false)
    assert_eq(p.peek(), none)
    assert_eq(type(p), "pool")
    let both = [p, p]                 // storing it does not decide
    assert_eq(len(both), 2)
    assert_eq(p.is_decided(), false)
    let v = p + 0                     // using it does
    assert_eq(p.is_decided(), true)
    assert(v in [1, 2, 3])
    assert_eq(p + 0, v)               // and it stays decided
    assert_eq(p * 1, v)
    assert_eq("{p}", "{v}")
    assert_eq(p.peek(), v)
    p.forget()
    assert_eq(p.is_decided(), false)
}

test "every way of using a pool decides it" {
    random.seed(2)
    for make in [|| pool [5, 5], || pool ["a", "a"], || pool [[1, 2], [1, 2]], || pool [true, true]] {
        let p = make()
        assert_eq(p.is_decided(), false)
        print_to_nowhere(p)
        assert_eq(p.is_decided(), true)
    }
    let a = pool [7, 7]
    assert_eq(a == 7, true)
    assert_eq(pool [1, 1] < 2, true)
    assert_eq(if pool [true, true] { "yes" } else { "no" }, "yes")
    assert_eq(match pool [3, 3] { 3 => "three", _ => "other" }, "three")
    assert_eq(pool [2, 2] ** 2, 4)
    assert_eq(-(pool [2, 2]), -2)
    let s = pool ["ab", "ab"]
    assert_eq(s.len(), 2)
    assert_eq(s.upper(), "AB")
    assert_eq(s[0], "a")
    var n = 0
    for x in pool [[1, 2], [1, 2]] { n += x }
    assert_eq(n, 3)
    assert_eq(abs(pool [-3, -3]), 3)
    assert_eq(pool [none, none] ?? 5, 5)
}
fn print_to_nowhere(x) { let y = str(x); y }

test "passing a pool around does not decide it, using it inside does" {
    fn describe(w) = if w == "rain" { "umbrella" } else { "sunglasses" }
    fn pass_along(w) = w
    random.seed(3)
    let w = pool ["rain", "sun"]
    let same = pass_along(w)
    assert_eq(w.is_decided(), false)
    let answer = describe(w)
    assert_eq(w.is_decided(), true)
    assert_eq(answer, if w.peek() == "rain" { "umbrella" } else { "sunglasses" })
    assert_eq(same.is_decided(), true)         // the very same pool
}

test "weights, odds and filters" {
    let loaded = pool {"six": 5, "other": 1}
    assert_eq(loaded.most_likely(), "six")
    assert(abs(loaded.odds_of("six") - 5 / 6) < 1e-12)
    assert_eq(loaded.chances().len(), 2)
    assert_eq(pool [1, 2, 3, 4].where(|n| n % 2 == 0).options(), [2, 4])
    assert_eq(pool [1, 2].map(|n| n * 10).options(), [10, 20])
    assert_eq((pool 1..=6).options(), [1, 2, 3, 4, 5, 6])
    assert_eq(pool([1, 2, 3], weights: [0, 0, 1]) + 0, 3)
    assert_eq(pool [1, 2, 3].with_weights([0, 1, 0]) + 0, 2)
    assert_throws(|| pool [] + 1)
    assert_throws(|| pool "text")
    assert_throws(|| pool {"a": -1})
    random.seed(4)
    let counts = pool {"a": 3, "b": 1}.simulate(4000)
    assert(counts["a"] > 2600 and counts["a"] < 3400)
    let before = pool [1, 2]
    before.simulate(10)
    assert_eq(before.is_decided(), false)       // simulating never decides
}

test "entangled pools decide together" {
    random.seed(5)
    let a = pool ["red", "green", "blue"]
    let b = pool ["stop", "go", "wait"]
    entangle(a, b)
    assert_eq(a.is_entangled(), true)
    let x = "{b}"
    assert_eq(a.is_decided(), false)             // deciding b has not touched a's value yet...
    let y = "{a}"
    let index_a = ["red", "green", "blue"].index_of(y)
    let index_b = ["stop", "go", "wait"].index_of(x)
    assert_eq(index_a, index_b)                  // ...but they always pick the same position
    assert_throws(|| entangle(pool [1, 2], pool [1, 2, 3]))
}

test "pools from functions and std.pool" {
    random.seed(6)
    let u = pools.uniform(10, 20)
    let v = u + 0
    assert(v >= 10 and v < 20)
    assert_eq(u + 0, v)
    let d = pools.die(6) + 0
    assert(d >= 1 and d <= 6)
    let sampler = pool || 42
    assert_eq(sampler + 0, 42)
    assert(pools.dice("3d6") + 0 >= 3)
    assert_eq(pools.shuffle([1, 2, 3]).decide().sort(), [1, 2, 3])
    assert_eq(pools.deal([1, 2, 3, 4], 2).decide().len(), 2)
    assert_eq(is_pool(pools.coin()), true)
    assert_eq(pools.decide_all([pool [1, 1], 5]), [1, 5])
    assert_eq(inspect(pool [1, 2]), "pool [1, 2] (undecided)")
    let seeded = []
    for run in 1..=2 { random.seed(99); seeded.push(pool [1, 2, 3, 4, 5, 6, 7, 8, 9] + 0) }
    assert_eq(seeded[0], seeded[1])              // a seed makes pools repeatable
}
