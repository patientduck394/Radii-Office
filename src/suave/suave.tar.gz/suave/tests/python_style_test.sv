# Python-style Suave: colons and indentation, def, elif, lambda, and friends.

test "def, if, elif, else":
    def sign(n):
        if n > 0:
            return "plus"
        elif n < 0:
            return "minus"
        else:
            return "zero"
    assert_eq(sign(5), "plus")
    assert_eq(sign(-2), "minus")
    assert_eq(sign(0), "zero")

test "for, while, and a one-line body":
    total = 0
    for i in range(1, 5):
        total += i
    assert_eq(total, 10)
    n = 3
    while n > 0:
        n -= 1
    assert_eq(n, 0)
    hits = []
    for k in range(6):
        if k % 2 == 0: hits.push(k)
    assert_eq(hits, [0, 2, 4])

test "plain assignment makes variables":
    x = 1
    x = x + 1
    assert_eq(x, 2)
    a, b = 1, 2
    a, b = b, a
    assert_eq([a, b], [2, 1])
    first, *rest = [1, 2, 3]
    assert_eq(rest, [2, 3])
    let locked = 5
    assert_eq(locked, 5)

test "assignment inside a function changes the outer variable":
    count = 0
    def bump():
        count += 1
    bump()
    bump()
    assert_eq(count, 2)

test "lambda, ternary, and comprehensions":
    double = lambda x: x * 2
    add = lambda a, b=10: a + b
    assert_eq(double(4), 8)
    assert_eq(add(1), 11)
    label = "adult" if 20 >= 18 else "minor"
    assert_eq(label, "adult")
    assert_eq([x if x > 1 else 0 for x in range(4)], [0, 0, 2, 3])
    assert_eq(sum(n * n for n in range(4)), 14)

test "True, False, None, pass, and, or, not":
    assert_eq(True and not False, true)
    assert_eq(None, none)
    def nothing():
        pass
    assert_eq(nothing(), none)

test "match with case":
    def kind(x):
        match x:
            case 0:
                return "zero"
            case 1 | 2:
                return "small"
            case n if n > 100:
                return "huge"
            case _:
                return "other"
    assert_eq(kind(0), "zero")
    assert_eq(kind(2), "small")
    assert_eq(kind(500), "huge")
    assert_eq(kind(50), "other")

test "try, except, finally, raise":
    log = []
    def risky(n):
        try:
            if n < 0:
                raise "negative"
            return n
        except e:
            return "caught {e}"
        finally:
            log.push(n)
    assert_eq(risky(2), 2)
    assert_eq(risky(-1), "caught negative")
    assert_eq(log, [2, -1])

test "class with fields and methods":
    class Dog:
        name: str
        age: num = 1

        def speak(self):
            return f"{self.name} is {self.age}"

        def birthday(self):
            self.age += 1
            return self
    rex = Dog("Rex")
    assert_eq(rex.speak(), "Rex is 1")
    assert_eq(rex.birthday().speak(), "Rex is 2")
    assert_eq(Dog(name="Fido", age=7).speak(), "Fido is 7")

test "import and from ... import":
    import math
    from math import sqrt, pi
    assert_eq(math.floor(2.7), 2)
    assert_eq(sqrt(16), 4)
    assert_eq(pi > 3.14, true)

test "named arguments with =":
    def box(w, h=2):
        return w * h
    assert_eq(box(3, h=5), 15)
    assert_eq(box(w=4), 8)

test "braces still work and mix with colons":
    fn old(n) {
        if n > 1 {
            return "big"
        }
        return "small"
    }
    assert_eq(old(2), "big")
    def newer(n):
        return [1, 2, 3].map(|v| v + n)
    assert_eq(newer(1), [2, 3, 4])

test "Python habits: append, sort, slices, strip, isinstance, join":
    xs = [3, 1]
    xs.append(2)
    xs.sort()
    assert_eq(xs, [1, 2, 3])
    xs.sort(reverse=True)
    assert_eq(xs, [3, 2, 1])
    assert_eq(sorted(["bb", "a"], key=len), ["a", "bb"])
    assert_eq(xs[1:3], [2, 1])
    assert_eq(xs[:2], [3, 2])
    assert_eq(xs[1:], [2, 1])
    assert_eq("hello"[1:3], "el")
    assert_eq("  hi ".strip(), "hi")
    assert_eq(isinstance(3, int), true)
    assert_eq(isinstance("a", int), false)
    assert_eq(", ".join(["a", "b"]), "a, b")
