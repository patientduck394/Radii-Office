// Quantum computing (std.quantum) and quantum mechanics (std.qm).
use std.quantum as q
use std.qm
use std.math
use std.random

test "single qubits and gates" {
    let r = q.register(1)
    assert_eq(r.probs(), {"0": 1})
    r.x(0)
    assert_eq(r.probs(), {"1": 1})
    r.x(0).h(0)
    assert_eq(r.probs(), {"0": 0.5, "1": 0.5})
    assert_eq(q.register(1).h(0).h(0).probs(), {"0": 1})              // H twice undoes itself
    assert_eq(q.register(1).h(0).z(0).h(0).probs(), {"1": 1})         // HZH = X
    assert_eq(q.register(1).h(0).s(0).s(0).h(0).probs(), {"1": 1})    // S twice is Z
    assert_eq(q.register(1).rx(0, math.PI).probs(), {"1": 1})
    assert_eq(q.register(1).ry(0, math.PI / 2).probs(), {"0": 0.5, "1": 0.5})
    let b = q.register(1).h(0).s(0).bloch(0)
    assert_eq((b.x, b.y, b.z), (0, 1, 0))
    assert_eq(q.register(1).h(0).text(), "0.7071|0> + 0.7071|1>")
    assert_eq(q.register(1).h(0).s(0).text(), "0.7071|0> + 0.7071i|1>")
    assert_throws(|| q.register(1).h(5))
    assert_throws(|| q.register(0))
    assert_throws(|| q.register(40))
    assert_throws(|| q.register(1).gate([[1, 1], [1, 1]], 0))         // not unitary
}

test "entanglement" {
    let bell = q.bell()
    assert_eq(bell.probs(), {"00": 0.5, "11": 0.5})
    assert_eq(bell.is_entangled(), true)
    assert_eq(bell.entanglement(0), 1)
    assert_eq(bell.expect("ZZ"), 1)
    assert_eq(bell.expect("XX"), 1)
    assert_eq(bell.expect("ZI"), 0)
    assert_eq(q.register(2).h(0).is_entangled(), false)
    assert_eq(q.bell(3).text(), "0.7071|01> - 0.7071|10>")
    let g = q.ghz(4)
    assert_eq(g.probs(), {"0000": 0.5, "1111": 0.5})
    assert_eq(q.w(3).probs().len(), 3)
    random.seed(11)
    for _ in 1..20 {
        let r = q.bell()
        let (a, b) = (r.measure(0), r.measure(1))
        assert_eq(a, b)                         // measuring one qubit decides the other
    }
    assert_eq(q.bell().draw().contains("●"), true)
    assert_eq(q.bell().ops().len(), 2)
}

test "more gates" {
    assert_eq(q.basis("100").swap(0, 2).text(), "1|001>")
    assert_eq(q.basis("110").ccx(0, 1, 2).text(), "1|111>")
    assert_eq(q.basis("010").ccx(0, 1, 2).text(), "1|010>")
    assert_eq(q.basis("11").cz(0, 1).text(), "-1|11>")
    assert_eq(q.basis("101").cswap(0, 1, 2).text(), "1|110>")
    let r = q.basis("01").qft()
    assert_eq(r.probabilities().map(|p| p.round(6)), [0.25, 0.25, 0.25, 0.25])
    let z = q.from_amplitudes([1, 2i, -1, 3])
    let w = z.copy()
    w.qft().iqft()
    assert_eq(z.fidelity(w), 1)
    assert_eq(q.register(2).h_all().probs().len(), 4)
    let flipped = q.register(3).phase_oracle(|i| i == 5)
    assert_eq(flipped.amplitudes().len(), 8)
    assert_eq(q.register(2).x(1).permute(|i| (i + 1) % 4).text(), "1|10>")
    assert_throws(|| q.register(2).permute(|i| 0))                    // must be reversible
    assert_eq(q.register(1).gate([[0, 1], [1, 0]], 0).probs(), {"1": 1})
}

test "measuring collapses the state" {
    random.seed(21)
    let r = q.register(3).h_all()
    let bits = r.measure()
    assert_eq(bits.len(), 3)
    let probs = r.probs()
    assert_eq(probs.len(), 1)                    // only one outcome is left
    assert_eq(r.measure(), bits)                 // measuring again gives the same answer
    let counts = q.bell().sample(2000)
    assert(counts["00"] > 850 and counts["00"] < 1150)
    assert_eq(counts.len(), 2)
    random.seed(22)
    let again = q.bell().sample(100)
    random.seed(22)
    assert_eq(q.bell().sample(100), again)       // a seed makes it repeatable
    assert_eq(q.random_bits(8).len(), 8)
    assert(q.random_int(10) < 10)
}

test "pools measured only when used" {
    random.seed(31)
    let r = q.register(1).h(0)
    let outcome = r.measure_later(0)
    assert_eq(is_pool(outcome), true)
    assert_eq(r.probs(), {"0": 0.5, "1": 0.5})  // nothing has been measured yet
    let value = outcome + 0                      // using it measures
    assert_eq(r.probs(), {"{value}": 1})
    let p = q.ghz(3).pool()
    assert_eq(p.options().sort(), ["000", "111"])
    assert_eq(p.is_decided(), false)
}

test "quantum algorithms" {
    random.seed(41)
    assert_eq(q.deutsch_jozsa(3, |x| 0).verdict, "constant")
    assert_eq(q.deutsch_jozsa(3, |x| 1).verdict, "constant")
    assert_eq(q.deutsch_jozsa(3, |x| x % 2).verdict, "balanced")
    assert_eq(q.deutsch_jozsa(4, |x| if x < 8 { 1 } else { 0 }).verdict, "balanced")
    assert_throws(|| q.deutsch_jozsa(2, |x| if x == 0 { 1 } else { 0 }))
    assert_eq(q.bernstein_vazirani("10110").secret, "10110")
    let g = q.grover(4, [11])
    assert_eq(g.iterations, 3)
    assert(abs(g.probability - 0.9613) < 0.001)
    assert_eq(q.grover(6, |x| x == 42).probability > 0.99, true)
    assert_eq(q.grover(5, [3, 9]).marked, 2)
    assert_throws(|| q.grover(3, []))
    for s in 1..=5 {
        random.seed(s)
        assert(abs(q.teleport(0.6, 0.8).fidelity - 1) < 1e-9)
    }
    assert_eq(q.shor(15).factors, [3, 5])
    assert_eq(q.shor(21).factors, [3, 7])
    assert_eq(q.shor(35).factors, [5, 7])
    assert_eq(q.shor(14).factors, [2, 7])
    assert_throws(|| q.shor(3))
}

test "physics constants and atoms" {
    assert(abs(qm.hydrogen_energy(1) + 13.6057) < 1e-3)
    assert(abs(qm.hydrogen_energy(2) + 3.4014) < 1e-3)
    assert(abs(qm.hydrogen_transition(3, 2).wavelength_nm - 656.11) < 0.05)
    assert_eq(qm.hydrogen_transition(2, 1).series, "Lyman")
    assert(abs(qm.hydrogen_transition(2, 1).wavelength_nm - 121.5) < 0.1)
    assert_throws(|| qm.hydrogen_transition(1, 2))
    assert(abs(qm.box_energy_ev(1, 1e-9) - 0.376) < 0.001)
    assert(abs(qm.box_probability(1, 1, 0, 0.5) - 0.5) < 1e-12)
    assert(abs(qm.box_probability(2, 1, 0, 1) - 1) < 1e-12)
    assert(abs(qm.photon_energy_ev(500) - 2.4797) < 1e-3)
    assert(abs(qm.electron_wavelength(100) * 1e12 - 122.64) < 0.01)
    assert_eq(qm.electron_configuration(11), "1s2 2s2 2p6 3s1")
    assert_eq(qm.orbital_name(3, 2), "3d")
    assert_eq(qm.hydrogen_degeneracy(3), 18)
    assert_eq(qm.quantum_numbers(2).len(), 8)
    var total = 0
    for i in 1..3000 { total += qm.hydrogen_density(2, 1, i * 0.01) * 0.01 }
    assert(abs(total - 1) < 1e-3)                 // the 2p orbital is normalised
    assert(qm.tunneling(1, 2, 1, 1, 1) > 0 and qm.tunneling(1, 2, 1, 1, 1) < 1)
    assert(qm.tunneling(1, 2, 3, 1, 1) < qm.tunneling(1, 2, 1, 1, 1))     // thicker barrier, less tunneling
    assert(abs(qm.oscillator_energy(2, 1, 1) - 2.5) < 1e-12)
    assert(abs(qm.min_momentum_spread(1e-10) - 5.2729e-25) < 1e-28)
}

test "the Schrodinger equation" {
    let sol = qm.solve_1d(|x| 0.5 * x * x, -8, 8, 500, k: 4)
    for (n, e) in sol.energies.enumerate() { assert(abs(e - (n + 0.5)) < 0.01) }
    let exact = sol.x.map(|x| qm.oscillator_psi(0, x))
    for (a, b) in sol.states[0].zip(exact) { assert(abs(a - b) < 1e-3) }
    let box = qm.solve_1d(|x| 0, 0, 1, 400, k: 3)
    for (i, n) in [1, 2, 3].enumerate() { assert(abs(box.energies[i] - n * n * math.PI ** 2 / 2) < 0.01) }
    let xs = (0..256).map(|i| -20 + i * 40 / 256)
    let psi0 = qm.gaussian_packet(xs, -5, 1, 2)
    let dx = xs[1] - xs[0]
    assert(abs(qm.norm(psi0, dx) - 1) < 1e-9)
    let psi1 = qm.evolve(psi0, 0, xs, dt: 0.05, steps: 100)
    assert(abs(qm.norm(psi1, dx) - 1) < 1e-9)                 // probability is conserved
    assert(abs(qm.expect_x(psi1, xs) - 5) < 0.05)             // the packet moved to x = -5 + k t = 5
    assert(qm.spread_x(psi1, xs) > qm.spread_x(psi0, xs))     // and spread out
    assert(abs(qm.expect_p(psi0, xs) - 2) < 0.05)
    assert_throws(|| qm.evolve(psi0.take(100), 0, xs.take(100), steps: 1))   // needs 2^k points
}

test "spin and complex matrices" {
    let P = qm.pauli()
    let two_iz = qm.scale(P.Z, 2i)
    let comm = qm.commutator(P.X, P.Y)
    for (i, row) in comm.enumerate() { for (j, v) in row.enumerate() { assert(abs(v - two_iz[i][j]) < 1e-12) } }
    assert_eq(qm.is_hermitian(P.Y), true)
    assert_eq(qm.is_unitary(P.X), true)
    assert_eq(qm.is_hermitian([[1, 2], [3, 4]]), false)
    assert(abs(qm.spin_expect(qm.spin_state(math.PI / 2, 0), "x") - 1) < 1e-12)
    assert_eq(qm.spin_expect(qm.spin_up(), "z"), 1)
    assert_eq(qm.spin_expect(qm.spin_down(), "z"), -1)
    let ev = qm.eigh([[0, 1], [1, 0]])
    assert_eq(ev.values.map(|v| v.round(9)), [-1, 1])
    let hy = qm.eigh([[1, 1i], [-1i, 1]])
    assert_eq(hy.values.map(|v| v.round(9)), [0, 2])
    let evolved = qm.time_evolve(P.X, qm.spin_up(), math.PI / 4)
    assert_eq(qm.born(evolved).map(|p| p.round(9)), [0.5, 0.5])
    let full = qm.time_evolve(P.X, qm.spin_up(), math.PI / 2)
    assert_eq(qm.born(full).map(|p| p.round(9)), [0, 1])        // a full spin flip
    let rho = qm.density(qm.normalize([1, 1]))
    assert(abs(qm.purity(rho) - 1) < 1e-12)
    assert(abs(qm.von_neumann(rho)) < 1e-9)
    assert(abs(qm.von_neumann([[0.5, 0], [0, 0.5]]) - 1) < 1e-9)
    assert_eq(qm.kron(P.Z, P.X).len(), 4)
    assert_eq(qm.trace(P.Z), 0)
    assert_eq(qm.ket_text([1, 1i]), "1|0> + i|1>")
    assert_eq(qm.inner([1, 0], [0, 1]), 0)
}
