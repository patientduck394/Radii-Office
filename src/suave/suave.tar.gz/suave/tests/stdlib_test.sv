// Tests for the standard library.
use std.math
use std.stats
use std.linalg
use std.random
use std.text
use std.fmt
use std.regex
use std.encoding
use std.hash
use std.uuid
use std.url
use std.markdown
use std.template
use std.color
use std.unit
use std.diff
use std.semver
use std.date
use std.time
use std.path
use std.fs
use std.os
use std.env
use std.process
use std.ds
use std.graph
use std.iter
use std.func
use std.algo
use std.table
use std.plot
use std.geometry
use std.xml
use std.ini
use std.complex
use std.rational
use std.bigint
use std.bits
use std.events
use std.cli

test "math" {
    assert_eq(math.gcd(12, 18), 6)
    assert_eq(math.lcm(4, 6), 12)
    assert_eq(math.factorial(10), 3628800)
    assert_eq(math.choose(5, 2), 10)
    assert_eq(math.is_prime(97), true)
    assert_eq(math.primes(20), [2, 3, 5, 7, 11, 13, 17, 19])
    assert_eq(math.prime_factors(360), [2, 2, 2, 3, 3, 5])
    assert_eq(math.divisors(12), [1, 2, 3, 4, 6, 12])
    assert_eq(math.fib(20), 6765)
    assert_eq(math.mod_pow(4, 13, 497), 445)
    assert_eq(math.round(2.675, 2), 2.68)
    assert_eq(math.clamp(15, 0, 10), 10)
    assert(math.approx(math.sqrt(2) ** 2, 2))
    assert(math.approx(math.solve(|x| x * x - 2, 0, 2), math.sqrt(2)))
    assert(math.approx(math.integrate(|x| x * x, 0, 3), 9, 1e-9))
    assert_eq(math.quadratic(1, -3, 2), [1, 2])
    assert_eq(math.collatz(6), [6, 3, 10, 5, 16, 8, 4, 2, 1])
}

test "stats" {
    assert_eq(stats.mean([1, 2, 3, 4]), 2.5)
    assert_eq(stats.median([5, 1, 3]), 3)
    assert_eq(stats.median([1, 2, 3, 4]), 2.5)
    assert_eq(stats.mode([1, 2, 2, 3]), 2)
    assert_eq(stats.stddev([2, 4, 4, 4, 5, 5, 7, 9]), 2)
    assert_eq(stats.percentile([1, 2, 3, 4, 5], 50), 3)
    assert(math.approx(stats.corr([1, 2, 3], [2, 4, 6]), 1))
    let fit = stats.linreg([1, 2, 3, 4], [3, 5, 7, 9])
    assert(math.approx(fit.slope, 2))
    assert(math.approx(fit.intercept, 1))
    assert_eq(stats.cumsum([1, 2, 3]), [1, 3, 6])
    assert_eq(stats.moving_avg([1, 2, 3, 4], 2), [1.5, 2.5, 3.5])
}

test "linear algebra" {
    assert_eq(linalg.det([[1, 2], [3, 4]]), -2)
    assert_eq(linalg.transpose([[1, 2, 3], [4, 5, 6]]), [[1, 4], [2, 5], [3, 6]])
    assert_eq(linalg.matmul([[1, 2], [3, 4]], [[5, 6], [7, 8]]), [[19, 22], [43, 50]])
    assert_eq(linalg.dot([1, 2, 3], [4, 5, 6]), 32)
    assert_eq(linalg.inverse([[2, 0], [0, 4]]), [[0.5, 0], [0, 0.25]])
    let x = linalg.solve([[2, 1], [1, 3]], [3, 5])
    assert(math.approx(x[0], 0.8) and math.approx(x[1], 1.4))
    assert_eq(linalg.eye(2), [[1, 0], [0, 1]])
    assert_eq(linalg.cross([1, 0, 0], [0, 1, 0]), [0, 0, 1])
    assert_throws(|| linalg.inverse([[1, 2], [2, 4]]))
}

test "random is repeatable with a seed" {
    random.seed(7)
    let a = [random.rand(), random.randint(1, 100), random.choice([1, 2, 3])]
    random.seed(7)
    let b = [random.rand(), random.randint(1, 100), random.choice([1, 2, 3])]
    assert_eq(a, b)
    assert_eq(random.shuffle([1, 2, 3, 4, 5]).sort(), [1, 2, 3, 4, 5])
    for _ in 1..50 { let r = random.randint(3, 6); assert(r >= 3 and r <= 6) }
    assert_eq(random.sample([1, 2, 3, 4], 2).len(), 2)
    assert_eq(random.string(8).len(), 8)
}

test "text and fmt" {
    assert_eq(text.slug("Héllo Wörld! Suave"), "hello-world-suave")
    assert_eq(text.levenshtein("kitten", "sitting"), 3)
    assert_eq(text.wrap("the quick brown fox", 10), "the quick\nbrown fox")
    assert_eq(text.snake("helloWorldFoo"), "hello_world_foo")
    assert_eq(text.pascal("hello world"), "HelloWorld")
    assert_eq(text.human_bytes(1536), "1.5 KB")
    assert_eq(text.human_number(1234567), "1.2M")
    assert_eq(text.ordinal(22), "22nd")
    assert_eq(text.is_palindrome("A man, a plan, a canal: Panama"), true)
    assert_eq(text.truncate("hello world", 8), "hello w…")
    assert_eq(fmt.sprintf("%5.2f|%-4s|%03d|%x|%%", 3.14159, "ab", 7, 255), " 3.14|ab  |007|ff|%")
    assert_eq(fmt.roman(1994), "MCMXCIV")
    assert_eq(fmt.from_roman("MCMXCIV"), 1994)
    assert_eq(fmt.words(1234), "one thousand two hundred and thirty-four")
    assert_eq(fmt.thousands(1234567.5), "1,234,567.5")
    assert_eq(fmt.money(1234.5), "$1,234.50")
    assert_eq(fmt.list(["a", "b", "c"]), "a, b, and c")
    assert(fmt.table([[1, 2], [3, 4]]).contains("┌"))
}

test "regex, encodings, hashes, ids" {
    assert_eq(regex.find_all("\\d+", "a1b22c333"), ["1", "22", "333"])
    assert_eq(regex.match(r"(?<y>\d{4})-(?<m>\d\d)", "on 2026-11 ok").named, {y: "2026", m: "11"})
    assert_eq(regex.replace("\\s+", "a   b \t c", " "), "a b c")
    assert_eq(regex.split(",\\s*", "a, b,c"), ["a", "b", "c"])
    assert_eq(regex.test("^[\\w.]+@[\\w.]+$", "a.b@c.d"), true)
    assert_eq(encoding.base64("Suave!"), "U3VhdmUh")
    assert_eq(encoding.base64_decode("U3VhdmUh"), "Suave!")
    assert_eq(encoding.hex("hi"), "6869")
    assert_eq(encoding.url_encode("a b&c"), "a%20b%26c")
    assert_eq(encoding.html_escape("<a & b>"), "&lt;a &amp; b&gt;")
    assert_eq(encoding.html_unescape("&lt;&amp;&gt;"), "<&>")
    assert_eq(hash.sha256("abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    assert_eq(hash.sha1("abc"), "a9993e364706816aba3e25717850c26c9cd0d89d")
    assert_eq(hash.md5("abc"), "900150983cd24fb0d6963f7d28e17f72")
    assert_eq(hash.crc32("123456789"), 3421780262)
    assert_eq(hash.hmac_sha256("key", "The quick brown fox jumps over the lazy dog"), "f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8")
    assert_eq(uuid.is_valid(uuid.v4()), true)
    assert_eq(uuid.is_valid("nope"), false)
    assert_eq(uuid.v4() == uuid.v4(), false)
}

test "url, markdown, templates" {
    let u = url.parse("https://u@example.com:8080/a/b?x=1&y=2&x=3#top")
    assert_eq((u.scheme, u.host, u.port, u.path, u.hash), ("https", "example.com", 8080, "/a/b", "top"))
    assert_eq(u.query, {x: ["1", "3"], y: "2"})
    assert_eq(url.join("https://a.com/b/c", "../d"), "https://a.com/d")
    assert_eq(markdown.to_html("# Hi\n\n**bold** and *it*"), "<h1>Hi</h1>\n<p><strong>bold</strong> and <em>it</em></p>")
    assert_eq(markdown.to_html("- a\n- b"), "<ul><li>a</li><li>b</li></ul>")
    assert_eq(markdown.headings("# A\n## B").len(), 2)
    assert_eq(template.render('Hi {{name}}! {{#each xs}}<{{this}}{{@index}}>{{/each}}{{#if ok}} yes{{else}} no{{/if}}', {name: "Ada", xs: ["a", "b"], ok: false}), "Hi Ada! <a0><b1> no")
    assert_eq(template.render('{{x}}', {x: "<b>"}), "&lt;b&gt;")
    assert_eq(template.render('{{{x}}}', {x: "<b>"}), "<b>")
    assert_eq(template.fill('Hello {name}', {name: "Ada"}), "Hello Ada")
}

test "colors, units, diffs, versions" {
    assert_eq(color.to_hex("red"), "#ff0000")
    assert_eq(color.to_rgb("#336699"), (51, 102, 153))
    assert_eq(color.mix("#ff0000", "#0000ff"), "#800080")
    assert_eq(color.contrast("#000", "#fff"), 21)
    assert_eq(color.hsl(120, 100, 50), "#00ff00")
    assert_eq(unit.convert(100, "km", "mi").round(2), 62.14)
    assert_eq(unit.convert(212, "F", "C"), 100)
    assert_eq(unit.convert(1, "kg", "lb").round(3), 2.205)
    assert_throws(|| unit.convert(1, "kg", "m"))
    assert_eq(diff.stats("a\nb\nc", "a\nx\nc"), {added: 1, removed: 1, same: 2})
    assert_eq(semver.compare("1.2.3", "1.10.0"), -1)
    assert_eq(semver.satisfies("1.4.2", "^1.2.0"), true)
    assert_eq(semver.satisfies("2.0.0", "^1.2.0"), false)
    assert_eq(semver.bump("1.2.3", "minor"), "1.3.0")
    assert_eq(semver.sort(["1.10.0", "1.2.0", "1.2.0-rc.1"]), ["1.2.0-rc.1", "1.2.0", "1.10.0"])
}

test "dates and time" {
    let d = date.parse("2026-11-17 14:30")
    assert_eq(date.format(d, "%A, %B %e, %Y %I:%M %p"), "Tuesday, November 17, 2026 02:30 PM")
    assert_eq(date.format(date.add(d, days: 30), "%F"), "2026-12-17")
    assert_eq(date.format(date.add(date.parse("2026-01-31"), months: 1), "%F"), "2026-02-28")
    assert_eq(date.diff(date.parse("2026-12-25"), date.parse("2026-12-01")), 24)
    assert_eq(date.weekday_name(date.parse("2000-01-01")), "Saturday")
    assert_eq(date.is_leap(2024), true)
    assert_eq(date.days_in_month(2026, 2), 28)
    assert_eq(date.age(date.parse("2000-06-15"), date.parse("2026-06-14")), 25)
    assert_eq(date.relative(date.parse("2026-01-01"), date.parse("2026-01-03")), "2 days ago")
    assert_eq(d.year(), 2026)
    assert_eq(date.parse("17/11/2026", "%d/%m/%Y").day(), 17)
    assert_eq(time.parse_duration("1h30m"), 5400)
    assert_eq(time.parse_duration("1:30"), 90)
    assert_eq(time.format_duration(3725), "1h 2m 5s")
    let (r, secs) = time.measure(|| 6 * 7)
    assert_eq(r, 42)
    assert(secs >= 0)
    let sw = time.stopwatch()
    assert(sw.elapsed() >= 0)
}

test "paths and files" {
    assert_eq(path.join("a", "../b", "c.txt"), "b/c.txt")
    assert_eq(path.dirname("/x/y/z.txt"), "/x/y")
    assert_eq(path.basename("/x/y/z.txt"), "z.txt")
    assert_eq(path.ext("a/b.tar.gz"), ".gz")
    assert_eq(path.stem("a/b.tar.gz"), "b.tar")
    assert_eq(path.relative("/a/b", "/a/c/d"), "../c/d")
    let dir = fs.temp_dir()
    let f = path.join(dir, "note.txt")
    fs.write(f, "hello\nworld\n")
    assert_eq(fs.read(f), "hello\nworld\n")
    assert_eq(fs.read_lines(f), ["hello", "world"])
    fs.append(f, "more\n")
    assert_eq(fs.read_lines(f).len(), 3)
    assert_eq(fs.exists(f), true)
    assert_eq(fs.is_file(f), true)
    assert_eq(fs.size(f), 17)
    fs.mkdir(path.join(dir, "sub/deeper"))
    fs.write(path.join(dir, "sub/a.sv"), "1")
    assert_eq(fs.list(dir), ["note.txt", "sub"])
    assert_eq(fs.walk(dir, pattern: "**/*.sv").len(), 1)
    fs.copy(f, path.join(dir, "copy.txt"))
    fs.rename(path.join(dir, "copy.txt"), path.join(dir, "moved.txt"))
    assert_eq(fs.exists(path.join(dir, "moved.txt")), true)
    fs.remove(dir, true)
    assert_eq(fs.exists(dir), false)
    assert_throws(|| fs.read("/definitely/not/here.txt"))
}

test "environment and processes" {
    env.set("SUAVE_TEST_VAR", "42")
    assert_eq(env.get("SUAVE_TEST_VAR"), "42")
    assert_eq(env.int("SUAVE_TEST_VAR"), 42)
    assert_eq(env.get("SUAVE_NOT_SET", "fallback"), "fallback")
    assert_eq(env.parse("A=1\n# c\nB=\"two words\"\nexport C='x'"), {A: "1", B: "two words", C: "x"})
    assert_eq(os.name().len() > 0, true)
    let r = process.run("echo", ["hi there"])
    assert_eq(r.stdout, "hi there\n")
    assert_eq(r.ok, true)
    assert_eq(process.shell("exit 3").code, 3)
    assert_eq(process.output("echo", ["x"]), "x\n")
}

test "data structures" {
    let h = ds.heap(key: |x| x.p)
    h.push({p: 3, n: "c"}, {p: 1, n: "a"}, {p: 2, n: "b"})
    assert_eq([h.pop().n, h.pop().n, h.pop().n, h.pop()], ["a", "b", "c", none])
    let mh = ds.max_heap([3, 9, 1])
    assert_eq(mh.pop(), 9)
    let s = ds.stack([1, 2, 3])
    assert_eq((s.pop(), s.peek(), len(s)), (3, 2, 2))
    let q = ds.queue()
    q.push(1, 2)
    assert_eq((q.pop(), q.pop(), q.pop()), (1, 2, none))
    let c = ds.counter("mississippi".chars())
    assert_eq(c.get("s"), 4)
    assert_eq(c.most_common(1), [("i", 4)])
    let lru = ds.lru(2)
    lru.set("a", 1)
    lru.set("b", 2)
    lru.get("a")
    lru.set("c", 3)
    assert_eq(lru.keys(), ["a", "c"])
    let t = ds.trie(["car", "card", "dog"])
    assert_eq(t.starts_with("car"), ["car", "card"])
    assert_eq(t.has("ca"), false)
    let uf = ds.union_find(5)
    uf.union(0, 1)
    uf.union(3, 4)
    assert_eq((uf.connected(0, 1), uf.connected(1, 3), uf.groups()), (true, false, 3))
    for x in ds.stack([1, 2]) { assert(x == 1 or x == 2) }
}

test "graphs" {
    let g = graph.new()
    g.add_edge("A", "B", 1)
    g.add_edge("B", "C", 2)
    g.add_edge("A", "C", 5)
    g.add_edge("C", "D", 1)
    assert_eq(g.shortest_path("A", "D"), {distance: 4, path: ["A", "B", "C", "D"]})
    assert_eq(g.shortest_path("A", "Z"), none)
    assert_eq(g.bfs("A"), ["A", "B", "C", "D"])
    assert_eq(g.has_cycle(), true)
    assert_eq(g.is_connected(), true)
    assert_eq(g.mst().len(), 3)
    let dag = graph.directed()
    dag.add_edges([("a", "b"), ("b", "c"), ("a", "c")])
    assert_eq(dag.topo_sort(), ["a", "b", "c"])
    dag.add_edge("c", "a")
    assert_throws(|| dag.topo_sort())
    assert_eq(dag.has_cycle(), true)
}

test "iterators and functions" {
    assert_eq(iter.count(10, 5).take(3).collect(), [10, 15, 20])
    assert_eq(iter.iterate(|x| x * 2, 1).take(5).collect(), [1, 2, 4, 8, 16])
    assert_eq((1..).iter().map(|x| x * x).filter(|x| x % 2 == 1).take(3).collect(), [1, 9, 25])
    assert_eq(iter.permutations([1, 2, 3]).len(), 6)
    assert_eq(iter.combinations([1, 2, 3, 4], 2).len(), 6)
    assert_eq(iter.product([1, 2], ["a", "b"]).len(), 4)
    assert_eq(iter.run_lengths("aaabcc".chars()), [("a", 3), ("b", 1), ("c", 2)])
    assert_eq(iter.pairwise([1, 2, 3]), [(1, 2), (2, 3)])
    assert_eq(iter.accumulate([1, 2, 3, 4]), [1, 3, 6, 10])
    assert_eq(iter.powerset([1, 2]).len(), 4)
    let inc = |x| x + 1
    let dbl = |x| x * 2
    assert_eq(func.compose(inc, dbl)(5), 11)
    assert_eq(func.pipe(5, inc, dbl), 12)
    assert_eq(func.curry(|a, b, c| a + b + c)(1)(2)(3), 6)
    assert_eq(func.partial(|a, b| a - b, 10)(3), 7)
    assert_eq(func.flip(|a, b| a - b)(1, 10), 9)
    assert_eq(func.juxt(inc, dbl)(4), [5, 8])
    var calls = 0
    let slow = func.memoize(|n| { calls += 1; n * 2 })
    slow(4)
    slow(4)
    assert_eq(calls, 1)
    fn countdown(n) = if n == 0 { "done" } else { || countdown(n - 1) }
    assert_eq(func.trampoline(countdown, 50000), "done")
    let once = func.once(|| { calls += 100; calls })
    once()
    once()
    assert_eq(calls, 101)
}

test "algorithms" {
    assert_eq(algo.lis([10, 9, 2, 5, 3, 7, 101, 18]), [2, 3, 7, 18])
    assert_eq(algo.lcs("AGGTAB", "GXTXAYB"), "GTAB")
    assert_eq(algo.knapsack([1, 3, 4, 5], [1, 4, 5, 7], 7), 9)
    assert_eq(algo.coin_change([1, 5, 10, 25], 63), 6)
    assert_eq(algo.n_queens(6).len(), 4)
    assert_eq(algo.kmp_search("abababab", "abab"), [0, 2, 4])
    assert_eq(algo.bisect_left([1, 3, 3, 5], 3), 1)
    assert_eq(algo.merge_sort([5, 2, 9, 1]), [1, 2, 5, 9])
    assert_eq(algo.merge_intervals([(1, 3), (2, 6), (8, 10)]), [(1, 6), (8, 10)])
    assert_eq(algo.two_sum([2, 7, 11, 15], 9), (0, 1))
    assert_eq(algo.max_subarray([-2, 1, -3, 4, -1, 2, 1, -5, 4]).sum, 6)
    assert_eq(algo.luhn("4539 1488 0343 6467"), true)
    assert_eq(algo.hanoi(3).len(), 7)
}

test "tables" {
    let t = table.from([{name: "Ada", city: "London", age: 36}, {name: "Bob", city: "Paris", age: 25}, {name: "Cy", city: "London", age: 41}])
    assert_eq(t.len(), 3)
    assert_eq(t.cols(), ["name", "city", "age"])
    assert_eq(t.where(|r| r.age > 30).col("name"), ["Ada", "Cy"])
    assert_eq(t.sort_by("age", desc: true).col("name"), ["Cy", "Ada", "Bob"])
    assert_eq(t.mean("age"), 34)
    let g = t.group_by("city", n: ["*", "count"], total: ["age", "sum"])
    assert_eq(g.rows(), [{city: "London", n: 2, total: 77}, {city: "Paris", n: 1, total: 25}])
    assert_eq(t.add_col("senior", |r| r.age > 40).col("senior"), [false, false, true])
    assert_eq(t.select("name").cols(), ["name"])
    let other = table.from([{city: "London", country: "UK"}])
    assert_eq(t.join(other, "city").col("country"), ["UK", "UK"])
    assert_eq(t.join(other, "city", kind: "left").len(), 3)
    assert_eq(t.value_counts("city").rows()[0], {city: "London", count: 2})
    assert(t.to_csv().starts_with("name,city,age\nAda,London,36"))
    assert_eq(table.from_csv("a,b\n1,2\n3,4").sum("b"), 6)
    assert_throws(|| t.col("nope"))
}

test "plots, geometry, xml, ini" {
    assert_eq(plot.sparkline([1, 3, 2, 8]), "▁▃▂█")
    assert(plot.bar({a: 1, b: 2}).contains("█"))
    assert(plot.svg_bar({a: 1, b: 2}).starts_with("<svg"))
    assert_eq(geometry.polygon_area([(0, 0), (4, 0), (4, 3)]), 6)
    assert_eq(geometry.distance((0, 0), (3, 4)), 5)
    assert_eq(geometry.convex_hull([(0, 0), (1, 1), (2, 2), (2, 0), (0, 2)]).len(), 4)
    assert_eq(geometry.point_in_polygon((1, 1), [(0, 0), (4, 0), (4, 4), (0, 4)]), true)
    let doc = xml.parse("<root a='1'><item id='x'>Hello &amp; bye</item><item id='y'/></root>")
    assert_eq((doc.tag, xml.select(doc, "item").len()), ("root", 2))
    assert_eq(xml.attr(xml.find(doc, "item"), "id"), "x")
    assert_eq(xml.text_of(doc), "Hello & bye")
    assert_eq(xml.parse(xml.stringify(doc)).children.len(), 2)
    assert_throws(|| xml.parse("<a><b></a>"))
    assert_eq(ini.parse("[s]\nk = 1\nflag = yes\nname = \"x\""), {s: {k: 1, flag: true, name: "x"}})
}

test "complex, rational, big, bits" {
    let z = complex.new(1, 2) * complex.new(3, -1) + 1
    assert_eq("{z}", "6 + 5i")
    assert_eq(complex.new(3, 4).abs(), 5)
    assert_eq("{rational.new(1, 3) + rational.new(1, 6)}", "1/2")
    assert_eq(rational.new(1, 2) < rational.new(2, 3), true)
    assert_eq(rational.from_float(0.75).to_str(), "3/4")
    assert_eq(bigint.factorial(25), 15511210043330985984000000n)
    assert_eq(bigint.is_prime(1000000007), true)
    assert_eq(bigint.mod_pow(2, 100, 1000000007), 976371285n)
    assert_eq(7n / 2n, 3n)
    assert_eq(bits.popcount(255), 8)
    assert_eq(bits.xor(5, 3), 6)
    assert_eq(bits.shl(1, 10), 1024)
    assert_eq(bits.to_bin(5, 8), "00000101")
}

test "events and command lines" {
    let e = events.new()
    var got = []
    e.on("hi", |x| got.push(x))
    e.once("hi", |x| got.push(x * 10))
    e.emit("hi", 1)
    e.emit("hi", 2)
    assert_eq(got, [1, 10, 2])
    let spec = {name: {short: "n", type: "str", default: "world"}, count: {short: "c", type: "int", default: 1}, loud: {short: "l", type: "bool"}}
    assert_eq(cli.parse(["--name", "Ada", "-c", "3", "-l", "file.txt"], spec), {name: "Ada", count: 3, loud: true, args: ["file.txt"]})
    assert_eq(cli.parse(["--count=2", "--no-loud"], spec).count, 2)
    assert_eq(cli.parse([], spec), {name: "world", count: 1, loud: false, args: []})
    assert_throws(|| cli.parse(["--bogus"], spec))
    assert_throws(|| cli.parse(["--count", "x"], spec))
}
