// Complex numbers and imaginary numbers.
use std.math
use std.complex as cx

test "imaginary literals and arithmetic" {
    let z = 3 + 4i
    assert_eq(z.re, 3)
    assert_eq(z.im, 4)
    assert_eq(abs(z), 5)
    assert_eq(z + 1, 4 + 4i)
    assert_eq(z * 2, 6 + 8i)
    assert_eq(z * z, -7 + 24i)
    assert_eq(z - z, 0)
    assert_eq(2i * 2i, -4)
    assert_eq(1i ** 2, -1)
    assert_eq((1 + 2i) / (3 - 4i), -0.2 + 0.4i)
    assert_eq(-z, -3 - 4i)
    assert_eq(z.conj(), 3 - 4i)
    assert_eq(1 / 1i, -1i)
    assert_eq(2.5i, complex(0, 2.5))
    assert_eq("{3 + 4i}", "3 + 4i")
    assert_eq("{1i}", "i")
    assert_eq("{1 - 1i}", "1 - i")
    assert_eq(type(z), "complex")
    assert(z is complex)
    assert_eq(z == 3 + 4i, true)
    assert_eq(5 == complex(5, 0), true)
    assert_throws(|| z < 1)
    assert_throws(|| z % 2)
    assert_throws(|| 1i / 0)
}

test "functions of complex numbers" {
    assert_eq(sqrt(-4), 2i)
    assert_eq(sqrt(-1) ** 2 == -1, true)
    assert_eq(math.sqrt(-9), 3i)
    assert(abs(math.exp(1i * math.PI) + 1) < 1e-12)
    assert_eq((3 + 4i).sqrt().round(9), 2 + 1i)
    assert(abs(math.ln(-1) - math.PI * 1i) < 1e-12)
    assert(abs(math.sin(1 + 1i) - (1.2984575814159773 + 0.6349639147847361i)) < 1e-12)
    assert_eq((1 + 1i).polar().map(|x| x.round(6)), (1.414214, 0.785398))
    assert_eq((1 + 1i) ** 8, 16)
    assert_eq((1i).pow(2), -1)
    assert_eq(complex("1+2i"), 1 + 2i)
    assert_eq(complex("-3.5i"), -3.5i)
    assert_eq((1.234567 + 2.345678i).round(2), 1.23 + 2.35i)
    assert_eq("{1.5 + 2.25i:.1f}", "1.5 + 2.3i")
}

test "roots, polynomials and the Fourier transform" {
    let roots = cx.roots_of_unity(4).map(|r| r.round(9))
    assert_eq(roots, [1, 1i, -1, -1i])
    assert_eq(cx.quadratic(1, 2, 5), [-1 - 2i, -1 + 2i])
    assert_eq(cx.quadratic(1, -3, 2), [1, 2])
    let pr = cx.polyroots([1, 0, 1]).map(|r| r.round(9))
    assert_eq(pr.len(), 2)
    assert(pr.contains(1i) and pr.contains(-1i))
    let f = cx.fft([1, 2, 3, 4]).map(|c| c.round(9))
    assert_eq(f, [10, -2 + 2i, -2, -2 - 2i])
    assert_eq(cx.ifft(cx.fft([1, 2, 3, 4, 5])).map(|c| c.round(9)), [1, 2, 3, 4, 5])
    assert_eq(cx.mandelbrot(0), 100)
    assert_eq(cx.mandelbrot(1 + 1i) < 5, true)
}
