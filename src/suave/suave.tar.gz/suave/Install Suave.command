#!/bin/sh
# Double-click this file in Finder to install Suave (Terminal opens and shows what happens).
cd "$(dirname "$0")"
chmod +x install.sh 2>/dev/null
./install.sh
echo
echo "You can close this window now."
